package com.meituan.sdk.model.foodmop.sku.updateComboPriceRule;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-523aecbc-3ac8-4dec-ab94-10f2b0296f78"><span style="color: rgb(102, 102, 102)">价格信息 基础价格和加价规则 如果需要更新必须同时传（如果只有固定分组可以不传加价规则） 基础价格和加价规则、分摊规则不能都为空 新建套餐时，都需要传</span></p>
* This file was automatically generated.
*/
public class ComboPriceModule {
    /**
    * <p data-diff-id="ct-diff-id-7938da98-7f74-42a7-9661-5b730e87f815"><span style="color: rgb(102, 102, 102)">基础价格</span></p>
    */
    @NotNull(message = "basicPrice不能为空")
    @SerializedName("basicPrice")
    private Long basicPrice;
    /**
    * <p data-diff-id="ct-diff-id-18fd0635-098a-454e-a6ae-d8be01cb08c0"><span style="color: rgb(102, 102, 102)">加价规则</span></p>
    */
    @NotNull(message = "addPriceRule不能为空")
    @SerializedName("addPriceRule")
    private AddPriceRule addPriceRule;
    /**
    * <p data-diff-id="ct-diff-id-456e446d-fdb8-43c8-b950-d026997f2e96"><span style="color: rgb(102, 102, 102)">分摊规则</span></p>
    */
    @NotNull(message = "sharePriceRule不能为空")
    @SerializedName("sharePriceRule")
    private SharePriceRule sharePriceRule;

    public Long getBasicPrice() {
        return basicPrice;
    }
    public void setBasicPrice(Long basicPrice) {
        this.basicPrice = basicPrice;
    }
    public AddPriceRule getAddPriceRule() {
        return addPriceRule;
    }
    public void setAddPriceRule(AddPriceRule addPriceRule) {
        this.addPriceRule = addPriceRule;
    }
    public SharePriceRule getSharePriceRule() {
        return sharePriceRule;
    }
    public void setSharePriceRule(SharePriceRule sharePriceRule) {
        this.sharePriceRule = sharePriceRule;
    }




    @Override
    public String toString() {
        return "ComboPriceModule{" + "basicPrice=" + basicPrice + "," + "addPriceRule=" + addPriceRule + "," + "sharePriceRule=" + sharePriceRule + "}";
    }
}
