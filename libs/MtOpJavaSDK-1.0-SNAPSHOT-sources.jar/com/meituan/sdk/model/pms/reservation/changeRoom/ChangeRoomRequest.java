package com.meituan.sdk.model.pms.reservation.changeRoom;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 换房
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/reservation/changeRoom",
    businessId = 57,
    apiVersion = "10030",
    apiName = "change_room",
    needAuth = true
)
public class ChangeRoomRequest implements MeituanRequest<ChangeRoomResponse> {
    /**
    * <p data-diff-id="ct-diff-id-35c91f78-b4ff-4cf6-98e4-7c86a9cb0a2e">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-1a8da5ec-729e-4ced-8372-7544d8d0a96b">接待单ID</p>
    */
    @NotNull(message = "checkinId不能为空")
    @SerializedName("checkinId")
    private Long checkinId;
    /**
    * <p data-diff-id="ct-diff-id-4b914a98-37fe-46a5-8acd-3610b6f14097">目前房间的房型编号</p>
    */
    @NotBlank(message = "destRoomTypeId不能为空")
    @SerializedName("destRoomTypeId")
    private String destRoomTypeId;
    /**
    * <p data-diff-id="ct-diff-id-186e8639-d62c-4c35-87bf-fc85d8cd0ad0">目标房间号</p>
    */
    @NotBlank(message = "destRoomNumber不能为空")
    @SerializedName("destRoomNumber")
    private String destRoomNumber;
    /**
    * <p data-diff-id="ct-diff-id-68ddb216-7b1c-4fb3-b02e-afc62074a0ff">是否免费换房</p>
    */
    @NotNull(message = "free不能为空")
    @SerializedName("free")
    private Boolean free;
    /**
    * <p data-diff-id="ct-diff-id-34c0fff0-5073-4899-a51a-9f5b9dced7a2">换房原因</p>
    */
    @NotBlank(message = "reason不能为空")
    @SerializedName("reason")
    private String reason;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public Long getCheckinId() {
        return checkinId;
    }
    public void setCheckinId(Long checkinId) {
        this.checkinId = checkinId;
    }
    public String getDestRoomTypeId() {
        return destRoomTypeId;
    }
    public void setDestRoomTypeId(String destRoomTypeId) {
        this.destRoomTypeId = destRoomTypeId;
    }
    public String getDestRoomNumber() {
        return destRoomNumber;
    }
    public void setDestRoomNumber(String destRoomNumber) {
        this.destRoomNumber = destRoomNumber;
    }
    public Boolean getFree() {
        return free;
    }
    public void setFree(Boolean free) {
        this.free = free;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }


    @Override
    public MeituanResponse<ChangeRoomResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ChangeRoomResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ChangeRoomRequest{" + "hotelId=" + hotelId + "," + "checkinId=" + checkinId + "," + "destRoomTypeId=" + destRoomTypeId + "," + "destRoomNumber=" + destRoomNumber + "," + "free=" + free + "," + "reason=" + reason + "}";
    }
}
