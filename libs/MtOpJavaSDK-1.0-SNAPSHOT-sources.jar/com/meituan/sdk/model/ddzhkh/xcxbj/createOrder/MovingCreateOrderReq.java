package com.meituan.sdk.model.ddzhkh.xcxbj.createOrder;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.NotEmpty;

/**
* 
* This file was automatically generated.
*/
public class MovingCreateOrderReq {
    @NotNull(message = "vendorInfoReq不能为空")
    @SerializedName("vendorInfoReq")
    private VendorInfoReq vendorInfoReq;
    /**
    * <p data-diff-id="ct-diff-id-778b4f29-2502-4b7c-bf62-4e6003f19221">订单超时时间，时间戳，毫秒值</p>
    */
    @NotNull(message = "expireTime不能为空")
    @SerializedName("expireTime")
    private Long expireTime;
    /**
    * <p data-diff-id="ct-diff-id-98b973f4-ee6c-444c-a2c1-767549124d9a">用户实际支付金额，单位分</p>
    */
    @NotNull(message = "payAmount不能为空")
    @SerializedName("payAmount")
    private Long payAmount;
    /**
    * <p data-diff-id="ct-diff-id-1a7ba406-224e-413a-a857-30c9219cb308">用户ip</p>
    */
    @NotBlank(message = "ip不能为空")
    @SerializedName("ip")
    private String ip;
    @NotEmpty(message = "productReqList不能为空")
    @SerializedName("productReqList")
    private List<BaseProductReq> productReqList;

    public VendorInfoReq getVendorInfoReq() {
        return vendorInfoReq;
    }
    public void setVendorInfoReq(VendorInfoReq vendorInfoReq) {
        this.vendorInfoReq = vendorInfoReq;
    }
    public Long getExpireTime() {
        return expireTime;
    }
    public void setExpireTime(Long expireTime) {
        this.expireTime = expireTime;
    }
    public Long getPayAmount() {
        return payAmount;
    }
    public void setPayAmount(Long payAmount) {
        this.payAmount = payAmount;
    }
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }
    public List<BaseProductReq> getProductReqList() {
        return productReqList;
    }
    public void setProductReqList(List<BaseProductReq> productReqList) {
        this.productReqList = productReqList;
    }




    @Override
    public String toString() {
        return "MovingCreateOrderReq{" + "vendorInfoReq=" + vendorInfoReq + "," + "expireTime=" + expireTime + "," + "payAmount=" + payAmount + "," + "ip=" + ip + "," + "productReqList=" + productReqList + "}";
    }
}
