package com.meituan.sdk.model.ddzh.yuding.createandprepayorder;

import com.google.gson.annotations.SerializedName;

/**
* 降级信息
* This file was automatically generated.
*/
public class DegradeInfo {
    @SerializedName("key")
    private String key;
    @SerializedName("value")
    private String value;

    public String getKey() {
        return key;
    }
    public void setKey(String key) {
        this.key = key;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }




    @Override
    public String toString() {
        return "DegradeInfo{" + "key=" + key + "," + "value=" + value + "}";
    }
}
