package com.meituan.sdk.model.ddzhkh.shangpin.productRelationshipSave;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-78450fc6-ad7a-4a62-8fff-3819ce192e82">关联关系信息</p>
* This file was automatically generated.
*/
public class BatchSaveRelationShipDTO {
    /**
    * <p data-diff-id="ct-diff-id-54540e68-9374-475a-a05e-73ab08415c99"><span style="color: ">操作类型(1:新建 2：编辑 3：上线 4：下线 5：删除 6：覆盖 ，注：创建和编辑场景都传6)</span></p>
    */
    @NotBlank(message = "operateType不能为空")
    @SerializedName("operateType")
    private String operateType;
    /**
    * <p data-diff-id="ct-diff-id-211195e6-0067-48ce-9165-da78c27c2524">关联关系集合</p>
    */
    @NotEmpty(message = "combinationRelationSubjects不能为空")
    @SerializedName("combinationRelationSubjects")
    private List<CombinationRelationSubjectDTO> combinationRelationSubjects;

    public String getOperateType() {
        return operateType;
    }
    public void setOperateType(String operateType) {
        this.operateType = operateType;
    }
    public List<CombinationRelationSubjectDTO> getCombinationRelationSubjects() {
        return combinationRelationSubjects;
    }
    public void setCombinationRelationSubjects(List<CombinationRelationSubjectDTO> combinationRelationSubjects) {
        this.combinationRelationSubjects = combinationRelationSubjects;
    }




    @Override
    public String toString() {
        return "BatchSaveRelationShipDTO{" + "operateType=" + operateType + "," + "combinationRelationSubjects=" + combinationRelationSubjects + "}";
    }
}
