package com.meituan.sdk.model.enterprise.bill.entInvoiceAblilityRegister;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class PoiSingleResultSub {
    /**
    * 加密poiId
    */
    @SerializedName("encryptPoiId")
    private String encryptPoiId;
    /**
    * 0:到餐 1:外卖
    */
    @SerializedName("bizType")
    private Long bizType;
    /**
    * 0:成功 1:失败
    */
    @SerializedName("result")
    private Long result;
    /**
    * 失败原因
    */
    @SerializedName("message")
    private String message;

    public String getEncryptPoiId() {
        return encryptPoiId;
    }
    public void setEncryptPoiId(String encryptPoiId) {
        this.encryptPoiId = encryptPoiId;
    }
    public Long getBizType() {
        return bizType;
    }
    public void setBizType(Long bizType) {
        this.bizType = bizType;
    }
    public Long getResult() {
        return result;
    }
    public void setResult(Long result) {
        this.result = result;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }




    @Override
    public String toString() {
        return "PoiSingleResultSub{" + "encryptPoiId=" + encryptPoiId + "," + "bizType=" + bizType + "," + "result=" + result + "," + "message=" + message + "}";
    }
}
