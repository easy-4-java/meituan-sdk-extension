package com.meituan.sdk.model.pms.data.queryJy08;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class TJYDimensionDTO {
    /**
    * 组织ID
    */
    @SerializedName("orgId")
    private Long orgId;
    /**
    * 营业日期
    */
    @SerializedName("businessDate")
    private String businessDate;
    /**
    * 营业日期周
    */
    @SerializedName("businessDateWeek")
    private String businessDateWeek;
    /**
    * 周
    */
    @SerializedName("week")
    private String week;
    /**
    * 周开始日期
    */
    @SerializedName("weekStartDate")
    private String weekStartDate;
    /**
    * 周结束日期
    */
    @SerializedName("weekEndDate")
    private String weekEndDate;
    /**
    * 营业日期月
    */
    @SerializedName("businessDateMonth")
    private String businessDateMonth;
    /**
    * 分析维度键
    */
    @SerializedName("analysisDimensionKey")
    private String analysisDimensionKey;
    /**
    * 分析维度名称
    */
    @SerializedName("analysisDimensionName")
    private String analysisDimensionName;
    /**
    * 分析维度主题名称
    */
    @SerializedName("analysisDimensionSubjectName")
    private String analysisDimensionSubjectName;
    /**
    * 分析维度主题值
    */
    @SerializedName("analysisDimensionSubjectValue")
    private String analysisDimensionSubjectValue;

    public Long getOrgId() {
        return orgId;
    }
    public void setOrgId(Long orgId) {
        this.orgId = orgId;
    }
    public String getBusinessDate() {
        return businessDate;
    }
    public void setBusinessDate(String businessDate) {
        this.businessDate = businessDate;
    }
    public String getBusinessDateWeek() {
        return businessDateWeek;
    }
    public void setBusinessDateWeek(String businessDateWeek) {
        this.businessDateWeek = businessDateWeek;
    }
    public String getWeek() {
        return week;
    }
    public void setWeek(String week) {
        this.week = week;
    }
    public String getWeekStartDate() {
        return weekStartDate;
    }
    public void setWeekStartDate(String weekStartDate) {
        this.weekStartDate = weekStartDate;
    }
    public String getWeekEndDate() {
        return weekEndDate;
    }
    public void setWeekEndDate(String weekEndDate) {
        this.weekEndDate = weekEndDate;
    }
    public String getBusinessDateMonth() {
        return businessDateMonth;
    }
    public void setBusinessDateMonth(String businessDateMonth) {
        this.businessDateMonth = businessDateMonth;
    }
    public String getAnalysisDimensionKey() {
        return analysisDimensionKey;
    }
    public void setAnalysisDimensionKey(String analysisDimensionKey) {
        this.analysisDimensionKey = analysisDimensionKey;
    }
    public String getAnalysisDimensionName() {
        return analysisDimensionName;
    }
    public void setAnalysisDimensionName(String analysisDimensionName) {
        this.analysisDimensionName = analysisDimensionName;
    }
    public String getAnalysisDimensionSubjectName() {
        return analysisDimensionSubjectName;
    }
    public void setAnalysisDimensionSubjectName(String analysisDimensionSubjectName) {
        this.analysisDimensionSubjectName = analysisDimensionSubjectName;
    }
    public String getAnalysisDimensionSubjectValue() {
        return analysisDimensionSubjectValue;
    }
    public void setAnalysisDimensionSubjectValue(String analysisDimensionSubjectValue) {
        this.analysisDimensionSubjectValue = analysisDimensionSubjectValue;
    }




    @Override
    public String toString() {
        return "TJYDimensionDTO{" + "orgId=" + orgId + "," + "businessDate=" + businessDate + "," + "businessDateWeek=" + businessDateWeek + "," + "week=" + week + "," + "weekStartDate=" + weekStartDate + "," + "weekEndDate=" + weekEndDate + "," + "businessDateMonth=" + businessDateMonth + "," + "analysisDimensionKey=" + analysisDimensionKey + "," + "analysisDimensionName=" + analysisDimensionName + "," + "analysisDimensionSubjectName=" + analysisDimensionSubjectName + "," + "analysisDimensionSubjectValue=" + analysisDimensionSubjectValue + "}";
    }
}
