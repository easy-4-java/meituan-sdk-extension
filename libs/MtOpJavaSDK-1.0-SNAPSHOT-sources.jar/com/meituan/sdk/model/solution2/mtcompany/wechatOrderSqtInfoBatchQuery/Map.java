package com.meituan.sdk.model.solution2.mtcompany.wechatOrderSqtInfoBatchQuery;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class Map {
    /**
    * 此字段为Map的key，值是string类型的orderId
    */
    @SerializedName("key")
    private String key;
    /**
    * 此字段为Map的value，值是object类型的订单信息
    */
    @SerializedName("value")
    private InvoiceWechatTagInfoBO value;

    public String getKey() {
        return key;
    }
    public void setKey(String key) {
        this.key = key;
    }
    public InvoiceWechatTagInfoBO getValue() {
        return value;
    }
    public void setValue(InvoiceWechatTagInfoBO value) {
        this.value = value;
    }




    @Override
    public String toString() {
        return "Map{" + "key=" + key + "," + "value=" + value + "}";
    }
}
