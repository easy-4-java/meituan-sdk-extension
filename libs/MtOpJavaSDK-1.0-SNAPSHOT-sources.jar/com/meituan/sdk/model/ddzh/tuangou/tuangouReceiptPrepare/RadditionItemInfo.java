package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptPrepare;

import com.google.gson.annotations.SerializedName;

/**
* 体检加项信息
* This file was automatically generated.
*/
public class RadditionItemInfo {
    /**
    * 服务名称
    */
    @SerializedName("serviceTitle")
    private String serviceTitle;
    /**
    * 加项价格
    */
    @SerializedName("adjustedAmount")
    private String adjustedAmount;
    /**
    * 商品ID
    */
    @SerializedName("productId")
    private String productId;
    /**
    * 三方加项ID
    */
    @SerializedName("addItemThirdPartyId")
    private String addItemThirdPartyId;

    public String getServiceTitle() {
        return serviceTitle;
    }
    public void setServiceTitle(String serviceTitle) {
        this.serviceTitle = serviceTitle;
    }
    public String getAdjustedAmount() {
        return adjustedAmount;
    }
    public void setAdjustedAmount(String adjustedAmount) {
        this.adjustedAmount = adjustedAmount;
    }
    public String getProductId() {
        return productId;
    }
    public void setProductId(String productId) {
        this.productId = productId;
    }
    public String getAddItemThirdPartyId() {
        return addItemThirdPartyId;
    }
    public void setAddItemThirdPartyId(String addItemThirdPartyId) {
        this.addItemThirdPartyId = addItemThirdPartyId;
    }




    @Override
    public String toString() {
        return "RadditionItemInfo{" + "serviceTitle=" + serviceTitle + "," + "adjustedAmount=" + adjustedAmount + "," + "productId=" + productId + "," + "addItemThirdPartyId=" + addItemThirdPartyId + "}";
    }
}
