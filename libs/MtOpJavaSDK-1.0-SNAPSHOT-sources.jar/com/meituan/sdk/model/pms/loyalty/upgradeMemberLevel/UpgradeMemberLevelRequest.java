package com.meituan.sdk.model.pms.loyalty.upgradeMemberLevel;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 会员升级
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/loyalty/upgradeMemberLevel",
    businessId = 57,
    apiVersion = "10017",
    apiName = "upgrade_member_level",
    needAuth = true
)
public class UpgradeMemberLevelRequest implements MeituanRequest<Boolean> {
    /**
    * <p data-diff-id="ct-diff-id-71535f08-5193-46f3-8818-a7e19c8d226d"><span style="color: rgba(0, 0, 0, 0.65)">会员ID</span></p>
    */
    @NotBlank(message = "memberId不能为空")
    @SerializedName("memberId")
    private String memberId;
    /**
    * <p data-diff-id="ct-diff-id-1b50922f-cb78-446b-81a9-ac072fbdb8ba">目标会员级别ID</p>
    */
    @NotNull(message = "targetMemberLevelId不能为空")
    @SerializedName("targetMemberLevelId")
    private Long targetMemberLevelId;
    /**
    * <p data-diff-id="ct-diff-id-dff5d0b7-d992-4cda-8fa2-96fc1495fd04"><span style="color: rgb(51, 51, 51)">支付方式，免费:FREE,积分:POINT,付费:PAY，当前只支持免费</span></p>
    */
    @NotBlank(message = "payType不能为空")
    @SerializedName("payType")
    private String payType;
    /**
    * <p data-diff-id="ct-diff-id-cea83ac4-14c6-42de-8363-3eb7b0fe50f8">支付金额，积分支付时代表积分金额，付费时代表付费金额<strong>单位为分</strong></p>
    */
    @SerializedName("amount")
    private Integer amount;
    /**
    * <p data-diff-id="ct-diff-id-5caaa33a-a7b0-42c6-ad42-b7d364cc2005">备注</p>
    */
    @SerializedName("remark")
    private String remark;

    public String getMemberId() {
        return memberId;
    }
    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
    public Long getTargetMemberLevelId() {
        return targetMemberLevelId;
    }
    public void setTargetMemberLevelId(Long targetMemberLevelId) {
        this.targetMemberLevelId = targetMemberLevelId;
    }
    public String getPayType() {
        return payType;
    }
    public void setPayType(String payType) {
        this.payType = payType;
    }
    public Integer getAmount() {
        return amount;
    }
    public void setAmount(Integer amount) {
        this.amount = amount;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }


    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "UpgradeMemberLevelRequest{" + "memberId=" + memberId + "," + "targetMemberLevelId=" + targetMemberLevelId + "," + "payType=" + payType + "," + "amount=" + amount + "," + "remark=" + remark + "}";
    }
}
