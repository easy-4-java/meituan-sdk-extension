package com.meituan.sdk.model.pms.reservation.querySingleOrder;

import com.google.gson.annotations.SerializedName;

/**
* 客源类别，详见CustomerCategory字典
* This file was automatically generated.
*/
public class EnumDTO {
    /**
    * 编码
    */
    @SerializedName("enName")
    private String enName;
    /**
    * 描述
    */
    @SerializedName("cnName")
    private String cnName;

    public String getEnName() {
        return enName;
    }
    public void setEnName(String enName) {
        this.enName = enName;
    }
    public String getCnName() {
        return cnName;
    }
    public void setCnName(String cnName) {
        this.cnName = cnName;
    }




    @Override
    public String toString() {
        return "EnumDTO{" + "enName=" + enName + "," + "cnName=" + cnName + "}";
    }
}
