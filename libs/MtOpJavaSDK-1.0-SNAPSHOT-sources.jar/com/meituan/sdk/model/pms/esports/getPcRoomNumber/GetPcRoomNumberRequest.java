package com.meituan.sdk.model.pms.esports.getPcRoomNumber;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取电竞设备所在的房间号
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/esports/getPcRoomNumber",
    businessId = 57,
    apiVersion = "10028",
    apiName = "get_pc_room_number",
    needAuth = true
)
public class GetPcRoomNumberRequest implements MeituanRequest<GetPcRoomNumberResponse> {
    /**
    * <p data-diff-id="ct-diff-id-1aeec7e0-5544-40d1-badb-dfe0c96497c2">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-e7b49a3c-e23f-4769-b9aa-a2b3d359d174">序列号</p>
    */
    @NotBlank(message = "serialNumber不能为空")
    @SerializedName("serialNumber")
    private String serialNumber;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getSerialNumber() {
        return serialNumber;
    }
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }


    @Override
    public MeituanResponse<GetPcRoomNumberResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<GetPcRoomNumberResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GetPcRoomNumberRequest{" + "hotelId=" + hotelId + "," + "serialNumber=" + serialNumber + "}";
    }
}
