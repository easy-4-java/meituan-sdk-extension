package com.meituan.sdk.model.waimaiNg.dish.toppingBatchInit;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 新建/更新小料接口
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/dish/topping/batchInit",
    businessId = 2,
    apiVersion = "10113",
    apiName = "topping_batch_init",
    needAuth = true
)
public class ToppingBatchInitRequest implements MeituanRequest<String> {
    /**
    * <p data-diff-id="ct-diff-id-0aa859f2-05d7-41f5-a52e-cd74d357cd73">新建/更新小料列表，存在即更新，不存在的话新建。一次最多100个，可能部分成功部分失败。</p>
    */
    @NotEmpty(message = "toppings不能为空")
    @SerializedName("toppings")
    private List<Topping> toppings;

    public List<Topping> getToppings() {
        return toppings;
    }
    public void setToppings(List<Topping> toppings) {
        this.toppings = toppings;
    }


    @Override
    public MeituanResponse<String> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<String>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ToppingBatchInitRequest{" + "toppings=" + toppings + "}";
    }
}
