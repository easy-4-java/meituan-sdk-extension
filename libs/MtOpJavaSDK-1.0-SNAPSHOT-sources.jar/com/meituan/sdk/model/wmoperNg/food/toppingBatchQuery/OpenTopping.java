package com.meituan.sdk.model.wmoperNg.food.toppingBatchQuery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class OpenTopping {
    /**
    * 小料名称
    */
    @SerializedName("name")
    private String name;
    /**
    * 小料偏移id
    */
    @SerializedName("mtToppingId")
    private Long mtToppingId;
    /**
    * 小料code
    */
    @SerializedName("toppingCode")
    private String toppingCode;
    /**
    * 价格
    */
    @SerializedName("price")
    private String price;
    /**
    * 最大库存，若stock为-1，则该字段自动置为-1
    */
    @SerializedName("maxStock")
    private Integer maxStock;
    /**
    * 当前库存，-1代表无限库存
    */
    @SerializedName("stock")
    private Integer stock;
    /**
    * 是否自动补足  该字段只能填写0， 1；  默认0  0- 不开启  1- 开启自动补足  若stock为-1则该字段自动置为0
    */
    @SerializedName("autoRefresh")
    private Integer autoRefresh;
    /**
    * 关联商品
    */
    @SerializedName("spuToppingRel")
    private List<OpenSpuToppingRel> spuToppingRel;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Long getMtToppingId() {
        return mtToppingId;
    }
    public void setMtToppingId(Long mtToppingId) {
        this.mtToppingId = mtToppingId;
    }
    public String getToppingCode() {
        return toppingCode;
    }
    public void setToppingCode(String toppingCode) {
        this.toppingCode = toppingCode;
    }
    public String getPrice() {
        return price;
    }
    public void setPrice(String price) {
        this.price = price;
    }
    public Integer getMaxStock() {
        return maxStock;
    }
    public void setMaxStock(Integer maxStock) {
        this.maxStock = maxStock;
    }
    public Integer getStock() {
        return stock;
    }
    public void setStock(Integer stock) {
        this.stock = stock;
    }
    public Integer getAutoRefresh() {
        return autoRefresh;
    }
    public void setAutoRefresh(Integer autoRefresh) {
        this.autoRefresh = autoRefresh;
    }
    public List<OpenSpuToppingRel> getSpuToppingRel() {
        return spuToppingRel;
    }
    public void setSpuToppingRel(List<OpenSpuToppingRel> spuToppingRel) {
        this.spuToppingRel = spuToppingRel;
    }




    @Override
    public String toString() {
        return "OpenTopping{" + "name=" + name + "," + "mtToppingId=" + mtToppingId + "," + "toppingCode=" + toppingCode + "," + "price=" + price + "," + "maxStock=" + maxStock + "," + "stock=" + stock + "," + "autoRefresh=" + autoRefresh + "," + "spuToppingRel=" + spuToppingRel + "}";
    }
}
