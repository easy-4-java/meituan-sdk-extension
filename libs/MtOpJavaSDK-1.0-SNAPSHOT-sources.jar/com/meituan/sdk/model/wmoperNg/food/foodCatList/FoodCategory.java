package com.meituan.sdk.model.wmoperNg.food.foodCatList;

import com.google.gson.annotations.SerializedName;

/**
* 分组数据
* This file was automatically generated.
*/
public class FoodCategory {
    /**
    * APP方门店ID
    */
    @SerializedName("epoiId")
    private String epoiId;
    /**
    * 分组描述
    */
    @SerializedName("category_description")
    private String categoryDescription;
    /**
    * 分组信息，0-普通分类；1-必选分类；2-可单独结算分类
    */
    @SerializedName("category_mode")
    private Integer categoryMode;
    /**
    * 创建时间
    */
    @SerializedName("ctime")
    private Long ctime;
    /**
    * 分类名称
    */
    @SerializedName("name")
    private String name;
    /**
    * 排序
    */
    @SerializedName("sequence")
    private Integer sequence;
    /**
    * 置顶时间，格式：{"1":[{"end":"86340","start":"0"}],"2":[{"end":"86340","start":"0"}],"3":[{"end":"86340","start":"0"}],"4":[{"end":"86340","start":"0"}],"5":[{"end":"86340","start":"0"}],"6":[{"end":"86340","start":"0"}],"7":[{"end":"86340","start":"0"}]}// 设置分组置顶时段。每个分组可从每周的周一至周日中选择时间，每天最多支持5个时段，时段之间不能有重合，时间跨度不能超过24h。
    */
    @SerializedName("time_zone")
    private String timeZone;
    /**
    * 置顶开关，0 关闭； 1 开启
    */
    @SerializedName("top_flag")
    private Integer topFlag;
    /**
    * 更新时间
    */
    @SerializedName("utime")
    private Long utime;

    public String getEpoiId() {
        return epoiId;
    }
    public void setEpoiId(String epoiId) {
        this.epoiId = epoiId;
    }
    public String getCategoryDescription() {
        return categoryDescription;
    }
    public void setCategoryDescription(String categoryDescription) {
        this.categoryDescription = categoryDescription;
    }
    public Integer getCategoryMode() {
        return categoryMode;
    }
    public void setCategoryMode(Integer categoryMode) {
        this.categoryMode = categoryMode;
    }
    public Long getCtime() {
        return ctime;
    }
    public void setCtime(Long ctime) {
        this.ctime = ctime;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getSequence() {
        return sequence;
    }
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    public String getTimeZone() {
        return timeZone;
    }
    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }
    public Integer getTopFlag() {
        return topFlag;
    }
    public void setTopFlag(Integer topFlag) {
        this.topFlag = topFlag;
    }
    public Long getUtime() {
        return utime;
    }
    public void setUtime(Long utime) {
        this.utime = utime;
    }




    @Override
    public String toString() {
        return "FoodCategory{" + "epoiId=" + epoiId + "," + "categoryDescription=" + categoryDescription + "," + "categoryMode=" + categoryMode + "," + "ctime=" + ctime + "," + "name=" + name + "," + "sequence=" + sequence + "," + "timeZone=" + timeZone + "," + "topFlag=" + topFlag + "," + "utime=" + utime + "}";
    }
}
