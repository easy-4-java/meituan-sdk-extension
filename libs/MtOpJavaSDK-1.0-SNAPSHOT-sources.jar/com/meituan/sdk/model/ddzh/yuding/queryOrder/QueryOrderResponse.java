package com.meituan.sdk.model.ddzh.yuding.queryOrder;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 查询订单信息
* This file was automatically generated.
*/
public class QueryOrderResponse {
    /**
    * 订单ID（商品）
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * 订单金额（已支付金额，包含商品以及其他费用）
    */
    @SerializedName("amount")
    private String amount;
    /**
    * 商品券码信息
    */
    @SerializedName("receipts")
    private List<ThirdPartReceiptDTO> receipts;
    /**
    * 其他费用信息
    */
    @SerializedName("extraPayments")
    private List<ExtraPaymentDTO> extraPayments;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public List<ThirdPartReceiptDTO> getReceipts() {
        return receipts;
    }
    public void setReceipts(List<ThirdPartReceiptDTO> receipts) {
        this.receipts = receipts;
    }
    public List<ExtraPaymentDTO> getExtraPayments() {
        return extraPayments;
    }
    public void setExtraPayments(List<ExtraPaymentDTO> extraPayments) {
        this.extraPayments = extraPayments;
    }




    @Override
    public String toString() {
        return "QueryOrderResponse{" + "orderId=" + orderId + "," + "amount=" + amount + "," + "receipts=" + receipts + "," + "extraPayments=" + extraPayments + "}";
    }
}
