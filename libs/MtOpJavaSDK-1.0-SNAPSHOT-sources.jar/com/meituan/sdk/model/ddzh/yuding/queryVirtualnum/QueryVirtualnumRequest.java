package com.meituan.sdk.model.ddzh.yuding.queryVirtualnum;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取手机虚拟号
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/query/virtualnum",
    businessId = 58,
    apiVersion = "10068",
    apiName = "query_virtualnum",
    needAuth = true
)
public class QueryVirtualnumRequest implements MeituanRequest<QueryVirtualnumResponse> {
    /**
    * <p data-diff-id="ct-diff-id-8373ada9-a9f0-44ce-b11a-85410243b906"><span style="color: #333">预约单id/统一订单号</span></p>
    */
    @NotNull(message = "orderId不能为空")
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-6830d777-9f24-4f25-9b84-e3f3c0096722"><span style="color: rgb(51, 51, 51)">类型：1-预订，2-团购后预约</span></p>
    */
    @NotNull(message = "type不能为空")
    @SerializedName("type")
    private Integer type;
    /**
    * <p data-diff-id="ct-diff-id-7be9525e-e676-4117-92c1-eb40862ac02a"><span style="color: rgb(6, 125, 23)">服务人员电话</span></p>
    */
    @NotBlank(message = "contactNumber不能为空")
    @SerializedName("contactNumber")
    private String contactNumber;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public String getContactNumber() {
        return contactNumber;
    }
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }


    @Override
    public MeituanResponse<QueryVirtualnumResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<QueryVirtualnumResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "QueryVirtualnumRequest{" + "orderId=" + orderId + "," + "type=" + type + "," + "contactNumber=" + contactNumber + "}";
    }
}
