package com.meituan.sdk.model.ddzh.yuding.queryUploadlink;

import com.google.gson.annotations.SerializedName;

/**
* 获取授权上传链接
* This file was automatically generated.
*/
public class QueryUploadlinkResponse {
    /**
    * 凭证授权链接
    */
    @SerializedName("preSignedUrl")
    private String preSignedUrl;
    /**
    * 凭证名
    */
    @SerializedName("fileName")
    private String fileName;

    public String getPreSignedUrl() {
        return preSignedUrl;
    }
    public void setPreSignedUrl(String preSignedUrl) {
        this.preSignedUrl = preSignedUrl;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }




    @Override
    public String toString() {
        return "QueryUploadlinkResponse{" + "preSignedUrl=" + preSignedUrl + "," + "fileName=" + fileName + "}";
    }
}
