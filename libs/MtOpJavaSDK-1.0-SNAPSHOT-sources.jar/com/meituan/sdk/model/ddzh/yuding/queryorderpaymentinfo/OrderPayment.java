package com.meituan.sdk.model.ddzh.yuding.queryorderpaymentinfo;

import com.google.gson.annotations.SerializedName;

/**
* 支付单信息
* This file was automatically generated.
*/
public class OrderPayment {
    /**
    * 支付单总金额
    */
    @SerializedName("totalAmount")
    private String totalAmount;
    /**
    * 支付批次
    */
    @SerializedName("payBatchNo")
    private Integer payBatchNo;
    /**
    * 支付成功时间（取不到则返回null）
    */
    @SerializedName("successTime")
    private Long successTime;
    /**
    * 预支付时，三方传递的自定义支付参数，查询时回传
    */
    @SerializedName("thirdPartyPaymentInfo")
    private String thirdPartyPaymentInfo;
    /**
    * 支付单状态，1-待支付，2-已取消，3-支付成功，4支付失败
    */
    @SerializedName("status")
    private Integer status;

    public String getTotalAmount() {
        return totalAmount;
    }
    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }
    public Integer getPayBatchNo() {
        return payBatchNo;
    }
    public void setPayBatchNo(Integer payBatchNo) {
        this.payBatchNo = payBatchNo;
    }
    public Long getSuccessTime() {
        return successTime;
    }
    public void setSuccessTime(Long successTime) {
        this.successTime = successTime;
    }
    public String getThirdPartyPaymentInfo() {
        return thirdPartyPaymentInfo;
    }
    public void setThirdPartyPaymentInfo(String thirdPartyPaymentInfo) {
        this.thirdPartyPaymentInfo = thirdPartyPaymentInfo;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }




    @Override
    public String toString() {
        return "OrderPayment{" + "totalAmount=" + totalAmount + "," + "payBatchNo=" + payBatchNo + "," + "successTime=" + successTime + "," + "thirdPartyPaymentInfo=" + thirdPartyPaymentInfo + "," + "status=" + status + "}";
    }
}
