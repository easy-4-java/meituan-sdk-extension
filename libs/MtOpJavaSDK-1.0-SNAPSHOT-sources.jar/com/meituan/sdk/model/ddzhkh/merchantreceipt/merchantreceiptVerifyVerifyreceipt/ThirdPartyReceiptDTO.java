package com.meituan.sdk.model.ddzhkh.merchantreceipt.merchantreceiptVerifyVerifyreceipt;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class ThirdPartyReceiptDTO {
    /**
    * 三方券ID
    */
    @SerializedName("receiptId")
    private Long receiptId;
    /**
    * 第三方套餐id
    */
    @SerializedName("dealId")
    private String dealId;
    /**
    * 券码
    */
    @SerializedName("serialNumber")
    private String serialNumber;
    /**
    * 状态 0序列号不存在 1验证成功 2已退款 3已使用 4验证失败
    */
    @SerializedName("status")
    private Integer status;
    /**
    * yyyy-MM-dd HH:mm:ss 格式时间
    */
    @SerializedName("statusTime")
    private String statusTime;
    /**
    * 商品快照
    */
    @SerializedName("productSnapshot")
    private String productSnapshot;
    /**
    * (体检)加项信息
    */
    @SerializedName("additionItemInfoList")
    private List<AdditionItemInfoDTO> additionItemInfoList;

    public Long getReceiptId() {
        return receiptId;
    }
    public void setReceiptId(Long receiptId) {
        this.receiptId = receiptId;
    }
    public String getDealId() {
        return dealId;
    }
    public void setDealId(String dealId) {
        this.dealId = dealId;
    }
    public String getSerialNumber() {
        return serialNumber;
    }
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getStatusTime() {
        return statusTime;
    }
    public void setStatusTime(String statusTime) {
        this.statusTime = statusTime;
    }
    public String getProductSnapshot() {
        return productSnapshot;
    }
    public void setProductSnapshot(String productSnapshot) {
        this.productSnapshot = productSnapshot;
    }
    public List<AdditionItemInfoDTO> getAdditionItemInfoList() {
        return additionItemInfoList;
    }
    public void setAdditionItemInfoList(List<AdditionItemInfoDTO> additionItemInfoList) {
        this.additionItemInfoList = additionItemInfoList;
    }




    @Override
    public String toString() {
        return "ThirdPartyReceiptDTO{" + "receiptId=" + receiptId + "," + "dealId=" + dealId + "," + "serialNumber=" + serialNumber + "," + "status=" + status + "," + "statusTime=" + statusTime + "," + "productSnapshot=" + productSnapshot + "," + "additionItemInfoList=" + additionItemInfoList + "}";
    }
}
