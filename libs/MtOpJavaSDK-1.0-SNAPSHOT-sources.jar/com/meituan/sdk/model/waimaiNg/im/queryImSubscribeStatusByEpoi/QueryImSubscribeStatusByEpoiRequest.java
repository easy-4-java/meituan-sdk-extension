package com.meituan.sdk.model.waimaiNg.im.queryImSubscribeStatusByEpoi;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询门店外卖IM消息订阅状态
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/im/queryImSubscribeStatusByEpoi",
    businessId = 2,
    apiVersion = "10047",
    apiName = "query_im_subscribe_status_by_epoi",
    needAuth = true
)
public class QueryImSubscribeStatusByEpoiRequest implements MeituanRequest<QueryImSubscribeStatusByEpoiResponse> {



    @Override
    public MeituanResponse<QueryImSubscribeStatusByEpoiResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<QueryImSubscribeStatusByEpoiResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return null;
    }


}
