package com.meituan.sdk.model.dcpd.queueShop.tableTypeClear;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 清空桌型
* This file was automatically generated.
*/
@ApiMeta(
    path = "/dcpd/queue/shop/config/tableType/clear",
    businessId = 49,
    apiVersion = "10001",
    apiName = "table_type_clear",
    needAuth = true
)
public class TableTypeClearRequest implements MeituanRequest<Boolean> {



    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return null;
    }


}
