package com.meituan.sdk.model.ddzhkh.dingdan.orderQueryInfo;

import com.google.gson.annotations.SerializedName;

/**
* 职人归因信息
* This file was automatically generated.
*/
public class TechInfoDTO {
    /**
    * 职人姓名
    */
    @SerializedName("techName")
    private String techName;
    /**
    * 职人脱敏手机号
    */
    @SerializedName("techMobileMasked")
    private String techMobileMasked;

    public String getTechName() {
        return techName;
    }
    public void setTechName(String techName) {
        this.techName = techName;
    }
    public String getTechMobileMasked() {
        return techMobileMasked;
    }
    public void setTechMobileMasked(String techMobileMasked) {
        this.techMobileMasked = techMobileMasked;
    }




    @Override
    public String toString() {
        return "TechInfoDTO{" + "techName=" + techName + "," + "techMobileMasked=" + techMobileMasked + "}";
    }
}
