package com.meituan.sdk.model.pms.priceinve.getRoomPrice;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 获取全天房价格
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/priceinve/getRoomPrice",
    businessId = 57,
    apiVersion = "10007",
    apiName = "get_room_price",
    needAuth = true
)
public class GetRoomPriceRequest implements MeituanRequest<GetRoomPriceResponse> {
    /**
    * <p data-diff-id="ct-diff-id-0d1f698a-cd8b-41ac-b922-cdfd91638786">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-81d531ac-b06f-4bea-aeeb-bbc15509048d">预抵时间，格式yyyy-MM-dd HH:mm:ss</p>
    */
    @NotBlank(message = "estimatedArriveTime不能为空")
    @SerializedName("estimatedArriveTime")
    private String estimatedArriveTime;
    /**
    * <p data-diff-id="ct-diff-id-0d0f9a88-d4c1-4d70-b84c-0dc0e9a990a4">预离时间，格式yyyy-MM-dd HH:mm:ss</p>
    */
    @NotBlank(message = "estimatedDepartureTime不能为空")
    @SerializedName("estimatedDepartureTime")
    private String estimatedDepartureTime;
    /**
    * <p data-diff-id="ct-diff-id-b0193850-5795-4984-b083-2c0f08109409">渠道：门店-Hotel、美团-MeiTuanEBK、携程<em>-</em>TRIP、抖音-DOUYIN、飞猪-FLIGGY、微信-WECHAT</p>
    */
    @NotBlank(message = "channel不能为空")
    @SerializedName("channel")
    private String channel;
    /**
    * <p data-diff-id="ct-diff-id-823008a0-944a-4838-85c5-7e0c873c4071"><span style="color: rgb(51, 51, 51)">房型编号列表</span></p>
    */
    @NotEmpty(message = "roomTypeIds不能为空")
    @SerializedName("roomTypeIds")
    private List<String> roomTypeIds;
    /**
    * <p data-diff-id="ct-diff-id-32e399ec-d1e3-40ce-8139-ad4fd7703ad7">客源类型，详见CustomerCategory字典，Normal代表散客</p>
    */
    @NotBlank(message = "customerCategory不能为空")
    @SerializedName("customerCategory")
    private String customerCategory;
    /**
    * <p data-diff-id="ct-diff-id-ee739c0d-fbdb-411b-b3f9-052dd85b0526">会员级别，详见MemberLevel字典</p>
    */
    @SerializedName("memberLevels")
    private List<String> memberLevels;
    /**
    * <p data-diff-id="ct-diff-id-e92d7637-bf10-459e-b07d-2d7d7477ee25">协议公司等级，详见ContractorLevel字典</p>
    */
    @SerializedName("contractorLevels")
    private List<String> contractorLevels;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getEstimatedArriveTime() {
        return estimatedArriveTime;
    }
    public void setEstimatedArriveTime(String estimatedArriveTime) {
        this.estimatedArriveTime = estimatedArriveTime;
    }
    public String getEstimatedDepartureTime() {
        return estimatedDepartureTime;
    }
    public void setEstimatedDepartureTime(String estimatedDepartureTime) {
        this.estimatedDepartureTime = estimatedDepartureTime;
    }
    public String getChannel() {
        return channel;
    }
    public void setChannel(String channel) {
        this.channel = channel;
    }
    public List<String> getRoomTypeIds() {
        return roomTypeIds;
    }
    public void setRoomTypeIds(List<String> roomTypeIds) {
        this.roomTypeIds = roomTypeIds;
    }
    public String getCustomerCategory() {
        return customerCategory;
    }
    public void setCustomerCategory(String customerCategory) {
        this.customerCategory = customerCategory;
    }
    public List<String> getMemberLevels() {
        return memberLevels;
    }
    public void setMemberLevels(List<String> memberLevels) {
        this.memberLevels = memberLevels;
    }
    public List<String> getContractorLevels() {
        return contractorLevels;
    }
    public void setContractorLevels(List<String> contractorLevels) {
        this.contractorLevels = contractorLevels;
    }


    @Override
    public MeituanResponse<GetRoomPriceResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<GetRoomPriceResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GetRoomPriceRequest{" + "hotelId=" + hotelId + "," + "estimatedArriveTime=" + estimatedArriveTime + "," + "estimatedDepartureTime=" + estimatedDepartureTime + "," + "channel=" + channel + "," + "roomTypeIds=" + roomTypeIds + "," + "customerCategory=" + customerCategory + "," + "memberLevels=" + memberLevels + "," + "contractorLevels=" + contractorLevels + "}";
    }
}
