package com.meituan.sdk.model.waimaiNg.dish.toppingGroupList;

import com.google.gson.annotations.SerializedName;

/**
* 关联小料
* This file was automatically generated.
*/
public class OpenRelTopping {
    /**
    * 小料code
    */
    @SerializedName("toppingCode")
    private String toppingCode;
    /**
    * 小料在小料组中的排序
    */
    @SerializedName("sequence")
    private Integer sequence;
    /**
    * 小料偏移id
    */
    @SerializedName("mtToppingId")
    private Long mtToppingId;
    /**
    * 默认选购数量，1或0
    */
    @SerializedName("defaultQuantity")
    private Integer defaultQuantity;

    public String getToppingCode() {
        return toppingCode;
    }
    public void setToppingCode(String toppingCode) {
        this.toppingCode = toppingCode;
    }
    public Integer getSequence() {
        return sequence;
    }
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    public Long getMtToppingId() {
        return mtToppingId;
    }
    public void setMtToppingId(Long mtToppingId) {
        this.mtToppingId = mtToppingId;
    }
    public Integer getDefaultQuantity() {
        return defaultQuantity;
    }
    public void setDefaultQuantity(Integer defaultQuantity) {
        this.defaultQuantity = defaultQuantity;
    }




    @Override
    public String toString() {
        return "OpenRelTopping{" + "toppingCode=" + toppingCode + "," + "sequence=" + sequence + "," + "mtToppingId=" + mtToppingId + "," + "defaultQuantity=" + defaultQuantity + "}";
    }
}
