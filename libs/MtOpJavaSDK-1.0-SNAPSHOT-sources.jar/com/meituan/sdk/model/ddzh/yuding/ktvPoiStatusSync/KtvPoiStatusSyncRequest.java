package com.meituan.sdk.model.ddzh.yuding.ktvPoiStatusSync;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* ktv悦享商户身份同步
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/ktv/poiStatus/sync",
    businessId = 58,
    apiVersion = "10053",
    apiName = "ktv_poi_status_sync",
    needAuth = true
)
public class KtvPoiStatusSyncRequest implements MeituanRequest<KtvPoiStatusSyncResponse> {
    /**
    * <p data-diff-id="ct-diff-id-f372a811-eb80-47f3-9539-72abace49dad">ktv商户身份变更信息详情</p>
    */
    @NotEmpty(message = "updateDetails不能为空")
    @SerializedName("updateDetails")
    private List<KtvShopIdentifierUpdateInfo> updateDetails;

    public List<KtvShopIdentifierUpdateInfo> getUpdateDetails() {
        return updateDetails;
    }
    public void setUpdateDetails(List<KtvShopIdentifierUpdateInfo> updateDetails) {
        this.updateDetails = updateDetails;
    }


    @Override
    public MeituanResponse<KtvPoiStatusSyncResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<KtvPoiStatusSyncResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "KtvPoiStatusSyncRequest{" + "updateDetails=" + updateDetails + "}";
    }
}
