package com.meituan.sdk.model.foodmop.sku.createComboS;

import java.util.List;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-377d62f6-d0be-4fd0-b3cd-bf43975c9607">套餐，不为空，每次最多传 1 个<br></p>
* This file was automatically generated.
*/
public class VendorComboDishDTO {
    /**
    * <p data-diff-id="ct-diff-id-676f8f71-53c0-4393-b03e-8050845995bd"><span style="color: rgb(102, 102, 102)">套餐基础信息</span></p>
    */
    @NotNull(message = "comboBasic不能为空")
    @SerializedName("comboBasic")
    private ComboDishBasicDTO comboBasic;
    /**
    * <p data-diff-id="ct-diff-id-b0d7bb04-46f2-4d2d-a127-8957657f83eb"><span style="color: rgb(102, 102, 102)">商品后台类目基本信息，用于经营宝后台配置营销活动时，按商品后台分类进行商品圈选。后台类目品牌自定义即可</span></p>
    */
    @NotNull(message = "backgroundCategoryBasic不能为空")
    @SerializedName("backgroundCategoryBasic")
    private BackgroundCategoryBasicDTO backgroundCategoryBasic;
    /**
    * <p data-diff-id="ct-diff-id-b189708c-4512-483a-9cda-4ec28744400d"><span style="color: rgb(102, 102, 102)">分组信息</span></p>
    */
    @NotEmpty(message = "comboGroupList不能为空")
    @SerializedName("comboGroupList")
    private List<ComboDishGroupDTO> comboGroupList;
    /**
    * <p data-diff-id="ct-diff-id-9aaa1299-e7f4-4699-8066-bf51a078ef7b"><span style="color: rgb(102, 102, 102)">套餐价格模块，包含基础价格、加价规则、分摊规则 基础价格和加价规则 如果需要更新必须同时传（如果只有固定分组可以不传加价规则） 基础价格和加价规则、分摊规则不能都为空 新建套餐时，都需要传</span></p>
    */
    @NotNull(message = "priceModule不能为空")
    @SerializedName("priceModule")
    private ComboPriceModule priceModule;

    public ComboDishBasicDTO getComboBasic() {
        return comboBasic;
    }
    public void setComboBasic(ComboDishBasicDTO comboBasic) {
        this.comboBasic = comboBasic;
    }
    public BackgroundCategoryBasicDTO getBackgroundCategoryBasic() {
        return backgroundCategoryBasic;
    }
    public void setBackgroundCategoryBasic(BackgroundCategoryBasicDTO backgroundCategoryBasic) {
        this.backgroundCategoryBasic = backgroundCategoryBasic;
    }
    public List<ComboDishGroupDTO> getComboGroupList() {
        return comboGroupList;
    }
    public void setComboGroupList(List<ComboDishGroupDTO> comboGroupList) {
        this.comboGroupList = comboGroupList;
    }
    public ComboPriceModule getPriceModule() {
        return priceModule;
    }
    public void setPriceModule(ComboPriceModule priceModule) {
        this.priceModule = priceModule;
    }




    @Override
    public String toString() {
        return "VendorComboDishDTO{" + "comboBasic=" + comboBasic + "," + "backgroundCategoryBasic=" + backgroundCategoryBasic + "," + "comboGroupList=" + comboGroupList + "," + "priceModule=" + priceModule + "}";
    }
}
