package com.meituan.sdk.model.ddzhkh.finance.queryPayplanInfo;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class SettledPayPlanDTO {
    /**
    * 账期ID(过期,使用payPlanIdV2)
    */
    @SerializedName("payPlanId")
    private String payPlanId;
    /**
    * 业务标识
    */
    @SerializedName("productCode")
    private String productCode;
    /**
    * 账期标识
    */
    @SerializedName("payPlanPeriod")
    private String payPlanPeriod;
    /**
    * 结算开始时间
    */
    @SerializedName("settleBeginTime")
    private Long settleBeginTime;
    /**
    * 结算截止时间
    */
    @SerializedName("settleEndTime")
    private Long settleEndTime;
    /**
    * 结算商户
    */
    @SerializedName("settledShop")
    private String settledShop;
    /**
    * 1初始,2待抵扣,3抵扣成功,4已提交打款计划,5打款成功,6打款失败,7已扣除资金账户余额，8打款暂停
    */
    @SerializedName("status")
    private Integer status;
    /**
    * 创建时间
    */
    @SerializedName("createTime")
    private Long createTime;
    /**
    * 结算金额
    */
    @SerializedName("settledAmount")
    private String settledAmount;
    /**
    * 总金额
    */
    @SerializedName("totalAmount")
    private String totalAmount;
    /**
    *  美团点评佣金
    */
    @SerializedName("commissionAmount")
    private String commissionAmount;
    /**
    * 营销扣款
    */
    @SerializedName("merchantDiscountAmount")
    private String merchantDiscountAmount;
    /**
    * 退款金额
    */
    @SerializedName("refundAmount")
    private String refundAmount;
    /**
    * 扣款金额
    */
    @SerializedName("deductAmount")
    private String deductAmount;
    /**
    * 往期欠款
    */
    @SerializedName("formerDeductAmount")
    private String formerDeductAmount;
    /**
    * 账期ID
    */
    @SerializedName("payPlanIdV2")
    private Long payPlanIdV2;

    public String getPayPlanId() {
        return payPlanId;
    }
    public void setPayPlanId(String payPlanId) {
        this.payPlanId = payPlanId;
    }
    public String getProductCode() {
        return productCode;
    }
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }
    public String getPayPlanPeriod() {
        return payPlanPeriod;
    }
    public void setPayPlanPeriod(String payPlanPeriod) {
        this.payPlanPeriod = payPlanPeriod;
    }
    public Long getSettleBeginTime() {
        return settleBeginTime;
    }
    public void setSettleBeginTime(Long settleBeginTime) {
        this.settleBeginTime = settleBeginTime;
    }
    public Long getSettleEndTime() {
        return settleEndTime;
    }
    public void setSettleEndTime(Long settleEndTime) {
        this.settleEndTime = settleEndTime;
    }
    public String getSettledShop() {
        return settledShop;
    }
    public void setSettledShop(String settledShop) {
        this.settledShop = settledShop;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Long getCreateTime() {
        return createTime;
    }
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
    public String getSettledAmount() {
        return settledAmount;
    }
    public void setSettledAmount(String settledAmount) {
        this.settledAmount = settledAmount;
    }
    public String getTotalAmount() {
        return totalAmount;
    }
    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }
    public String getCommissionAmount() {
        return commissionAmount;
    }
    public void setCommissionAmount(String commissionAmount) {
        this.commissionAmount = commissionAmount;
    }
    public String getMerchantDiscountAmount() {
        return merchantDiscountAmount;
    }
    public void setMerchantDiscountAmount(String merchantDiscountAmount) {
        this.merchantDiscountAmount = merchantDiscountAmount;
    }
    public String getRefundAmount() {
        return refundAmount;
    }
    public void setRefundAmount(String refundAmount) {
        this.refundAmount = refundAmount;
    }
    public String getDeductAmount() {
        return deductAmount;
    }
    public void setDeductAmount(String deductAmount) {
        this.deductAmount = deductAmount;
    }
    public String getFormerDeductAmount() {
        return formerDeductAmount;
    }
    public void setFormerDeductAmount(String formerDeductAmount) {
        this.formerDeductAmount = formerDeductAmount;
    }
    public Long getPayPlanIdV2() {
        return payPlanIdV2;
    }
    public void setPayPlanIdV2(Long payPlanIdV2) {
        this.payPlanIdV2 = payPlanIdV2;
    }




    @Override
    public String toString() {
        return "SettledPayPlanDTO{" + "payPlanId=" + payPlanId + "," + "productCode=" + productCode + "," + "payPlanPeriod=" + payPlanPeriod + "," + "settleBeginTime=" + settleBeginTime + "," + "settleEndTime=" + settleEndTime + "," + "settledShop=" + settledShop + "," + "status=" + status + "," + "createTime=" + createTime + "," + "settledAmount=" + settledAmount + "," + "totalAmount=" + totalAmount + "," + "commissionAmount=" + commissionAmount + "," + "merchantDiscountAmount=" + merchantDiscountAmount + "," + "refundAmount=" + refundAmount + "," + "deductAmount=" + deductAmount + "," + "formerDeductAmount=" + formerDeductAmount + "," + "payPlanIdV2=" + payPlanIdV2 + "}";
    }
}
