package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptQueryUsablerevelant;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 券关联订单可用券码查询
* This file was automatically generated.
*/
public class TuangouReceiptQueryUsablerevelantResponse {
    /**
    * 可用券信息
    */
    @SerializedName("availableReceiptList")
    private List<ReveiptInfo> availableReceiptList;

    public List<ReveiptInfo> getAvailableReceiptList() {
        return availableReceiptList;
    }
    public void setAvailableReceiptList(List<ReveiptInfo> availableReceiptList) {
        this.availableReceiptList = availableReceiptList;
    }




    @Override
    public String toString() {
        return "TuangouReceiptQueryUsablerevelantResponse{" + "availableReceiptList=" + availableReceiptList + "}";
    }
}
