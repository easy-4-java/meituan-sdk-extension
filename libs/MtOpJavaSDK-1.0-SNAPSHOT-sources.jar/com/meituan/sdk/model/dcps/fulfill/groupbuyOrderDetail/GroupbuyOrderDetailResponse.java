package com.meituan.sdk.model.dcps.fulfill.groupbuyOrderDetail;

import com.google.gson.annotations.SerializedName;

/**
* 1.1.9.查询订单详情
* This file was automatically generated.
*/
public class GroupbuyOrderDetailResponse {
    /**
    * 预约单id
    */
    @SerializedName("bookingOrderId")
    private String bookingOrderId;
    /**
    * 备注
    */
    @SerializedName("caution")
    private String caution;
    /**
    * 配送地址
    */
    @SerializedName("consignAddress")
    private String consignAddress;
    /**
    * 收货人
    */
    @SerializedName("consignee")
    private String consignee;
    /**
    * 	性别
    */
    @SerializedName("consigneeGender")
    private Long consigneeGender;
    /**
    * 收货人手机号
    */
    @SerializedName("consigneeMobile")
    private String consigneeMobile;
    /**
    * 预计送达时间
    */
    @SerializedName("deliveryTime")
    private Long deliveryTime;
    /**
    * 配送物流状态
    */
    @SerializedName("logisticsStatus")
    private Long logisticsStatus;
    /**
    * 配送商流状态
    */
    @SerializedName("merchantStatus")
    private Long merchantStatus;
    /**
    * 	订单创建时间
    */
    @SerializedName("orderCreateTime")
    private Long orderCreateTime;
    /**
    * 扩展信息
    */
    @SerializedName("orderDetailExt")
    private OrderDetailExt orderDetailExt;
    /**
    * 	团购订单id
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * 更新时间
    */
    @SerializedName("orderModifyTime")
    private Long orderModifyTime;
    /**
    * 用户支付金额：套餐售卖价+打包费+配送费-套餐营销金额-打包费立减金额
    */
    @SerializedName("payFee")
    private Long payFee;
    /**
    * 	配送类型0无，1美配，2自配
    */
    @SerializedName("peisongType")
    private Long peisongType;
    /**
    * 商品原价：套餐美团售卖价
    */
    @SerializedName("price")
    private Long price;
    /**
    * 	商品数量
    */
    @SerializedName("quantity")
    private Integer quantity;
    /**
    * 退款状态
    */
    @SerializedName("refundStatus")
    private Long refundStatus;
    /**
    * 拒绝接单原因
    */
    @SerializedName("refusedOrderReason")
    private String refusedOrderReason;
    /**
    * 履约配送单状态
    */
    @SerializedName("status")
    private Integer status;
    /**
    * 预约单类型
    */
    @SerializedName("type")
    private Long type;
    /**
    * 授权实体
    */
    @SerializedName("opBizCode")
    private String opBizCode;
    /**
    * 	拒绝退款原因
    */
    @SerializedName("refusedCancelReason")
    private String refusedCancelReason;

    public String getBookingOrderId() {
        return bookingOrderId;
    }
    public void setBookingOrderId(String bookingOrderId) {
        this.bookingOrderId = bookingOrderId;
    }
    public String getCaution() {
        return caution;
    }
    public void setCaution(String caution) {
        this.caution = caution;
    }
    public String getConsignAddress() {
        return consignAddress;
    }
    public void setConsignAddress(String consignAddress) {
        this.consignAddress = consignAddress;
    }
    public String getConsignee() {
        return consignee;
    }
    public void setConsignee(String consignee) {
        this.consignee = consignee;
    }
    public Long getConsigneeGender() {
        return consigneeGender;
    }
    public void setConsigneeGender(Long consigneeGender) {
        this.consigneeGender = consigneeGender;
    }
    public String getConsigneeMobile() {
        return consigneeMobile;
    }
    public void setConsigneeMobile(String consigneeMobile) {
        this.consigneeMobile = consigneeMobile;
    }
    public Long getDeliveryTime() {
        return deliveryTime;
    }
    public void setDeliveryTime(Long deliveryTime) {
        this.deliveryTime = deliveryTime;
    }
    public Long getLogisticsStatus() {
        return logisticsStatus;
    }
    public void setLogisticsStatus(Long logisticsStatus) {
        this.logisticsStatus = logisticsStatus;
    }
    public Long getMerchantStatus() {
        return merchantStatus;
    }
    public void setMerchantStatus(Long merchantStatus) {
        this.merchantStatus = merchantStatus;
    }
    public Long getOrderCreateTime() {
        return orderCreateTime;
    }
    public void setOrderCreateTime(Long orderCreateTime) {
        this.orderCreateTime = orderCreateTime;
    }
    public OrderDetailExt getOrderDetailExt() {
        return orderDetailExt;
    }
    public void setOrderDetailExt(OrderDetailExt orderDetailExt) {
        this.orderDetailExt = orderDetailExt;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public Long getOrderModifyTime() {
        return orderModifyTime;
    }
    public void setOrderModifyTime(Long orderModifyTime) {
        this.orderModifyTime = orderModifyTime;
    }
    public Long getPayFee() {
        return payFee;
    }
    public void setPayFee(Long payFee) {
        this.payFee = payFee;
    }
    public Long getPeisongType() {
        return peisongType;
    }
    public void setPeisongType(Long peisongType) {
        this.peisongType = peisongType;
    }
    public Long getPrice() {
        return price;
    }
    public void setPrice(Long price) {
        this.price = price;
    }
    public Integer getQuantity() {
        return quantity;
    }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
    public Long getRefundStatus() {
        return refundStatus;
    }
    public void setRefundStatus(Long refundStatus) {
        this.refundStatus = refundStatus;
    }
    public String getRefusedOrderReason() {
        return refusedOrderReason;
    }
    public void setRefusedOrderReason(String refusedOrderReason) {
        this.refusedOrderReason = refusedOrderReason;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Long getType() {
        return type;
    }
    public void setType(Long type) {
        this.type = type;
    }
    public String getOpBizCode() {
        return opBizCode;
    }
    public void setOpBizCode(String opBizCode) {
        this.opBizCode = opBizCode;
    }
    public String getRefusedCancelReason() {
        return refusedCancelReason;
    }
    public void setRefusedCancelReason(String refusedCancelReason) {
        this.refusedCancelReason = refusedCancelReason;
    }




    @Override
    public String toString() {
        return "GroupbuyOrderDetailResponse{" + "bookingOrderId=" + bookingOrderId + "," + "caution=" + caution + "," + "consignAddress=" + consignAddress + "," + "consignee=" + consignee + "," + "consigneeGender=" + consigneeGender + "," + "consigneeMobile=" + consigneeMobile + "," + "deliveryTime=" + deliveryTime + "," + "logisticsStatus=" + logisticsStatus + "," + "merchantStatus=" + merchantStatus + "," + "orderCreateTime=" + orderCreateTime + "," + "orderDetailExt=" + orderDetailExt + "," + "orderId=" + orderId + "," + "orderModifyTime=" + orderModifyTime + "," + "payFee=" + payFee + "," + "peisongType=" + peisongType + "," + "price=" + price + "," + "quantity=" + quantity + "," + "refundStatus=" + refundStatus + "," + "refusedOrderReason=" + refusedOrderReason + "," + "status=" + status + "," + "type=" + type + "," + "opBizCode=" + opBizCode + "," + "refusedCancelReason=" + refusedCancelReason + "}";
    }
}
