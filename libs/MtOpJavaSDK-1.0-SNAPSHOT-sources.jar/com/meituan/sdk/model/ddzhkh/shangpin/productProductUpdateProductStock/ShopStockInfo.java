package com.meituan.sdk.model.ddzhkh.shangpin.productProductUpdateProductStock;

import com.google.gson.annotations.SerializedName;

/**
* 售卖SKU属性列表，业务参考属性文档，注：类型为对象类型，详见扩展参数shop_stock_infos 
* This file was automatically generated.
*/
public class ShopStockInfo {
    /**
    * 门店ID
    */
    @SerializedName("opPoiId")
    private String opPoiId;
    /**
    * 美团门店名称
    */
    @SerializedName("shopName")
    private String shopName;
    /**
    * 总库存
    */
    @SerializedName("stock")
    private Integer stock;
    /**
    * 已售库存
    */
    @SerializedName("saleStock")
    private Integer saleStock;
    /**
    * 剩余库存
    */
    @SerializedName("remainStock")
    private Integer remainStock;

    public String getOpPoiId() {
        return opPoiId;
    }
    public void setOpPoiId(String opPoiId) {
        this.opPoiId = opPoiId;
    }
    public String getShopName() {
        return shopName;
    }
    public void setShopName(String shopName) {
        this.shopName = shopName;
    }
    public Integer getStock() {
        return stock;
    }
    public void setStock(Integer stock) {
        this.stock = stock;
    }
    public Integer getSaleStock() {
        return saleStock;
    }
    public void setSaleStock(Integer saleStock) {
        this.saleStock = saleStock;
    }
    public Integer getRemainStock() {
        return remainStock;
    }
    public void setRemainStock(Integer remainStock) {
        this.remainStock = remainStock;
    }




    @Override
    public String toString() {
        return "ShopStockInfo{" + "opPoiId=" + opPoiId + "," + "shopName=" + shopName + "," + "stock=" + stock + "," + "saleStock=" + saleStock + "," + "remainStock=" + remainStock + "}";
    }
}
