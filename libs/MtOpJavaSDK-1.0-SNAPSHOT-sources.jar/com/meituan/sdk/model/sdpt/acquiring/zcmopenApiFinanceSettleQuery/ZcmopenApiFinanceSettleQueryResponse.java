package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiFinanceSettleQuery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* [结算]查询结算明细
* This file was automatically generated.
*/
public class ZcmopenApiFinanceSettleQueryResponse {
    /**
    * SUCCESS： 请求成功；FAIL：请求失败 请重试
    */
    @SerializedName("status")
    private String status;
    /**
    * 错误消息描述（status 为失败的时候有）
    */
    @SerializedName("errMsg")
    private String errMsg;
    @SerializedName("settleDetailList")
    private List<SettleDetailListSub> settleDetailList;

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getErrMsg() {
        return errMsg;
    }
    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
    public List<SettleDetailListSub> getSettleDetailList() {
        return settleDetailList;
    }
    public void setSettleDetailList(List<SettleDetailListSub> settleDetailList) {
        this.settleDetailList = settleDetailList;
    }




    @Override
    public String toString() {
        return "ZcmopenApiFinanceSettleQueryResponse{" + "status=" + status + "," + "errMsg=" + errMsg + "," + "settleDetailList=" + settleDetailList + "}";
    }
}
