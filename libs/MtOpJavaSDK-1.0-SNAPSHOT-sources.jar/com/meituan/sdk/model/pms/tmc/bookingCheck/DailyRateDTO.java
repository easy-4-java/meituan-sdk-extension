package com.meituan.sdk.model.pms.tmc.bookingCheck;

import com.google.gson.annotations.SerializedName;

/**
* 每日价量信息
* This file was automatically generated.
*/
public class DailyRateDTO {
    /**
    * 入住日期
    */
    @SerializedName("date")
    private String date;
    /**
    * 原始价格（单位：元）
    */
    @SerializedName("originPrice")
    private String originPrice;
    /**
    * 优惠后价格（单位：元）
    */
    @SerializedName("actualPrice")
    private String actualPrice;
    /**
    * 是否已关房
    */
    @SerializedName("isClosed")
    private Boolean isClosed;
    /**
    * 房量
    */
    @SerializedName("inventory")
    private Integer inventory;

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getOriginPrice() {
        return originPrice;
    }
    public void setOriginPrice(String originPrice) {
        this.originPrice = originPrice;
    }
    public String getActualPrice() {
        return actualPrice;
    }
    public void setActualPrice(String actualPrice) {
        this.actualPrice = actualPrice;
    }
    public Boolean getIsClosed() {
        return isClosed;
    }
    public void setIsClosed(Boolean isClosed) {
        this.isClosed = isClosed;
    }
    public Integer getInventory() {
        return inventory;
    }
    public void setInventory(Integer inventory) {
        this.inventory = inventory;
    }




    @Override
    public String toString() {
        return "DailyRateDTO{" + "date=" + date + "," + "originPrice=" + originPrice + "," + "actualPrice=" + actualPrice + "," + "isClosed=" + isClosed + "," + "inventory=" + inventory + "}";
    }
}
