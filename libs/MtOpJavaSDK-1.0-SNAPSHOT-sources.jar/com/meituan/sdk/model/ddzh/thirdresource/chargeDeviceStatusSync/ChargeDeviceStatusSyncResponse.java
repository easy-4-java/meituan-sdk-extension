package com.meituan.sdk.model.ddzh.thirdresource.chargeDeviceStatusSync;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 充电站设备状态同步
* This file was automatically generated.
*/
public class ChargeDeviceStatusSyncResponse {
    /**
    * 同步失败设备数量
    */
    @SerializedName("failureCount")
    private Integer failureCount;
    /**
    * 同步失败设备明细
    */
    @SerializedName("failureDetails")
    private List<RSyncDeviceFailureDetail> failureDetails;

    public Integer getFailureCount() {
        return failureCount;
    }
    public void setFailureCount(Integer failureCount) {
        this.failureCount = failureCount;
    }
    public List<RSyncDeviceFailureDetail> getFailureDetails() {
        return failureDetails;
    }
    public void setFailureDetails(List<RSyncDeviceFailureDetail> failureDetails) {
        this.failureDetails = failureDetails;
    }




    @Override
    public String toString() {
        return "ChargeDeviceStatusSyncResponse{" + "failureCount=" + failureCount + "," + "failureDetails=" + failureDetails + "}";
    }
}
