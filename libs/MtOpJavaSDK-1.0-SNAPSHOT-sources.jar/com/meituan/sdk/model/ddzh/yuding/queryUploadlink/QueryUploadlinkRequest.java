package com.meituan.sdk.model.ddzh.yuding.queryUploadlink;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取授权上传链接
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/query/uploadlink",
    businessId = 58,
    apiVersion = "10053",
    apiName = "query_uploadlink",
    needAuth = true
)
public class QueryUploadlinkRequest implements MeituanRequest<QueryUploadlinkResponse> {
    /**
    * <p data-diff-id="ct-diff-id-78f6bead-07d4-4226-b6f9-3b7574defb0d"><span style="color: rgb(31, 45, 61)">订单ID（预约单id）</span></p>
    */
    @NotNull(message = "reserveOrderId不能为空")
    @SerializedName("reserveOrderId")
    private Long reserveOrderId;
    /**
    * <p data-diff-id="ct-diff-id-2ffdb3ac-0403-4452-84c2-ffefb10814c8"><span style="color: rgb(31, 45, 61)">凭证名（文件名)</span></p>
    */
    @NotBlank(message = "fileName不能为空")
    @SerializedName("fileName")
    private String fileName;
    /**
    * <p data-diff-id="ct-diff-id-71e20102-c569-4732-89a0-d0adec2c2a34"><span style="color: rgb(31, 45, 61)">过期时长，不得超过30分钟，单位：毫秒milliSecond（限时上传）</span></p>
    */
    @NotNull(message = "expiration不能为空")
    @SerializedName("expiration")
    private Long expiration;

    public Long getReserveOrderId() {
        return reserveOrderId;
    }
    public void setReserveOrderId(Long reserveOrderId) {
        this.reserveOrderId = reserveOrderId;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public Long getExpiration() {
        return expiration;
    }
    public void setExpiration(Long expiration) {
        this.expiration = expiration;
    }


    @Override
    public MeituanResponse<QueryUploadlinkResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<QueryUploadlinkResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "QueryUploadlinkRequest{" + "reserveOrderId=" + reserveOrderId + "," + "fileName=" + fileName + "," + "expiration=" + expiration + "}";
    }
}
