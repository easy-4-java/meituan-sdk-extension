package com.meituan.sdk.model.pms.priceinve.priceSuggest;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 价格建议
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/priceinve/pushPriceSuggestion",
    businessId = 57,
    apiVersion = "10018",
    apiName = "price_suggest",
    needAuth = true
)
public class PriceSuggestRequest implements MeituanRequest<Boolean> {
    /**
    * <p data-diff-id="ct-diff-id-c4364fa9-bd4b-4628-83f8-eb4c6cb3f6fe">供应商ID</p>
    */
    @NotNull(message = "partnerId不能为空")
    @SerializedName("partnerId")
    private Long partnerId;
    /**
    * <p data-diff-id="ct-diff-id-ec5108c3-1550-47dc-99bf-04c32840ead2">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-a392cd84-ffa9-4b25-a08b-4d9f74e09e4e">酒店美团POI ID</p>
    */
    @NotNull(message = "poiId不能为空")
    @SerializedName("poiId")
    private Long poiId;
    /**
    * <p data-diff-id="ct-diff-id-10b263d4-3233-4f46-9c45-a87cf183dc4b">定价日期，格式yyyy-MM-dd</p>
    */
    @NotBlank(message = "priceDate不能为空")
    @SerializedName("priceDate")
    private String priceDate;
    /**
    * <p data-diff-id="ct-diff-id-e69cf9cb-0c4c-49f6-8753-d46a0ecfce67">定价原因</p>
    */
    @NotBlank(message = "reason不能为空")
    @SerializedName("reason")
    private String reason;
    /**
    * <p data-diff-id="ct-diff-id-da8c4ff0-2054-4374-90d8-d08ec5368671"><span style="color: #333">价格建议单据ID，用于关联最终的采纳/拒绝结果</span></p>
    */
    @NotBlank(message = "pricingSuggestionNo不能为空")
    @SerializedName("pricingSuggestionNo")
    private String pricingSuggestionNo;
    /**
    * <p data-diff-id="ct-diff-id-e161b450-6f61-41b4-b56b-f7cd153a9607"><span style="color: rgba(0, 0, 0, 0.65)">执行时间，格式yyyy-MM-dd HH:mm:ss</span></p>
    */
    @NotBlank(message = "executeTime不能为空")
    @SerializedName("executeTime")
    private String executeTime;
    /**
    * <p data-diff-id="ct-diff-id-49858200-6e96-4436-a837-22f9365582b8">过期时间，格式yyyy-MM-dd HH:mm:ss</p>
    */
    @NotBlank(message = "expireDateTime不能为空")
    @SerializedName("expireDateTime")
    private String expireDateTime;
    /**
    * <p data-diff-id="ct-diff-id-431be8de-d3f1-4969-8d6b-4e491ddea53e">价格建议详情列表</p>
    */
    @NotEmpty(message = "priceDetailList不能为空")
    @SerializedName("priceDetailList")
    private List<PriceSuggestionDetailDTO> priceDetailList;

    public Long getPartnerId() {
        return partnerId;
    }
    public void setPartnerId(Long partnerId) {
        this.partnerId = partnerId;
    }
    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public Long getPoiId() {
        return poiId;
    }
    public void setPoiId(Long poiId) {
        this.poiId = poiId;
    }
    public String getPriceDate() {
        return priceDate;
    }
    public void setPriceDate(String priceDate) {
        this.priceDate = priceDate;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }
    public String getPricingSuggestionNo() {
        return pricingSuggestionNo;
    }
    public void setPricingSuggestionNo(String pricingSuggestionNo) {
        this.pricingSuggestionNo = pricingSuggestionNo;
    }
    public String getExecuteTime() {
        return executeTime;
    }
    public void setExecuteTime(String executeTime) {
        this.executeTime = executeTime;
    }
    public String getExpireDateTime() {
        return expireDateTime;
    }
    public void setExpireDateTime(String expireDateTime) {
        this.expireDateTime = expireDateTime;
    }
    public List<PriceSuggestionDetailDTO> getPriceDetailList() {
        return priceDetailList;
    }
    public void setPriceDetailList(List<PriceSuggestionDetailDTO> priceDetailList) {
        this.priceDetailList = priceDetailList;
    }


    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "PriceSuggestRequest{" + "partnerId=" + partnerId + "," + "hotelId=" + hotelId + "," + "poiId=" + poiId + "," + "priceDate=" + priceDate + "," + "reason=" + reason + "," + "pricingSuggestionNo=" + pricingSuggestionNo + "," + "executeTime=" + executeTime + "," + "expireDateTime=" + expireDateTime + "," + "priceDetailList=" + priceDetailList + "}";
    }
}
