package com.meituan.sdk.model.ddzhkh.shangpin.productDealgroupUpdateprice;

import com.google.gson.annotations.SerializedName;

/**
* 修改团单价格
* This file was automatically generated.
*/
public class ProductDealgroupUpdatepriceResponse {
    /**
    * 团单id（即将下线）
    */
    @SerializedName("dealGroupId")
    private Long dealGroupId;
    /**
    * 团单id（使用该字段）
    */
    @SerializedName("longDealGroupId")
    private Long longDealGroupId;

    public Long getDealGroupId() {
        return dealGroupId;
    }
    public void setDealGroupId(Long dealGroupId) {
        this.dealGroupId = dealGroupId;
    }
    public Long getLongDealGroupId() {
        return longDealGroupId;
    }
    public void setLongDealGroupId(Long longDealGroupId) {
        this.longDealGroupId = longDealGroupId;
    }




    @Override
    public String toString() {
        return "ProductDealgroupUpdatepriceResponse{" + "dealGroupId=" + dealGroupId + "," + "longDealGroupId=" + longDealGroupId + "}";
    }
}
