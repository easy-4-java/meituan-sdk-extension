package com.meituan.sdk.model.solution2.csaccount.dcSrcollQueryTradeProfitDetail;

import com.google.gson.annotations.SerializedName;

/**
* 流水列表
* This file was automatically generated.
*/
public class SettleTradeDetailModel {
    /**
    * 券码,团购用
    */
    @SerializedName("orderItemId")
    private String orderItemId;
    /**
    * 订单号
    */
    @SerializedName("orderId")
    private String orderId;
    /**
    * 收益时间 格式：yyyy/MM/dd HH:mm:ss
    */
    @SerializedName("accountTime")
    private String accountTime;
    /**
    * 下单时间 格式：yyyy/MM/dd HH:mm:ss
    */
    @SerializedName("orderCreateTime")
    private String orderCreateTime;
    /**
    * 消费时间 格式：yyyy/MM/dd HH:mm:ss
    */
    @SerializedName("useTime")
    private String useTime;
    /**
    * 撤销时间 格式：yyyy/MM/dd HH:mm:ss
    */
    @SerializedName("cancelTime")
    private String cancelTime;
    /**
    * 退款时间 格式：yyyy/MM/dd HH:mm:ss
    */
    @SerializedName("refundTime")
    private String refundTime;
    /**
    * 门店城市
    */
    @SerializedName("poiCityName")
    private String poiCityName;
    /**
    * 美团门店名称
    */
    @SerializedName("poiName")
    private String poiName;
    /**
    * 美团门店ID
    */
    @SerializedName("poiId")
    private String poiId;
    /**
    * 项目
    */
    @SerializedName("dealName")
    private String dealName;
    /**
    * 商品名称
    */
    @SerializedName("onlyDealName")
    private String onlyDealName;
    /**
    * 项目ID
    */
    @SerializedName("dealId")
    private String dealId;
    /**
    * 合同
    */
    @SerializedName("contractName")
    private String contractName;
    /**
    * 账户
    */
    @SerializedName("accountName")
    private String accountName;
    /**
    * 1=团购 2=买单 3=超值加菜 12=美团圈圈 14=超值优惠券包 15=空间预定 16=在线点 21=服务费返还 22=服务商 33=神会员 34=到餐服务市场
    */
    @SerializedName("bizType")
    private String bizType;
    /**
    * 0=其它流水 1=支付流水 1=确认/成单流水 2=消费 3=取消消费 4=促销 5=已消费退款 6=运费 7=未消费退款 8=过期流水 9=过期退款 10=保险投保 11=保险退保 12=结算差额 13=有责退 14=赔付流水 15=补款流水 16=非交易流水
    */
    @SerializedName("traceType")
    private String traceType;
    /**
    * 原价
    */
    @SerializedName("originPrice")
    private String originPrice;
    /**
    * 售价（美团售价）
    */
    @SerializedName("salePrice")
    private String salePrice;
    /**
    * 商家承担促销费-随单抵扣
    */
    @SerializedName("bizCost")
    private String bizCost;
    /**
    * 商家承担促销费-营销账户余额抵扣
    */
    @SerializedName("bizCostByAccount")
    private String bizCostByAccount;
    /**
    * 商家承担促销费-配送费减免
    */
    @SerializedName("deliverDiscountFee")
    private String deliverDiscountFee;
    /**
    * 服务费（平台实际扣除）
    */
    @SerializedName("serviceFee")
    private String serviceFee;
    /**
    * 技术服务费优惠
    */
    @SerializedName("serviceFeeDiscount")
    private String serviceFeeDiscount;
    /**
    * 服务费-配送费
    */
    @SerializedName("deliveryFee")
    private String deliveryFee;
    /**
    * 商家自配配送费
    */
    @SerializedName("partnerSelfDeliverFee")
    private String partnerSelfDeliverFee;
    /**
    * 合作商商业支持费用
    */
    @SerializedName("agentCommissionAmount")
    private String agentCommissionAmount;
    /**
    * 合作商
    */
    @SerializedName("agentCommissionName")
    private String agentCommissionName;
    /**
    * 商家承担退款
    */
    @SerializedName("refund")
    private String refund;
    /**
    * 代运营服务费
    */
    @SerializedName("sharedAmount")
    private String sharedAmount;
    /**
    * 安心吃保险费用
    */
    @SerializedName("otherIncome")
    private String otherIncome;
    /**
    * 公益捐款
    */
    @SerializedName("publicBenefitFee")
    private String publicBenefitFee;
    /**
    * 核销订单推广费
    */
    @SerializedName("adFee")
    private String adFee;
    /**
    * 达人分销服务费
    */
    @SerializedName("drfxFee")
    private String drfxFee;
    /**
    * 政府消费券扣补款
    */
    @SerializedName("governmentDiscountAmount")
    private String governmentDiscountAmount;
    /**
    * 交易额转推广充值
    */
    @SerializedName("jyeztgAdFee")
    private String jyeztgAdFee;
    /**
    * 远程锁客节省转推广
    */
    @SerializedName("ycskAdFee")
    private String ycskAdFee;
    /**
    * 渠道推广服务费
    */
    @SerializedName("mtUnionOdpFee")
    private String mtUnionOdpFee;
    /**
    * 商家应得
    */
    @SerializedName("partnerIncome")
    private String partnerIncome;
    /**
    * 美团承担促销费
    */
    @SerializedName("mtPreTotal")
    private String mtPreTotal;
    /**
    * 顾客实际支付
    */
    @SerializedName("payAmount")
    private String payAmount;
    /**
    * 商品类型
    */
    @SerializedName("dealTypeName")
    private String dealTypeName;
    /**
    * 是否代金券买单
    */
    @SerializedName("voucherPayFlag")
    private String voucherPayFlag;
    /**
    * 预约单号
    */
    @SerializedName("bookingOrderId")
    private String bookingOrderId;
    /**
    * 下单渠道
    */
    @SerializedName("enterpriseOrder")
    private String enterpriseOrder;
    /**
    * 发票标识
    */
    @SerializedName("needInvoiceFlag")
    private String needInvoiceFlag;
    /**
    * 结算状态
    */
    @SerializedName("settleStatus")
    private String settleStatus;
    /**
    * 付款单名称
    */
    @SerializedName("payment")
    private String payment;
    /**
    * 发起付款时间
    */
    @SerializedName("payStartTime")
    private String payStartTime;
    /**
    * 付款流水号
    */
    @SerializedName("mtpp")
    private String mtpp;
    /**
    * 付款状态
    */
    @SerializedName("payStatus")
    private String payStatus;
    /**
    * 付款成功时间
    */
    @SerializedName("paySuccessTime")
    private String paySuccessTime;
    /**
    * 收款账户
    */
    @SerializedName("recvAccountName")
    private String recvAccountName;
    /**
    * 付款失败原因
    */
    @SerializedName("payFailReason")
    private String payFailReason;
    /**
    * 自有系统门店编号
    */
    @SerializedName("merchantPoiId")
    private String merchantPoiId;
    /**
    * 自有系统门店名称
    */
    @SerializedName("merchantPoiName")
    private String merchantPoiName;
    /**
    * 是否预付款
    */
    @SerializedName("isAdvancePay")
    private String isAdvancePay;
    /**
    * 三方订单号
    */
    @SerializedName("partnerOrderId")
    private String partnerOrderId;
    /**
    * 扩展字段 Map<String, String>
    */
    @SerializedName("extendInfo")
    private Map extendInfo;

    public String getOrderItemId() {
        return orderItemId;
    }
    public void setOrderItemId(String orderItemId) {
        this.orderItemId = orderItemId;
    }
    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public String getAccountTime() {
        return accountTime;
    }
    public void setAccountTime(String accountTime) {
        this.accountTime = accountTime;
    }
    public String getOrderCreateTime() {
        return orderCreateTime;
    }
    public void setOrderCreateTime(String orderCreateTime) {
        this.orderCreateTime = orderCreateTime;
    }
    public String getUseTime() {
        return useTime;
    }
    public void setUseTime(String useTime) {
        this.useTime = useTime;
    }
    public String getCancelTime() {
        return cancelTime;
    }
    public void setCancelTime(String cancelTime) {
        this.cancelTime = cancelTime;
    }
    public String getRefundTime() {
        return refundTime;
    }
    public void setRefundTime(String refundTime) {
        this.refundTime = refundTime;
    }
    public String getPoiCityName() {
        return poiCityName;
    }
    public void setPoiCityName(String poiCityName) {
        this.poiCityName = poiCityName;
    }
    public String getPoiName() {
        return poiName;
    }
    public void setPoiName(String poiName) {
        this.poiName = poiName;
    }
    public String getPoiId() {
        return poiId;
    }
    public void setPoiId(String poiId) {
        this.poiId = poiId;
    }
    public String getDealName() {
        return dealName;
    }
    public void setDealName(String dealName) {
        this.dealName = dealName;
    }
    public String getOnlyDealName() {
        return onlyDealName;
    }
    public void setOnlyDealName(String onlyDealName) {
        this.onlyDealName = onlyDealName;
    }
    public String getDealId() {
        return dealId;
    }
    public void setDealId(String dealId) {
        this.dealId = dealId;
    }
    public String getContractName() {
        return contractName;
    }
    public void setContractName(String contractName) {
        this.contractName = contractName;
    }
    public String getAccountName() {
        return accountName;
    }
    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }
    public String getBizType() {
        return bizType;
    }
    public void setBizType(String bizType) {
        this.bizType = bizType;
    }
    public String getTraceType() {
        return traceType;
    }
    public void setTraceType(String traceType) {
        this.traceType = traceType;
    }
    public String getOriginPrice() {
        return originPrice;
    }
    public void setOriginPrice(String originPrice) {
        this.originPrice = originPrice;
    }
    public String getSalePrice() {
        return salePrice;
    }
    public void setSalePrice(String salePrice) {
        this.salePrice = salePrice;
    }
    public String getBizCost() {
        return bizCost;
    }
    public void setBizCost(String bizCost) {
        this.bizCost = bizCost;
    }
    public String getBizCostByAccount() {
        return bizCostByAccount;
    }
    public void setBizCostByAccount(String bizCostByAccount) {
        this.bizCostByAccount = bizCostByAccount;
    }
    public String getDeliverDiscountFee() {
        return deliverDiscountFee;
    }
    public void setDeliverDiscountFee(String deliverDiscountFee) {
        this.deliverDiscountFee = deliverDiscountFee;
    }
    public String getServiceFee() {
        return serviceFee;
    }
    public void setServiceFee(String serviceFee) {
        this.serviceFee = serviceFee;
    }
    public String getServiceFeeDiscount() {
        return serviceFeeDiscount;
    }
    public void setServiceFeeDiscount(String serviceFeeDiscount) {
        this.serviceFeeDiscount = serviceFeeDiscount;
    }
    public String getDeliveryFee() {
        return deliveryFee;
    }
    public void setDeliveryFee(String deliveryFee) {
        this.deliveryFee = deliveryFee;
    }
    public String getPartnerSelfDeliverFee() {
        return partnerSelfDeliverFee;
    }
    public void setPartnerSelfDeliverFee(String partnerSelfDeliverFee) {
        this.partnerSelfDeliverFee = partnerSelfDeliverFee;
    }
    public String getAgentCommissionAmount() {
        return agentCommissionAmount;
    }
    public void setAgentCommissionAmount(String agentCommissionAmount) {
        this.agentCommissionAmount = agentCommissionAmount;
    }
    public String getAgentCommissionName() {
        return agentCommissionName;
    }
    public void setAgentCommissionName(String agentCommissionName) {
        this.agentCommissionName = agentCommissionName;
    }
    public String getRefund() {
        return refund;
    }
    public void setRefund(String refund) {
        this.refund = refund;
    }
    public String getSharedAmount() {
        return sharedAmount;
    }
    public void setSharedAmount(String sharedAmount) {
        this.sharedAmount = sharedAmount;
    }
    public String getOtherIncome() {
        return otherIncome;
    }
    public void setOtherIncome(String otherIncome) {
        this.otherIncome = otherIncome;
    }
    public String getPublicBenefitFee() {
        return publicBenefitFee;
    }
    public void setPublicBenefitFee(String publicBenefitFee) {
        this.publicBenefitFee = publicBenefitFee;
    }
    public String getAdFee() {
        return adFee;
    }
    public void setAdFee(String adFee) {
        this.adFee = adFee;
    }
    public String getDrfxFee() {
        return drfxFee;
    }
    public void setDrfxFee(String drfxFee) {
        this.drfxFee = drfxFee;
    }
    public String getGovernmentDiscountAmount() {
        return governmentDiscountAmount;
    }
    public void setGovernmentDiscountAmount(String governmentDiscountAmount) {
        this.governmentDiscountAmount = governmentDiscountAmount;
    }
    public String getJyeztgAdFee() {
        return jyeztgAdFee;
    }
    public void setJyeztgAdFee(String jyeztgAdFee) {
        this.jyeztgAdFee = jyeztgAdFee;
    }
    public String getYcskAdFee() {
        return ycskAdFee;
    }
    public void setYcskAdFee(String ycskAdFee) {
        this.ycskAdFee = ycskAdFee;
    }
    public String getMtUnionOdpFee() {
        return mtUnionOdpFee;
    }
    public void setMtUnionOdpFee(String mtUnionOdpFee) {
        this.mtUnionOdpFee = mtUnionOdpFee;
    }
    public String getPartnerIncome() {
        return partnerIncome;
    }
    public void setPartnerIncome(String partnerIncome) {
        this.partnerIncome = partnerIncome;
    }
    public String getMtPreTotal() {
        return mtPreTotal;
    }
    public void setMtPreTotal(String mtPreTotal) {
        this.mtPreTotal = mtPreTotal;
    }
    public String getPayAmount() {
        return payAmount;
    }
    public void setPayAmount(String payAmount) {
        this.payAmount = payAmount;
    }
    public String getDealTypeName() {
        return dealTypeName;
    }
    public void setDealTypeName(String dealTypeName) {
        this.dealTypeName = dealTypeName;
    }
    public String getVoucherPayFlag() {
        return voucherPayFlag;
    }
    public void setVoucherPayFlag(String voucherPayFlag) {
        this.voucherPayFlag = voucherPayFlag;
    }
    public String getBookingOrderId() {
        return bookingOrderId;
    }
    public void setBookingOrderId(String bookingOrderId) {
        this.bookingOrderId = bookingOrderId;
    }
    public String getEnterpriseOrder() {
        return enterpriseOrder;
    }
    public void setEnterpriseOrder(String enterpriseOrder) {
        this.enterpriseOrder = enterpriseOrder;
    }
    public String getNeedInvoiceFlag() {
        return needInvoiceFlag;
    }
    public void setNeedInvoiceFlag(String needInvoiceFlag) {
        this.needInvoiceFlag = needInvoiceFlag;
    }
    public String getSettleStatus() {
        return settleStatus;
    }
    public void setSettleStatus(String settleStatus) {
        this.settleStatus = settleStatus;
    }
    public String getPayment() {
        return payment;
    }
    public void setPayment(String payment) {
        this.payment = payment;
    }
    public String getPayStartTime() {
        return payStartTime;
    }
    public void setPayStartTime(String payStartTime) {
        this.payStartTime = payStartTime;
    }
    public String getMtpp() {
        return mtpp;
    }
    public void setMtpp(String mtpp) {
        this.mtpp = mtpp;
    }
    public String getPayStatus() {
        return payStatus;
    }
    public void setPayStatus(String payStatus) {
        this.payStatus = payStatus;
    }
    public String getPaySuccessTime() {
        return paySuccessTime;
    }
    public void setPaySuccessTime(String paySuccessTime) {
        this.paySuccessTime = paySuccessTime;
    }
    public String getRecvAccountName() {
        return recvAccountName;
    }
    public void setRecvAccountName(String recvAccountName) {
        this.recvAccountName = recvAccountName;
    }
    public String getPayFailReason() {
        return payFailReason;
    }
    public void setPayFailReason(String payFailReason) {
        this.payFailReason = payFailReason;
    }
    public String getMerchantPoiId() {
        return merchantPoiId;
    }
    public void setMerchantPoiId(String merchantPoiId) {
        this.merchantPoiId = merchantPoiId;
    }
    public String getMerchantPoiName() {
        return merchantPoiName;
    }
    public void setMerchantPoiName(String merchantPoiName) {
        this.merchantPoiName = merchantPoiName;
    }
    public String getIsAdvancePay() {
        return isAdvancePay;
    }
    public void setIsAdvancePay(String isAdvancePay) {
        this.isAdvancePay = isAdvancePay;
    }
    public String getPartnerOrderId() {
        return partnerOrderId;
    }
    public void setPartnerOrderId(String partnerOrderId) {
        this.partnerOrderId = partnerOrderId;
    }
    public Map getExtendInfo() {
        return extendInfo;
    }
    public void setExtendInfo(Map extendInfo) {
        this.extendInfo = extendInfo;
    }




    @Override
    public String toString() {
        return "SettleTradeDetailModel{" + "orderItemId=" + orderItemId + "," + "orderId=" + orderId + "," + "accountTime=" + accountTime + "," + "orderCreateTime=" + orderCreateTime + "," + "useTime=" + useTime + "," + "cancelTime=" + cancelTime + "," + "refundTime=" + refundTime + "," + "poiCityName=" + poiCityName + "," + "poiName=" + poiName + "," + "poiId=" + poiId + "," + "dealName=" + dealName + "," + "onlyDealName=" + onlyDealName + "," + "dealId=" + dealId + "," + "contractName=" + contractName + "," + "accountName=" + accountName + "," + "bizType=" + bizType + "," + "traceType=" + traceType + "," + "originPrice=" + originPrice + "," + "salePrice=" + salePrice + "," + "bizCost=" + bizCost + "," + "bizCostByAccount=" + bizCostByAccount + "," + "deliverDiscountFee=" + deliverDiscountFee + "," + "serviceFee=" + serviceFee + "," + "serviceFeeDiscount=" + serviceFeeDiscount + "," + "deliveryFee=" + deliveryFee + "," + "partnerSelfDeliverFee=" + partnerSelfDeliverFee + "," + "agentCommissionAmount=" + agentCommissionAmount + "," + "agentCommissionName=" + agentCommissionName + "," + "refund=" + refund + "," + "sharedAmount=" + sharedAmount + "," + "otherIncome=" + otherIncome + "," + "publicBenefitFee=" + publicBenefitFee + "," + "adFee=" + adFee + "," + "drfxFee=" + drfxFee + "," + "governmentDiscountAmount=" + governmentDiscountAmount + "," + "jyeztgAdFee=" + jyeztgAdFee + "," + "ycskAdFee=" + ycskAdFee + "," + "mtUnionOdpFee=" + mtUnionOdpFee + "," + "partnerIncome=" + partnerIncome + "," + "mtPreTotal=" + mtPreTotal + "," + "payAmount=" + payAmount + "," + "dealTypeName=" + dealTypeName + "," + "voucherPayFlag=" + voucherPayFlag + "," + "bookingOrderId=" + bookingOrderId + "," + "enterpriseOrder=" + enterpriseOrder + "," + "needInvoiceFlag=" + needInvoiceFlag + "," + "settleStatus=" + settleStatus + "," + "payment=" + payment + "," + "payStartTime=" + payStartTime + "," + "mtpp=" + mtpp + "," + "payStatus=" + payStatus + "," + "paySuccessTime=" + paySuccessTime + "," + "recvAccountName=" + recvAccountName + "," + "payFailReason=" + payFailReason + "," + "merchantPoiId=" + merchantPoiId + "," + "merchantPoiName=" + merchantPoiName + "," + "isAdvancePay=" + isAdvancePay + "," + "partnerOrderId=" + partnerOrderId + "," + "extendInfo=" + extendInfo + "}";
    }
}
