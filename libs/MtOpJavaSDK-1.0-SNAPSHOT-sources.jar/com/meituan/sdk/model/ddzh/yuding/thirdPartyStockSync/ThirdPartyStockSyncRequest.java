package com.meituan.sdk.model.ddzh.yuding.thirdPartyStockSync;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 场馆实时库存同步
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/thirdParty/stockSync",
    businessId = 58,
    apiVersion = "10053",
    apiName = "third_party_stock_sync",
    needAuth = true
)
public class ThirdPartyStockSyncRequest implements MeituanRequest<Boolean> {
    /**
    * <p data-diff-id="ct-diff-id-0467d6b7-36f1-4b6f-b21f-01a708cf53c9">库存信息</p>
    */
    @NotEmpty(message = "stockInfoList不能为空")
    @SerializedName("stockInfoList")
    private List<StockInfo> stockInfoList;
    /**
    * <p data-diff-id="ct-diff-id-e843c995-a32a-4c1a-be85-64b64d57f55b">同步的日期范围（stockInfo里的stockDate需要与此范围一一对应）</p>
    */
    @NotNull(message = "dateRange不能为空")
    @SerializedName("dateRange")
    private DateRange dateRange;

    public List<StockInfo> getStockInfoList() {
        return stockInfoList;
    }
    public void setStockInfoList(List<StockInfo> stockInfoList) {
        this.stockInfoList = stockInfoList;
    }
    public DateRange getDateRange() {
        return dateRange;
    }
    public void setDateRange(DateRange dateRange) {
        this.dateRange = dateRange;
    }


    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ThirdPartyStockSyncRequest{" + "stockInfoList=" + stockInfoList + "," + "dateRange=" + dateRange + "}";
    }
}
