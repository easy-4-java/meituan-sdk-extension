package com.meituan.sdk.model.ddzh.yuding.pricelistSubmit;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 价目表商品创建提交/编辑接口
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/pricelist/submit",
    businessId = 58,
    apiVersion = "10085",
    apiName = "pricelist_submit",
    needAuth = true
)
public class PricelistSubmitRequest implements MeituanRequest<PricelistSubmitResponse> {
    /**
    * <p data-diff-id="ct-diff-id-53b331e5-b7a8-4818-a548-5c622849cbf0">业务类型：</p><p data-diff-id="ct-diff-id-6420c185-dd68-4386-b570-3c6828476888">100088<span style="color: rgba(0, 0, 0, 0.65)">-</span>棋牌预订</p>
    */
    @NotNull(message = "bizType不能为空")
    @SerializedName("bizType")
    private Integer bizType;
    /**
    * <p data-diff-id="ct-diff-id-debbf9f9-dd58-42a4-afea-9907a9abdd63">商品分类：</p><p data-diff-id="ct-diff-id-80816146-edf2-4a8a-935a-5eae5ec58b96">2000251<span style="color: rgba(0, 0, 0, 0.87)">-棋牌行业</span></p>
    */
    @NotNull(message = "spuType不能为空")
    @SerializedName("spuType")
    private Long spuType;
    /**
    * <p data-diff-id="ct-diff-id-743921f5-20c5-4f52-9077-1f408a14f624">按固定时长房间计费规则</p>
    */
    @SerializedName("billingRules")
    private List<FixedDurationBillingRule> billingRules;

    public Integer getBizType() {
        return bizType;
    }
    public void setBizType(Integer bizType) {
        this.bizType = bizType;
    }
    public Long getSpuType() {
        return spuType;
    }
    public void setSpuType(Long spuType) {
        this.spuType = spuType;
    }
    public List<FixedDurationBillingRule> getBillingRules() {
        return billingRules;
    }
    public void setBillingRules(List<FixedDurationBillingRule> billingRules) {
        this.billingRules = billingRules;
    }


    @Override
    public MeituanResponse<PricelistSubmitResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<PricelistSubmitResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "PricelistSubmitRequest{" + "bizType=" + bizType + "," + "spuType=" + spuType + "," + "billingRules=" + billingRules + "}";
    }
}
