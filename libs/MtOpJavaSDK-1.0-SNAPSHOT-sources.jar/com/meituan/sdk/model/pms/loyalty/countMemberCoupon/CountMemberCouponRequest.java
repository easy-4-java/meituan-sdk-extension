package com.meituan.sdk.model.pms.loyalty.countMemberCoupon;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询会员优惠券数量
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/loyalty/countMemberCoupon",
    businessId = 57,
    apiVersion = "10002",
    apiName = "count_member_coupon",
    needAuth = true
)
public class CountMemberCouponRequest implements MeituanRequest<CountMemberCouponResponse> {
    /**
    * <p data-diff-id="ct-diff-id-0f24a24d-3cba-4afb-9139-51788fed7bb2">会员ID</p>
    */
    @NotNull(message = "memberId不能为空")
    @SerializedName("memberId")
    private Long memberId;
    /**
    * <p data-diff-id="ct-diff-id-cc7e4619-09a5-4430-ace6-ec6122fcdaec"><span style="color: #333">优惠券类型：1代表代金券，2代表折扣券，3代表免费券，4代表通用兑换券，5代表早餐券</span></p>
    */
    @SerializedName("couponTypes")
    private List<Integer> couponTypes;
    /**
    * <p data-diff-id="ct-diff-id-55537e80-15c8-4935-be51-7a159b6a44ad"><span style="color: #333">默认查询待使用。优惠券状态：Init---初始化，ReadyForUse---待使用，Used---已使用，Locked---已锁定，Expire---已失效</span></p>
    */
    @SerializedName("couponStatus")
    private List<String> couponStatus;

    public Long getMemberId() {
        return memberId;
    }
    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }
    public List<Integer> getCouponTypes() {
        return couponTypes;
    }
    public void setCouponTypes(List<Integer> couponTypes) {
        this.couponTypes = couponTypes;
    }
    public List<String> getCouponStatus() {
        return couponStatus;
    }
    public void setCouponStatus(List<String> couponStatus) {
        this.couponStatus = couponStatus;
    }


    @Override
    public MeituanResponse<CountMemberCouponResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<CountMemberCouponResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "CountMemberCouponRequest{" + "memberId=" + memberId + "," + "couponTypes=" + couponTypes + "," + "couponStatus=" + couponStatus + "}";
    }
}
