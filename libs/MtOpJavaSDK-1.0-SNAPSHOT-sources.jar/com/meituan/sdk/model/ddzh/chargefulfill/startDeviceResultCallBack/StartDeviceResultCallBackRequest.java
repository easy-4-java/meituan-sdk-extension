package com.meituan.sdk.model.ddzh.chargefulfill.startDeviceResultCallBack;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 启动充电设备结果回调
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/chargefulfill/startresult/callback",
    businessId = 58,
    apiVersion = "10000",
    apiName = "start_device_result_call_back",
    needAuth = true
)
public class StartDeviceResultCallBackRequest implements MeituanRequest<StartDeviceResultCallBackResponse> {
    /**
    * <p data-diff-id="ct-diff-id-3f6fbe25-a77c-4e59-962e-c7a321ed49e8">美团充电订单号</p>
    */
    @NotBlank(message = "startChargeSeq不能为空")
    @SerializedName("startChargeSeq")
    private String startChargeSeq;
    /**
    * <p data-diff-id="ct-diff-id-ae3b9df1-a885-4fdd-a100-4930557415a4">充电订单状态，1-启动中，2-启动失败，3-充电中，4-停止中，5-已结束，10-未知</p>
    */
    @SerializedName("startChargeSeqStat")
    private Integer startChargeSeqStat;
    /**
    * <p data-diff-id="ct-diff-id-2027dabd-d0e1-4c69-961b-de0d05a0a776">启动回调结果，1-成功，2-失败</p>
    */
    @NotNull(message = "result不能为空")
    @SerializedName("result")
    private Integer result;
    /**
    * <p data-diff-id="ct-diff-id-2b5a364d-9039-4878-9088-7b1d52c66dbb">充电枪接口编码</p>
    */
    @NotBlank(message = "connectorId不能为空")
    @SerializedName("connectorId")
    private String connectorId;
    /**
    * <p data-diff-id="ct-diff-id-21ce2d64-08d4-46ea-a84c-166a75170157">设备启动时间，启动成功时需要传入</p>
    */
    @SerializedName("startTime")
    private Long startTime;
    /**
    * <p data-diff-id="ct-diff-id-a2ce221a-e026-4569-b71a-f0d2f87b4ae9">用户停止充电时的验证码</p>
    */
    @SerializedName("identCode")
    private String identCode;
    /**
    * <p data-diff-id="ct-diff-id-911a4580-0a14-466d-ae19-1706b8f5a2e8">车牌号</p>
    */
    @SerializedName("licensePlate")
    private String licensePlate;
    /**
    * <p data-diff-id="ct-diff-id-ed67d35f-7465-4d65-b50f-a740e83c2de3">车辆VIN码</p>
    */
    @SerializedName("vehicleVin")
    private String vehicleVin;
    /**
    * <p data-diff-id="ct-diff-id-93e4ddc8-65b2-4bb7-a621-763b8d8bf508">启动方式，1-APP扫码，2-即插即充，3-蓝牙</p>
    */
    @SerializedName("startMethod")
    private Integer startMethod;
    /**
    * <p data-diff-id="ct-diff-id-6c65cbee-60d4-4d3e-bc8c-753d2bf7bfbf">即插即充充电状态，1-待插枪，2-已插枪，3-充电中，4-已结束</p>
    */
    @SerializedName("plugChargeStatus")
    private Integer plugChargeStatus;
    /**
    * <p data-diff-id="ct-diff-id-b8bc9997-ada4-4c79-8a73-34e8b715ca13">即插即充启动失败原因</p>
    */
    @SerializedName("plugChargeFailureReason")
    private String plugChargeFailureReason;

    public String getStartChargeSeq() {
        return startChargeSeq;
    }
    public void setStartChargeSeq(String startChargeSeq) {
        this.startChargeSeq = startChargeSeq;
    }
    public Integer getStartChargeSeqStat() {
        return startChargeSeqStat;
    }
    public void setStartChargeSeqStat(Integer startChargeSeqStat) {
        this.startChargeSeqStat = startChargeSeqStat;
    }
    public Integer getResult() {
        return result;
    }
    public void setResult(Integer result) {
        this.result = result;
    }
    public String getConnectorId() {
        return connectorId;
    }
    public void setConnectorId(String connectorId) {
        this.connectorId = connectorId;
    }
    public Long getStartTime() {
        return startTime;
    }
    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }
    public String getIdentCode() {
        return identCode;
    }
    public void setIdentCode(String identCode) {
        this.identCode = identCode;
    }
    public String getLicensePlate() {
        return licensePlate;
    }
    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }
    public String getVehicleVin() {
        return vehicleVin;
    }
    public void setVehicleVin(String vehicleVin) {
        this.vehicleVin = vehicleVin;
    }
    public Integer getStartMethod() {
        return startMethod;
    }
    public void setStartMethod(Integer startMethod) {
        this.startMethod = startMethod;
    }
    public Integer getPlugChargeStatus() {
        return plugChargeStatus;
    }
    public void setPlugChargeStatus(Integer plugChargeStatus) {
        this.plugChargeStatus = plugChargeStatus;
    }
    public String getPlugChargeFailureReason() {
        return plugChargeFailureReason;
    }
    public void setPlugChargeFailureReason(String plugChargeFailureReason) {
        this.plugChargeFailureReason = plugChargeFailureReason;
    }


    @Override
    public MeituanResponse<StartDeviceResultCallBackResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<StartDeviceResultCallBackResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "StartDeviceResultCallBackRequest{" + "startChargeSeq=" + startChargeSeq + "," + "startChargeSeqStat=" + startChargeSeqStat + "," + "result=" + result + "," + "connectorId=" + connectorId + "," + "startTime=" + startTime + "," + "identCode=" + identCode + "," + "licensePlate=" + licensePlate + "," + "vehicleVin=" + vehicleVin + "," + "startMethod=" + startMethod + "," + "plugChargeStatus=" + plugChargeStatus + "," + "plugChargeFailureReason=" + plugChargeFailureReason + "}";
    }
}
