package com.meituan.sdk.model.pms.loyalty.revokeMemberPoint;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 会员积分流水撤销
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/loyalty/revokeMemberPoint",
    businessId = 57,
    apiVersion = "10010",
    apiName = "revoke_member_point",
    needAuth = true
)
public class RevokeMemberPointRequest implements MeituanRequest<Long> {
    /**
    * <p data-diff-id="ct-diff-id-591dd4a5-3505-423f-b9c3-a437228c2b65">积分来源门店，集团总部请填写0</p>
    */
    @NotNull(message = "pointHotelId不能为空")
    @SerializedName("pointHotelId")
    private Long pointHotelId;
    /**
    * <p data-diff-id="ct-diff-id-a3228fa6-436a-43bb-bc28-4e521816f61e"><span style="color: #333">积分流水ID</span></p>
    */
    @NotNull(message = "pointTransactionId不能为空")
    @SerializedName("pointTransactionId")
    private Long pointTransactionId;
    /**
    * <p data-diff-id="ct-diff-id-8ffd60f3-2e6d-442b-86dd-d5b38e53c32f">备注</p>
    */
    @NotBlank(message = "remark不能为空")
    @SerializedName("remark")
    private String remark;

    public Long getPointHotelId() {
        return pointHotelId;
    }
    public void setPointHotelId(Long pointHotelId) {
        this.pointHotelId = pointHotelId;
    }
    public Long getPointTransactionId() {
        return pointTransactionId;
    }
    public void setPointTransactionId(Long pointTransactionId) {
        this.pointTransactionId = pointTransactionId;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }


    @Override
    public MeituanResponse<Long> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Long>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "RevokeMemberPointRequest{" + "pointHotelId=" + pointHotelId + "," + "pointTransactionId=" + pointTransactionId + "," + "remark=" + remark + "}";
    }
}
