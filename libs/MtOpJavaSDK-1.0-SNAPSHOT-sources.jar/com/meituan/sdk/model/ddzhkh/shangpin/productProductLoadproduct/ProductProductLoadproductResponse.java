package com.meituan.sdk.model.ddzhkh.shangpin.productProductLoadproduct;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 查询商品信息
* This file was automatically generated.
*/
public class ProductProductLoadproductResponse {
    /**
    * 美团商品ID
    */
    @SerializedName("productId")
    private Long productId;
    /**
    * 美团商品名称
    */
    @SerializedName("productName")
    private String productName;
    /**
    * 三方商品ID
    */
    @SerializedName("appProductId")
    private String appProductId;
    /**
    * 美团商品品类列表，三方需确定要接入商品品类和品类ID，例如体检预订[100016,735]
    */
    @SerializedName("categoryIds")
    private List<Long> categoryIds;
    /**
    * 美团店铺ID列表
    */
    @SerializedName("opPoiIds")
    private List<String> opPoiIds;
    /**
    * 商品属性，业务参考属性文档,字典参考「创建商品」接口商品属性文档
    */
    @SerializedName("attributes")
    private String attributes;
    /**
    * 商品的流程状态，10-编辑中，12-已提交，20-审核中，22-审核通过，24-审核驳回，30-已发布 
    */
    @SerializedName("flowStatus")
    private Integer flowStatus;
    /**
    * 售卖SKU列表，注：类型为对象类型
    */
    @SerializedName("items")
    private List<Item> items;
    /**
    * 商品上下架状态
    */
    @SerializedName("status")
    private Integer status;

    public Long getProductId() {
        return productId;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public String getAppProductId() {
        return appProductId;
    }
    public void setAppProductId(String appProductId) {
        this.appProductId = appProductId;
    }
    public List<Long> getCategoryIds() {
        return categoryIds;
    }
    public void setCategoryIds(List<Long> categoryIds) {
        this.categoryIds = categoryIds;
    }
    public List<String> getOpPoiIds() {
        return opPoiIds;
    }
    public void setOpPoiIds(List<String> opPoiIds) {
        this.opPoiIds = opPoiIds;
    }
    public String getAttributes() {
        return attributes;
    }
    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }
    public Integer getFlowStatus() {
        return flowStatus;
    }
    public void setFlowStatus(Integer flowStatus) {
        this.flowStatus = flowStatus;
    }
    public List<Item> getItems() {
        return items;
    }
    public void setItems(List<Item> items) {
        this.items = items;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }




    @Override
    public String toString() {
        return "ProductProductLoadproductResponse{" + "productId=" + productId + "," + "productName=" + productName + "," + "appProductId=" + appProductId + "," + "categoryIds=" + categoryIds + "," + "opPoiIds=" + opPoiIds + "," + "attributes=" + attributes + "," + "flowStatus=" + flowStatus + "," + "items=" + items + "," + "status=" + status + "}";
    }
}
