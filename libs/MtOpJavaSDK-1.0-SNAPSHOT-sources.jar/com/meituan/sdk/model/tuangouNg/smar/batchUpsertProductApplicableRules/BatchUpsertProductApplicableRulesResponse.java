package com.meituan.sdk.model.tuangouNg.smar.batchUpsertProductApplicableRules;


/**
* 批量上传/更新团购映射/代金券适用规则
* This file was automatically generated.
*/
public class BatchUpsertProductApplicableRulesResponse {





}
