package com.meituan.sdk.model.pms.tmc.queryHotelProducts;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 取消规则
* This file was automatically generated.
*/
public class TMCCancelRuleDTO {
    /**
    * 取消类型 FREE_CANCEL-免费取消 FREE_CANCEL_BEFORE_TIME-限时免费取消 NON_CANCELLABLE-不可取消
    */
    @SerializedName("cancelType")
    private String cancelType;
    /**
    * 取消规则费用项
    */
    @SerializedName("chargeList")
    private List<TMCCancelChargeDTO> chargeList;

    public String getCancelType() {
        return cancelType;
    }
    public void setCancelType(String cancelType) {
        this.cancelType = cancelType;
    }
    public List<TMCCancelChargeDTO> getChargeList() {
        return chargeList;
    }
    public void setChargeList(List<TMCCancelChargeDTO> chargeList) {
        this.chargeList = chargeList;
    }




    @Override
    public String toString() {
        return "TMCCancelRuleDTO{" + "cancelType=" + cancelType + "," + "chargeList=" + chargeList + "}";
    }
}
