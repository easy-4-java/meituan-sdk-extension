package com.meituan.sdk.model.resv2.table.tableUpdate;


/**
* 预订上传桌台
* This file was automatically generated.
*/
public class TableUpdateResponse {





}
