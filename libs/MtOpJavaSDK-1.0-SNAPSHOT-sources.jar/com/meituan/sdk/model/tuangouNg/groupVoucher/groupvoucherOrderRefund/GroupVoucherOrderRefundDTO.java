package com.meituan.sdk.model.tuangouNg.groupVoucher.groupvoucherOrderRefund;


/**
* null
* This file was automatically generated.
*/
public class GroupVoucherOrderRefundDTO {





}
