package com.meituan.sdk.model.waimaiNg.dish.listMarketPlaces;

import com.google.gson.annotations.SerializedName;

/**
* 场域数据
* This file was automatically generated.
*/
public class MarketplaceData {
    /**
    * 场域标识
    */
    @SerializedName("marketplaceId")
    private String marketplaceId;
    /**
    * 场域名称
    */
    @SerializedName("name")
    private String name;

    public String getMarketplaceId() {
        return marketplaceId;
    }
    public void setMarketplaceId(String marketplaceId) {
        this.marketplaceId = marketplaceId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }




    @Override
    public String toString() {
        return "MarketplaceData{" + "marketplaceId=" + marketplaceId + "," + "name=" + name + "}";
    }
}
