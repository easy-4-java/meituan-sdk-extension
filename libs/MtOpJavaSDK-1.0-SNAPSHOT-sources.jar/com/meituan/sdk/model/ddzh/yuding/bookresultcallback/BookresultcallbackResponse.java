package com.meituan.sdk.model.ddzh.yuding.bookresultcallback;

import com.google.gson.annotations.SerializedName;

/**
* 预订结果回调
* This file was automatically generated.
*/
public class BookresultcallbackResponse {
    /**
    * 平台订单id
    */
    @SerializedName("orderId")
    private String orderId;

    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }




    @Override
    public String toString() {
        return "BookresultcallbackResponse{" + "orderId=" + orderId + "}";
    }
}
