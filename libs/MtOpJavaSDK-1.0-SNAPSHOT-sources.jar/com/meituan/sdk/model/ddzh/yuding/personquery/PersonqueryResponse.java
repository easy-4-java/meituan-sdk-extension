package com.meituan.sdk.model.ddzh.yuding.personquery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 查询绑定在门店下的服务人员信息
* This file was automatically generated.
*/
public class PersonqueryResponse {
    /**
    * 记录总数
    */
    @SerializedName("total")
    private Long total;
    /**
    * 人员信息列表 注：类型为对象类型，详见扩展参数technicians
    */
    @SerializedName("technicians")
    private List<Technician> technicians;

    public Long getTotal() {
        return total;
    }
    public void setTotal(Long total) {
        this.total = total;
    }
    public List<Technician> getTechnicians() {
        return technicians;
    }
    public void setTechnicians(List<Technician> technicians) {
        this.technicians = technicians;
    }




    @Override
    public String toString() {
        return "PersonqueryResponse{" + "total=" + total + "," + "technicians=" + technicians + "}";
    }
}
