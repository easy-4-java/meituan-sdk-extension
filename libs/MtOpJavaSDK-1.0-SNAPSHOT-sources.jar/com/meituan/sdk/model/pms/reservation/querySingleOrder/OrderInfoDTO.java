package com.meituan.sdk.model.pms.reservation.querySingleOrder;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 订单详情
* This file was automatically generated.
*/
public class OrderInfoDTO {
    /**
    * 酒店ID
    */
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * 订单ID
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * 订单编号
    */
    @SerializedName("orderSn")
    private String orderSn;
    /**
    * 账套ID
    */
    @SerializedName("billId")
    private Long billId;
    /**
    * 客源类别，详见CustomerCategory字典
    */
    @SerializedName("customerCategory")
    private EnumDTO customerCategory;
    /**
    * 订单来源
    */
    @SerializedName("orderSource")
    private EnumDTO orderSource;
    /**
    * 入住类型，详见CheckinType字典
    */
    @SerializedName("checkinType")
    private EnumDTO checkinType;
    /**
    * 订单状态
    */
    @SerializedName("orderStatus")
    private EnumDTO orderStatus;
    /**
    * 预抵时间，格式yyyy-MM-dd HH:mm:ss
    */
    @SerializedName("estimatedArriveTime")
    private String estimatedArriveTime;
    /**
    * 预计离店时间
    */
    @SerializedName("estimatedDepartureTime")
    private String estimatedDepartureTime;
    /**
    * 预离时间，格式yyyy-MM-dd HH:mm:ss
    */
    @SerializedName("actualArriveTime")
    private String actualArriveTime;
    /**
    * 备注
    */
    @SerializedName("memo")
    private String memo;
    /**
    * 渠道备注
    */
    @SerializedName("channelMemo")
    private String channelMemo;
    /**
    * 渠道
    */
    @SerializedName("channel")
    private String channel;
    /**
    * 预付类型
    */
    @SerializedName("prePaymentType")
    private EnumDTO prePaymentType;
    /**
    * 市场活动ID
    */
    @SerializedName("promotionId")
    private String promotionId;
    /**
    * 是否锁单
    */
    @SerializedName("locked")
    private Boolean locked;
    /**
    * 取消原因
    */
    @SerializedName("cancelReason")
    private String cancelReason;
    /**
    * 联系人信息
    */
    @SerializedName("liaisons")
    private List<LiaisonDTO> liaisons;
    /**
    * 最晚保留时间
    */
    @SerializedName("expireKeepTime")
    private String expireKeepTime;
    /**
    * 创建时间
    */
    @SerializedName("createTime")
    private String createTime;
    /**
    * 会员ID
    */
    @SerializedName("memberId")
    private String memberId;
    /**
    * 协议公司ID
    */
    @SerializedName("contractorId")
    private String contractorId;
    /**
    * 渠道订单号
    */
    @SerializedName("channelOrderSn")
    private String channelOrderSn;
    /**
    * 定价人（会员信息）
    */
    @SerializedName("orderBuyerMember")
    private OrderCustomerDTO orderBuyerMember;
    /**
    * 定价人（中介或协议公司信息）
    */
    @SerializedName("orderBuyerContractor")
    private OrderContractorDTO orderBuyerContractor;
    /**
    * 占房信息
    */
    @SerializedName("occupations")
    private List<OccupationDTO> occupations;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getOrderSn() {
        return orderSn;
    }
    public void setOrderSn(String orderSn) {
        this.orderSn = orderSn;
    }
    public Long getBillId() {
        return billId;
    }
    public void setBillId(Long billId) {
        this.billId = billId;
    }
    public EnumDTO getCustomerCategory() {
        return customerCategory;
    }
    public void setCustomerCategory(EnumDTO customerCategory) {
        this.customerCategory = customerCategory;
    }
    public EnumDTO getOrderSource() {
        return orderSource;
    }
    public void setOrderSource(EnumDTO orderSource) {
        this.orderSource = orderSource;
    }
    public EnumDTO getCheckinType() {
        return checkinType;
    }
    public void setCheckinType(EnumDTO checkinType) {
        this.checkinType = checkinType;
    }
    public EnumDTO getOrderStatus() {
        return orderStatus;
    }
    public void setOrderStatus(EnumDTO orderStatus) {
        this.orderStatus = orderStatus;
    }
    public String getEstimatedArriveTime() {
        return estimatedArriveTime;
    }
    public void setEstimatedArriveTime(String estimatedArriveTime) {
        this.estimatedArriveTime = estimatedArriveTime;
    }
    public String getEstimatedDepartureTime() {
        return estimatedDepartureTime;
    }
    public void setEstimatedDepartureTime(String estimatedDepartureTime) {
        this.estimatedDepartureTime = estimatedDepartureTime;
    }
    public String getActualArriveTime() {
        return actualArriveTime;
    }
    public void setActualArriveTime(String actualArriveTime) {
        this.actualArriveTime = actualArriveTime;
    }
    public String getMemo() {
        return memo;
    }
    public void setMemo(String memo) {
        this.memo = memo;
    }
    public String getChannelMemo() {
        return channelMemo;
    }
    public void setChannelMemo(String channelMemo) {
        this.channelMemo = channelMemo;
    }
    public String getChannel() {
        return channel;
    }
    public void setChannel(String channel) {
        this.channel = channel;
    }
    public EnumDTO getPrePaymentType() {
        return prePaymentType;
    }
    public void setPrePaymentType(EnumDTO prePaymentType) {
        this.prePaymentType = prePaymentType;
    }
    public String getPromotionId() {
        return promotionId;
    }
    public void setPromotionId(String promotionId) {
        this.promotionId = promotionId;
    }
    public Boolean getLocked() {
        return locked;
    }
    public void setLocked(Boolean locked) {
        this.locked = locked;
    }
    public String getCancelReason() {
        return cancelReason;
    }
    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }
    public List<LiaisonDTO> getLiaisons() {
        return liaisons;
    }
    public void setLiaisons(List<LiaisonDTO> liaisons) {
        this.liaisons = liaisons;
    }
    public String getExpireKeepTime() {
        return expireKeepTime;
    }
    public void setExpireKeepTime(String expireKeepTime) {
        this.expireKeepTime = expireKeepTime;
    }
    public String getCreateTime() {
        return createTime;
    }
    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }
    public String getMemberId() {
        return memberId;
    }
    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
    public String getContractorId() {
        return contractorId;
    }
    public void setContractorId(String contractorId) {
        this.contractorId = contractorId;
    }
    public String getChannelOrderSn() {
        return channelOrderSn;
    }
    public void setChannelOrderSn(String channelOrderSn) {
        this.channelOrderSn = channelOrderSn;
    }
    public OrderCustomerDTO getOrderBuyerMember() {
        return orderBuyerMember;
    }
    public void setOrderBuyerMember(OrderCustomerDTO orderBuyerMember) {
        this.orderBuyerMember = orderBuyerMember;
    }
    public OrderContractorDTO getOrderBuyerContractor() {
        return orderBuyerContractor;
    }
    public void setOrderBuyerContractor(OrderContractorDTO orderBuyerContractor) {
        this.orderBuyerContractor = orderBuyerContractor;
    }
    public List<OccupationDTO> getOccupations() {
        return occupations;
    }
    public void setOccupations(List<OccupationDTO> occupations) {
        this.occupations = occupations;
    }




    @Override
    public String toString() {
        return "OrderInfoDTO{" + "hotelId=" + hotelId + "," + "orderId=" + orderId + "," + "orderSn=" + orderSn + "," + "billId=" + billId + "," + "customerCategory=" + customerCategory + "," + "orderSource=" + orderSource + "," + "checkinType=" + checkinType + "," + "orderStatus=" + orderStatus + "," + "estimatedArriveTime=" + estimatedArriveTime + "," + "estimatedDepartureTime=" + estimatedDepartureTime + "," + "actualArriveTime=" + actualArriveTime + "," + "memo=" + memo + "," + "channelMemo=" + channelMemo + "," + "channel=" + channel + "," + "prePaymentType=" + prePaymentType + "," + "promotionId=" + promotionId + "," + "locked=" + locked + "," + "cancelReason=" + cancelReason + "," + "liaisons=" + liaisons + "," + "expireKeepTime=" + expireKeepTime + "," + "createTime=" + createTime + "," + "memberId=" + memberId + "," + "contractorId=" + contractorId + "," + "channelOrderSn=" + channelOrderSn + "," + "orderBuyerMember=" + orderBuyerMember + "," + "orderBuyerContractor=" + orderBuyerContractor + "," + "occupations=" + occupations + "}";
    }
}
