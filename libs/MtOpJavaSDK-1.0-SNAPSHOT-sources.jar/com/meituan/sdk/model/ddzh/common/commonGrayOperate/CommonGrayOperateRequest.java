package com.meituan.sdk.model.ddzh.common.commonGrayOperate;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 服务零售自定义灰度
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/common/virtualnum/gray/create",
    businessId = 58,
    apiVersion = "10005",
    apiName = "common_gray_operate",
    needAuth = false
)
public class CommonGrayOperateRequest implements MeituanRequest<CommonGrayOperateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-e1631fc5-a227-4306-a91e-ebafdec34591"><span style="color: ">灰度ID，开发者维度时非必传，最多100个</span></p>
    */
    @SerializedName("grayConfigIds")
    private List<String> grayConfigIds;
    /**
    * <p data-diff-id="ct-diff-id-523c597a-3a4c-4cc0-a6df-2eab01e6db02"><span style="color: ">设置灰度或不灰度(1-灰度关闭，2灰度开启)</span></p>
    */
    @NotNull(message = "grayStatus不能为空")
    @SerializedName("grayStatus")
    private Integer grayStatus;
    /**
    * <p data-diff-id="ct-diff-id-dd7d6cee-5bfb-439b-8e93-4cdcbd2b769e"><span style="color: ">业务类型(1-门店，2-开发者)</span></p>
    */
    @NotNull(message = "grayType不能为空")
    @SerializedName("grayType")
    private Integer grayType;
    /**
    * <p data-diff-id="ct-diff-id-16448830-1a6e-424b-97ff-cf77ac1ee38f">灰度业务类型：</p><p data-diff-id="ct-diff-id-d0d75043-6108-40c1-85b7-4f9d7fcc1133"><span style="color: rgb(6, 125, 23)">virtual_num ： 隐私号业务</span></p>
    */
    @NotBlank(message = "businessType不能为空")
    @SerializedName("businessType")
    private String businessType;

    public List<String> getGrayConfigIds() {
        return grayConfigIds;
    }
    public void setGrayConfigIds(List<String> grayConfigIds) {
        this.grayConfigIds = grayConfigIds;
    }
    public Integer getGrayStatus() {
        return grayStatus;
    }
    public void setGrayStatus(Integer grayStatus) {
        this.grayStatus = grayStatus;
    }
    public Integer getGrayType() {
        return grayType;
    }
    public void setGrayType(Integer grayType) {
        this.grayType = grayType;
    }
    public String getBusinessType() {
        return businessType;
    }
    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }


    @Override
    public MeituanResponse<CommonGrayOperateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<CommonGrayOperateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "CommonGrayOperateRequest{" + "grayConfigIds=" + grayConfigIds + "," + "grayStatus=" + grayStatus + "," + "grayType=" + grayType + "," + "businessType=" + businessType + "}";
    }
}
