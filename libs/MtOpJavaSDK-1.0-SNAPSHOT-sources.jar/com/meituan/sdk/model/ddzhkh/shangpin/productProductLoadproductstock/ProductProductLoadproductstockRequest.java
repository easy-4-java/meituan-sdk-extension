package com.meituan.sdk.model.ddzhkh.shangpin.productProductLoadproductstock;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 查询商品库存信息
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/shangpin/product/loadproductstock",
    businessId = 59,
    apiVersion = "10117",
    apiName = "product_product_loadproductstock",
    needAuth = true
)
public class ProductProductLoadproductstockRequest implements MeituanRequest<ProductProductLoadproductstockResponse> {
    /**
    * <p data-diff-id="ct-diff-id-078286a5-a345-4514-9624-69dc9b99ceec">商品ID</p>
    */
    @NotNull(message = "productId不能为空")
    @SerializedName("productId")
    private Long productId;
    /**
    * <p data-diff-id="ct-diff-id-483ca6aa-ae6e-48ca-bd0d-9853f2907682">门店ID列表</p>
    */
    @NotEmpty(message = "opPoiIds不能为空")
    @SerializedName("opPoiIds")
    private List<String> opPoiIds;

    public Long getProductId() {
        return productId;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }
    public List<String> getOpPoiIds() {
        return opPoiIds;
    }
    public void setOpPoiIds(List<String> opPoiIds) {
        this.opPoiIds = opPoiIds;
    }


    @Override
    public MeituanResponse<ProductProductLoadproductstockResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ProductProductLoadproductstockResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ProductProductLoadproductstockRequest{" + "productId=" + productId + "," + "opPoiIds=" + opPoiIds + "}";
    }
}
