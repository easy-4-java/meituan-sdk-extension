package com.meituan.sdk.model.ddzhkh.generalreserve.generalreserveReserveModifyconfirm;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 改约回调接口-改约结果确认
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/generalreserve/reserve/modifyconfirm",
    businessId = 59,
    apiVersion = "10003",
    apiName = "generalreserve_reserve_modifyconfirm",
    needAuth = true
)
public class GeneralreserveReserveModifyconfirmRequest implements MeituanRequest<GeneralreserveReserveModifyconfirmResponse> {
    /**
    * <p data-diff-id="ct-diff-id-c6078359-7aea-4203-b6c9-1fdc6babd259"><span style="color: rgb(31, 45, 61)">预约单id</span></p>
    */
    @NotNull(message = "leadsId不能为空")
    @SerializedName("leadsId")
    private Long leadsId;
    /**
    * <p data-diff-id="ct-diff-id-c693f017-08b7-4f66-90f4-d7cc6d7f818a"><span style="color: ">美团门店id</span></p><p data-diff-id="ct-diff-id-ae013713-e166-4dd6-bacf-f8122ce339b4"><span style="color: rgba(0, 0, 0, 0.87)">该字段是混淆字段，实际值类型为混淆后的字符串类型</span></p>
    */
    @NotBlank(message = "opPoiId不能为空")
    @SerializedName("opPoiId")
    private String opPoiId;
    /**
    * <p data-diff-id="ct-diff-id-732c36bb-9b9f-4446-b300-41d553db43e3"><span style="color: rgb(31, 45, 61)">接单结果：1.同意改约 2.拒绝改约</span></p>
    */
    @NotNull(message = "result不能为空")
    @SerializedName("result")
    private Integer result;
    /**
    * <p data-diff-id="ct-diff-id-4a5191e2-5c00-4fbf-8854-f1b66cd86daa"><span style="color: rgb(31, 45, 61)">附加字段</span></p>
    */
    @SerializedName("extraMap")
    private String extraMap;

    public Long getLeadsId() {
        return leadsId;
    }
    public void setLeadsId(Long leadsId) {
        this.leadsId = leadsId;
    }
    public String getOpPoiId() {
        return opPoiId;
    }
    public void setOpPoiId(String opPoiId) {
        this.opPoiId = opPoiId;
    }
    public Integer getResult() {
        return result;
    }
    public void setResult(Integer result) {
        this.result = result;
    }
    public String getExtraMap() {
        return extraMap;
    }
    public void setExtraMap(String extraMap) {
        this.extraMap = extraMap;
    }


    @Override
    public MeituanResponse<GeneralreserveReserveModifyconfirmResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<GeneralreserveReserveModifyconfirmResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GeneralreserveReserveModifyconfirmRequest{" + "leadsId=" + leadsId + "," + "opPoiId=" + opPoiId + "," + "result=" + result + "," + "extraMap=" + extraMap + "}";
    }
}
