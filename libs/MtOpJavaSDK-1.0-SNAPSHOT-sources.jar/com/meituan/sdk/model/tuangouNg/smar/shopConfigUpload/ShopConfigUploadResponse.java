package com.meituan.sdk.model.tuangouNg.smar.shopConfigUpload;


/**
* 门店配置上传【必接】
* This file was automatically generated.
*/
public class ShopConfigUploadResponse {





}
