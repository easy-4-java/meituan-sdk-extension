package com.meituan.sdk.model.dishconnect.settle.queryByPage;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 扩展信息
* This file was automatically generated.
*/
public class ExtendInfo {
    /**
    * 服务费率，保留4位小数  bizType=40点餐必传，单位1，保留4位小数。如0.0060表示千分之六的费率  bizType=10团购,actType=70阶梯次卡结算差额时为佣金率,多张券码的佣金率一致。
    */
    @SerializedName("serviceFeeRate")
    private String serviceFeeRate;
    /**
    * 团购券抵扣金额，单位元，保留两位小数  bizType=40点餐必传，即美团团购券（含代金券、套餐券）在该笔点餐订单中总计抵扣掉的金额，actType为10消费时为正数，20撤销消费为负数
    */
    @SerializedName("couponExchangeAmount")
    private String couponExchangeAmount;
    /**
    * 美团订单号  bizType=10且券码用于点餐必传，即美团系统内点餐订单号  bizType=10且券码用于团购配送必传，即美团系统内订单号
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * 当bizType=10且用于团购配送必传，预约单单号
    */
    @SerializedName("bookingOrderId")
    private String bookingOrderId;
    /**
    * 当bizType=10且用于团购配送必传，打包服务费，单位为分
    */
    @SerializedName("packageFee")
    private String packageFee;
    /**
    * 当bizType=10且用于团购配送必传，打包技术服务费，单位为分
    */
    @SerializedName("packingMtFee")
    private String packingMtFee;
    /**
    * 当bizType=10且为团购配送时，deliverType=1美团配送时，必传，指商户需要承担的配送费，单位分
    */
    @SerializedName("deliveryFee")
    private String deliveryFee;
    /**
    * 当bizType=10且用于团购配送必传，商家承担促销费-配送费减免，单位分
    */
    @SerializedName("deliverDiscountFee")
    private String deliverDiscountFee;
    /**
    * 当bizType=10且用于团购配送必传，deliverType=商家自配2时，必传，指用户支付的配送费  deliverType=美团配送1，则该字段为0.00，单位分
    */
    @SerializedName("partnerSelfDeliverFee")
    private String partnerSelfDeliverFee;
    /**
    * 当bizType=10时且用于团购配送必传，美团配送为1 或者 商家自配为2
    */
    @SerializedName("deliverType")
    private Integer deliverType;
    /**
    * 次卡类型，条件性必填项，  1普通团购，2阶梯次卡
    */
    @SerializedName("timesCardType")
    private Integer timesCardType;
    /**
    * 本次次数，涉及阶梯次卡未消费退的券码数量  【serialNum字段的元素数量】  条件性必填项，当TimesCardType=2，且AcType=70必填。  比如序号2和序号3未消费退，次数是2次，非零整数
    */
    @SerializedName("times")
    private Integer times;
    /**
    * 阶梯次卡-未消费退-券码序号列表 条件性必填项，当TimesCardType=2，且AcType=70必填。
    */
    @SerializedName("serialNum")
    private List<Integer> serialNum;
    /**
    * 在线点订单对应团购应收金额，bizType=40 必传  订单中关联的团购券对应的商家应收金额，在团购业务中单独结算，团购应收=团购售价-团购商家承担促销费
    */
    @SerializedName("couponReceivableAmount")
    private String couponReceivableAmount;
    /**
    * 合作商商业支持费用，单位元，保留两位小数  合作商商业支持费用=（券售价-商家优惠）*商业支持费率  bizType=10团购  bizType=20买单
    */
    @SerializedName("agentCommissionAmount")
    private String agentCommissionAmount;
    /**
    * bizType=40（点餐）必传  秒提卖价，单位元，保留两位小数  团购抵扣后剩余的秒提订单原价  公式=秒提商品总售卖价-团购券抵扣面值  消费流水为正数，已消费退流水为负数
    */
    @SerializedName("mopOrderSaleAmount")
    private String mopOrderSaleAmount;
    /**
    * bizType=40（点餐）必传  秒提商家承担，单位元，保留两位小数  商家承担的秒提产品促销费，不限于单品特价、优惠券（商家出资的满减、折扣、一口价）等
    */
    @SerializedName("mopVendorPreTotalAmount")
    private String mopVendorPreTotalAmount;
    /**
    * bizType=40（点餐）必传  秒提商家收入，单位元，保留两位小数  秒提商家应收=秒提卖价-秒提商家营销，也可以描述：秒提商家应收=订单原价-团购应收-商家承担
    */
    @SerializedName("mopVendorReceivableAmount")
    private String mopVendorReceivableAmount;
    /**
    * bizType=10（团购）必传  安心吃保险费用
    */
    @SerializedName("insuranceAmount")
    private String insuranceAmount;
    /**
    * bizType=10（团购）必传  公益捐款
    */
    @SerializedName("publicBenefitFee")
    private String publicBenefitFee;
    /**
    * bizType=10（团购）非必传（当下单渠道为美团企业版时）  1: 大票模式 商家向美团开票  2: 小票模式 商家直接向用户开票
    */
    @SerializedName("invoiceFlag")
    private Integer invoiceFlag;
    /**
    * 远程锁客节省转推广费（当前仅支持团购业务的消费结算）  远程锁客接入智能引流活动后，节省商家补贴转入广告侧专属流量账户的资金。  单位元，保留两位小数
    */
    @SerializedName("ycskAdFee")
    private String ycskAdFee;
    /**
    * bizType=10（团购）必传，秒提上翻团购品字段标识  0：默认值（历史数据标识），1：非秒提上翻品 ，2：秒提上翻品
    */
    @SerializedName("productCreateType")
    private Integer productCreateType;
    /**
    * 达人分销服务费，单位元，保留两位小数 bizType=10团购美团码，商家开通达人直播活动产生的费用
    */
    @SerializedName("drfxFee")
    private String drfxFee;
    /**
    * 渠道推广服务费，单位元，保留两位小数 bizType=10团购美团码，商家开通美团联盟渠道推广产生的费用
    */
    @SerializedName("mtUnionOdpFee")
    private String mtUnionOdpFee;

    public String getServiceFeeRate() {
        return serviceFeeRate;
    }
    public void setServiceFeeRate(String serviceFeeRate) {
        this.serviceFeeRate = serviceFeeRate;
    }
    public String getCouponExchangeAmount() {
        return couponExchangeAmount;
    }
    public void setCouponExchangeAmount(String couponExchangeAmount) {
        this.couponExchangeAmount = couponExchangeAmount;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getBookingOrderId() {
        return bookingOrderId;
    }
    public void setBookingOrderId(String bookingOrderId) {
        this.bookingOrderId = bookingOrderId;
    }
    public String getPackageFee() {
        return packageFee;
    }
    public void setPackageFee(String packageFee) {
        this.packageFee = packageFee;
    }
    public String getPackingMtFee() {
        return packingMtFee;
    }
    public void setPackingMtFee(String packingMtFee) {
        this.packingMtFee = packingMtFee;
    }
    public String getDeliveryFee() {
        return deliveryFee;
    }
    public void setDeliveryFee(String deliveryFee) {
        this.deliveryFee = deliveryFee;
    }
    public String getDeliverDiscountFee() {
        return deliverDiscountFee;
    }
    public void setDeliverDiscountFee(String deliverDiscountFee) {
        this.deliverDiscountFee = deliverDiscountFee;
    }
    public String getPartnerSelfDeliverFee() {
        return partnerSelfDeliverFee;
    }
    public void setPartnerSelfDeliverFee(String partnerSelfDeliverFee) {
        this.partnerSelfDeliverFee = partnerSelfDeliverFee;
    }
    public Integer getDeliverType() {
        return deliverType;
    }
    public void setDeliverType(Integer deliverType) {
        this.deliverType = deliverType;
    }
    public Integer getTimesCardType() {
        return timesCardType;
    }
    public void setTimesCardType(Integer timesCardType) {
        this.timesCardType = timesCardType;
    }
    public Integer getTimes() {
        return times;
    }
    public void setTimes(Integer times) {
        this.times = times;
    }
    public List<Integer> getSerialNum() {
        return serialNum;
    }
    public void setSerialNum(List<Integer> serialNum) {
        this.serialNum = serialNum;
    }
    public String getCouponReceivableAmount() {
        return couponReceivableAmount;
    }
    public void setCouponReceivableAmount(String couponReceivableAmount) {
        this.couponReceivableAmount = couponReceivableAmount;
    }
    public String getAgentCommissionAmount() {
        return agentCommissionAmount;
    }
    public void setAgentCommissionAmount(String agentCommissionAmount) {
        this.agentCommissionAmount = agentCommissionAmount;
    }
    public String getMopOrderSaleAmount() {
        return mopOrderSaleAmount;
    }
    public void setMopOrderSaleAmount(String mopOrderSaleAmount) {
        this.mopOrderSaleAmount = mopOrderSaleAmount;
    }
    public String getMopVendorPreTotalAmount() {
        return mopVendorPreTotalAmount;
    }
    public void setMopVendorPreTotalAmount(String mopVendorPreTotalAmount) {
        this.mopVendorPreTotalAmount = mopVendorPreTotalAmount;
    }
    public String getMopVendorReceivableAmount() {
        return mopVendorReceivableAmount;
    }
    public void setMopVendorReceivableAmount(String mopVendorReceivableAmount) {
        this.mopVendorReceivableAmount = mopVendorReceivableAmount;
    }
    public String getInsuranceAmount() {
        return insuranceAmount;
    }
    public void setInsuranceAmount(String insuranceAmount) {
        this.insuranceAmount = insuranceAmount;
    }
    public String getPublicBenefitFee() {
        return publicBenefitFee;
    }
    public void setPublicBenefitFee(String publicBenefitFee) {
        this.publicBenefitFee = publicBenefitFee;
    }
    public Integer getInvoiceFlag() {
        return invoiceFlag;
    }
    public void setInvoiceFlag(Integer invoiceFlag) {
        this.invoiceFlag = invoiceFlag;
    }
    public String getYcskAdFee() {
        return ycskAdFee;
    }
    public void setYcskAdFee(String ycskAdFee) {
        this.ycskAdFee = ycskAdFee;
    }
    public Integer getProductCreateType() {
        return productCreateType;
    }
    public void setProductCreateType(Integer productCreateType) {
        this.productCreateType = productCreateType;
    }
    public String getDrfxFee() {
        return drfxFee;
    }
    public void setDrfxFee(String drfxFee) {
        this.drfxFee = drfxFee;
    }
    public String getMtUnionOdpFee() {
        return mtUnionOdpFee;
    }
    public void setMtUnionOdpFee(String mtUnionOdpFee) {
        this.mtUnionOdpFee = mtUnionOdpFee;
    }




    @Override
    public String toString() {
        return "ExtendInfo{" + "serviceFeeRate=" + serviceFeeRate + "," + "couponExchangeAmount=" + couponExchangeAmount + "," + "orderId=" + orderId + "," + "bookingOrderId=" + bookingOrderId + "," + "packageFee=" + packageFee + "," + "packingMtFee=" + packingMtFee + "," + "deliveryFee=" + deliveryFee + "," + "deliverDiscountFee=" + deliverDiscountFee + "," + "partnerSelfDeliverFee=" + partnerSelfDeliverFee + "," + "deliverType=" + deliverType + "," + "timesCardType=" + timesCardType + "," + "times=" + times + "," + "serialNum=" + serialNum + "," + "couponReceivableAmount=" + couponReceivableAmount + "," + "agentCommissionAmount=" + agentCommissionAmount + "," + "mopOrderSaleAmount=" + mopOrderSaleAmount + "," + "mopVendorPreTotalAmount=" + mopVendorPreTotalAmount + "," + "mopVendorReceivableAmount=" + mopVendorReceivableAmount + "," + "insuranceAmount=" + insuranceAmount + "," + "publicBenefitFee=" + publicBenefitFee + "," + "invoiceFlag=" + invoiceFlag + "," + "ycskAdFee=" + ycskAdFee + "," + "productCreateType=" + productCreateType + "," + "drfxFee=" + drfxFee + "," + "mtUnionOdpFee=" + mtUnionOdpFee + "}";
    }
}
