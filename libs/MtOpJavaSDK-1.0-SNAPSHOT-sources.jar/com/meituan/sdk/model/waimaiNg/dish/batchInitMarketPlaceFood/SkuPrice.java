package com.meituan.sdk.model.waimaiNg.dish.batchInitMarketPlaceFood;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-f7cb9d85-9ee1-4e88-bcbd-832ec7d20581">价格模型</p>
* This file was automatically generated.
*/
public class SkuPrice {
    /**
    * <p data-diff-id="ct-diff-id-10583c61-589a-4c38-9b80-6e2b4ea3c3d8">sku价格</p>
    */
    @NotBlank(message = "price不能为空")
    @SerializedName("price")
    private String price;
    /**
    * <p data-diff-id="ct-diff-id-69aa3b7e-5fc8-4218-b477-8d4d728d98e3">价格类型，0.原价 1.售价</p>
    */
    @NotNull(message = "type不能为空")
    @SerializedName("type")
    private Integer type;

    public String getPrice() {
        return price;
    }
    public void setPrice(String price) {
        this.price = price;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }




    @Override
    public String toString() {
        return "SkuPrice{" + "price=" + price + "," + "type=" + type + "}";
    }
}
