package com.meituan.sdk.model.ddzh.merchantdata.merchantDataPoitraffic;

import com.google.gson.annotations.SerializedName;

/**
* 获取门店流量数据
* This file was automatically generated.
*/
public class MerchantDataPoitrafficResponse {
    /**
    * 曝光人数
    */
    @SerializedName("viewUv")
    private Integer viewUv;
    /**
    * 商详页访问人数
    */
    @SerializedName("shopUv")
    private Integer shopUv;
    /**
    * 下单人数
    */
    @SerializedName("buyUv")
    private Integer buyUv;
    /**
    * 到店核销人数
    */
    @SerializedName("consumeUv")
    private Integer consumeUv;
    /**
    * 预约人数（客资数）
    */
    @SerializedName("bookUv")
    private Integer bookUv;
    /**
    * 页面停留时间（单位:秒）
    */
    @SerializedName("pageTime")
    private Integer pageTime;

    public Integer getViewUv() {
        return viewUv;
    }
    public void setViewUv(Integer viewUv) {
        this.viewUv = viewUv;
    }
    public Integer getShopUv() {
        return shopUv;
    }
    public void setShopUv(Integer shopUv) {
        this.shopUv = shopUv;
    }
    public Integer getBuyUv() {
        return buyUv;
    }
    public void setBuyUv(Integer buyUv) {
        this.buyUv = buyUv;
    }
    public Integer getConsumeUv() {
        return consumeUv;
    }
    public void setConsumeUv(Integer consumeUv) {
        this.consumeUv = consumeUv;
    }
    public Integer getBookUv() {
        return bookUv;
    }
    public void setBookUv(Integer bookUv) {
        this.bookUv = bookUv;
    }
    public Integer getPageTime() {
        return pageTime;
    }
    public void setPageTime(Integer pageTime) {
        this.pageTime = pageTime;
    }




    @Override
    public String toString() {
        return "MerchantDataPoitrafficResponse{" + "viewUv=" + viewUv + "," + "shopUv=" + shopUv + "," + "buyUv=" + buyUv + "," + "consumeUv=" + consumeUv + "," + "bookUv=" + bookUv + "," + "pageTime=" + pageTime + "}";
    }
}
