package com.meituan.sdk.model.ddzhkh.shangpin.productShopproductsGet;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 店铺商品查询
* This file was automatically generated.
*/
public class ProductShopproductsGetResponse {
    /**
    * 页码 
    */
    @SerializedName("pageNo")
    private Integer pageNo;
    /**
    * 每页条数      
    */
    @SerializedName("pageSize")
    private Integer pageSize;
    /**
    * 产品信息列表
    */
    @SerializedName("shopProducts")
    private List<ShopProductTO> shopProducts;
    /**
    * 总条数
    */
    @SerializedName("totalCount")
    private Integer totalCount;

    public Integer getPageNo() {
        return pageNo;
    }
    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    public List<ShopProductTO> getShopProducts() {
        return shopProducts;
    }
    public void setShopProducts(List<ShopProductTO> shopProducts) {
        this.shopProducts = shopProducts;
    }
    public Integer getTotalCount() {
        return totalCount;
    }
    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }




    @Override
    public String toString() {
        return "ProductShopproductsGetResponse{" + "pageNo=" + pageNo + "," + "pageSize=" + pageSize + "," + "shopProducts=" + shopProducts + "," + "totalCount=" + totalCount + "}";
    }
}
