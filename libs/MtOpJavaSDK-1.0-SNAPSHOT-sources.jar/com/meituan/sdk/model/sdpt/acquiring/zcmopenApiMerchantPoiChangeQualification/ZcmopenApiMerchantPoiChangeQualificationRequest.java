package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiMerchantPoiChangeQualification;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* [变更]修改主体资质
* This file was automatically generated.
*/
@ApiMeta(
    path = "/sdpt/acquiring/api/merchant/poi/change/qualification",
    businessId = 52,
    apiVersion = "10121",
    apiName = "zcmopen_api_merchant_poi_change_qualification",
    needAuth = false
)
public class ZcmopenApiMerchantPoiChangeQualificationRequest implements MeituanRequest<ZcmopenApiMerchantPoiChangeQualificationResponse> {
    /**
    * <p data-diff-id="ct-diff-id-3ec2cba1-a5fa-46d8-bcfd-1590ae433b91"><span style="color: ">美团门店id</span></p>
    */
    @NotNull(message = "merchantId不能为空")
    @SerializedName("merchantId")
    private Long merchantId;
    /**
    * <p data-diff-id="ct-diff-id-d51f9f61-3da6-44ae-a253-7bba762a3c01"><span style="color: #333">变更类型</span></p>
    */
    @NotNull(message = "changeType不能为空")
    @SerializedName("changeType")
    private Integer changeType;
    /**
    * <p data-diff-id="ct-diff-id-3ce8fb19-21e3-4ffa-bde4-cb93c28ebde9"><span style="color: #333">对公资质必填 营业执照类型 201：个体工商户营业执照 202：企业法人营业执照</span></p>
    */
    @SerializedName("businessLicenceType")
    private Integer businessLicenceType;
    /**
    * <p data-diff-id="ct-diff-id-a5589b3d-e16f-4477-afab-ceb2e239533c"><span style="color: #333">对公资质必填 营业执照名称</span></p>
    */
    @SerializedName("businessLicenceName")
    private String businessLicenceName;
    /**
    * <p data-diff-id="ct-diff-id-03778186-a237-44db-8f53-0b006dd90b70"><span style="color: #333">对公资质必填 营业执照注册号</span></p>
    */
    @SerializedName("businessLicenceNumber")
    private String businessLicenceNumber;
    /**
    * <p data-diff-id="ct-diff-id-11c88020-91a3-4532-afc5-5165b7860bc3"><span style="color: #333">对公资质必填 商户注册地址</span></p>
    */
    @SerializedName("businessLicenceAddress")
    private String businessLicenceAddress;
    /**
    * <p data-diff-id="ct-diff-id-94441974-c599-4f02-a65a-0dbac3162ebe"><span style="color: #333">对公资质必填 营业执照图片id 的encryptId</span></p>
    */
    @SerializedName("businessLicencePhotoId")
    private String businessLicencePhotoId;
    /**
    * <p data-diff-id="ct-diff-id-853d2d2b-ab94-4080-9e8a-322ad407cee6"><em>对公资质必填</em><span style="color: rgb(51, 51, 51)"> 营业执照开始时间</span></p>
    */
    @SerializedName("businessLicenceStartTime")
    private Long businessLicenceStartTime;
    /**
    * <p data-diff-id="ct-diff-id-c3fbb2b9-9c77-41ee-b789-de7cc6febe49"><span style="color: #333">对公资质必填 截止日期类型 0 永久 1 选择截止日期</span></p>
    */
    @SerializedName("businessLicenceExpiredType")
    private Integer businessLicenceExpiredType;
    /**
    * <p data-diff-id="ct-diff-id-b21cf82c-88e8-47be-b119-9a0d1de15eb1"><span style="color: #333">对公资质必填 截止日期 Unix时间戳</span></p>
    */
    @SerializedName("businessLicenceExpiredTime")
    private Long businessLicenceExpiredTime;
    /**
    * <p data-diff-id="ct-diff-id-b471b662-5c78-4341-824d-918425f37be4"><span style="color: #333">对公资质必填 法定代表人</span></p>
    */
    @SerializedName("legalPerson")
    private String legalPerson;
    /**
    * <p data-diff-id="ct-diff-id-9347a243-6171-4d71-8780-341c05709293"><span style="color: #333">对公资质必填 法定代表人证件类型 0是身份证 1是护照</span></p>
    */
    @SerializedName("legalPersonIdType")
    private Integer legalPersonIdType;
    /**
    * <p data-diff-id="ct-diff-id-e95a6cff-0ca9-407e-ba11-3539f64541bd"><span style="color: #333">对公资质必填 法定代表人证件身份证/护照 号码</span></p>
    */
    @SerializedName("legalPersonIdNo")
    private String legalPersonIdNo;
    /**
    * <p data-diff-id="ct-diff-id-de687dd1-b260-44cb-9237-de8c2c1194bd"><span style="color: #333">对公资质必填 法定代表人身份证/护照 图片URL_正面</span></p>
    */
    @SerializedName("legalPersonIdFront")
    private String legalPersonIdFront;
    /**
    * <p data-diff-id="ct-diff-id-4f841910-0f51-47f0-b7f5-4366e023d8e3"><span style="color: #333">对公资质必填 法定代表人身份证/护照 图片URL_背面</span></p>
    */
    @SerializedName("legalPersonIdBack")
    private String legalPersonIdBack;
    /**
    * <p data-diff-id="ct-diff-id-638fee0c-1e82-40dd-a32c-6e5163b1454a"><em><span style="color: ">对公资质必填</span></em><span style="color: rgb(51, 51, 51)"> 法人证件号开始时间</span></p>
    */
    @SerializedName("legalPersonIdStartTime")
    private Long legalPersonIdStartTime;
    /**
    * <p data-diff-id="ct-diff-id-8922ff62-aaca-4dbd-87fa-0fd29e6b0a5c"><em><span style="color: ">对公资质必填</span></em><span style="color: rgb(51, 51, 51)"> 法人证件截止时间</span></p>
    */
    @SerializedName("legalPersonIdExpiredTime")
    private Long legalPersonIdExpiredTime;
    /**
    * <p data-diff-id="ct-diff-id-5d6354a6-a140-476a-8205-efd8c6939c9b"><em><span style="color: #333">对公资质必填</span></em><span style="color: #333"> 法人证件截止类型</span></p>
    */
    @SerializedName("legalPersonIdExpiredType")
    private Integer legalPersonIdExpiredType;
    /**
    * <p data-diff-id="ct-diff-id-d299bb4b-3925-40d5-8b1d-ddb03d0eb240"><span style="color: #333">个人资质时必填 证件类型 0是身份证 1是护照</span></p>
    */
    @SerializedName("identificationType")
    private Integer identificationType;
    /**
    * <p data-diff-id="ct-diff-id-bb462e76-df6d-4f04-97ff-47877008ceec"><span style="color: #333">个人资质时必填 证件姓名</span></p>
    */
    @SerializedName("identificationName")
    private String identificationName;
    /**
    * <p data-diff-id="ct-diff-id-b635b127-9b1f-40db-b9a1-789b0d5c34df"><span style="color: #333">个人资质时必填 身份证/护照 图片URL_正面</span></p>
    */
    @SerializedName("identificationFront")
    private String identificationFront;
    /**
    * <p data-diff-id="ct-diff-id-dd78294d-411a-4958-abab-65f2226356dd"><span style="color: #333">个人资质时必填 身份证/护照 图片URL_背面</span></p>
    */
    @SerializedName("identificationBack")
    private String identificationBack;
    /**
    * <p data-diff-id="ct-diff-id-ba9e4efd-f196-428a-83fa-ff81f8295cef"><em><span style="color: ">个人资质时必填</span></em><span style="color: rgb(51, 51, 51)"> 证件开始时间</span></p>
    */
    @SerializedName("identificationStartTime")
    private Long identificationStartTime;
    /**
    * <p data-diff-id="ct-diff-id-6cd58d50-1327-404c-8e0d-e7adebf08a8d"><em><span style="color: ">个人资质时必填</span></em><span style="color: rgb(51, 51, 51)"> 证件过期类型</span></p>
    */
    @SerializedName("identificationExpiredType")
    private Integer identificationExpiredType;
    /**
    * <p data-diff-id="ct-diff-id-ffc9b29e-3715-4c0f-ba58-c4b6770e48b4"><em><span style="color: ">个人资质时必填 </span></em><span style="color: rgb(51, 51, 51)">证件过期时间</span></p>
    */
    @SerializedName("identificationExpiredTime")
    private Long identificationExpiredTime;
    /**
    * <p data-diff-id="ct-diff-id-13d9b6dc-60bc-4ae8-a4ad-9221a0f186e9"><span style="color: #333">附件 企业资质变更证明图片</span></p>
    */
    @SerializedName("qualificationProofPhotoVOS")
    private List<QualificationProofPhotoTO> qualificationProofPhotoVOS;
    /**
    * <p data-diff-id="ct-diff-id-e01b70c8-cdf4-46af-b13c-59bc18fc0fce"><span style="color: #333">0 不需要审核 1需要审核</span></p>
    */
    @SerializedName("manualAuditState")
    private Integer manualAuditState;

    public Long getMerchantId() {
        return merchantId;
    }
    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }
    public Integer getChangeType() {
        return changeType;
    }
    public void setChangeType(Integer changeType) {
        this.changeType = changeType;
    }
    public Integer getBusinessLicenceType() {
        return businessLicenceType;
    }
    public void setBusinessLicenceType(Integer businessLicenceType) {
        this.businessLicenceType = businessLicenceType;
    }
    public String getBusinessLicenceName() {
        return businessLicenceName;
    }
    public void setBusinessLicenceName(String businessLicenceName) {
        this.businessLicenceName = businessLicenceName;
    }
    public String getBusinessLicenceNumber() {
        return businessLicenceNumber;
    }
    public void setBusinessLicenceNumber(String businessLicenceNumber) {
        this.businessLicenceNumber = businessLicenceNumber;
    }
    public String getBusinessLicenceAddress() {
        return businessLicenceAddress;
    }
    public void setBusinessLicenceAddress(String businessLicenceAddress) {
        this.businessLicenceAddress = businessLicenceAddress;
    }
    public String getBusinessLicencePhotoId() {
        return businessLicencePhotoId;
    }
    public void setBusinessLicencePhotoId(String businessLicencePhotoId) {
        this.businessLicencePhotoId = businessLicencePhotoId;
    }
    public Long getBusinessLicenceStartTime() {
        return businessLicenceStartTime;
    }
    public void setBusinessLicenceStartTime(Long businessLicenceStartTime) {
        this.businessLicenceStartTime = businessLicenceStartTime;
    }
    public Integer getBusinessLicenceExpiredType() {
        return businessLicenceExpiredType;
    }
    public void setBusinessLicenceExpiredType(Integer businessLicenceExpiredType) {
        this.businessLicenceExpiredType = businessLicenceExpiredType;
    }
    public Long getBusinessLicenceExpiredTime() {
        return businessLicenceExpiredTime;
    }
    public void setBusinessLicenceExpiredTime(Long businessLicenceExpiredTime) {
        this.businessLicenceExpiredTime = businessLicenceExpiredTime;
    }
    public String getLegalPerson() {
        return legalPerson;
    }
    public void setLegalPerson(String legalPerson) {
        this.legalPerson = legalPerson;
    }
    public Integer getLegalPersonIdType() {
        return legalPersonIdType;
    }
    public void setLegalPersonIdType(Integer legalPersonIdType) {
        this.legalPersonIdType = legalPersonIdType;
    }
    public String getLegalPersonIdNo() {
        return legalPersonIdNo;
    }
    public void setLegalPersonIdNo(String legalPersonIdNo) {
        this.legalPersonIdNo = legalPersonIdNo;
    }
    public String getLegalPersonIdFront() {
        return legalPersonIdFront;
    }
    public void setLegalPersonIdFront(String legalPersonIdFront) {
        this.legalPersonIdFront = legalPersonIdFront;
    }
    public String getLegalPersonIdBack() {
        return legalPersonIdBack;
    }
    public void setLegalPersonIdBack(String legalPersonIdBack) {
        this.legalPersonIdBack = legalPersonIdBack;
    }
    public Long getLegalPersonIdStartTime() {
        return legalPersonIdStartTime;
    }
    public void setLegalPersonIdStartTime(Long legalPersonIdStartTime) {
        this.legalPersonIdStartTime = legalPersonIdStartTime;
    }
    public Long getLegalPersonIdExpiredTime() {
        return legalPersonIdExpiredTime;
    }
    public void setLegalPersonIdExpiredTime(Long legalPersonIdExpiredTime) {
        this.legalPersonIdExpiredTime = legalPersonIdExpiredTime;
    }
    public Integer getLegalPersonIdExpiredType() {
        return legalPersonIdExpiredType;
    }
    public void setLegalPersonIdExpiredType(Integer legalPersonIdExpiredType) {
        this.legalPersonIdExpiredType = legalPersonIdExpiredType;
    }
    public Integer getIdentificationType() {
        return identificationType;
    }
    public void setIdentificationType(Integer identificationType) {
        this.identificationType = identificationType;
    }
    public String getIdentificationName() {
        return identificationName;
    }
    public void setIdentificationName(String identificationName) {
        this.identificationName = identificationName;
    }
    public String getIdentificationFront() {
        return identificationFront;
    }
    public void setIdentificationFront(String identificationFront) {
        this.identificationFront = identificationFront;
    }
    public String getIdentificationBack() {
        return identificationBack;
    }
    public void setIdentificationBack(String identificationBack) {
        this.identificationBack = identificationBack;
    }
    public Long getIdentificationStartTime() {
        return identificationStartTime;
    }
    public void setIdentificationStartTime(Long identificationStartTime) {
        this.identificationStartTime = identificationStartTime;
    }
    public Integer getIdentificationExpiredType() {
        return identificationExpiredType;
    }
    public void setIdentificationExpiredType(Integer identificationExpiredType) {
        this.identificationExpiredType = identificationExpiredType;
    }
    public Long getIdentificationExpiredTime() {
        return identificationExpiredTime;
    }
    public void setIdentificationExpiredTime(Long identificationExpiredTime) {
        this.identificationExpiredTime = identificationExpiredTime;
    }
    public List<QualificationProofPhotoTO> getQualificationProofPhotoVOS() {
        return qualificationProofPhotoVOS;
    }
    public void setQualificationProofPhotoVOS(List<QualificationProofPhotoTO> qualificationProofPhotoVOS) {
        this.qualificationProofPhotoVOS = qualificationProofPhotoVOS;
    }
    public Integer getManualAuditState() {
        return manualAuditState;
    }
    public void setManualAuditState(Integer manualAuditState) {
        this.manualAuditState = manualAuditState;
    }


    @Override
    public MeituanResponse<ZcmopenApiMerchantPoiChangeQualificationResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ZcmopenApiMerchantPoiChangeQualificationResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ZcmopenApiMerchantPoiChangeQualificationRequest{" + "merchantId=" + merchantId + "," + "changeType=" + changeType + "," + "businessLicenceType=" + businessLicenceType + "," + "businessLicenceName=" + businessLicenceName + "," + "businessLicenceNumber=" + businessLicenceNumber + "," + "businessLicenceAddress=" + businessLicenceAddress + "," + "businessLicencePhotoId=" + businessLicencePhotoId + "," + "businessLicenceStartTime=" + businessLicenceStartTime + "," + "businessLicenceExpiredType=" + businessLicenceExpiredType + "," + "businessLicenceExpiredTime=" + businessLicenceExpiredTime + "," + "legalPerson=" + legalPerson + "," + "legalPersonIdType=" + legalPersonIdType + "," + "legalPersonIdNo=" + legalPersonIdNo + "," + "legalPersonIdFront=" + legalPersonIdFront + "," + "legalPersonIdBack=" + legalPersonIdBack + "," + "legalPersonIdStartTime=" + legalPersonIdStartTime + "," + "legalPersonIdExpiredTime=" + legalPersonIdExpiredTime + "," + "legalPersonIdExpiredType=" + legalPersonIdExpiredType + "," + "identificationType=" + identificationType + "," + "identificationName=" + identificationName + "," + "identificationFront=" + identificationFront + "," + "identificationBack=" + identificationBack + "," + "identificationStartTime=" + identificationStartTime + "," + "identificationExpiredType=" + identificationExpiredType + "," + "identificationExpiredTime=" + identificationExpiredTime + "," + "qualificationProofPhotoVOS=" + qualificationProofPhotoVOS + "," + "manualAuditState=" + manualAuditState + "}";
    }
}
