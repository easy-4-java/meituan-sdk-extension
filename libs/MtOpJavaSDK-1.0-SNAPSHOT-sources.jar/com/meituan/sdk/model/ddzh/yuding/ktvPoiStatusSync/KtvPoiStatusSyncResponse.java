package com.meituan.sdk.model.ddzh.yuding.ktvPoiStatusSync;

import com.google.gson.annotations.SerializedName;

/**
* ktv悦享商户身份同步
* This file was automatically generated.
*/
public class KtvPoiStatusSyncResponse {
    /**
    * 返回错误码
    */
    @SerializedName("code")
    private Integer code;
    /**
    * 返回信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 返回数据，更新成功或失败
    */
    @SerializedName("data")
    private Boolean data;

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Boolean getData() {
        return data;
    }
    public void setData(Boolean data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "KtvPoiStatusSyncResponse{" + "code=" + code + "," + "msg=" + msg + "," + "data=" + data + "}";
    }
}
