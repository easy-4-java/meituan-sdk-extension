package com.meituan.sdk.model.tuangouNg.smar.shopTableUpload;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-4ac0a05b-6729-48ba-8599-d7f51dd4ed59"><span style="color: rgba(0, 0, 0, 0.65)">桌台信息</span></p>
* This file was automatically generated.
*/
public class PFDCShopTable {
    /**
    * <p data-diff-id="ct-diff-id-8dbbb985-9f4d-4082-a9d9-998f892fa50c"><em><span style="color: rgba(0, 0, 0, 0.65)">桌台唯一标识，可用id，同一门店下标识唯一，最长100字符</span></em></p>
    */
    @NotBlank(message = "tableCode不能为空")
    @SerializedName("tableCode")
    private String tableCode;
    /**
    * <p data-diff-id="ct-diff-id-3c56f067-f5db-4854-a315-68a6bc9a2a51"><em><span style="color: rgba(0, 0, 0, 0.65)">桌台名称，最长100字符</span></em></p>
    */
    @NotBlank(message = "tableName不能为空")
    @SerializedName("tableName")
    private String tableName;
    /**
    * <p data-diff-id="ct-diff-id-b890fb19-f1ad-4c49-80ed-caa1cb8c7fd6"><em><span style="color: rgba(0, 0, 0, 0.65)">最小人数，不填默认为0</span></em></p>
    */
    @SerializedName("minPerson")
    private Long minPerson;
    /**
    * <p data-diff-id="ct-diff-id-1e2905ed-fb5b-4500-baff-a8349c602cab"><em><span style="color: rgba(0, 0, 0, 0.65)">最大人数</span></em></p>
    */
    @NotNull(message = "maxPerson不能为空")
    @SerializedName("maxPerson")
    private Long maxPerson;
    /**
    * <p data-diff-id="ct-diff-id-8bc7c808-647a-403b-8584-f34f6fd6d4c9"><em><span style="color: rgba(0, 0, 0, 0.65)">桌台类型。1-堂食，2-非堂食</span></em></p>
    */
    @NotNull(message = "tableUseType不能为空")
    @SerializedName("tableUseType")
    private Integer tableUseType;
    /**
    * <p data-diff-id="ct-diff-id-c2de9244-f198-4f55-9ec2-353ad0e47995">所在区域，1-大厅，2-包间，3-室外，4-其他</p><p data-diff-id="ct-diff-id-ac6e5776-66e9-47b5-acb9-cea87b22d919">该分类有则填写即可，无该分类时可填4，或与美团侧沟通</p>
    */
    @NotNull(message = "areaType不能为空")
    @SerializedName("areaType")
    private Integer areaType;
    /**
    * <p data-diff-id="ct-diff-id-60dcc0ad-67c5-4fba-8216-5efa70ad5aeb"><em><span style="color: rgba(0, 0, 0, 0.65)">区域id，最长100字符</span></em></p>
    */
    @NotBlank(message = "areaId不能为空")
    @SerializedName("areaId")
    private String areaId;
    /**
    * <p data-diff-id="ct-diff-id-86100eb5-3e5c-4886-a131-cefa1a1b53a8"><em><span style="color: rgba(0, 0, 0, 0.65)">areaType=4时可自定义名称，最长100字符</span></em></p>
    */
    @NotBlank(message = "areaName不能为空")
    @SerializedName("areaName")
    private String areaName;
    /**
    * <p data-diff-id="ct-diff-id-4f9c8dd2-1684-4934-8a46-66ab3cc51ac7">二维码标识列表，列表最大</p><p data-diff-id="ct-diff-id-3a5f5a91-0853-495d-a230-b15a59f8ace4">5000，字符最长100字符</p><p data-diff-id="ct-diff-id-0ed0cad1-05c9-4eab-833a-380cadf7ec64"><strong><span style="color: rgb(255, 74, 71)">二维码标识要唯一。</span></strong></p>
    */
    @SerializedName("qrCodeList")
    private List<String> qrCodeList;
    /**
    * <p data-diff-id="ct-diff-id-47ca8f06-48f0-4585-aea1-2bb78ff69921">变更类型（1新增，2删除，3更新）</p><p data-diff-id="ct-diff-id-ffcdb89f-2f69-4f30-9b9f-a5a57236a495"><strong>变更类型为删除时，仅填tableCode即可</strong></p><p data-diff-id="ct-diff-id-86d845e1-073e-415c-b953-6269d893b9ac"><strong>一次请求仅支持相同的变更类型</strong></p>
    */
    @NotNull(message = "changeType不能为空")
    @SerializedName("changeType")
    private Integer changeType;

    public String getTableCode() {
        return tableCode;
    }
    public void setTableCode(String tableCode) {
        this.tableCode = tableCode;
    }
    public String getTableName() {
        return tableName;
    }
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    public Long getMinPerson() {
        return minPerson;
    }
    public void setMinPerson(Long minPerson) {
        this.minPerson = minPerson;
    }
    public Long getMaxPerson() {
        return maxPerson;
    }
    public void setMaxPerson(Long maxPerson) {
        this.maxPerson = maxPerson;
    }
    public Integer getTableUseType() {
        return tableUseType;
    }
    public void setTableUseType(Integer tableUseType) {
        this.tableUseType = tableUseType;
    }
    public Integer getAreaType() {
        return areaType;
    }
    public void setAreaType(Integer areaType) {
        this.areaType = areaType;
    }
    public String getAreaId() {
        return areaId;
    }
    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }
    public String getAreaName() {
        return areaName;
    }
    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }
    public List<String> getQrCodeList() {
        return qrCodeList;
    }
    public void setQrCodeList(List<String> qrCodeList) {
        this.qrCodeList = qrCodeList;
    }
    public Integer getChangeType() {
        return changeType;
    }
    public void setChangeType(Integer changeType) {
        this.changeType = changeType;
    }




    @Override
    public String toString() {
        return "PFDCShopTable{" + "tableCode=" + tableCode + "," + "tableName=" + tableName + "," + "minPerson=" + minPerson + "," + "maxPerson=" + maxPerson + "," + "tableUseType=" + tableUseType + "," + "areaType=" + areaType + "," + "areaId=" + areaId + "," + "areaName=" + areaName + "," + "qrCodeList=" + qrCodeList + "," + "changeType=" + changeType + "}";
    }
}
