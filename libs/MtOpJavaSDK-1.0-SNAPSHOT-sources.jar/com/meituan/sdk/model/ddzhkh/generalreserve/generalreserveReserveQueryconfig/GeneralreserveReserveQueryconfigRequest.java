package com.meituan.sdk.model.ddzhkh.generalreserve.generalreserveReserveQueryconfig;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询预约配置
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/generalreserve/reserve/queryconfig",
    businessId = 59,
    apiVersion = "10022",
    apiName = "generalreserve_reserve_queryconfig",
    needAuth = true
)
public class GeneralreserveReserveQueryconfigRequest implements MeituanRequest<GeneralreserveReserveQueryconfigResponse> {
    /**
    * <p data-diff-id="ct-diff-id-55caccd4-89cc-4675-a5aa-e4cc1b7693b9"><span style="color: ">美团门店id</span></p><p data-diff-id="ct-diff-id-7f428bc1-a857-4af0-8245-529789a46785"><span style="color: rgba(0, 0, 0, 0.87)">该字段是混淆字段，实际值类型为混淆后的字符串类型</span></p>
    */
    @NotBlank(message = "opPoiId不能为空")
    @SerializedName("opPoiId")
    private String opPoiId;

    public String getOpPoiId() {
        return opPoiId;
    }
    public void setOpPoiId(String opPoiId) {
        this.opPoiId = opPoiId;
    }


    @Override
    public MeituanResponse<GeneralreserveReserveQueryconfigResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<GeneralreserveReserveQueryconfigResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GeneralreserveReserveQueryconfigRequest{" + "opPoiId=" + opPoiId + "}";
    }
}
