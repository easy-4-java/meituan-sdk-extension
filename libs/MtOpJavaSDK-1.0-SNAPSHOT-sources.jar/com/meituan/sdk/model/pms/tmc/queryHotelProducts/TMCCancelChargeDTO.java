package com.meituan.sdk.model.pms.tmc.queryHotelProducts;

import com.google.gson.annotations.SerializedName;

/**
* 取消规则费用项
* This file was automatically generated.
*/
public class TMCCancelChargeDTO {
    /**
    * 最晚可取消时间点（24小时制）​，从T+1天0点倒推的小时数例如：入住时间为12月10日，取消规则是入住前一天18:00前可取消，则lastCancelHour=12月11日0点 - 30小时
    */
    @SerializedName("lastCancelHour")
    private Integer lastCancelHour;
    /**
    * 费用比例（百分比，如50表示50%）
    */
    @SerializedName("chargeRate")
    private Integer chargeRate;

    public Integer getLastCancelHour() {
        return lastCancelHour;
    }
    public void setLastCancelHour(Integer lastCancelHour) {
        this.lastCancelHour = lastCancelHour;
    }
    public Integer getChargeRate() {
        return chargeRate;
    }
    public void setChargeRate(Integer chargeRate) {
        this.chargeRate = chargeRate;
    }




    @Override
    public String toString() {
        return "TMCCancelChargeDTO{" + "lastCancelHour=" + lastCancelHour + "," + "chargeRate=" + chargeRate + "}";
    }
}
