package com.meituan.sdk.model.ddzhkh.xcxpw.queryRefundInfo;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 退款结果
* This file was automatically generated.
*/
public class QueryRefundRes {
    /**
    * 退款list
    */
    @SerializedName("refundList")
    private List<RefundInfo> refundList;

    public List<RefundInfo> getRefundList() {
        return refundList;
    }
    public void setRefundList(List<RefundInfo> refundList) {
        this.refundList = refundList;
    }




    @Override
    public String toString() {
        return "QueryRefundRes{" + "refundList=" + refundList + "}";
    }
}
