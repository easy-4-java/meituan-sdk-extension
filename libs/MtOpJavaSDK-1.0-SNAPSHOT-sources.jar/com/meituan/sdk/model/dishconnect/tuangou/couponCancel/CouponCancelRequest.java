package com.meituan.sdk.model.dishconnect.tuangou.couponCancel;

import com.meituan.sdk.annotations.ApiMeta;
import java.lang.Void;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 券码撤销核销
* This file was automatically generated.
*/
@ApiMeta(
    path = "/dishconnect/tuangou/coupon/cancel",
    businessId = 79,
    apiVersion = "10048",
    apiName = "coupon_cancel",
    needAuth = false
)
public class CouponCancelRequest implements MeituanRequest<Void> {
    /**
    * <p data-diff-id="ct-diff-id-e0445853-f4ff-4a9f-a1d5-2b496013f4a0"><span style="color: #333">门店在商家收银系统编号</span></p>
    */
    @NotBlank(message = "vendorShopId不能为空")
    @SerializedName("vendorShopId")
    private String vendorShopId;
    /**
    * <p data-diff-id="ct-diff-id-196cc7e1-adec-4c59-8fb0-b2abe5c6f758">券码</p>
    */
    @NotBlank(message = "couponCode不能为空")
    @SerializedName("couponCode")
    private String couponCode;
    /**
    * <p data-diff-id="ct-diff-id-0c68770d-9dcb-41ad-b110-c2f54e753fd9"><span style="color: #333">商家ERP账号ID</span></p>
    */
    @NotBlank(message = "erpId不能为空")
    @SerializedName("erpId")
    private String erpId;
    /**
    * <p data-diff-id="ct-diff-id-71e45445-a4dd-4325-a904-71faa3a717f3"><span style="color: #333">商家ERP账号名称</span></p>
    */
    @NotBlank(message = "erpName不能为空")
    @SerializedName("erpName")
    private String erpName;

    public String getVendorShopId() {
        return vendorShopId;
    }
    public void setVendorShopId(String vendorShopId) {
        this.vendorShopId = vendorShopId;
    }
    public String getCouponCode() {
        return couponCode;
    }
    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }
    public String getErpId() {
        return erpId;
    }
    public void setErpId(String erpId) {
        this.erpId = erpId;
    }
    public String getErpName() {
        return erpName;
    }
    public void setErpName(String erpName) {
        this.erpName = erpName;
    }


    @Override
    public MeituanResponse<Void> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Void>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "CouponCancelRequest{" + "vendorShopId=" + vendorShopId + "," + "couponCode=" + couponCode + "," + "erpId=" + erpId + "," + "erpName=" + erpName + "}";
    }
}
