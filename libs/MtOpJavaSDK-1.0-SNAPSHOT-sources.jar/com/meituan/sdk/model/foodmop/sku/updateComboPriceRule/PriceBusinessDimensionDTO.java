package com.meituan.sdk.model.foodmop.sku.updateComboPriceRule;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-c8006514-6290-4add-94bf-3332dd981db4"><span style="color: rgb(102, 102, 102)">价格维度</span></p>
* This file was automatically generated.
*/
public class PriceBusinessDimensionDTO {
    /**
    * <p data-diff-id="ct-diff-id-8e4f526c-c119-4f66-98d9-935c88322a44"><span style="color: rgb(102, 102, 102)">1：商品基础价格；2：门店聚合维度价格，3：门店维度</span></p>
    */
    @NotNull(message = "businessDimensionType不能为空")
    @SerializedName("businessDimensionType")
    private Integer businessDimensionType;
    /**
    * <p data-diff-id="ct-diff-id-e93ce5c3-1da0-4559-be56-b57af0154a62"><span style="color: rgb(102, 102, 102)">三方套餐id</span></p>
    */
    @NotBlank(message = "vendorComboId不能为空")
    @SerializedName("vendorComboId")
    private String vendorComboId;
    /**
    * <p data-diff-id="ct-diff-id-0bc5e70e-2517-4553-a8f9-3ee6d899ab1e"><span style="color: rgb(102, 102, 102)">价格维度kv：type=2时，需要传入区域id、type=3时，需要传入门店id</span></p>
    */
    @SerializedName("businessDimensionMap")
    private Map businessDimensionMap;

    public Integer getBusinessDimensionType() {
        return businessDimensionType;
    }
    public void setBusinessDimensionType(Integer businessDimensionType) {
        this.businessDimensionType = businessDimensionType;
    }
    public String getVendorComboId() {
        return vendorComboId;
    }
    public void setVendorComboId(String vendorComboId) {
        this.vendorComboId = vendorComboId;
    }
    public Map getBusinessDimensionMap() {
        return businessDimensionMap;
    }
    public void setBusinessDimensionMap(Map businessDimensionMap) {
        this.businessDimensionMap = businessDimensionMap;
    }




    @Override
    public String toString() {
        return "PriceBusinessDimensionDTO{" + "businessDimensionType=" + businessDimensionType + "," + "vendorComboId=" + vendorComboId + "," + "businessDimensionMap=" + businessDimensionMap + "}";
    }
}
