package com.meituan.sdk.model.ddzhkh.miniprogram.tradeCreateOrder;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-29ccecc3-1d88-46a7-9c5c-5b750bb5dde2">用车人信息。（预约成功需必传）</p>
* This file was automatically generated.
*/
public class UseCarPersonReq {
    /**
    * <p data-diff-id="ct-diff-id-62383b9b-0ace-4c03-8b01-e85122f524a0">用车人姓名</p>
    */
    @SerializedName("personName")
    private String personName;
    /**
    * <p data-diff-id="ct-diff-id-ad52e46f-115f-4cfc-b4b5-5293999b5ff0">用车人手机号</p>
    */
    @SerializedName("mobileNo")
    private String mobileNo;
    /**
    * <p data-diff-id="ct-diff-id-7dc8a679-f4fb-4128-a6f6-edf971d514d7">用车人证件类型：</p><p data-diff-id="ct-diff-id-5ad9d468-9bc9-4594-a43b-b9d9d196718c">1-身份证</p><p data-diff-id="ct-diff-id-ec36539f-c862-42f8-a91a-efee22bf6968">2-护照</p><p data-diff-id="ct-diff-id-d9133807-979d-4a49-b62b-c65c4a85323d">3-台胞证</p><p data-diff-id="ct-diff-id-098de96d-10f7-472d-aa61-812f38fa3378">4-港澳居民来往内地通行证</p><p data-diff-id="ct-diff-id-bea714e2-9d16-4f5a-bc9d-06b7c195ce8c">5-港澳台居住证</p><p data-diff-id="ct-diff-id-28635dff-76e8-4174-85ee-6626ba36ebe9">6-外国人永久居留身份证</p>
    */
    @SerializedName("certificateType")
    private Integer certificateType;
    /**
    * <p data-diff-id="ct-diff-id-bf518723-de67-4346-a197-9981eceac47e">用车人证件号码</p>
    */
    @SerializedName("certificateNo")
    private String certificateNo;

    public String getPersonName() {
        return personName;
    }
    public void setPersonName(String personName) {
        this.personName = personName;
    }
    public String getMobileNo() {
        return mobileNo;
    }
    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }
    public Integer getCertificateType() {
        return certificateType;
    }
    public void setCertificateType(Integer certificateType) {
        this.certificateType = certificateType;
    }
    public String getCertificateNo() {
        return certificateNo;
    }
    public void setCertificateNo(String certificateNo) {
        this.certificateNo = certificateNo;
    }




    @Override
    public String toString() {
        return "UseCarPersonReq{" + "personName=" + personName + "," + "mobileNo=" + mobileNo + "," + "certificateType=" + certificateType + "," + "certificateNo=" + certificateNo + "}";
    }
}
