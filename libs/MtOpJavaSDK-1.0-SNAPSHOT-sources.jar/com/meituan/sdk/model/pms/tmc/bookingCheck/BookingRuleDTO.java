package com.meituan.sdk.model.pms.tmc.bookingCheck;

import com.google.gson.annotations.SerializedName;

/**
* 预订规则
* This file was automatically generated.
*/
public class BookingRuleDTO {
    /**
    * 提前预订天数
    */
    @SerializedName("advanceBookingDays")
    private Integer advanceBookingDays;
    /**
    * 预订窗口期(天)
    */
    @SerializedName("bookingWindowDays")
    private Integer bookingWindowDays;
    /**
    * 最少入住天数
    */
    @SerializedName("minStayDays")
    private Integer minStayDays;
    /**
    * 最多入住天数
    */
    @SerializedName("maxStayDays")
    private Integer maxStayDays;

    public Integer getAdvanceBookingDays() {
        return advanceBookingDays;
    }
    public void setAdvanceBookingDays(Integer advanceBookingDays) {
        this.advanceBookingDays = advanceBookingDays;
    }
    public Integer getBookingWindowDays() {
        return bookingWindowDays;
    }
    public void setBookingWindowDays(Integer bookingWindowDays) {
        this.bookingWindowDays = bookingWindowDays;
    }
    public Integer getMinStayDays() {
        return minStayDays;
    }
    public void setMinStayDays(Integer minStayDays) {
        this.minStayDays = minStayDays;
    }
    public Integer getMaxStayDays() {
        return maxStayDays;
    }
    public void setMaxStayDays(Integer maxStayDays) {
        this.maxStayDays = maxStayDays;
    }




    @Override
    public String toString() {
        return "BookingRuleDTO{" + "advanceBookingDays=" + advanceBookingDays + "," + "bookingWindowDays=" + bookingWindowDays + "," + "minStayDays=" + minStayDays + "," + "maxStayDays=" + maxStayDays + "}";
    }
}
