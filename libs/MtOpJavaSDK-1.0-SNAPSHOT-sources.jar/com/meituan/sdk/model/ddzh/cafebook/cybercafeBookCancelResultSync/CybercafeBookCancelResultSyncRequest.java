package com.meituan.sdk.model.ddzh.cafebook.cybercafeBookCancelResultSync;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 网吧订座取消结果同步
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/cafebook/cancelresult/sync",
    businessId = 58,
    apiVersion = "10000",
    apiName = "cybercafe_book_cancel_result_sync",
    needAuth = true
)
public class CybercafeBookCancelResultSyncRequest implements MeituanRequest<CybercafeBookCancelResultSyncResponse> {
    /**
    * <p data-diff-id="ct-diff-id-bfc0ffec-6ba2-43b1-9752-fd51c211b440">美团订座单号</p>
    */
    @NotBlank(message = "orderId不能为空")
    @SerializedName("orderId")
    private String orderId;
    /**
    * <p data-diff-id="ct-diff-id-726faa50-c6bc-45d4-9c00-dc438575d46c">退款类型，1-全额退，用户在免费时间内取消订座，不产生任何费用，直接美团全额退<br>给用户；2-账户网费退，用户已经产生实际占座费用，不退团购，三方需要把退回用户<br>账户网费金额和已消费网费金额回传给美团</p>
    */
    @NotNull(message = "refundType不能为空")
    @SerializedName("refundType")
    private Integer refundType;
    @SerializedName("refundInfo")
    private RefundInfo refundInfo;

    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public Integer getRefundType() {
        return refundType;
    }
    public void setRefundType(Integer refundType) {
        this.refundType = refundType;
    }
    public RefundInfo getRefundInfo() {
        return refundInfo;
    }
    public void setRefundInfo(RefundInfo refundInfo) {
        this.refundInfo = refundInfo;
    }


    @Override
    public MeituanResponse<CybercafeBookCancelResultSyncResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<CybercafeBookCancelResultSyncResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "CybercafeBookCancelResultSyncRequest{" + "orderId=" + orderId + "," + "refundType=" + refundType + "," + "refundInfo=" + refundInfo + "}";
    }
}
