package com.meituan.sdk.model.waimaiNg.order.orderRejectRefund;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 订单拒绝退款
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/order/rejectRefund",
    businessId = 2,
    apiVersion = "10103",
    apiName = "order_reject_refund",
    needAuth = true
)
public class OrderRejectRefundRequest implements MeituanRequest<String> {
    /**
    * <p><span style="color: rgba(0, 0, 0, 0.87)"><font style="font-size:14px;line-height:22px" data-size="14">原因</font></span></p>
    */
    @NotBlank(message = "reason不能为空")
    @SerializedName("reason")
    private String reason;
    /**
    * <p><span style="color: rgba(0, 0, 0, 0.87)"><font style="font-size:14px;line-height:22px" data-size="14">订单号</font></span></p>
    */
    @NotNull(message = "orderId不能为空")
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-6dcda618-4c8f-4a42-bdbe-6876445c3dcd">业务类型</p>
    */
    @SerializedName("source")
    private String source;
    /**
    * <p data-diff-id="ct-diff-id-f8be83a2-fb9f-4bb1-b12f-8af040de7b8e">mop退款唯一标识</p>
    */
    @SerializedName("refundNum")
    private String refundNum;

    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getSource() {
        return source;
    }
    public void setSource(String source) {
        this.source = source;
    }
    public String getRefundNum() {
        return refundNum;
    }
    public void setRefundNum(String refundNum) {
        this.refundNum = refundNum;
    }


    @Override
    public MeituanResponse<String> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<String>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "OrderRejectRefundRequest{" + "reason=" + reason + "," + "orderId=" + orderId + "," + "source=" + source + "," + "refundNum=" + refundNum + "}";
    }
}
