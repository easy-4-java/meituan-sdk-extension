package com.meituan.sdk.model.waimaiNg.diancan.diancanShopStatusUpdate;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-f6008565-7fff-4767-bfc0-9b2bf54f1c14"><font style="font-size:14px;line-height:22px" data-size="14">厂商门店配置列表，<span style="color: ">批量限制20</span></font></p>
* This file was automatically generated.
*/
public class ShopBizConfigRequest {
    /**
    * <p data-diff-id="ct-diff-id-4bb63fab-ad2e-453f-ac56-efdaac00c672"><font style="font-size:14px;line-height:22px" data-size="14">厂商门店ID</font></p>
    */
    @SerializedName("appPoiCode")
    private String appPoiCode;
    /**
    * <p data-diff-id="ct-diff-id-151602a4-1f05-4980-8d5d-d34a0839458d"><font style="font-size:14px;line-height:22px" data-size="14">线上点业务开关</font></p><ul data-diff-id="ct-diff-id-b1ada988-cad6-4ac5-b816-c909d697f2f9"><li data-list-item-diff-id="ct-list-item-diff-id-68085b45-6de3-4ca1-8a1c-4a87e6330d7f"><p style="text-align: start;" data-diff-id="ct-diff-id-5fd9a3e4-e75d-42d4-9280-ce834c2649a6"><font style="font-size:14px;line-height:22px" data-size="14">10: 开</font></p></li></ul><ul data-diff-id="ct-diff-id-aae7be46-6899-454e-86ae-ff79c0c84f3a"><li data-list-item-diff-id="ct-list-item-diff-id-1f91b02f-ba9f-4ad6-9fca-ba740b7f0415"><p style="text-align: start;" data-diff-id="ct-diff-id-c4b30d13-ea96-4b87-9dcd-4bb6fc0559be"><font style="font-size:14px;line-height:22px" data-size="14">20：关</font></p></li></ul>
    */
    @NotNull(message = "shopBizOpenStatus不能为空")
    @SerializedName("shopBizOpenStatus")
    private Integer shopBizOpenStatus;

    public String getAppPoiCode() {
        return appPoiCode;
    }
    public void setAppPoiCode(String appPoiCode) {
        this.appPoiCode = appPoiCode;
    }
    public Integer getShopBizOpenStatus() {
        return shopBizOpenStatus;
    }
    public void setShopBizOpenStatus(Integer shopBizOpenStatus) {
        this.shopBizOpenStatus = shopBizOpenStatus;
    }




    @Override
    public String toString() {
        return "ShopBizConfigRequest{" + "appPoiCode=" + appPoiCode + "," + "shopBizOpenStatus=" + shopBizOpenStatus + "}";
    }
}
