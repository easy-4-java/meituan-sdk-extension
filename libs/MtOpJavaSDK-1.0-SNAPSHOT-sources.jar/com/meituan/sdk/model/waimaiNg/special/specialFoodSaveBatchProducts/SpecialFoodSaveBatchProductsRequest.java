package com.meituan.sdk.model.waimaiNg.special.specialFoodSaveBatchProducts;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 单门店下批量保存商品(拼好饭)
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/special/phf/product/batchSaveProduct",
    businessId = 2,
    apiVersion = "10007",
    apiName = "special_food_save_batch_products",
    needAuth = true
)
public class SpecialFoodSaveBatchProductsRequest implements MeituanRequest<SpecialFoodSaveBatchProductsResponse> {
    /**
    * <p>商品集合数据，不能为空，单次不能超过20个商品</p>
    */
    @NotEmpty(message = "foodData不能为空")
    @SerializedName("food_data")
    private List<FoodData> foodData;

    public List<FoodData> getFoodData() {
        return foodData;
    }
    public void setFoodData(List<FoodData> foodData) {
        this.foodData = foodData;
    }


    @Override
    public MeituanResponse<SpecialFoodSaveBatchProductsResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<SpecialFoodSaveBatchProductsResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "SpecialFoodSaveBatchProductsRequest{" + "foodData=" + foodData + "}";
    }
}
