package com.meituan.sdk.model.tuangouNg.atomgoods.productBoxUpdate;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-ca840bdc-7b48-4d4b-be2b-71ecc2da55a2">标签列表</p>
* This file was automatically generated.
*/
public class PTag {
    /**
    * <p data-diff-id="ct-diff-id-e5584618-1dc6-4f51-8e48-bc571dad891b">三方标签id</p>
    */
    @SerializedName("tagId")
    private String tagId;
    /**
    * <p data-diff-id="ct-diff-id-08406259-7019-4bbd-b5bc-0ef45a31cb12">标签名称</p>
    */
    @NotBlank(message = "tagName不能为空")
    @SerializedName("tagName")
    private String tagName;
    /**
    * <p data-diff-id="ct-diff-id-5236ffa6-087e-4592-a4c6-9acf7dfd732a">标签值</p>
    */
    @SerializedName("tagValue")
    private String tagValue;

    public String getTagId() {
        return tagId;
    }
    public void setTagId(String tagId) {
        this.tagId = tagId;
    }
    public String getTagName() {
        return tagName;
    }
    public void setTagName(String tagName) {
        this.tagName = tagName;
    }
    public String getTagValue() {
        return tagValue;
    }
    public void setTagValue(String tagValue) {
        this.tagValue = tagValue;
    }




    @Override
    public String toString() {
        return "PTag{" + "tagId=" + tagId + "," + "tagName=" + tagName + "," + "tagValue=" + tagValue + "}";
    }
}
