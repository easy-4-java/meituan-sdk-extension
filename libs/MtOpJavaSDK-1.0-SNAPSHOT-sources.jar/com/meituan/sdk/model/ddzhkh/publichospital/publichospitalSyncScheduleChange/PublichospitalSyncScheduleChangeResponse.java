package com.meituan.sdk.model.ddzhkh.publichospital.publichospitalSyncScheduleChange;

import com.google.gson.annotations.SerializedName;

/**
* 排班变更通知
* This file was automatically generated.
*/
public class PublichospitalSyncScheduleChangeResponse {
    /**
    * 是否变更成功
    */
    @SerializedName("result")
    private Boolean result;

    public Boolean getResult() {
        return result;
    }
    public void setResult(Boolean result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "PublichospitalSyncScheduleChangeResponse{" + "result=" + result + "}";
    }
}
