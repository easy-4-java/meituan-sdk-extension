package com.meituan.sdk.model.ddzhkh.xcxwy.submitFileTransfer;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-b5d378f4-9ab5-40b3-90d8-c0be21860acc">提审文件列表</p>
* This file was automatically generated.
*/
public class PrintShopFileItem {
    /**
    * <p data-diff-id="ct-diff-id-2c65bb31-a3e1-4c51-a917-55862df49fc4">文件ID，<span style="color: #f5222d">必填</span></p>
    */
    @NotBlank(message = "fileId不能为空")
    @SerializedName("fileId")
    private String fileId;
    /**
    * <p data-diff-id="ct-diff-id-147622eb-9699-4f15-9728-5c047a1e0106">文件下载链接</p>
    */
    @SerializedName("fileUrl")
    private String fileUrl;

    public String getFileId() {
        return fileId;
    }
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
    public String getFileUrl() {
        return fileUrl;
    }
    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }




    @Override
    public String toString() {
        return "PrintShopFileItem{" + "fileId=" + fileId + "," + "fileUrl=" + fileUrl + "}";
    }
}
