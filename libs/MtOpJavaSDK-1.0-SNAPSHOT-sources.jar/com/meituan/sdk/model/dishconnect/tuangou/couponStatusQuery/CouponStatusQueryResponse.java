package com.meituan.sdk.model.dishconnect.tuangou.couponStatusQuery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 券码查询
* This file was automatically generated.
*/
public class CouponStatusQueryResponse {
    /**
    * 券码状态，10-可用，20-不可用
    */
    @SerializedName("status")
    private Integer status;
    /**
    * 券码详细状态，10-未使用，20-已使用，30-已撤销，40-已退款，50-已冻结，100-其他
    */
    @SerializedName("couponStatus")
    private Integer couponStatus;
    /**
    * 券码有效期开始时间
    */
    @SerializedName("couponStartTime")
    private String couponStartTime;
    /**
    * 券码有效期截止时间
    */
    @SerializedName("couponEndTime")
    private String couponEndTime;
    /**
    * 券码的购买时间  套餐券和代金券必返回
    */
    @SerializedName("couponBuyTime")
    private String couponBuyTime;
    /**
    * 商家实收金额，这里不考虑手续费，即手续费未扣除（粗略估算，实际以结算账单为准）（例如15抵20的代金券，这里就是15）
    */
    @SerializedName("realAmount")
    private String realAmount;
    /**
    * 美团团单类型，1-代金券，2-套餐券，4-免费试券
    */
    @SerializedName("dealType")
    private Integer dealType;
    /**
    * 项目ID，即美团点评的商品ID
    */
    @SerializedName("dealId")
    private String dealId;
    /**
    * 美团团单名称
    */
    @SerializedName("dealTitle")
    private String dealTitle;
    /**
    * 美团团单短标题，即点评/美团App团单详情页展示的名称，小程序核销方案使用，极端情况下可能不返回，需要dealTitle作为兜底
    */
    @SerializedName("poiDealTitle")
    private String poiDealTitle;
    /**
    * 团单售卖价格（例如15抵20的代金券，这里就是15）
    */
    @SerializedName("dealPrice")
    private String dealPrice;
    /**
    * 团单面额，即市场价（例如15抵20的代金券，这里就是20）
    */
    @SerializedName("dealValue")
    private String dealValue;
    /**
    * 购买团购券的用户手机尾号
    */
    @SerializedName("userPhoneTail")
    private String userPhoneTail;
    /**
    * 预先配置的团单-菜品ID映射【套餐券必填】
    */
    @SerializedName("dealSkuMappingDetail")
    private RDealSkuMappingDetail dealSkuMappingDetail;
    /**
    * 预先配置的团单-促销ID映射，多个之间以英文逗号分隔（美团团单映射商家侧收银系统内的促销活动，没有这个需求的商家不用关心）
    */
    @SerializedName("dealPromotionMappingDetail")
    private String dealPromotionMappingDetail;
    /**
    * 是否可以跟其他不同团单券码优惠共享（能否和其他美团券一起使用），true可共享，false/null均表示不可共享(小程序核销使用) 举例：商家有50元代金券和30元代金券，这里不可共享表示不可在一个订单中同时使用50元代金券和30元代金券。平台不卡控同时使用2张50元代金券 注意: 该字段对试用劵无效，试用劵都是单独核销，其他券码不能与免费试券码在一个请求里核销
    */
    @SerializedName("canShareOtherPromotion")
    private Boolean canShareOtherPromotion;
    /**
    * 最大使用数量限制，-1表示券码优惠活动无最大使用数量限制（小程序核销使用）
    */
    @SerializedName("dealRuleCouponLimit")
    private Integer dealRuleCouponLimit;
    /**
    * 会员openId，商家交互用户识别唯一标识
    */
    @SerializedName("openId")
    private String openId;
    /**
    * 用户可用券码数量，此字段不表示核销时可以成功核销张数，仅表示此用户在同一购券订单下可用券码数量；实际核销张数以核销接口返回结果为准
    */
    @SerializedName("count")
    private Integer count;
    /**
    * 券码渠道，一键买单场景下，须将该字段填入核销接口请求参数的同名字段
    */
    @SerializedName("receiptChannel")
    private Integer receiptChannel;
    /**
    * 一键买单场景（receiptChannel==1004）必填
    */
    @SerializedName("maitonOrderInfo")
    private RMaitonOrderInfo maitonOrderInfo;
    /**
    * 次卡类型，1-阶梯次卡，2-普通次卡。仅当券为次卡时有值
    */
    @SerializedName("timeCardType")
    private Integer timeCardType;
    /**
    * 券码在次卡中的次序，从1开始。仅当券为阶梯次卡时有值
    */
    @SerializedName("timeCardSequence")
    private Integer timeCardSequence;
    /**
    * 当前仅供阶梯次卡场景使用。同一购券订单下剩余所有可用状态的券列表（包含当前入参券码），仅当入参券为可用状态时返回
    */
    @SerializedName("availableCouponList")
    private List<RAvailableCoupon> availableCouponList;
    /**
    * 商企通相关信息，仅当券为可用状态时（status==10）才有可能返回
    */
    @SerializedName("sqtInfo")
    private SqtInfoDTO sqtInfo;

    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getCouponStatus() {
        return couponStatus;
    }
    public void setCouponStatus(Integer couponStatus) {
        this.couponStatus = couponStatus;
    }
    public String getCouponStartTime() {
        return couponStartTime;
    }
    public void setCouponStartTime(String couponStartTime) {
        this.couponStartTime = couponStartTime;
    }
    public String getCouponEndTime() {
        return couponEndTime;
    }
    public void setCouponEndTime(String couponEndTime) {
        this.couponEndTime = couponEndTime;
    }
    public String getCouponBuyTime() {
        return couponBuyTime;
    }
    public void setCouponBuyTime(String couponBuyTime) {
        this.couponBuyTime = couponBuyTime;
    }
    public String getRealAmount() {
        return realAmount;
    }
    public void setRealAmount(String realAmount) {
        this.realAmount = realAmount;
    }
    public Integer getDealType() {
        return dealType;
    }
    public void setDealType(Integer dealType) {
        this.dealType = dealType;
    }
    public String getDealId() {
        return dealId;
    }
    public void setDealId(String dealId) {
        this.dealId = dealId;
    }
    public String getDealTitle() {
        return dealTitle;
    }
    public void setDealTitle(String dealTitle) {
        this.dealTitle = dealTitle;
    }
    public String getPoiDealTitle() {
        return poiDealTitle;
    }
    public void setPoiDealTitle(String poiDealTitle) {
        this.poiDealTitle = poiDealTitle;
    }
    public String getDealPrice() {
        return dealPrice;
    }
    public void setDealPrice(String dealPrice) {
        this.dealPrice = dealPrice;
    }
    public String getDealValue() {
        return dealValue;
    }
    public void setDealValue(String dealValue) {
        this.dealValue = dealValue;
    }
    public String getUserPhoneTail() {
        return userPhoneTail;
    }
    public void setUserPhoneTail(String userPhoneTail) {
        this.userPhoneTail = userPhoneTail;
    }
    public RDealSkuMappingDetail getDealSkuMappingDetail() {
        return dealSkuMappingDetail;
    }
    public void setDealSkuMappingDetail(RDealSkuMappingDetail dealSkuMappingDetail) {
        this.dealSkuMappingDetail = dealSkuMappingDetail;
    }
    public String getDealPromotionMappingDetail() {
        return dealPromotionMappingDetail;
    }
    public void setDealPromotionMappingDetail(String dealPromotionMappingDetail) {
        this.dealPromotionMappingDetail = dealPromotionMappingDetail;
    }
    public Boolean getCanShareOtherPromotion() {
        return canShareOtherPromotion;
    }
    public void setCanShareOtherPromotion(Boolean canShareOtherPromotion) {
        this.canShareOtherPromotion = canShareOtherPromotion;
    }
    public Integer getDealRuleCouponLimit() {
        return dealRuleCouponLimit;
    }
    public void setDealRuleCouponLimit(Integer dealRuleCouponLimit) {
        this.dealRuleCouponLimit = dealRuleCouponLimit;
    }
    public String getOpenId() {
        return openId;
    }
    public void setOpenId(String openId) {
        this.openId = openId;
    }
    public Integer getCount() {
        return count;
    }
    public void setCount(Integer count) {
        this.count = count;
    }
    public Integer getReceiptChannel() {
        return receiptChannel;
    }
    public void setReceiptChannel(Integer receiptChannel) {
        this.receiptChannel = receiptChannel;
    }
    public RMaitonOrderInfo getMaitonOrderInfo() {
        return maitonOrderInfo;
    }
    public void setMaitonOrderInfo(RMaitonOrderInfo maitonOrderInfo) {
        this.maitonOrderInfo = maitonOrderInfo;
    }
    public Integer getTimeCardType() {
        return timeCardType;
    }
    public void setTimeCardType(Integer timeCardType) {
        this.timeCardType = timeCardType;
    }
    public Integer getTimeCardSequence() {
        return timeCardSequence;
    }
    public void setTimeCardSequence(Integer timeCardSequence) {
        this.timeCardSequence = timeCardSequence;
    }
    public List<RAvailableCoupon> getAvailableCouponList() {
        return availableCouponList;
    }
    public void setAvailableCouponList(List<RAvailableCoupon> availableCouponList) {
        this.availableCouponList = availableCouponList;
    }
    public SqtInfoDTO getSqtInfo() {
        return sqtInfo;
    }
    public void setSqtInfo(SqtInfoDTO sqtInfo) {
        this.sqtInfo = sqtInfo;
    }




    @Override
    public String toString() {
        return "CouponStatusQueryResponse{" + "status=" + status + "," + "couponStatus=" + couponStatus + "," + "couponStartTime=" + couponStartTime + "," + "couponEndTime=" + couponEndTime + "," + "couponBuyTime=" + couponBuyTime + "," + "realAmount=" + realAmount + "," + "dealType=" + dealType + "," + "dealId=" + dealId + "," + "dealTitle=" + dealTitle + "," + "poiDealTitle=" + poiDealTitle + "," + "dealPrice=" + dealPrice + "," + "dealValue=" + dealValue + "," + "userPhoneTail=" + userPhoneTail + "," + "dealSkuMappingDetail=" + dealSkuMappingDetail + "," + "dealPromotionMappingDetail=" + dealPromotionMappingDetail + "," + "canShareOtherPromotion=" + canShareOtherPromotion + "," + "dealRuleCouponLimit=" + dealRuleCouponLimit + "," + "openId=" + openId + "," + "count=" + count + "," + "receiptChannel=" + receiptChannel + "," + "maitonOrderInfo=" + maitonOrderInfo + "," + "timeCardType=" + timeCardType + "," + "timeCardSequence=" + timeCardSequence + "," + "availableCouponList=" + availableCouponList + "," + "sqtInfo=" + sqtInfo + "}";
    }
}
