package com.meituan.sdk.model.resv2.rule.supplyRuleSave;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-84845b72-dc94-48fc-b49e-b94fc486fb00"><span style="color: rgba(0, 0, 0, 0.65)">提前可订规则</span></p>
* This file was automatically generated.
*/
public class VendorAdvanceRuleDTO {
    /**
    * <p data-diff-id="ct-diff-id-4b4b72dd-01d7-4fd7-81a0-0a7122c33a44"><span style="color: rgba(0, 0, 0, 0.65)">提前多少秒可订</span></p>
    */
    @SerializedName("earlyBookableHour")
    private Integer earlyBookableHour;
    /**
    * <p data-diff-id="ct-diff-id-edb337fd-1ec4-49d5-9545-9e2261c9bc1d"><span style="color: rgba(0, 0, 0, 0.65)">提前多少天可订,范围为[0,30]</span></p>
    */
    @SerializedName("earlyBookableDay")
    private Integer earlyBookableDay;
    /**
    * <p data-diff-id="ct-diff-id-29712317-953c-4205-bf3c-c88dda7c0aeb"><span style="color: rgba(0, 0, 0, 0.65)">最大可预订天数</span></p>
    */
    @SerializedName("maxBookableDay")
    private Integer maxBookableDay;

    public Integer getEarlyBookableHour() {
        return earlyBookableHour;
    }
    public void setEarlyBookableHour(Integer earlyBookableHour) {
        this.earlyBookableHour = earlyBookableHour;
    }
    public Integer getEarlyBookableDay() {
        return earlyBookableDay;
    }
    public void setEarlyBookableDay(Integer earlyBookableDay) {
        this.earlyBookableDay = earlyBookableDay;
    }
    public Integer getMaxBookableDay() {
        return maxBookableDay;
    }
    public void setMaxBookableDay(Integer maxBookableDay) {
        this.maxBookableDay = maxBookableDay;
    }




    @Override
    public String toString() {
        return "VendorAdvanceRuleDTO{" + "earlyBookableHour=" + earlyBookableHour + "," + "earlyBookableDay=" + earlyBookableDay + "," + "maxBookableDay=" + maxBookableDay + "}";
    }
}
