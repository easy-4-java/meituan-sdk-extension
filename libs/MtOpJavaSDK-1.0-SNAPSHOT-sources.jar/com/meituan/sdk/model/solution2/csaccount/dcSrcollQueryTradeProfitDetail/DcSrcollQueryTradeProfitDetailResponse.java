package com.meituan.sdk.model.solution2.csaccount.dcSrcollQueryTradeProfitDetail;

import com.google.gson.annotations.SerializedName;

/**
* 游标查询交易结算流水
* This file was automatically generated.
*/
public class DcSrcollQueryTradeProfitDetailResponse {
    /**
    * 游标ID
    */
    @SerializedName("scrollId")
    private Long scrollId;
    /**
    * 流水列表
    */
    @SerializedName("traceDetails")
    private SettleTradeDetailModel traceDetails;

    public Long getScrollId() {
        return scrollId;
    }
    public void setScrollId(Long scrollId) {
        this.scrollId = scrollId;
    }
    public SettleTradeDetailModel getTraceDetails() {
        return traceDetails;
    }
    public void setTraceDetails(SettleTradeDetailModel traceDetails) {
        this.traceDetails = traceDetails;
    }




    @Override
    public String toString() {
        return "DcSrcollQueryTradeProfitDetailResponse{" + "scrollId=" + scrollId + "," + "traceDetails=" + traceDetails + "}";
    }
}
