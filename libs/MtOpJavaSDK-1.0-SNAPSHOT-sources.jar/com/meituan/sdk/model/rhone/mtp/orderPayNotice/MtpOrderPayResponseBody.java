package com.meituan.sdk.model.rhone.mtp.orderPayNotice;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-cae20dfd-9af1-416f-83a7-eef37a326ad9"><span style="color: ">出票通知接口必须返回body数据</span></p>
* This file was automatically generated.
*/
public class MtpOrderPayResponseBody {
    /**
    * <p data-diff-id="ct-diff-id-7c3026ab-8b46-4dec-a102-abfd15f8f808"><span style="color: ">美团订单ID，必须回传</span></p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-2b3a2fc4-1f6a-4281-98dd-4aded62f84c1"><span style="color: ">合作方订单ID，必须回传</span></p>
    */
    @SerializedName("partnerOrderId")
    private String partnerOrderId;
    /**
    * <p data-diff-id="ct-diff-id-32e84a13-d373-49dd-b230-4adfe04d5c51"><span style="color: ">凭证码类型：0为不需要码核销，1为需要码核销。</span><br><font style="font-size:14px;line-height:22px" data-size="14">voucher type 原语义为：0为不回传凭证，1为一码一验，2为一码多验，原语义已废弃。现voucher type只有0和1，voucher type=1对应之前的一码一验，凭证码数量必须与订单里的票数对应，核销时按照回传的凭证码进行核销；其他情况需回传voucher type=0，此种情况下退款请求不会传凭证码给商家，核销时商家也可以不回传凭证码（按used quantity进行核销），需要码入园的产品商家照常返回凭证码即可，凭证码会照常展示。</font></p>
    */
    @SerializedName("voucherType")
    private Integer voucherType;
    /**
    * <p data-diff-id="ct-diff-id-6815247b-74c5-4694-9326-53fad2c8a2ea"><span style="color: ">出票成功时为必传字段；凭证码数组，每个凭证码的最大长度为 varchar(20)；凭证码不区分大小写，只有大小写不同的两个码将会判定为重复码，导致出票失败。</span></p>
    */
    @SerializedName("vouchers")
    private List<String> vouchers;
    /**
    * <p data-diff-id="ct-diff-id-1b020dbd-6e41-48f2-ba43-05b9e29ddc4f"><span style="color: ">图片凭证码数组，出票成功时为必传字段；传图片链接地址, 有多个时,顺序必须与vouchers的顺序一致；每个地址指向一张可下载的图片</span></p>
    */
    @SerializedName("voucherPics")
    private List<String> voucherPics;
    /**
    * <p data-diff-id="ct-diff-id-15f12bc1-a137-4e41-9d2d-6969673d3574"><span style="color: ">凭证附加信息</span></p>
    */
    @SerializedName("voucherAdditionalList")
    private List<VoucherAdditionalListSub> voucherAdditionalList;
    /**
    * <p data-diff-id="ct-diff-id-4cb48b34-fa39-44db-93bb-29f0cce01f0b"><span style="color: ">实名制订单标识，取值：0、1；</span><br><span style="color: ">0 代表非实名制订单(退款和核销无需传身份证信息)；1 代表实名制且需要凭证码订单(退款和核销需要凭码+身份证信息，即需要券码和游客信息相匹配)；不传默认为0 非实名制订单</span></p>
    */
    @SerializedName("realNameType")
    private Integer realNameType;
    /**
    * <p data-diff-id="ct-diff-id-5b1643c5-4671-44ee-a2fc-94e433c31aeb"><span style="color: ">实名制证件、凭证码信息列表</span></p>
    */
    @SerializedName("credentialList")
    private List<CredentialListSub> credentialList;
    /**
    * <p data-diff-id="ct-diff-id-7d287cf5-fff3-4965-9e9e-228690d6ae25"><span style="color: ">订单附加信息列表</span></p>
    */
    @SerializedName("orderAdditionalList")
    private List<OrderAdditionalListSub> orderAdditionalList;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getPartnerOrderId() {
        return partnerOrderId;
    }
    public void setPartnerOrderId(String partnerOrderId) {
        this.partnerOrderId = partnerOrderId;
    }
    public Integer getVoucherType() {
        return voucherType;
    }
    public void setVoucherType(Integer voucherType) {
        this.voucherType = voucherType;
    }
    public List<String> getVouchers() {
        return vouchers;
    }
    public void setVouchers(List<String> vouchers) {
        this.vouchers = vouchers;
    }
    public List<String> getVoucherPics() {
        return voucherPics;
    }
    public void setVoucherPics(List<String> voucherPics) {
        this.voucherPics = voucherPics;
    }
    public List<VoucherAdditionalListSub> getVoucherAdditionalList() {
        return voucherAdditionalList;
    }
    public void setVoucherAdditionalList(List<VoucherAdditionalListSub> voucherAdditionalList) {
        this.voucherAdditionalList = voucherAdditionalList;
    }
    public Integer getRealNameType() {
        return realNameType;
    }
    public void setRealNameType(Integer realNameType) {
        this.realNameType = realNameType;
    }
    public List<CredentialListSub> getCredentialList() {
        return credentialList;
    }
    public void setCredentialList(List<CredentialListSub> credentialList) {
        this.credentialList = credentialList;
    }
    public List<OrderAdditionalListSub> getOrderAdditionalList() {
        return orderAdditionalList;
    }
    public void setOrderAdditionalList(List<OrderAdditionalListSub> orderAdditionalList) {
        this.orderAdditionalList = orderAdditionalList;
    }




    @Override
    public String toString() {
        return "MtpOrderPayResponseBody{" + "orderId=" + orderId + "," + "partnerOrderId=" + partnerOrderId + "," + "voucherType=" + voucherType + "," + "vouchers=" + vouchers + "," + "voucherPics=" + voucherPics + "," + "voucherAdditionalList=" + voucherAdditionalList + "," + "realNameType=" + realNameType + "," + "credentialList=" + credentialList + "," + "orderAdditionalList=" + orderAdditionalList + "}";
    }
}
