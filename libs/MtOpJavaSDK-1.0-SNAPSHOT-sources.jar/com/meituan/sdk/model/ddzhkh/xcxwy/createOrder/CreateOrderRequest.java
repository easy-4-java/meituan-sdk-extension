package com.meituan.sdk.model.ddzhkh.xcxwy.createOrder;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 下单并支付
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/xcxwy/create_order",
    businessId = 59,
    apiVersion = "10002",
    apiName = "create_order",
    needAuth = true
)
public class CreateOrderRequest implements MeituanRequest<CreateOrderResponse> {
    @NotBlank(message = "generalBizData不能为空")
    @SerializedName("generalBizData")
    private String generalBizData;
    @NotNull(message = "createOrderReq不能为空")
    @SerializedName("createOrderReq")
    private PriintingCreateOrderReq createOrderReq;

    public String getGeneralBizData() {
        return generalBizData;
    }
    public void setGeneralBizData(String generalBizData) {
        this.generalBizData = generalBizData;
    }
    public PriintingCreateOrderReq getCreateOrderReq() {
        return createOrderReq;
    }
    public void setCreateOrderReq(PriintingCreateOrderReq createOrderReq) {
        this.createOrderReq = createOrderReq;
    }


    @Override
    public MeituanResponse<CreateOrderResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<CreateOrderResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "CreateOrderRequest{" + "generalBizData=" + generalBizData + "," + "createOrderReq=" + createOrderReq + "}";
    }
}
