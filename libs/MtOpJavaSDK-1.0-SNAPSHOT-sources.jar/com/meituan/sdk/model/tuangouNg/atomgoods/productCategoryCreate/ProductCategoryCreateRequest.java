package com.meituan.sdk.model.tuangouNg.atomgoods.productCategoryCreate;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 上传菜品前台类目
* This file was automatically generated.
*/
@ApiMeta(
    path = "/tuangou/ng/atomgoods/product/category/create",
    businessId = 1,
    apiVersion = "10030",
    apiName = "product_category_create",
    needAuth = true
)
public class ProductCategoryCreateRequest implements MeituanRequest<ProductCategoryCreateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-3d14ff69-4bf5-4f42-b4ec-3ac3a9f613ac">附件信息/加价属性类型，1-总部, 2-门店</p>
    */
    @NotNull(message = "scope不能为空")
    @SerializedName("scope")
    private Integer scope;
    /**
    * <p data-diff-id="ct-diff-id-2a35464d-56ed-4845-9a20-4dab1988465e">总部code，当scope = 1时必填</p>
    */
    @SerializedName("vendorChainId")
    private String vendorChainId;
    /**
    * <p data-diff-id="ct-diff-id-9009cc9c-6e1f-4bab-b794-89c80546a019">门店code，当scope = 2时必填</p>
    */
    @SerializedName("vendorShopId")
    private String vendorShopId;
    /**
    * <p data-diff-id="ct-diff-id-03c3586e-29ad-45c6-934a-b28a664bbf79">批量更新的前台类目</p>
    */
    @NotEmpty(message = "categoryList不能为空")
    @SerializedName("categoryList")
    private List<PCategory> categoryList;

    public Integer getScope() {
        return scope;
    }
    public void setScope(Integer scope) {
        this.scope = scope;
    }
    public String getVendorChainId() {
        return vendorChainId;
    }
    public void setVendorChainId(String vendorChainId) {
        this.vendorChainId = vendorChainId;
    }
    public String getVendorShopId() {
        return vendorShopId;
    }
    public void setVendorShopId(String vendorShopId) {
        this.vendorShopId = vendorShopId;
    }
    public List<PCategory> getCategoryList() {
        return categoryList;
    }
    public void setCategoryList(List<PCategory> categoryList) {
        this.categoryList = categoryList;
    }


    @Override
    public MeituanResponse<ProductCategoryCreateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ProductCategoryCreateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ProductCategoryCreateRequest{" + "scope=" + scope + "," + "vendorChainId=" + vendorChainId + "," + "vendorShopId=" + vendorShopId + "," + "categoryList=" + categoryList + "}";
    }
}
