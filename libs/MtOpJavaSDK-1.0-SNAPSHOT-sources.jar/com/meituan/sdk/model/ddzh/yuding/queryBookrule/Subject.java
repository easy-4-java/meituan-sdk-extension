package com.meituan.sdk.model.ddzh.yuding.queryBookrule;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 主体信息
* This file was automatically generated.
*/
public class Subject {
    /**
    * 主体类型  KTV包房时段：141
    */
    @SerializedName("subjectType")
    private Integer subjectType;
    /**
    * 主体id列表
    */
    @SerializedName("subjectIdItemList")
    private List<SubjectIdItemListSub> subjectIdItemList;

    public Integer getSubjectType() {
        return subjectType;
    }
    public void setSubjectType(Integer subjectType) {
        this.subjectType = subjectType;
    }
    public List<SubjectIdItemListSub> getSubjectIdItemList() {
        return subjectIdItemList;
    }
    public void setSubjectIdItemList(List<SubjectIdItemListSub> subjectIdItemList) {
        this.subjectIdItemList = subjectIdItemList;
    }




    @Override
    public String toString() {
        return "Subject{" + "subjectType=" + subjectType + "," + "subjectIdItemList=" + subjectIdItemList + "}";
    }
}
