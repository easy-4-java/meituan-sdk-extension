package com.meituan.sdk.model.waimaiNg.dish.toppingList;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询小料信息接口（分页）
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/dish/topping/list",
    businessId = 2,
    apiVersion = "10113",
    apiName = "topping_list",
    needAuth = true
)
public class ToppingListRequest implements MeituanRequest<List<OpenTopping>> {
    /**
    * <p data-diff-id="ct-diff-id-c8e4ceb7-37de-4ab8-97d0-b75389049737">需要查询的小料分页大小</p>
    */
    @NotNull(message = "pageSize不能为空")
    @SerializedName("pageSize")
    private Integer pageSize;
    /**
    * <p data-diff-id="ct-diff-id-6b07fc5b-1d50-4108-a930-fe972876e171">页码</p>
    */
    @NotNull(message = "pageNo不能为空")
    @SerializedName("pageNo")
    private Integer pageNo;

    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    public Integer getPageNo() {
        return pageNo;
    }
    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }


    @Override
    public MeituanResponse<List<OpenTopping>> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<List<OpenTopping>>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ToppingListRequest{" + "pageSize=" + pageSize + "," + "pageNo=" + pageNo + "}";
    }
}
