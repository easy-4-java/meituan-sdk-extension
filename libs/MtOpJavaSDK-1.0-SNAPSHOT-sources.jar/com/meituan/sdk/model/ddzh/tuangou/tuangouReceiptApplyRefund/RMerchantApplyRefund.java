package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptApplyRefund;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class RMerchantApplyRefund {
    /**
    * 退款申请单号
    */
    @SerializedName("refundId")
    private String refundId;
    /**
    * 商家结算款退还金额，单位：分，仅部分退场景返回
    */
    @SerializedName("settleRefundAmount")
    private Long settleRefundAmount;

    public String getRefundId() {
        return refundId;
    }
    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }
    public Long getSettleRefundAmount() {
        return settleRefundAmount;
    }
    public void setSettleRefundAmount(Long settleRefundAmount) {
        this.settleRefundAmount = settleRefundAmount;
    }




    @Override
    public String toString() {
        return "RMerchantApplyRefund{" + "refundId=" + refundId + "," + "settleRefundAmount=" + settleRefundAmount + "}";
    }
}
