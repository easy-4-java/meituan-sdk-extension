package com.meituan.sdk.model.ddzh.tuangou.tuangouProductQueryproductbytype;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class ProductDTO {
    /**
    * 产品ID（即将下线）
    */
    @SerializedName("productId")
    private Integer productId;
    /**
    * 产品IDLong（使用该字段）
    */
    @SerializedName("productIdLong")
    private Long productIdLong;
    /**
    * 支持商品类型：500-款式一口价，723-运动健身拼团，722-足疗按摩拼团，792-洗浴拼团，793-密室拼团，795-体检拼团，850-医美预付，922-丽人拼团，923-生活服务拼团，924-教育培训拼团，926-K歌拼团，1081-次卡，1359-结婚代金券，2000：医美预付拼团。若不确定具体商品类型，可通过在线咨询
    */
    @SerializedName("type")
    private Integer type;
    /**
    * sku列表
    */
    @SerializedName("productItemList")
    private List<ProductItemDTO> productItemList;

    public Integer getProductId() {
        return productId;
    }
    public void setProductId(Integer productId) {
        this.productId = productId;
    }
    public Long getProductIdLong() {
        return productIdLong;
    }
    public void setProductIdLong(Long productIdLong) {
        this.productIdLong = productIdLong;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public List<ProductItemDTO> getProductItemList() {
        return productItemList;
    }
    public void setProductItemList(List<ProductItemDTO> productItemList) {
        this.productItemList = productItemList;
    }




    @Override
    public String toString() {
        return "ProductDTO{" + "productId=" + productId + "," + "productIdLong=" + productIdLong + "," + "type=" + type + "," + "productItemList=" + productItemList + "}";
    }
}
