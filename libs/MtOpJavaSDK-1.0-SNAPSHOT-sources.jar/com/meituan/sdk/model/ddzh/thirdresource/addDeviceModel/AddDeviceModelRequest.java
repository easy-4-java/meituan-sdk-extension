package com.meituan.sdk.model.ddzh.thirdresource.addDeviceModel;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 新增设备型号信息
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/thirdresource/adddevicemodel",
    businessId = 58,
    apiVersion = "10030",
    apiName = "add_device_model",
    needAuth = true
)
public class AddDeviceModelRequest implements MeituanRequest<AddDeviceModelResponse> {
    /**
    * <p data-diff-id="ct-diff-id-43b57349-3812-4b6a-874d-8c80d1e9a594"><span style="color: #333">新增设备型号列表</span></p>
    */
    @NotEmpty(message = "deviceModelList不能为空")
    @SerializedName("deviceModelList")
    private List<UnifiedDeviceModel> deviceModelList;

    public List<UnifiedDeviceModel> getDeviceModelList() {
        return deviceModelList;
    }
    public void setDeviceModelList(List<UnifiedDeviceModel> deviceModelList) {
        this.deviceModelList = deviceModelList;
    }


    @Override
    public MeituanResponse<AddDeviceModelResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<AddDeviceModelResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "AddDeviceModelRequest{" + "deviceModelList=" + deviceModelList + "}";
    }
}
