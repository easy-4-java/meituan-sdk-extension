package com.meituan.sdk.model.ddzhkh.xcxmj.syncStatus;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* 
* This file was automatically generated.
*/
public class OrderDataChangeReq {
    /**
    * <p data-diff-id="ct-diff-id-47a6e34d-b404-41a7-afc2-e30af8f995ba"><span style="color: rgba(0, 0, 0, 0.65)">美团订单号，与三方商户订单号二选一</span></p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-8c46338c-b200-4131-a85a-0b0b2b9015b7"><span style="color: rgba(0, 0, 0, 0.65)">三方商户订单号，与美团订单号二选一</span></p>
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * <p data-diff-id="ct-diff-id-5a486bb4-316d-4c10-874b-d5d75a069327"><span style="color: rgba(0, 0, 0, 0.65)">版本号，保障接口幂等，低于上一个版本不处理</span></p>
    */
    @NotNull(message = "version不能为空")
    @SerializedName("version")
    private Long version;
    /**
    * <p data-diff-id="ct-diff-id-321b250f-67cf-4f97-833e-1144227adb08">商户订单原状态。</p><p data-diff-id="ct-diff-id-f03a03e4-fa60-4291-ba5c-0196e7a949fb">行业枚举:</p><table data-borderwidth="1" data-diff-id="ct-diff-id-39dc67e6-20be-4b69-b877-2337f6f607b9"><tbody><tr data-row-diff-id="d5301d7f-e7fe-4e91-8d6a-602070ee417c"><th data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-489b1464-cdb6-40d7-8fbf-0525be90dd58"><p data-diff-id="ct-diff-id-60c8c7c1-c459-4848-b1cd-216b9f5fbbd1">状态代码</p></th><th data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-a2e09626-46ad-4b6b-b0e0-60f03c7f2b5e"><p data-diff-id="ct-diff-id-ad43e7ac-f8c8-4460-95e7-29ec322892b0">状态描述</p></th><th data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-8e7fc20d-6d78-485b-9a4e-3fce1bdfa512"><p data-diff-id="ct-diff-id-812f4b09-57d5-4d78-8f27-53ab20f8900f">备注</p></th></tr><tr data-row-diff-id="d8d6e598-af7d-4590-8d52-4f89169da6ce"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-eacf9289-74ff-4a11-8a01-f87b715f767d"><p data-diff-id="ct-diff-id-c104b9b9-3e8f-4abd-9147-653e29b16409">1</p></td><td data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-c9375eb4-93eb-418d-b557-80e8a86988d7"><p data-diff-id="ct-diff-id-b3aef22d-2793-4f41-b6ad-16951e3557dd">初始化</p></td><td data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-39689a18-0930-46dd-9f2e-08de3bb38900"><p data-diff-id="ct-diff-id-048cd2ce-a937-4e57-904c-a1d0d73b0907">美团创建订单完成的状态，不对外展示</p></td></tr><tr data-row-diff-id="2472ae3a-27e3-4341-8b16-20d9cc7a0239"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-31dcd5b9-0ee7-4a3d-92bf-426b1566b5fd"><p data-diff-id="ct-diff-id-06f8bed2-9d8f-45c2-98ea-8c249f486632">2</p></td><td data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-ce9ee6f9-ff1e-41b4-ba75-2c04d15bb232"><p data-diff-id="ct-diff-id-78b24edc-8d81-47b3-9118-f0774345eb9a">已取消</p></td><td data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-8b3e89fe-04c2-482a-91cb-09a67c5bfb30"><p data-diff-id="ct-diff-id-be5bf176-044c-4bae-bf39-17b069d37da8">用户/商户取消订单</p></td></tr><tr data-row-diff-id="61ead149-2862-45c8-8211-6aa517f3b2ac"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-6edb6afc-0b46-4ea4-8532-c2ca22a71725"><p data-diff-id="ct-diff-id-0cf169ce-1f51-49b0-9c0c-d01bfecf1428">3</p></td><td data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-81aed85e-a33a-4fb3-abf7-a1afd3a6dde2"><p data-diff-id="ct-diff-id-000ff208-1595-4b2e-9a83-d1528373c3a5">待支付</p></td><td data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-101ccc60-c3ee-4aa6-a219-ba2d3fa1e477"><p data-diff-id="ct-diff-id-30f0d797-8f10-4a33-96f9-f96b2e4edf3a">用户创建订单后，未在美团收银台支付完成</p></td></tr><tr data-row-diff-id="7776774a-7e4c-4876-96ff-63037e143d4d"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-fede8b67-594a-44cd-bb84-c5155bec839d"><p data-diff-id="ct-diff-id-681868c8-ac69-4fb0-abf5-20d8ad984c2e">4</p></td><td data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-91c23190-1c94-4016-a5eb-cdeb5dadca22"><p data-diff-id="ct-diff-id-5efc3563-cce7-4ae0-bf62-116db52ab42a">服务中</p></td><td data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-b029ba8d-19f6-406a-9db8-73172113dbd4"><p data-diff-id="ct-diff-id-5c619dc5-f324-4afa-bf15-3a5b344e877a">用户支付完成，商户提供服务中</p></td></tr><tr data-row-diff-id="884bc6bf-a134-481b-9bc2-84903471ceda"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-6f575c0f-ec5d-4cb3-b412-1f5adfe42d37"><p data-diff-id="ct-diff-id-942a9a0e-9eb4-4d35-bf14-b4d9115dbce3">5</p></td><td data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-1de25d55-cd0d-4b30-ac6b-cbbbdcd0d3a0"><p data-diff-id="ct-diff-id-37a9bb5a-975f-440c-af9a-c08399e5fbc2">已完成</p></td><td data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-1dd982b5-8333-4e3a-a46e-aa7d53fc94d3"><p data-diff-id="ct-diff-id-1b5ab327-acfa-4b5b-a82d-49c929820d50">服务履约完成，触发结算</p></td></tr><tr data-row-diff-id="fb5668c7-4b7e-4d4f-a90c-64e937f768fa"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-9b906506-a3d8-472c-b407-fe12fd64e09c"><p data-diff-id="ct-diff-id-c7f4a392-88dd-4f4e-a261-d1af5c9b0879">6</p></td><td data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-7f7b5b2d-64b5-4d4a-a42f-c783e2a049cb"><p data-diff-id="ct-diff-id-624761bd-eb78-481d-acce-0a3679f29dde">已退款</p></td><td data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-4410c97f-5e30-48af-8a21-dbc46d7cd2e6"><p data-diff-id="ct-diff-id-9867130a-afca-4de5-bba3-ca3b28ed8e5d">用户已支付，并且退款完成</p></td></tr></tbody></table>
    */
    @NotBlank(message = "fromStatus不能为空")
    @SerializedName("fromStatus")
    private String fromStatus;
    /**
    * <p data-diff-id="ct-diff-id-8f38ff33-1169-47a2-8afd-33b4de4092c9">商户订单新状态。</p><p data-diff-id="ct-diff-id-84e235e8-0272-4974-ac9c-370ba87d41ba">行业枚举:</p><table data-borderwidth="1" data-diff-id="ct-diff-id-8aa7469e-83d9-4135-90d0-328c11c812af"><tbody><tr data-row-diff-id="d5301d7f-e7fe-4e91-8d6a-602070ee417c"><th data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-f9580c80-965b-4ece-8964-3b2cc46ef8d5"><p data-diff-id="ct-diff-id-77c42be0-41cd-4986-91e0-5f2404241e9e">状态代码</p></th><th data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-6acc0c0b-e4ea-456c-8386-7a747bda381b"><p data-diff-id="ct-diff-id-da20d0e8-0ff3-415c-8a69-c3500e7ad2e4">状态描述</p></th><th data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-14da5d08-ed02-4f7b-b7b4-9bd596595845"><p data-diff-id="ct-diff-id-473d3ae7-7dda-4a68-be70-130ffb82bae5">备注</p></th></tr><tr data-row-diff-id="d8d6e598-af7d-4590-8d52-4f89169da6ce"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-30ab42b6-f02f-47eb-82d9-22155c30b889"><p data-diff-id="ct-diff-id-1b0e1169-09d8-4fe1-ad26-94069758821c">1</p></td><td data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-e92df620-5788-4131-930c-9d07d4cccd4f"><p data-diff-id="ct-diff-id-74c26de1-d921-4b5b-a666-4d56e629d607">初始化</p></td><td data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-d4b49660-106a-4611-8ffd-586c2f8a339e"><p data-diff-id="ct-diff-id-d50d6687-9a2d-4043-8d01-2770d1fa65c0">美团创建订单完成的状态，不对外展示</p></td></tr><tr data-row-diff-id="2472ae3a-27e3-4341-8b16-20d9cc7a0239"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-edc1d15b-70d0-49f5-9539-c965016569dd"><p data-diff-id="ct-diff-id-6d18cb15-4fa7-4fed-8e39-8244536539b7">2</p></td><td data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-b2c1d6c8-56b2-4a01-90f4-82c6001fcfc8"><p data-diff-id="ct-diff-id-13de7402-1bb8-442a-abcc-d102e2171eea">已取消</p></td><td data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-381afe58-cd95-4127-b730-d8e5e0b794fd"><p data-diff-id="ct-diff-id-66e72b06-7ef4-4c9d-b146-1058374293e5">用户/商户取消订单</p></td></tr><tr data-row-diff-id="61ead149-2862-45c8-8211-6aa517f3b2ac"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-3f2e98db-c9cd-43f4-b260-78adc29c60f5"><p data-diff-id="ct-diff-id-fbca51eb-487e-4022-bd08-af32b583e8f0">3</p></td><td data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-c377c81e-7d29-4a8d-a54e-483d41beea33"><p data-diff-id="ct-diff-id-99e2a752-3f8b-496d-a8ca-d1ff9acdf76c">待支付</p></td><td data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-3fc13fcd-c42c-44e2-93b1-e09f9c51369e"><p data-diff-id="ct-diff-id-43ffd31e-273d-4d62-8330-62ea1e8749a7">用户创建订单后，未在美团收银台支付完成</p></td></tr><tr data-row-diff-id="7776774a-7e4c-4876-96ff-63037e143d4d"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-316b802b-edec-4979-a999-c7d742b32b79"><p data-diff-id="ct-diff-id-55d34ee8-1e59-4c84-9171-0fec99ec6e48">4</p></td><td data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-0f3859c0-dff3-46b5-850f-f3c09d23c930"><p data-diff-id="ct-diff-id-f321d386-af84-43bc-8be7-e4f1ea020587">服务中</p></td><td data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-a5c74f51-c5cf-4fd7-891d-451c26bb33c8"><p data-diff-id="ct-diff-id-ea2027e8-413e-493e-ae5f-688c6cd02ba9">用户支付完成，商户提供服务中</p></td></tr><tr data-row-diff-id="884bc6bf-a134-481b-9bc2-84903471ceda"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-4d545cdb-b3af-4fdb-8d22-2adc7b57ca68"><p data-diff-id="ct-diff-id-c5509ebe-52c9-4e01-b5ce-0a66cab9d0c1">5</p></td><td data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-eec7dcfa-f2b7-4c53-ab2c-08fb4befdb59"><p data-diff-id="ct-diff-id-13bf5140-a4a3-40fd-8a14-2ff65aef648a">已完成</p></td><td data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-3b8a923b-d4a9-40c9-8c05-f9fde839cd16"><p data-diff-id="ct-diff-id-e2c42c3d-fa61-4c45-957b-8f68240f9c4c">服务履约完成，触发结算</p></td></tr><tr data-row-diff-id="fb5668c7-4b7e-4d4f-a90c-64e937f768fa"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-a0dd8b4a-e2b5-42cf-aec3-a71b8965d968"><p data-diff-id="ct-diff-id-2217d6c3-afc4-4a37-9372-8f1f98410953">6</p></td><td data-colwidth="105" width="105" data-cell-diff-id="ct-cell-diff-id-0eb030d1-2b16-49bc-b9e5-418a11037ac5"><p data-diff-id="ct-diff-id-9dac360e-9f14-44fa-810a-819af953d2ae">已退款</p></td><td data-colwidth="311" width="311" data-cell-diff-id="ct-cell-diff-id-59c7331f-0aa4-4fa0-9fb9-a880e5e4c4a3"><p data-diff-id="ct-diff-id-5e9d0156-02fb-49e0-a9c1-46a7235f5f2c">用户已支付，并且退款完成</p></td></tr></tbody></table>
    */
    @NotBlank(message = "toStatus不能为空")
    @SerializedName("toStatus")
    private String toStatus;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public Long getVersion() {
        return version;
    }
    public void setVersion(Long version) {
        this.version = version;
    }
    public String getFromStatus() {
        return fromStatus;
    }
    public void setFromStatus(String fromStatus) {
        this.fromStatus = fromStatus;
    }
    public String getToStatus() {
        return toStatus;
    }
    public void setToStatus(String toStatus) {
        this.toStatus = toStatus;
    }




    @Override
    public String toString() {
        return "OrderDataChangeReq{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "," + "version=" + version + "," + "fromStatus=" + fromStatus + "," + "toStatus=" + toStatus + "}";
    }
}
