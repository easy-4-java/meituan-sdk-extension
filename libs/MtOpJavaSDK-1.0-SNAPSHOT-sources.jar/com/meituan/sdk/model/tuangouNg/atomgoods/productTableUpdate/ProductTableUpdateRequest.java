package com.meituan.sdk.model.tuangouNg.atomgoods.productTableUpdate;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 上传桌台信息
* This file was automatically generated.
*/
@ApiMeta(
    path = "/tuangou/ng/atomgoods/product/table/update",
    businessId = 1,
    apiVersion = "10039",
    apiName = "product_table_update",
    needAuth = true
)
public class ProductTableUpdateRequest implements MeituanRequest<ProductTableUpdateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-98670b69-55c7-43b2-ad82-45b0d174f082">桌台列表</p>
    */
    @NotEmpty(message = "tableList不能为空")
    @SerializedName("tableList")
    private List<PFDCShopTable> tableList;
    /**
    * <p data-diff-id="ct-diff-id-baeb2b28-ba29-47c4-b732-3d0673c4997f">扩展预留字段</p>
    */
    @SerializedName("reqExt")
    private Map reqExt;

    public List<PFDCShopTable> getTableList() {
        return tableList;
    }
    public void setTableList(List<PFDCShopTable> tableList) {
        this.tableList = tableList;
    }
    public Map getReqExt() {
        return reqExt;
    }
    public void setReqExt(Map reqExt) {
        this.reqExt = reqExt;
    }


    @Override
    public MeituanResponse<ProductTableUpdateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ProductTableUpdateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ProductTableUpdateRequest{" + "tableList=" + tableList + "," + "reqExt=" + reqExt + "}";
    }
}
