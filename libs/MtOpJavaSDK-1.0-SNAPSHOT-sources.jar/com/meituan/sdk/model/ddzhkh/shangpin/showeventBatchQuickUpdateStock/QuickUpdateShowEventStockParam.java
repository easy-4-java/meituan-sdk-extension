package com.meituan.sdk.model.ddzhkh.shangpin.showeventBatchQuickUpdateStock;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* 
* This file was automatically generated.
*/
public class QuickUpdateShowEventStockParam {
    /**
    * <p data-diff-id="ct-diff-id-7dc5e2e6-1153-4592-927d-39c8c71236c5"><em><span style="color: rgba(0, 0, 0, 0.65)">三方演出项目id（单次上限10）</span></em></p>
    */
    @NotBlank(message = "thirdPartyShowEventId不能为空")
    @SerializedName("thirdPartyShowEventId")
    private String thirdPartyShowEventId;
    /**
    * <p data-diff-id="ct-diff-id-5a5c92b0-51e3-4b50-bb86-792ee56ee93b"><span style="color: rgba(0, 0, 0, 0.65)">场次信息</span></p>
    */
    @NotEmpty(message = "showtime不能为空")
    @SerializedName("showtime")
    private List<PShowTimeStocksParam> showtime;

    public String getThirdPartyShowEventId() {
        return thirdPartyShowEventId;
    }
    public void setThirdPartyShowEventId(String thirdPartyShowEventId) {
        this.thirdPartyShowEventId = thirdPartyShowEventId;
    }
    public List<PShowTimeStocksParam> getShowtime() {
        return showtime;
    }
    public void setShowtime(List<PShowTimeStocksParam> showtime) {
        this.showtime = showtime;
    }




    @Override
    public String toString() {
        return "QuickUpdateShowEventStockParam{" + "thirdPartyShowEventId=" + thirdPartyShowEventId + "," + "showtime=" + showtime + "}";
    }
}
