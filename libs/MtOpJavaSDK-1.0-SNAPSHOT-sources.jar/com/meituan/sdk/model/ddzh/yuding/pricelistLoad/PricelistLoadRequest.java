package com.meituan.sdk.model.ddzh.yuding.pricelistLoad;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 价目表商品加载查询接口
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/pricelist/load",
    businessId = 58,
    apiVersion = "10085",
    apiName = "pricelist_load",
    needAuth = true
)
public class PricelistLoadRequest implements MeituanRequest<PricelistLoadResponse> {
    /**
    * <p data-diff-id="ct-diff-id-9514c3de-18dd-48f5-a0f2-0bb0232e9466">业务类型：</p><p data-diff-id="ct-diff-id-3cac4265-fbb0-4412-9dc3-795722ca324a">100088<span style="color: rgba(0, 0, 0, 0.65)">-棋牌预定</span></p>
    */
    @NotNull(message = "bizType不能为空")
    @SerializedName("bizType")
    private Integer bizType;
    /**
    * <p data-diff-id="ct-diff-id-8169f3fb-8dcd-4c49-952c-214af2fd70c6">商品分类：</p><p data-diff-id="ct-diff-id-08cca9bc-f90b-44cb-a9f9-f1d920021728">2000251<span style="color: rgba(0, 0, 0, 0.87)">-棋牌行业</span></p>
    */
    @NotNull(message = "spuType不能为空")
    @SerializedName("spuType")
    private Long spuType;

    public Integer getBizType() {
        return bizType;
    }
    public void setBizType(Integer bizType) {
        this.bizType = bizType;
    }
    public Long getSpuType() {
        return spuType;
    }
    public void setSpuType(Long spuType) {
        this.spuType = spuType;
    }


    @Override
    public MeituanResponse<PricelistLoadResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<PricelistLoadResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "PricelistLoadRequest{" + "bizType=" + bizType + "," + "spuType=" + spuType + "}";
    }
}
