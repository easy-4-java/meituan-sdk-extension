package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiMerchantPoiProtocolAccept;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* [入件]签订电子协议接口
* This file was automatically generated.
*/
@ApiMeta(
    path = "/sdpt/acquiring/api/merchant/poi/protocol/accept",
    businessId = 52,
    apiVersion = "10105",
    apiName = "zcmopen_api_merchant_poi_protocol_accept",
    needAuth = false
)
public class ZcmopenApiMerchantPoiProtocolAcceptRequest implements MeituanRequest<ZcmopenApiMerchantPoiProtocolAcceptResponse> {
    /**
    * <p data-diff-id="ct-diff-id-d56e369c-88f2-40ff-a315-014a09164b87">用户IP</p>
    */
    @NotBlank(message = "userIp不能为空")
    @SerializedName("userIp")
    private String userIp;
    /**
    * <p data-diff-id="ct-diff-id-333475f5-5da1-4536-bb76-9f256cdb5663">商户ID</p>
    */
    @NotNull(message = "merchantId不能为空")
    @SerializedName("merchantId")
    private Long merchantId;

    public String getUserIp() {
        return userIp;
    }
    public void setUserIp(String userIp) {
        this.userIp = userIp;
    }
    public Long getMerchantId() {
        return merchantId;
    }
    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }


    @Override
    public MeituanResponse<ZcmopenApiMerchantPoiProtocolAcceptResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ZcmopenApiMerchantPoiProtocolAcceptResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ZcmopenApiMerchantPoiProtocolAcceptRequest{" + "userIp=" + userIp + "," + "merchantId=" + merchantId + "}";
    }
}
