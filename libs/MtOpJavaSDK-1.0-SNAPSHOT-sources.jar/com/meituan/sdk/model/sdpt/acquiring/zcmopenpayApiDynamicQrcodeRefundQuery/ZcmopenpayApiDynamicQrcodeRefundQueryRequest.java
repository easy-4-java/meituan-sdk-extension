package com.meituan.sdk.model.sdpt.acquiring.zcmopenpayApiDynamicQrcodeRefundQuery;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 【美团收单】动态二维码订单退款查询
* This file was automatically generated.
*/
@ApiMeta(
    path = "/sdpt/acquiring/sdpt/acquiring/api/dynamic-code/payment/refund/query",
    businessId = 52,
    apiVersion = "10135",
    apiName = "zcmopenpay_api_dynamic_qrcode_refund_query",
    needAuth = false
)
public class ZcmopenpayApiDynamicQrcodeRefundQueryRequest implements MeituanRequest<ZcmopenpayApiDynamicQrcodeRefundQueryResponse> {
    /**
    * <p data-diff-id="ct-diff-id-d1e457af-8463-4319-9992-c671bebd2407">门店ID</p>
    */
    @NotNull(message = "merchantId不能为空")
    @SerializedName("merchantId")
    private Long merchantId;
    /**
    * <p data-diff-id="ct-diff-id-2855f5dc-c65c-4c8c-9fbe-cfad51785238"><span style="color: rgb(106, 171, 115)">动态码支付单号，与outOrderNo二选一</span></p>
    */
    @SerializedName("dynamicCodePaymentOrderId")
    private String dynamicCodePaymentOrderId;
    /**
    * <p data-diff-id="ct-diff-id-39190b40-f7e3-4f39-989c-4b10f8daa5c4">业务单号</p>
    */
    @SerializedName("outOrderNo")
    private String outOrderNo;
    /**
    * <p data-diff-id="ct-diff-id-e4263350-2e7b-4250-966c-b728c01ea104">业务方退款单号</p>
    */
    @NotBlank(message = "refundRequestNo不能为空")
    @SerializedName("refundRequestNo")
    private String refundRequestNo;

    public Long getMerchantId() {
        return merchantId;
    }
    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }
    public String getDynamicCodePaymentOrderId() {
        return dynamicCodePaymentOrderId;
    }
    public void setDynamicCodePaymentOrderId(String dynamicCodePaymentOrderId) {
        this.dynamicCodePaymentOrderId = dynamicCodePaymentOrderId;
    }
    public String getOutOrderNo() {
        return outOrderNo;
    }
    public void setOutOrderNo(String outOrderNo) {
        this.outOrderNo = outOrderNo;
    }
    public String getRefundRequestNo() {
        return refundRequestNo;
    }
    public void setRefundRequestNo(String refundRequestNo) {
        this.refundRequestNo = refundRequestNo;
    }


    @Override
    public MeituanResponse<ZcmopenpayApiDynamicQrcodeRefundQueryResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ZcmopenpayApiDynamicQrcodeRefundQueryResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ZcmopenpayApiDynamicQrcodeRefundQueryRequest{" + "merchantId=" + merchantId + "," + "dynamicCodePaymentOrderId=" + dynamicCodePaymentOrderId + "," + "outOrderNo=" + outOrderNo + "," + "refundRequestNo=" + refundRequestNo + "}";
    }
}
