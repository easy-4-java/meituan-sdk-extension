package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiFinanceSettleQueryByid;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class PageContentDTO {
    @SerializedName("pageContent")
    private List<SettleDetailModelDTO> pageContent;
    /**
    * 分页参数
    */
    @SerializedName("pageInfo")
    private PageInfoDTO pageInfo;

    public List<SettleDetailModelDTO> getPageContent() {
        return pageContent;
    }
    public void setPageContent(List<SettleDetailModelDTO> pageContent) {
        this.pageContent = pageContent;
    }
    public PageInfoDTO getPageInfo() {
        return pageInfo;
    }
    public void setPageInfo(PageInfoDTO pageInfo) {
        this.pageInfo = pageInfo;
    }




    @Override
    public String toString() {
        return "PageContentDTO{" + "pageContent=" + pageContent + "," + "pageInfo=" + pageInfo + "}";
    }
}
