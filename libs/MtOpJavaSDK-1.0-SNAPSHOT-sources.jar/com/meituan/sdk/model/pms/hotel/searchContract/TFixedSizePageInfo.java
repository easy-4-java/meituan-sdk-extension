package com.meituan.sdk.model.pms.hotel.searchContract;

import com.google.gson.annotations.SerializedName;

/**
* 分页信息
* This file was automatically generated.
*/
public class TFixedSizePageInfo {
    /**
    * 当前页码
    */
    @SerializedName("currentPageNum")
    private Long currentPageNum;
    /**
    * 每页显示数量
    */
    @SerializedName("pageSize")
    private Long pageSize;
    /**
    * 总页数
    */
    @SerializedName("totalPageCount")
    private Long totalPageCount;
    /**
    * 总记录数
    */
    @SerializedName("totalCount")
    private Long totalCount;

    public Long getCurrentPageNum() {
        return currentPageNum;
    }
    public void setCurrentPageNum(Long currentPageNum) {
        this.currentPageNum = currentPageNum;
    }
    public Long getPageSize() {
        return pageSize;
    }
    public void setPageSize(Long pageSize) {
        this.pageSize = pageSize;
    }
    public Long getTotalPageCount() {
        return totalPageCount;
    }
    public void setTotalPageCount(Long totalPageCount) {
        this.totalPageCount = totalPageCount;
    }
    public Long getTotalCount() {
        return totalCount;
    }
    public void setTotalCount(Long totalCount) {
        this.totalCount = totalCount;
    }




    @Override
    public String toString() {
        return "TFixedSizePageInfo{" + "currentPageNum=" + currentPageNum + "," + "pageSize=" + pageSize + "," + "totalPageCount=" + totalPageCount + "," + "totalCount=" + totalCount + "}";
    }
}
