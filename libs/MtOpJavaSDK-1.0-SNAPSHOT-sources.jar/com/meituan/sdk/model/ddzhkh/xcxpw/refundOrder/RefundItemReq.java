package com.meituan.sdk.model.ddzhkh.xcxpw.refundOrder;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class RefundItemReq {
    /**
    * <p data-diff-id="ct-diff-id-78940549-c3e0-4705-a230-34c2f4bc5ec6">消费项ID，按项退时必传</p>
    */
    @SerializedName("consumeItemId")
    private Long consumeItemId;
    /**
    * <p data-diff-id="ct-diff-id-4375db5e-c995-49d7-ac7a-fb1cccf91f1b">订单退款实付金额，单位：分，按项退时必传</p>
    */
    @SerializedName("refundAmount")
    private Long refundAmount;
    /**
    * <p data-diff-id="ct-diff-id-9c60a5dd-4e2e-4f52-8cc9-735032b03ad3">待收取罚金金额，单位：分，按项退时必传</p>
    */
    @SerializedName("penaltyAmount")
    private Long penaltyAmount;

    public Long getConsumeItemId() {
        return consumeItemId;
    }
    public void setConsumeItemId(Long consumeItemId) {
        this.consumeItemId = consumeItemId;
    }
    public Long getRefundAmount() {
        return refundAmount;
    }
    public void setRefundAmount(Long refundAmount) {
        this.refundAmount = refundAmount;
    }
    public Long getPenaltyAmount() {
        return penaltyAmount;
    }
    public void setPenaltyAmount(Long penaltyAmount) {
        this.penaltyAmount = penaltyAmount;
    }




    @Override
    public String toString() {
        return "RefundItemReq{" + "consumeItemId=" + consumeItemId + "," + "refundAmount=" + refundAmount + "," + "penaltyAmount=" + penaltyAmount + "}";
    }
}
