package com.meituan.sdk.model.tuangouNg.atomgoods.orderUpload;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-843bbe44-e664-4282-a5cc-7ff90e16f7d6">订单商品信息列表</p>
* This file was automatically generated.
*/
public class POrderItem {
    /**
    * <p data-diff-id="ct-diff-id-aeaff068-1604-4633-baac-306602b16101"><font style="font-size:14px;line-height:22px" data-size="14">SKU ID</font></p>
    */
    @NotNull(message = "skuId不能为空")
    @SerializedName("skuId")
    private Long skuId;
    /**
    * <p data-diff-id="ct-diff-id-227bf1c6-71d0-4a1e-8901-5ba21f9f8cb7"><font style="font-size:14px;line-height:22px" data-size="14">商品名</font></p>
    */
    @NotBlank(message = "skuName不能为空")
    @SerializedName("skuName")
    private String skuName;
    /**
    * <p data-diff-id="ct-diff-id-ad6b827b-07dd-483e-8be2-a276f73be380"><font style="font-size:14px;line-height:22px" data-size="14">SPU ID</font></p>
    */
    @NotNull(message = "spuId不能为空")
    @SerializedName("spuId")
    private Long spuId;
    /**
    * <p data-diff-id="ct-diff-id-d5d0f156-700c-45cf-ba2d-4c42179afda3"><font style="font-size:14px;line-height:22px" data-size="14">SPU名称</font></p>
    */
    @NotBlank(message = "spuName不能为空")
    @SerializedName("spuName")
    private String spuName;
    /**
    * <p data-diff-id="ct-diff-id-0696b640-94c6-4a0d-af2b-502825a51c40">是否套餐,<font style="font-size:14px;line-height:22px" data-size="14">1-是、2-否，套餐内商品值都为1</font></p>
    */
    @NotNull(message = "isCombo不能为空")
    @SerializedName("isCombo")
    private Integer isCombo;
    /**
    * <p data-diff-id="ct-diff-id-c31184f2-b382-43c1-977e-a7da02d97735"><font style="font-size:14px;line-height:22px" data-size="14">非套餐的情况下，和count一样，套餐头也一样，但是套餐子菜，count和weight是单份套餐的数量，spuCount记录的套餐份数</font></p>
    */
    @NotNull(message = "spuCount不能为空")
    @SerializedName("spuCount")
    private Long spuCount;
    /**
    * <p data-diff-id="ct-diff-id-02b517f9-3a1f-4bb6-a195-d65e9d822d5a">商品类型,<font style="font-size:14px;line-height:22px" data-size="14">1-正餐、2-称重菜</font></p>
    */
    @NotNull(message = "type不能为空")
    @SerializedName("type")
    private Long type;
    /**
    * <p data-diff-id="ct-diff-id-1291dec2-f2e3-464a-a873-31affe839554"><font style="font-size:14px;line-height:22px" data-size="14">普通菜取count，称重菜时count一般为1，代表一份</font></p><p data-diff-id="ct-diff-id-cc450dd1-ca26-48e3-92c2-0ca2717b2ebd"></p>
    */
    @NotBlank(message = "count不能为空")
    @SerializedName("count")
    private String count;
    /**
    * <p data-diff-id="ct-diff-id-51e4fc88-d012-400a-8341-53fa92498b55"><font style="font-size:14px;line-height:22px" data-size="14">称重菜时设置,默认为"0"</font></p>
    */
    @NotBlank(message = "weight不能为空")
    @SerializedName("weight")
    private String weight;
    /**
    * <p data-diff-id="ct-diff-id-5e22b292-f0bb-4809-8c0c-2e5284ca87e6"><font style="font-size:14px;line-height:22px" data-size="14">规格,</font>"大份"、"中份"、"小份"</p>
    */
    @NotBlank(message = "specs不能为空")
    @SerializedName("specs")
    private String specs;
    /**
    * <p data-diff-id="ct-diff-id-d9fcc1bc-496a-4ec2-9336-651f2cd9351f"><font style="font-size:14px;line-height:22px" data-size="14">单位,</font>"份"、"KG"</p>
    */
    @NotBlank(message = "unit不能为空")
    @SerializedName("unit")
    private String unit;
    /**
    * <p data-diff-id="ct-diff-id-ecbbf77c-8a0d-407b-9311-3bf0fa51fbe4">原价<font style="font-size:14px;line-height:22px" data-size="14">单价,单位为分</font></p>
    */
    @SerializedName("price")
    private Long price;
    /**
    * <p data-diff-id="ct-diff-id-e23b899c-9002-444c-b482-ba761694691d">原价总价<font style="font-size:14px;line-height:22px" data-size="14">,单位为分</font></p>
    */
    @SerializedName("originalTotalPrice")
    private Long originalTotalPrice;
    /**
    * <p data-diff-id="ct-diff-id-482f6b4e-0ad1-4ce1-809d-b215a62291a9"><font style="font-size:14px;line-height:22px" data-size="14">联台订单类型unionType为0的时候传订单基础信息的订单号，unionType为1的时候传子订单号。</font></p>
    */
    @NotBlank(message = "orderId不能为空")
    @SerializedName("orderId")
    private String orderId;
    /**
    * <p data-diff-id="ct-diff-id-35b55470-6742-4bed-8406-7e9118f56363">订单明细唯一标识</p>
    */
    @NotBlank(message = "itemNo不能为空")
    @SerializedName("itemNo")
    private String itemNo;
    /**
    * <p data-diff-id="ct-diff-id-bdb6c71b-a270-4737-bf8c-ea7d59691451">套餐头明细唯一标识</p>
    */
    @NotBlank(message = "parentItemNo不能为空")
    @SerializedName("parentItemNo")
    private String parentItemNo;
    /**
    * <p data-diff-id="ct-diff-id-50e50bdc-0091-44c0-b17f-cf10a34d4b44">商品类型,1:正常,2:加料,4:套餐,5:餐盒,6:宴会套餐</p>
    */
    @NotNull(message = "goodsType不能为空")
    @SerializedName("goodsType")
    private Integer goodsType;

    public Long getSkuId() {
        return skuId;
    }
    public void setSkuId(Long skuId) {
        this.skuId = skuId;
    }
    public String getSkuName() {
        return skuName;
    }
    public void setSkuName(String skuName) {
        this.skuName = skuName;
    }
    public Long getSpuId() {
        return spuId;
    }
    public void setSpuId(Long spuId) {
        this.spuId = spuId;
    }
    public String getSpuName() {
        return spuName;
    }
    public void setSpuName(String spuName) {
        this.spuName = spuName;
    }
    public Integer getIsCombo() {
        return isCombo;
    }
    public void setIsCombo(Integer isCombo) {
        this.isCombo = isCombo;
    }
    public Long getSpuCount() {
        return spuCount;
    }
    public void setSpuCount(Long spuCount) {
        this.spuCount = spuCount;
    }
    public Long getType() {
        return type;
    }
    public void setType(Long type) {
        this.type = type;
    }
    public String getCount() {
        return count;
    }
    public void setCount(String count) {
        this.count = count;
    }
    public String getWeight() {
        return weight;
    }
    public void setWeight(String weight) {
        this.weight = weight;
    }
    public String getSpecs() {
        return specs;
    }
    public void setSpecs(String specs) {
        this.specs = specs;
    }
    public String getUnit() {
        return unit;
    }
    public void setUnit(String unit) {
        this.unit = unit;
    }
    public Long getPrice() {
        return price;
    }
    public void setPrice(Long price) {
        this.price = price;
    }
    public Long getOriginalTotalPrice() {
        return originalTotalPrice;
    }
    public void setOriginalTotalPrice(Long originalTotalPrice) {
        this.originalTotalPrice = originalTotalPrice;
    }
    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public String getItemNo() {
        return itemNo;
    }
    public void setItemNo(String itemNo) {
        this.itemNo = itemNo;
    }
    public String getParentItemNo() {
        return parentItemNo;
    }
    public void setParentItemNo(String parentItemNo) {
        this.parentItemNo = parentItemNo;
    }
    public Integer getGoodsType() {
        return goodsType;
    }
    public void setGoodsType(Integer goodsType) {
        this.goodsType = goodsType;
    }




    @Override
    public String toString() {
        return "POrderItem{" + "skuId=" + skuId + "," + "skuName=" + skuName + "," + "spuId=" + spuId + "," + "spuName=" + spuName + "," + "isCombo=" + isCombo + "," + "spuCount=" + spuCount + "," + "type=" + type + "," + "count=" + count + "," + "weight=" + weight + "," + "specs=" + specs + "," + "unit=" + unit + "," + "price=" + price + "," + "originalTotalPrice=" + originalTotalPrice + "," + "orderId=" + orderId + "," + "itemNo=" + itemNo + "," + "parentItemNo=" + parentItemNo + "," + "goodsType=" + goodsType + "}";
    }
}
