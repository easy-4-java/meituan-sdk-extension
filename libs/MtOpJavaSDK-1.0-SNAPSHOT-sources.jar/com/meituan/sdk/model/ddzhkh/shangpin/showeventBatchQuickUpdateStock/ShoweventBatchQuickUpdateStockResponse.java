package com.meituan.sdk.model.ddzhkh.shangpin.showeventBatchQuickUpdateStock;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 演出项目批量快速改库存
* This file was automatically generated.
*/
public class ShoweventBatchQuickUpdateStockResponse {
    /**
    * 是否全部成功，true-全部成功；false-未全部成功
    */
    @SerializedName("allSuccess")
    private Boolean allSuccess;
    /**
    * 成功项列表
    */
    @SerializedName("successItems")
    private List<RSuccessItem> successItems;
    /**
    * 失败项列表
    */
    @SerializedName("failedItems")
    private List<RFailedItem> failedItems;

    public Boolean getAllSuccess() {
        return allSuccess;
    }
    public void setAllSuccess(Boolean allSuccess) {
        this.allSuccess = allSuccess;
    }
    public List<RSuccessItem> getSuccessItems() {
        return successItems;
    }
    public void setSuccessItems(List<RSuccessItem> successItems) {
        this.successItems = successItems;
    }
    public List<RFailedItem> getFailedItems() {
        return failedItems;
    }
    public void setFailedItems(List<RFailedItem> failedItems) {
        this.failedItems = failedItems;
    }




    @Override
    public String toString() {
        return "ShoweventBatchQuickUpdateStockResponse{" + "allSuccess=" + allSuccess + "," + "successItems=" + successItems + "," + "failedItems=" + failedItems + "}";
    }
}
