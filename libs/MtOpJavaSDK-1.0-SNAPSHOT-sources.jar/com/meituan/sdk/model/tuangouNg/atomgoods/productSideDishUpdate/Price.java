package com.meituan.sdk.model.tuangouNg.atomgoods.productSideDishUpdate;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-b83d49f0-a689-42ec-9465-28518f2eee8c">其他价格</p>
* This file was automatically generated.
*/
public class Price {
    /**
    * <p data-diff-id="ct-diff-id-fe45eae4-bc1e-4806-bbf8-eb3d4980cc28">价格名称, 会员价等自定义名称</p>
    */
    @NotBlank(message = "priceName不能为空")
    @SerializedName("priceName")
    private String priceName;
    /**
    * <p data-diff-id="ct-diff-id-8329f2f4-2b6a-4b4b-a412-6a261b20231b">价格类型, 1=普通价 2=会员价</p>
    */
    @NotNull(message = "priceType不能为空")
    @SerializedName("priceType")
    private Integer priceType;
    /**
    * <p data-diff-id="ct-diff-id-3ac89174-ba67-46d6-b15b-8348089875c7">价格, 单位是分，不可以为负</p>
    */
    @NotNull(message = "price不能为空")
    @SerializedName("price")
    private Long price;

    public String getPriceName() {
        return priceName;
    }
    public void setPriceName(String priceName) {
        this.priceName = priceName;
    }
    public Integer getPriceType() {
        return priceType;
    }
    public void setPriceType(Integer priceType) {
        this.priceType = priceType;
    }
    public Long getPrice() {
        return price;
    }
    public void setPrice(Long price) {
        this.price = price;
    }




    @Override
    public String toString() {
        return "Price{" + "priceName=" + priceName + "," + "priceType=" + priceType + "," + "price=" + price + "}";
    }
}
