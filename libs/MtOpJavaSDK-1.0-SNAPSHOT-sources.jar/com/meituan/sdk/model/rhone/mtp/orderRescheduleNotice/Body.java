package com.meituan.sdk.model.rhone.mtp.orderRescheduleNotice;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-6a0d8951-bd9e-430e-8381-6d9599dd2e59"><span style="color: ">改签通知请求内容</span></p>
* This file was automatically generated.
*/
public class Body {
    /**
    * <p data-diff-id="ct-diff-id-4d5ff72c-8962-43c5-bcc3-d97f0c515a5a"><span style="color: ">美团订单id</span></p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-20fd4fca-8bfd-4491-9107-94ebe465f138"><span style="color: ">改签唯一识别号</span></p>
    */
    @SerializedName("rescheduleNo")
    private String rescheduleNo;
    /**
    * <p data-diff-id="ct-diff-id-1c032f82-884d-4660-b822-ce3597692e84"><span style="color: ">该类型的改签已经成功改签过的次数</span><font style="font-size:14px;line-height:22px" data-size="14">（注意改签游玩人信息和改签游玩日的次数是分开统计的，该字段会用来判断是否能让用户改签，如果产品对改签次数有严格限制，请务必传入正确的值）</font></p>
    */
    @SerializedName("successCount")
    private Integer successCount;
    /**
    * <p data-diff-id="ct-diff-id-dc5d1438-29e0-47cb-9980-49e34f8d84dc"><span style="color: ">实名制证件信息</span></p>
    */
    @SerializedName("credentialVouchers")
    private List<CredentialVouchersSub> credentialVouchers;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getRescheduleNo() {
        return rescheduleNo;
    }
    public void setRescheduleNo(String rescheduleNo) {
        this.rescheduleNo = rescheduleNo;
    }
    public Integer getSuccessCount() {
        return successCount;
    }
    public void setSuccessCount(Integer successCount) {
        this.successCount = successCount;
    }
    public List<CredentialVouchersSub> getCredentialVouchers() {
        return credentialVouchers;
    }
    public void setCredentialVouchers(List<CredentialVouchersSub> credentialVouchers) {
        this.credentialVouchers = credentialVouchers;
    }




    @Override
    public String toString() {
        return "Body{" + "orderId=" + orderId + "," + "rescheduleNo=" + rescheduleNo + "," + "successCount=" + successCount + "," + "credentialVouchers=" + credentialVouchers + "}";
    }
}
