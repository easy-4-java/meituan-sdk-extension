package com.meituan.sdk.model.ddzh.yuding.queryBookrule;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class SubjectRuleDTOListSub {
    /**
    * 主体信息
    */
    @SerializedName("subject")
    private Subject subject;
    /**
    * 规则列表
    */
    @SerializedName("rules")
    private List<RulesSub> rules;

    public Subject getSubject() {
        return subject;
    }
    public void setSubject(Subject subject) {
        this.subject = subject;
    }
    public List<RulesSub> getRules() {
        return rules;
    }
    public void setRules(List<RulesSub> rules) {
        this.rules = rules;
    }




    @Override
    public String toString() {
        return "SubjectRuleDTOListSub{" + "subject=" + subject + "," + "rules=" + rules + "}";
    }
}
