package com.meituan.sdk.model.dishconnect.tuangou.couponQueryLocalList;

import com.google.gson.annotations.SerializedName;

/**
* 券详情
* This file was automatically generated.
*/
public class RCouponDetail {
    /**
    * 券码
    */
    @SerializedName("couponCode")
    private String couponCode;
    /**
    * 券码状态：10-已核销 25-已撤销。注意：同一个订单包含多张券时接口返回的券码状态可能会不一样，比如：所有券都核销后，撤销了部分券
    */
    @SerializedName("couponStatus")
    private Integer couponStatus;
    /**
    * 商家实收金额。比如一张售卖30抵50的代金券，实收就是30元，这里不考虑手续费（粗略估算，实际以结算账单为准）
    */
    @SerializedName("realAmount")
    private String realAmount;
    /**
    * 券抵扣金额。比如30抵50的代金券，核销后就可以抵扣订单中的50元；套餐券是抵扣某些商品，比如抵扣一杯奶茶，那么这里就是该奶茶的价格
    */
    @SerializedName("dealCouponAmount")
    private String dealCouponAmount;
    /**
    * 商企通相关信息
    */
    @SerializedName("sqtInfo")
    private SqtInfoDTO sqtInfo;

    public String getCouponCode() {
        return couponCode;
    }
    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }
    public Integer getCouponStatus() {
        return couponStatus;
    }
    public void setCouponStatus(Integer couponStatus) {
        this.couponStatus = couponStatus;
    }
    public String getRealAmount() {
        return realAmount;
    }
    public void setRealAmount(String realAmount) {
        this.realAmount = realAmount;
    }
    public String getDealCouponAmount() {
        return dealCouponAmount;
    }
    public void setDealCouponAmount(String dealCouponAmount) {
        this.dealCouponAmount = dealCouponAmount;
    }
    public SqtInfoDTO getSqtInfo() {
        return sqtInfo;
    }
    public void setSqtInfo(SqtInfoDTO sqtInfo) {
        this.sqtInfo = sqtInfo;
    }




    @Override
    public String toString() {
        return "RCouponDetail{" + "couponCode=" + couponCode + "," + "couponStatus=" + couponStatus + "," + "realAmount=" + realAmount + "," + "dealCouponAmount=" + dealCouponAmount + "," + "sqtInfo=" + sqtInfo + "}";
    }
}
