package com.meituan.sdk.model.ddzhkh.clubactivity.clubactivityClubActivitystatusUpdate;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class ThirdPartyUpdateActivityStatusSingleResultDTO {
    /**
    * 业务结果 true/false
    */
    @SerializedName("success")
    private Boolean success;
    /**
    * 失败原因
    */
    @SerializedName("failReason")
    private String failReason;
    /**
    * 活动id
    */
    @SerializedName("thirdPartyActivityId")
    private String thirdPartyActivityId;

    public Boolean getSuccess() {
        return success;
    }
    public void setSuccess(Boolean success) {
        this.success = success;
    }
    public String getFailReason() {
        return failReason;
    }
    public void setFailReason(String failReason) {
        this.failReason = failReason;
    }
    public String getThirdPartyActivityId() {
        return thirdPartyActivityId;
    }
    public void setThirdPartyActivityId(String thirdPartyActivityId) {
        this.thirdPartyActivityId = thirdPartyActivityId;
    }




    @Override
    public String toString() {
        return "ThirdPartyUpdateActivityStatusSingleResultDTO{" + "success=" + success + "," + "failReason=" + failReason + "," + "thirdPartyActivityId=" + thirdPartyActivityId + "}";
    }
}
