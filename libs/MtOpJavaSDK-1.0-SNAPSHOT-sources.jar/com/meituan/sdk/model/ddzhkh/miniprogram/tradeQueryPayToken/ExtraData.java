package com.meituan.sdk.model.ddzhkh.miniprogram.tradeQueryPayToken;

import com.google.gson.annotations.SerializedName;

/**
* 系统交互结果
* This file was automatically generated.
*/
public class ExtraData {
    @SerializedName("errorCode")
    private Integer errorCode;
    @SerializedName("errorMsg")
    private String errorMsg;
    @SerializedName("traceId")
    private String traceId;

    public Integer getErrorCode() {
        return errorCode;
    }
    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }
    public String getErrorMsg() {
        return errorMsg;
    }
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
    public String getTraceId() {
        return traceId;
    }
    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }




    @Override
    public String toString() {
        return "ExtraData{" + "errorCode=" + errorCode + "," + "errorMsg=" + errorMsg + "," + "traceId=" + traceId + "}";
    }
}
