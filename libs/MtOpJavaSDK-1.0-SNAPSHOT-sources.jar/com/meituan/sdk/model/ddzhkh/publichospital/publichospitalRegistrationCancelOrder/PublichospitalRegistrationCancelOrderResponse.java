package com.meituan.sdk.model.ddzhkh.publichospital.publichospitalRegistrationCancelOrder;

import com.google.gson.annotations.SerializedName;

/**
* 公立医院挂号-取消订单
* This file was automatically generated.
*/
public class PublichospitalRegistrationCancelOrderResponse {
    @SerializedName("merchantCancelOrderRes")
    private MerchantCancelOrderRes merchantCancelOrderRes;

    public MerchantCancelOrderRes getMerchantCancelOrderRes() {
        return merchantCancelOrderRes;
    }
    public void setMerchantCancelOrderRes(MerchantCancelOrderRes merchantCancelOrderRes) {
        this.merchantCancelOrderRes = merchantCancelOrderRes;
    }




    @Override
    public String toString() {
        return "PublichospitalRegistrationCancelOrderResponse{" + "merchantCancelOrderRes=" + merchantCancelOrderRes + "}";
    }
}
