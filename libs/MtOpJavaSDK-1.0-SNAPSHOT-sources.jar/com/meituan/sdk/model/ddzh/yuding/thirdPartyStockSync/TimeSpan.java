package com.meituan.sdk.model.ddzh.yuding.thirdPartyStockSync;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-dbf6181c-372e-4d0f-b0cc-ab06c8480801">当日库存时间跨度</p>
* This file was automatically generated.
*/
public class TimeSpan {
    /**
    * <p data-diff-id="ct-diff-id-109f9044-eada-4bd2-9af2-6c0d5bffb68c">开始时间 HH:mm:ss</p>
    */
    @NotBlank(message = "startTime不能为空")
    @SerializedName("startTime")
    private String startTime;
    /**
    * <p data-diff-id="ct-diff-id-cb4051a6-ff4f-4d2f-8a5a-fc21920ae2bb">结束时间 HH:mm:ss（表示一整天：  endTime 00:00:00 endInNextDay = true）</p>
    */
    @NotBlank(message = "endTime不能为空")
    @SerializedName("endTime")
    private String endTime;
    /**
    * <p data-diff-id="ct-diff-id-0f84ec14-9832-4d6d-a74a-6f402f5bdca4">时段开始时间是否跨天（可选，默认false）</p>
    */
    @SerializedName("startInNextDay")
    private Boolean startInNextDay;
    /**
    * <p data-diff-id="ct-diff-id-d59022b6-4f51-47fd-a890-2c3ba3c4d416">时段结束时间是否跨天（可选，默认false）</p>
    */
    @SerializedName("endInNextDay")
    private Boolean endInNextDay;

    public String getStartTime() {
        return startTime;
    }
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    public String getEndTime() {
        return endTime;
    }
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    public Boolean getStartInNextDay() {
        return startInNextDay;
    }
    public void setStartInNextDay(Boolean startInNextDay) {
        this.startInNextDay = startInNextDay;
    }
    public Boolean getEndInNextDay() {
        return endInNextDay;
    }
    public void setEndInNextDay(Boolean endInNextDay) {
        this.endInNextDay = endInNextDay;
    }




    @Override
    public String toString() {
        return "TimeSpan{" + "startTime=" + startTime + "," + "endTime=" + endTime + "," + "startInNextDay=" + startInNextDay + "," + "endInNextDay=" + endInNextDay + "}";
    }
}
