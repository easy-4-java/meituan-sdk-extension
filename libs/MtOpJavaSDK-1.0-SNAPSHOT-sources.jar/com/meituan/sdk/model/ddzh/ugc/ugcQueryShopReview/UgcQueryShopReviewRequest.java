package com.meituan.sdk.model.ddzh.ugc.ugcQueryShopReview;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 单一门店查询评论数据
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/ugc/queryshopreview",
    businessId = 58,
    apiVersion = "10007",
    apiName = "ugc_query_shop_review",
    needAuth = true
)
public class UgcQueryShopReviewRequest implements MeituanRequest<UgcQueryShopReviewResponse> {
    /**
    * <p data-diff-id="ct-diff-id-3dce4046-8b5f-4a27-9a25-23d55a940381"><span style="color: rgb(31, 45, 61)">星级筛选 1-全部， 2-好评 3-中差评</span></p>
    */
    @NotNull(message = "star不能为空")
    @SerializedName("star")
    private Integer star;
    /**
    * <p data-diff-id="ct-diff-id-ea36a2dd-1d95-45cf-ae24-236aec59a1cc">查询页码，从1开始</p>
    */
    @NotNull(message = "offset不能为空")
    @SerializedName("offset")
    private Integer offset;
    /**
    * <p data-diff-id="ct-diff-id-0cc98acd-899b-499c-ac7b-b85fea853b0b"><span style="color: rgb(31, 45, 61)">每页数量 最大不超过50</span></p>
    */
    @NotNull(message = "limit不能为空")
    @SerializedName("limit")
    private Integer limit;
    /**
    * <p data-diff-id="ct-diff-id-6005e4ed-b6a6-412e-910e-79ecc7609b5d"><span style="color: rgb(31, 45, 61)">评论添加日期开始，格式如 2016-05-24 10:10:10</span></p>
    */
    @NotBlank(message = "beginTime不能为空")
    @SerializedName("beginTime")
    private String beginTime;
    /**
    * <p data-diff-id="ct-diff-id-799c7522-dca0-4a3d-aef5-2547ea5f3043"><span style="color: rgb(31, 45, 61)">评论添加日期结束，格式如 2016-06-24 10:10:10，查询区间最多一年</span></p>
    */
    @NotBlank(message = "endTime不能为空")
    @SerializedName("endTime")
    private String endTime;
    /**
    * <p data-diff-id="ct-diff-id-1fc83360-982e-4200-bfd1-172bab78813d"><span style="color: rgb(31, 45, 61)">1-大众点评，2-美团 （美团的评价与大众点评的评价是分开的，需要单独查）</span></p>
    */
    @NotNull(message = "platform不能为空")
    @SerializedName("platform")
    private Integer platform;

    public Integer getStar() {
        return star;
    }
    public void setStar(Integer star) {
        this.star = star;
    }
    public Integer getOffset() {
        return offset;
    }
    public void setOffset(Integer offset) {
        this.offset = offset;
    }
    public Integer getLimit() {
        return limit;
    }
    public void setLimit(Integer limit) {
        this.limit = limit;
    }
    public String getBeginTime() {
        return beginTime;
    }
    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime;
    }
    public String getEndTime() {
        return endTime;
    }
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    public Integer getPlatform() {
        return platform;
    }
    public void setPlatform(Integer platform) {
        this.platform = platform;
    }


    @Override
    public MeituanResponse<UgcQueryShopReviewResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<UgcQueryShopReviewResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "UgcQueryShopReviewRequest{" + "star=" + star + "," + "offset=" + offset + "," + "limit=" + limit + "," + "beginTime=" + beginTime + "," + "endTime=" + endTime + "," + "platform=" + platform + "}";
    }
}
