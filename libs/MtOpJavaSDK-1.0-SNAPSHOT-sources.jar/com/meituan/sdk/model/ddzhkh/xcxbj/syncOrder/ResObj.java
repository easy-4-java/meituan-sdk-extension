package com.meituan.sdk.model.ddzhkh.xcxbj.syncOrder;

import com.google.gson.annotations.SerializedName;

/**
* 业务交互结果业务交互结果
* This file was automatically generated.
*/
public class ResObj {
    @SerializedName("code")
    private Integer code;
    @SerializedName("msg")
    private String msg;

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }




    @Override
    public String toString() {
        return "ResObj{" + "code=" + code + "," + "msg=" + msg + "}";
    }
}
