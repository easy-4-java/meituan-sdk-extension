package com.meituan.sdk.model.ddzhkh.miniprogram.tradeRefundOrder;

import com.google.gson.annotations.SerializedName;

/**
* 业务交互结果
* This file was automatically generated.
*/
public class TradeInwardRes {
    @SerializedName("code")
    private Integer code;
    @SerializedName("msg")
    private String msg;
    /**
    * 申请退款响应数据
    */
    @SerializedName("data")
    private RefundOrderRes data;

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public RefundOrderRes getData() {
        return data;
    }
    public void setData(RefundOrderRes data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "TradeInwardRes{" + "code=" + code + "," + "msg=" + msg + "," + "data=" + data + "}";
    }
}
