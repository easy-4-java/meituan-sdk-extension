package com.meituan.sdk.model.waimaiNg.diancan.diancanShopconfigQuery;

import com.google.gson.annotations.SerializedName;

/**
* 业务配置
* This file was automatically generated.
*/
public class VendorBizConfigDTO {
    /**
    * 门店业务开通状态，参数值范例：  {\"timestamp\":1675241667962,\"turnOn\":true}
    */
    @SerializedName("vendorBizOpenStatus")
    private String vendorBizOpenStatus;

    public String getVendorBizOpenStatus() {
        return vendorBizOpenStatus;
    }
    public void setVendorBizOpenStatus(String vendorBizOpenStatus) {
        this.vendorBizOpenStatus = vendorBizOpenStatus;
    }




    @Override
    public String toString() {
        return "VendorBizConfigDTO{" + "vendorBizOpenStatus=" + vendorBizOpenStatus + "}";
    }
}
