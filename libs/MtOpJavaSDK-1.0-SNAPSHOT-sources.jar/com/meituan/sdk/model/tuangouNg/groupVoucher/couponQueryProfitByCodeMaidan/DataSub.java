package com.meituan.sdk.model.tuangouNg.groupVoucher.couponQueryProfitByCodeMaidan;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class DataSub {
    /**
    * 买单800码
    */
    @SerializedName("orderItemId")
    private String orderItemId;
    /**
    * 买单订单号（即尾款订单号）
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * 美团门店ID
    */
    @SerializedName("poiId")
    private Long poiId;
    /**
    * 美团项目ID，等同DealID
    */
    @SerializedName("productId")
    private Long productId;
    /**
    * 流水类型，包括：消费、退款
    */
    @SerializedName("traceType")
    private String traceType;
    /**
    * 退款时间，精确到秒
    */
    @SerializedName("refundTime")
    private String refundTime;
    /**
    * 消费时间，精确到秒
    */
    @SerializedName("useTime")
    private String useTime;
    /**
    * 收益时间，精确到秒
    */
    @SerializedName("gmtCreateTime")
    private String gmtCreateTime;
    /**
    * 消费金额(原价)
    */
    @SerializedName("originalPrice")
    private String originalPrice;
    /**
    * 顾客应付(售价)
    */
    @SerializedName("salePrice")
    private String salePrice;
    /**
    * 商家应得
    */
    @SerializedName("partnerIncome")
    private String partnerIncome;
    /**
    * 商家承担退款
    */
    @SerializedName("refund")
    private String refund;
    /**
    * 顾客实付
    */
    @SerializedName("payAmount")
    private String payAmount;
    /**
    * 代金券/充值抵扣
    */
    @SerializedName("savingCardAmount")
    private String savingCardAmount;
    /**
    * 服务费total
    */
    @SerializedName("serviceTotal")
    private String serviceTotal;
    /**
    * 服务费明细
    */
    @SerializedName("serviceDTO")
    private String serviceDTO;
    /**
    * 其他费用total
    */
    @SerializedName("otherIncomeTotal")
    private String otherIncomeTotal;
    /**
    * 其他费用明细
    */
    @SerializedName("otherIncomeDTO")
    private String otherIncomeDTO;
    /**
    * 促消费total
    */
    @SerializedName("bizCostTotal")
    private String bizCostTotal;
    /**
    * 促消费明细
    */
    @SerializedName("bizCostDTO")
    private String bizCostDTO;

    public String getOrderItemId() {
        return orderItemId;
    }
    public void setOrderItemId(String orderItemId) {
        this.orderItemId = orderItemId;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public Long getPoiId() {
        return poiId;
    }
    public void setPoiId(Long poiId) {
        this.poiId = poiId;
    }
    public Long getProductId() {
        return productId;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }
    public String getTraceType() {
        return traceType;
    }
    public void setTraceType(String traceType) {
        this.traceType = traceType;
    }
    public String getRefundTime() {
        return refundTime;
    }
    public void setRefundTime(String refundTime) {
        this.refundTime = refundTime;
    }
    public String getUseTime() {
        return useTime;
    }
    public void setUseTime(String useTime) {
        this.useTime = useTime;
    }
    public String getGmtCreateTime() {
        return gmtCreateTime;
    }
    public void setGmtCreateTime(String gmtCreateTime) {
        this.gmtCreateTime = gmtCreateTime;
    }
    public String getOriginalPrice() {
        return originalPrice;
    }
    public void setOriginalPrice(String originalPrice) {
        this.originalPrice = originalPrice;
    }
    public String getSalePrice() {
        return salePrice;
    }
    public void setSalePrice(String salePrice) {
        this.salePrice = salePrice;
    }
    public String getPartnerIncome() {
        return partnerIncome;
    }
    public void setPartnerIncome(String partnerIncome) {
        this.partnerIncome = partnerIncome;
    }
    public String getRefund() {
        return refund;
    }
    public void setRefund(String refund) {
        this.refund = refund;
    }
    public String getPayAmount() {
        return payAmount;
    }
    public void setPayAmount(String payAmount) {
        this.payAmount = payAmount;
    }
    public String getSavingCardAmount() {
        return savingCardAmount;
    }
    public void setSavingCardAmount(String savingCardAmount) {
        this.savingCardAmount = savingCardAmount;
    }
    public String getServiceTotal() {
        return serviceTotal;
    }
    public void setServiceTotal(String serviceTotal) {
        this.serviceTotal = serviceTotal;
    }
    public String getServiceDTO() {
        return serviceDTO;
    }
    public void setServiceDTO(String serviceDTO) {
        this.serviceDTO = serviceDTO;
    }
    public String getOtherIncomeTotal() {
        return otherIncomeTotal;
    }
    public void setOtherIncomeTotal(String otherIncomeTotal) {
        this.otherIncomeTotal = otherIncomeTotal;
    }
    public String getOtherIncomeDTO() {
        return otherIncomeDTO;
    }
    public void setOtherIncomeDTO(String otherIncomeDTO) {
        this.otherIncomeDTO = otherIncomeDTO;
    }
    public String getBizCostTotal() {
        return bizCostTotal;
    }
    public void setBizCostTotal(String bizCostTotal) {
        this.bizCostTotal = bizCostTotal;
    }
    public String getBizCostDTO() {
        return bizCostDTO;
    }
    public void setBizCostDTO(String bizCostDTO) {
        this.bizCostDTO = bizCostDTO;
    }




    @Override
    public String toString() {
        return "DataSub{" + "orderItemId=" + orderItemId + "," + "orderId=" + orderId + "," + "poiId=" + poiId + "," + "productId=" + productId + "," + "traceType=" + traceType + "," + "refundTime=" + refundTime + "," + "useTime=" + useTime + "," + "gmtCreateTime=" + gmtCreateTime + "," + "originalPrice=" + originalPrice + "," + "salePrice=" + salePrice + "," + "partnerIncome=" + partnerIncome + "," + "refund=" + refund + "," + "payAmount=" + payAmount + "," + "savingCardAmount=" + savingCardAmount + "," + "serviceTotal=" + serviceTotal + "," + "serviceDTO=" + serviceDTO + "," + "otherIncomeTotal=" + otherIncomeTotal + "," + "otherIncomeDTO=" + otherIncomeDTO + "," + "bizCostTotal=" + bizCostTotal + "," + "bizCostDTO=" + bizCostDTO + "}";
    }
}
