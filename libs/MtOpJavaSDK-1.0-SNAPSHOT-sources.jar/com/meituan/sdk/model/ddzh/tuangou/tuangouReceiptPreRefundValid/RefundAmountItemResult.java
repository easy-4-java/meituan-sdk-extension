package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptPreRefundValid;

import com.google.gson.annotations.SerializedName;

/**
* 退款金额组成
* This file was automatically generated.
*/
public class RefundAmountItemResult {
    /**
    * 资金类型
    */
    @SerializedName("amountType")
    private Integer amountType;
    /**
    * 优惠名称
    */
    @SerializedName("title")
    private String title;
    /**
    * 优惠金额(单位分)
    */
    @SerializedName("value")
    private Long value;
    /**
    * 是否展示可退回
    */
    @SerializedName("refundable")
    private Boolean refundable;

    public Integer getAmountType() {
        return amountType;
    }
    public void setAmountType(Integer amountType) {
        this.amountType = amountType;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public Long getValue() {
        return value;
    }
    public void setValue(Long value) {
        this.value = value;
    }
    public Boolean getRefundable() {
        return refundable;
    }
    public void setRefundable(Boolean refundable) {
        this.refundable = refundable;
    }




    @Override
    public String toString() {
        return "RefundAmountItemResult{" + "amountType=" + amountType + "," + "title=" + title + "," + "value=" + value + "," + "refundable=" + refundable + "}";
    }
}
