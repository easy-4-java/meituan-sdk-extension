package com.meituan.sdk.model.pms.reservation.autoDispatchRoom;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 预订单自动排房
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/reservation/autoDispatchRoom",
    businessId = 57,
    apiVersion = "10058",
    apiName = "auto_dispatch_room",
    needAuth = true
)
public class AutoDispatchRoomRequest implements MeituanRequest<AutoDispatchRoomResponse> {
    /**
    * <p data-diff-id="ct-diff-id-8b89eba7-ad40-4664-b353-8eacd4b6541c">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-439d997d-0740-4a6f-8b4c-c16a1a92478f">订单ID</p>
    */
    @NotNull(message = "orderId不能为空")
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-ca93e91f-30cb-4138-8381-194e339f5ae4">占房ID</p>
    */
    @NotNull(message = "occupationId不能为空")
    @SerializedName("occupationId")
    private Long occupationId;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public Long getOccupationId() {
        return occupationId;
    }
    public void setOccupationId(Long occupationId) {
        this.occupationId = occupationId;
    }


    @Override
    public MeituanResponse<AutoDispatchRoomResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<AutoDispatchRoomResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "AutoDispatchRoomRequest{" + "hotelId=" + hotelId + "," + "orderId=" + orderId + "," + "occupationId=" + occupationId + "}";
    }
}
