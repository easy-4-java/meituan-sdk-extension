package com.meituan.sdk.model.ddzhkh.dingdan.orderBookBatchQuery;

import com.google.gson.annotations.SerializedName;

/**
* 退款申请单列表
* This file was automatically generated.
*/
public class RefundApplication {
    /**
    * 退款申请单状态，：0004-退款完成，0005-退款失败，其他状态码-退款中
    */
    @SerializedName("refundStatus")
    private String refundStatus;
    /**
    * 实际退款金额
    */
    @SerializedName("refundAmount")
    private String refundAmount;
    /**
    * 退款完成时间(退款成功时才有)
    */
    @SerializedName("refundSuccessTime")
    private String refundSuccessTime;
    /**
    * 退款单ID
    */
    @SerializedName("refundId")
    private String refundId;

    public String getRefundStatus() {
        return refundStatus;
    }
    public void setRefundStatus(String refundStatus) {
        this.refundStatus = refundStatus;
    }
    public String getRefundAmount() {
        return refundAmount;
    }
    public void setRefundAmount(String refundAmount) {
        this.refundAmount = refundAmount;
    }
    public String getRefundSuccessTime() {
        return refundSuccessTime;
    }
    public void setRefundSuccessTime(String refundSuccessTime) {
        this.refundSuccessTime = refundSuccessTime;
    }
    public String getRefundId() {
        return refundId;
    }
    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }




    @Override
    public String toString() {
        return "RefundApplication{" + "refundStatus=" + refundStatus + "," + "refundAmount=" + refundAmount + "," + "refundSuccessTime=" + refundSuccessTime + "," + "refundId=" + refundId + "}";
    }
}
