package com.meituan.sdk.model.ddzh.tuangou.tuangouGoodsStockSync;

import com.google.gson.annotations.SerializedName;

/**
* 商品库存批量同步
* This file was automatically generated.
*/
public class TuangouGoodsStockSyncResponse {
    @SerializedName("result")
    private Boolean result;

    public Boolean getResult() {
        return result;
    }
    public void setResult(Boolean result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "TuangouGoodsStockSyncResponse{" + "result=" + result + "}";
    }
}
