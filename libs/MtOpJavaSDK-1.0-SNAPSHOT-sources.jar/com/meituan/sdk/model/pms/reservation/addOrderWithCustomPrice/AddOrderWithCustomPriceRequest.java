package com.meituan.sdk.model.pms.reservation.addOrderWithCustomPrice;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 添加自定义价订单
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/reservation/addOrderWithCustomPrice",
    businessId = 57,
    apiVersion = "10040",
    apiName = "add_order_with_custom_price",
    needAuth = true
)
public class AddOrderWithCustomPriceRequest implements MeituanRequest<AddOrderWithCustomPriceResponse> {
    /**
    * <p data-diff-id="ct-diff-id-d5519ad1-d4d6-4f61-9a26-c4797d486f7b">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-c7d76c0b-f39c-4ff2-9e6a-834782e3db53">订单编号</p>
    */
    @SerializedName("orderSn")
    private String orderSn;
    /**
    * <p data-diff-id="ct-diff-id-8f8f804a-7588-4313-ac2d-e53d6058a2e1">渠道订单号</p>
    */
    @SerializedName("channelOrderSn")
    private String channelOrderSn;
    /**
    * <p data-diff-id="ct-diff-id-af135d19-2373-4168-a297-407ab30c09c7">订房计划。</p><p data-diff-id="ct-diff-id-1b455286-9969-4e6b-bfd1-c3dafd2a8fe8"><strong>特别说明：同房型同一天多间不同价如何传参？</strong></p><p data-diff-id="ct-diff-id-33d18357-4da2-4748-a044-c2c3ac8412b2">假设预订10月8日的大床房2间，一个房间首住享受优惠后价格100元，另一个房间门市价售卖150元，则按照如下格式传参：<br><span style="color: rgb(163, 21, 21)">"roomPlans"</span><span style="color: rgb(0, 0, 0)">: [{</span></p><p style="margin-left: 20px;" data-diff-id="ct-diff-id-e831b60f-8194-4a7d-b564-3707e7b666d6"><span style="color: rgb(163, 21, 21)">"roomTypeId"</span><span style="color: rgb(0, 0, 0)">: </span><span style="color: rgb(4, 81, 165)">"DR"</span><span style="color: rgb(0, 0, 0)">,</span></p><p style="margin-left: 20px;" data-diff-id="ct-diff-id-251686a5-6823-448e-a53f-b5da70467d14"><span style="color: rgb(163, 21, 21)">"count"</span><span style="color: rgb(0, 0, 0)">: </span><span style="color: rgb(9, 134, 88)">1</span><span style="color: rgb(0, 0, 0)">,</span></p><p style="margin-left: 20px;" data-diff-id="ct-diff-id-71852757-cc22-4573-a823-bcf342137ae4"><span style="color: rgb(163, 21, 21)">"priceDetails"</span><span style="color: rgb(0, 0, 0)">: [{</span></p><p style="margin-left: 20px;" data-diff-id="ct-diff-id-9e0c9d6c-a9a5-4816-91b5-a69072c0c5e0"><span style="color: rgb(163, 21, 21)">"date"</span><span style="color: rgb(0, 0, 0)">: </span><span style="color: rgb(4, 81, 165)">"2024-10-08"</span><span style="color: rgb(0, 0, 0)">,</span></p><p style="margin-left: 20px;" data-diff-id="ct-diff-id-f72754ce-2a1e-498f-aa5e-89814877d1d4"><span style="color: rgb(163, 21, 21)">"actualPrice"</span><span style="color: rgb(0, 0, 0)">: </span><span style="color: rgb(4, 81, 165)">"100.00"</span></p><p style="margin-left: 20px;" data-diff-id="ct-diff-id-c2257514-af80-4e1a-a44e-9387289dc3e0"><span style="color: rgb(0, 0, 0)">}]</span></p><p data-diff-id="ct-diff-id-0e2fd621-dfa5-42fe-8a1a-d31d7933af22"><span style="color: rgb(0, 0, 0)"> },</span></p><p data-diff-id="ct-diff-id-c1cfb124-3eda-4fa7-a2e0-a09272ef331f"><span style="color: rgb(0, 0, 0)"> {</span></p><p style="margin-left: 20px;" data-diff-id="ct-diff-id-1e5375e3-dd30-4d28-bd7f-d9bcf4692e39"><span style="color: rgb(163, 21, 21)">"roomTypeId"</span><span style="color: rgb(0, 0, 0)">: </span><span style="color: rgb(4, 81, 165)">"DR"</span><span style="color: rgb(0, 0, 0)">,</span></p><p style="margin-left: 20px;" data-diff-id="ct-diff-id-1ce56135-9b31-4aa9-a4cc-abe46aa47f79"><span style="color: rgb(163, 21, 21)">"count"</span><span style="color: rgb(0, 0, 0)">: </span><span style="color: rgb(9, 134, 88)">1</span><span style="color: rgb(0, 0, 0)">,</span></p><p style="margin-left: 20px;" data-diff-id="ct-diff-id-458cff7c-6bf6-414c-abb4-1845b4e731bf"><span style="color: rgb(163, 21, 21)">"priceDetails"</span><span style="color: rgb(0, 0, 0)">: [{</span></p><p style="margin-left: 40px;" data-diff-id="ct-diff-id-ba953c7b-7e91-4358-a643-d7b9573c139a"><span style="color: rgb(163, 21, 21)">"date"</span><span style="color: rgb(0, 0, 0)">: </span><span style="color: rgb(4, 81, 165)">"2024-10-08"</span><span style="color: rgb(0, 0, 0)">,</span></p><p style="margin-left: 40px;" data-diff-id="ct-diff-id-d2efffe3-8ad0-4801-a7b7-5c95d78f0f40"><span style="color: rgb(163, 21, 21)">"actualPrice"</span><span style="color: rgb(0, 0, 0)">: </span><span style="color: rgb(4, 81, 165)">"150.00"</span></p><p style="margin-left: 20px;" data-diff-id="ct-diff-id-ab5a2027-0c43-49ce-90d2-06a062704f6c"><span style="color: rgb(0, 0, 0)"> }</span></p><p style="margin-left: 20px;" data-diff-id="ct-diff-id-e2ce0cbe-4530-46bc-ae5c-9105451ac36f"><span style="color: rgb(0, 0, 0)"> ]</span></p><p data-diff-id="ct-diff-id-c7f74d70-691e-46e6-98dd-cad6dabd50d0"><span style="color: rgb(0, 0, 0)"> }]</span></p>
    */
    @NotEmpty(message = "roomPlans不能为空")
    @SerializedName("roomPlans")
    private List<CustomPriceRoomPlanDTO> roomPlans;
    /**
    * <p data-diff-id="ct-diff-id-e8e0fc7f-329e-45c0-8cf9-bb31ce32947a">担保类型，详见PrePayment字典</p>
    */
    @SerializedName("prePaymentType")
    private String prePaymentType;
    /**
    * <p data-diff-id="ct-diff-id-dfba7330-682f-4e9a-8686-82e515ab472b">保留时间，格式yyy-MM-dd HH:mm:ss</p>
    */
    @SerializedName("expireKeepTime")
    private String expireKeepTime;
    /**
    * <p data-diff-id="ct-diff-id-834c074f-4583-4cf4-bb5f-ebeec8804ee1">入住类型，详见CheckinType字典</p>
    */
    @NotBlank(message = "checkinType不能为空")
    @SerializedName("checkinType")
    private String checkinType;
    /**
    * <p data-diff-id="ct-diff-id-831027da-96ea-4c6b-8ab0-ae49774705da">预抵时间，格式yyyy-MM-dd HH:mm:ss</p>
    */
    @SerializedName("estimatedArriveTime")
    private String estimatedArriveTime;
    /**
    * <p data-diff-id="ct-diff-id-c3788edb-f273-4b8b-8f76-2ef4b1fe16fb">预离时间，格式yyyy-MM-dd HH:mm:ss</p>
    */
    @SerializedName("estimatedDepartureTime")
    private String estimatedDepartureTime;
    /**
    * <p data-diff-id="ct-diff-id-06d087a8-c186-4257-a2cd-4b4bf487fe7b">联系人信息</p>
    */
    @NotEmpty(message = "liaisons不能为空")
    @SerializedName("liaisons")
    private List<LiaisonsDTO> liaisons;
    /**
    * <p data-diff-id="ct-diff-id-d6282a3f-5eb4-4804-ac1c-c5dc6f45bc02">备注</p>
    */
    @SerializedName("memo")
    private String memo;
    /**
    * <p data-diff-id="ct-diff-id-698c1c6c-b483-46ee-998d-73abfb60039e">渠道订单备注</p>
    */
    @SerializedName("channelMemo")
    private String channelMemo;
    /**
    * <p data-diff-id="ct-diff-id-f133dc77-d77b-4d33-bdd1-71ec3816b01e">会员ID，会员预订时填写</p>
    */
    @SerializedName("memberId")
    private Long memberId;
    /**
    * <p data-diff-id="ct-diff-id-44abb4e3-5d30-43e7-8345-8339482e0997">协议公司/中介ID，中介和协议公司预订时填写</p>
    */
    @SerializedName("contractId")
    private Long contractId;
    /**
    * <p data-diff-id="ct-diff-id-bbd9e2f4-ed4e-4f33-88c0-7038b7d40de5">是否锁房</p>
    */
    @SerializedName("locked")
    private Boolean locked;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getOrderSn() {
        return orderSn;
    }
    public void setOrderSn(String orderSn) {
        this.orderSn = orderSn;
    }
    public String getChannelOrderSn() {
        return channelOrderSn;
    }
    public void setChannelOrderSn(String channelOrderSn) {
        this.channelOrderSn = channelOrderSn;
    }
    public List<CustomPriceRoomPlanDTO> getRoomPlans() {
        return roomPlans;
    }
    public void setRoomPlans(List<CustomPriceRoomPlanDTO> roomPlans) {
        this.roomPlans = roomPlans;
    }
    public String getPrePaymentType() {
        return prePaymentType;
    }
    public void setPrePaymentType(String prePaymentType) {
        this.prePaymentType = prePaymentType;
    }
    public String getExpireKeepTime() {
        return expireKeepTime;
    }
    public void setExpireKeepTime(String expireKeepTime) {
        this.expireKeepTime = expireKeepTime;
    }
    public String getCheckinType() {
        return checkinType;
    }
    public void setCheckinType(String checkinType) {
        this.checkinType = checkinType;
    }
    public String getEstimatedArriveTime() {
        return estimatedArriveTime;
    }
    public void setEstimatedArriveTime(String estimatedArriveTime) {
        this.estimatedArriveTime = estimatedArriveTime;
    }
    public String getEstimatedDepartureTime() {
        return estimatedDepartureTime;
    }
    public void setEstimatedDepartureTime(String estimatedDepartureTime) {
        this.estimatedDepartureTime = estimatedDepartureTime;
    }
    public List<LiaisonsDTO> getLiaisons() {
        return liaisons;
    }
    public void setLiaisons(List<LiaisonsDTO> liaisons) {
        this.liaisons = liaisons;
    }
    public String getMemo() {
        return memo;
    }
    public void setMemo(String memo) {
        this.memo = memo;
    }
    public String getChannelMemo() {
        return channelMemo;
    }
    public void setChannelMemo(String channelMemo) {
        this.channelMemo = channelMemo;
    }
    public Long getMemberId() {
        return memberId;
    }
    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }
    public Long getContractId() {
        return contractId;
    }
    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }
    public Boolean getLocked() {
        return locked;
    }
    public void setLocked(Boolean locked) {
        this.locked = locked;
    }


    @Override
    public MeituanResponse<AddOrderWithCustomPriceResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<AddOrderWithCustomPriceResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "AddOrderWithCustomPriceRequest{" + "hotelId=" + hotelId + "," + "orderSn=" + orderSn + "," + "channelOrderSn=" + channelOrderSn + "," + "roomPlans=" + roomPlans + "," + "prePaymentType=" + prePaymentType + "," + "expireKeepTime=" + expireKeepTime + "," + "checkinType=" + checkinType + "," + "estimatedArriveTime=" + estimatedArriveTime + "," + "estimatedDepartureTime=" + estimatedDepartureTime + "," + "liaisons=" + liaisons + "," + "memo=" + memo + "," + "channelMemo=" + channelMemo + "," + "memberId=" + memberId + "," + "contractId=" + contractId + "," + "locked=" + locked + "}";
    }
}
