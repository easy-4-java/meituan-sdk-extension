package com.meituan.sdk.model.pms.reservation.dispatchOrderRoom;

import com.google.gson.annotations.SerializedName;

/**
* 预订单排房
* This file was automatically generated.
*/
public class DispatchOrderRoomResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    /**
    * 操作结果
    */
    @SerializedName("data")
    private Boolean data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public Boolean getData() {
        return data;
    }
    public void setData(Boolean data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "DispatchOrderRoomResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
