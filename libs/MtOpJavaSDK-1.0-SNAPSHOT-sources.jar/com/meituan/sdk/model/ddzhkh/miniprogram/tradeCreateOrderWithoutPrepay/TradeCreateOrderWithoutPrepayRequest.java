package com.meituan.sdk.model.ddzhkh.miniprogram.tradeCreateOrderWithoutPrepay;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 下单（不包含预支付）
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/miniprogram/trade/create_order_without_prepay",
    businessId = 59,
    apiVersion = "10014",
    apiName = "trade_create_order_without_prepay",
    needAuth = true
)
public class TradeCreateOrderWithoutPrepayRequest implements MeituanRequest<TradeCreateOrderWithoutPrepayResponse> {
    @NotBlank(message = "generalBizData不能为空")
    @SerializedName("generalBizData")
    private String generalBizData;
    @NotNull(message = "createOrderReq不能为空")
    @SerializedName("createOrderReq")
    private CreateOrderReq createOrderReq;

    public String getGeneralBizData() {
        return generalBizData;
    }
    public void setGeneralBizData(String generalBizData) {
        this.generalBizData = generalBizData;
    }
    public CreateOrderReq getCreateOrderReq() {
        return createOrderReq;
    }
    public void setCreateOrderReq(CreateOrderReq createOrderReq) {
        this.createOrderReq = createOrderReq;
    }


    @Override
    public MeituanResponse<TradeCreateOrderWithoutPrepayResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<TradeCreateOrderWithoutPrepayResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TradeCreateOrderWithoutPrepayRequest{" + "generalBizData=" + generalBizData + "," + "createOrderReq=" + createOrderReq + "}";
    }
}
