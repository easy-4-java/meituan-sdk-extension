package com.meituan.sdk.model.ddzhkh.shangpin.productUnitedUpdateShop;

import com.google.gson.annotations.SerializedName;

/**
* 商品快速改门店（通用）
* This file was automatically generated.
*/
public class ProductUnitedUpdateShopResponse {
    /**
    * 响应结果
    */
    @SerializedName("result")
    private String result;

    public String getResult() {
        return result;
    }
    public void setResult(String result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "ProductUnitedUpdateShopResponse{" + "result=" + result + "}";
    }
}
