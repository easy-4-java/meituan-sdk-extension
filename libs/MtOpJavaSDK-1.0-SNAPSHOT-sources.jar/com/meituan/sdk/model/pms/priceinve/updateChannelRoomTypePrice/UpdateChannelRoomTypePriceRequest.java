package com.meituan.sdk.model.pms.priceinve.updateChannelRoomTypePrice;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 修改渠道售卖价
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/priceinve/updateChannelRoomTypePrice",
    businessId = 57,
    apiVersion = "10021",
    apiName = "update_channel_room_type_price",
    needAuth = true
)
public class UpdateChannelRoomTypePriceRequest implements MeituanRequest<Boolean> {
    /**
    * 酒店ID
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * 渠道编码，如 TRIP/MeituanEBK/DOUYIN/FLIGGY 或门店渠道标识
    */
    @NotBlank(message = "channelKey不能为空")
    @SerializedName("channelKey")
    private String channelKey;
    /**
    * 房型ID，OTA渠道传渠道房型编码；门店渠道传物理房型编码字符串
    */
    @NotBlank(message = "roomTypeId不能为空")
    @SerializedName("roomTypeId")
    private String roomTypeId;
    /**
    * 价格联动策略ID，OTA渠道必传，门店渠道不传
    */
    @NotNull(message = "policyId不能为空")
    @SerializedName("policyId")
    private Long policyId;
    /**
    * 开始日期，格式 yyyy-MM-dd
    */
    @NotBlank(message = "startDate不能为空")
    @SerializedName("startDate")
    private String startDate;
    /**
    * 结束日期，格式 yyyy-MM-dd
    */
    @NotBlank(message = "endDate不能为空")
    @SerializedName("endDate")
    private String endDate;
    /**
    * 售卖价，单位：分，>=0
    */
    @NotNull(message = "price不能为空")
    @SerializedName("price")
    private Integer price;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getChannelKey() {
        return channelKey;
    }
    public void setChannelKey(String channelKey) {
        this.channelKey = channelKey;
    }
    public String getRoomTypeId() {
        return roomTypeId;
    }
    public void setRoomTypeId(String roomTypeId) {
        this.roomTypeId = roomTypeId;
    }
    public Long getPolicyId() {
        return policyId;
    }
    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }
    public String getStartDate() {
        return startDate;
    }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    public String getEndDate() {
        return endDate;
    }
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    public Integer getPrice() {
        return price;
    }
    public void setPrice(Integer price) {
        this.price = price;
    }


    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "UpdateChannelRoomTypePriceRequest{" + "hotelId=" + hotelId + "," + "channelKey=" + channelKey + "," + "roomTypeId=" + roomTypeId + "," + "policyId=" + policyId + "," + "startDate=" + startDate + "," + "endDate=" + endDate + "," + "price=" + price + "}";
    }
}
