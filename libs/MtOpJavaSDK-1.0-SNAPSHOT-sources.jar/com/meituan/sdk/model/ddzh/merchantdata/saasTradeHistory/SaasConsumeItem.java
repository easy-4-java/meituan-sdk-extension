package com.meituan.sdk.model.ddzh.merchantdata.saasTradeHistory;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-c354fd55-49d3-4117-8061-69ee649fea38">消费项目</p>
* This file was automatically generated.
*/
public class SaasConsumeItem {
    /**
    * <p data-diff-id="ct-diff-id-1ad4a361-b921-4c39-bd0f-e5daeac4a13c">项目名称</p>
    */
    @NotBlank(message = "name不能为空")
    @SerializedName("name")
    private String name;
    /**
    * <p data-diff-id="ct-diff-id-3d90b9c2-8b54-4b0c-849e-c0c5b9eac82d">项目原价，以分为单位</p>
    */
    @SerializedName("originalPrice")
    private Long originalPrice;
    /**
    * <p data-diff-id="ct-diff-id-eb2fd9cc-138d-43e9-8580-1c4b0844ace3">项目折后价，以分为单位</p>
    */
    @SerializedName("discountPrice")
    private Long discountPrice;
    /**
    * <p data-diff-id="ct-diff-id-7bd91444-b07e-4011-8ff4-ba3da384af11">项目实付价，以分为单位</p>
    */
    @NotNull(message = "payPrice不能为空")
    @SerializedName("payPrice")
    private Long payPrice;
    /**
    * <p data-diff-id="ct-diff-id-cbc5c866-be89-4f6d-93e8-98afda504044">项目结算方式，枚举：Cash（现金）、ProjectCard（项目次卡）、ProjectCoupon（项目券）、TuanGouCoupon（团购券）、OnlineBooking（线上预订）、Others（其他）</p>
    */
    @NotBlank(message = "settlementType不能为空")
    @SerializedName("settlementType")
    private String settlementType;
    /**
    * <p data-diff-id="ct-diff-id-1799e4b7-9681-4bfa-9093-e9c79a862af0">团购渠道，当项目结算方式为“团购券”时必填，枚举：MT（美团）、DP（点评）、DouYin（抖音）、Others（其他）</p>
    */
    @SerializedName("tuanGouChannel")
    private String tuanGouChannel;
    /**
    * <p data-diff-id="ct-diff-id-11119227-93d1-4aff-89a0-003cbd909b4b">预订渠道，当项目结算方式为“预订”时必填，枚举：MT（美团）、DP（点评）、DouYin（抖音）、Others（其他）</p>
    */
    @SerializedName("bookChannel")
    private String bookChannel;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Long getOriginalPrice() {
        return originalPrice;
    }
    public void setOriginalPrice(Long originalPrice) {
        this.originalPrice = originalPrice;
    }
    public Long getDiscountPrice() {
        return discountPrice;
    }
    public void setDiscountPrice(Long discountPrice) {
        this.discountPrice = discountPrice;
    }
    public Long getPayPrice() {
        return payPrice;
    }
    public void setPayPrice(Long payPrice) {
        this.payPrice = payPrice;
    }
    public String getSettlementType() {
        return settlementType;
    }
    public void setSettlementType(String settlementType) {
        this.settlementType = settlementType;
    }
    public String getTuanGouChannel() {
        return tuanGouChannel;
    }
    public void setTuanGouChannel(String tuanGouChannel) {
        this.tuanGouChannel = tuanGouChannel;
    }
    public String getBookChannel() {
        return bookChannel;
    }
    public void setBookChannel(String bookChannel) {
        this.bookChannel = bookChannel;
    }




    @Override
    public String toString() {
        return "SaasConsumeItem{" + "name=" + name + "," + "originalPrice=" + originalPrice + "," + "discountPrice=" + discountPrice + "," + "payPrice=" + payPrice + "," + "settlementType=" + settlementType + "," + "tuanGouChannel=" + tuanGouChannel + "," + "bookChannel=" + bookChannel + "}";
    }
}
