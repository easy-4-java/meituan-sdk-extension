package com.meituan.sdk.model.tuangouNg.coupon.msSuperPrepare;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 提供开放平台的预验券接口，聚合商品数据信息
* This file was automatically generated.
*/
@ApiMeta(
    path = "/tuangou/ng/coupon/msprepare",
    businessId = 1,
    apiVersion = "10120",
    apiName = "ms_super_prepare",
    needAuth = true
)
public class MsSuperPrepareRequest implements MeituanRequest<MsSuperPrepareResponse> {
    /**
    * <p data-diff-id="ct-diff-id-8ae98d45-098c-4093-8808-cce3c71d03e1"><span style="color: rgba(0, 0, 0, 0.87)">券码</span></p>
    */
    @SerializedName("code")
    private String code;
    /**
    * <p data-diff-id="ct-diff-id-4f7fb658-2de9-4fb5-a70c-cb9f26e27342"><span style="color: #333">版本控制：0:版本无兼容买单核销 1:兼容买单核销</span></p>
    */
    @SerializedName("version")
    private Integer version;

    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public Integer getVersion() {
        return version;
    }
    public void setVersion(Integer version) {
        this.version = version;
    }


    @Override
    public MeituanResponse<MsSuperPrepareResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<MsSuperPrepareResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "MsSuperPrepareRequest{" + "code=" + code + "," + "version=" + version + "}";
    }
}
