package com.meituan.sdk.model.resv2.table.supplyTableDelete;

import java.util.List;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* 
* This file was automatically generated.
*/
public class VendorTableDeleteDTO {
    /**
    * <p data-diff-id="ct-diff-id-4034a73d-6b68-4e9b-af9c-9bae6466681a"><span style="color: ">桌型</span></p>
    */
    @NotNull(message = "tableType不能为空")
    @SerializedName("tableType")
    private Integer tableType;
    /**
    * <p data-diff-id="ct-diff-id-00669acf-0835-4935-950b-8c450986e938"><span style="color: rgba(0, 0, 0, 0.65)">桌型名称</span></p>
    */
    @SerializedName("tableTypeName")
    private String tableTypeName;
    /**
    * <p data-diff-id="ct-diff-id-5adf8dbc-9d93-4d70-87bb-b4d9b1f2856d"><span style="color: ">删除对象 1-删除桌型 2-删除桌位</span></p>
    */
    @NotNull(message = "operateType不能为空")
    @SerializedName("operateType")
    private Integer operateType;
    @SerializedName("tableGroupList")
    private List<VendorTableGroupDTO> tableGroupList;

    public Integer getTableType() {
        return tableType;
    }
    public void setTableType(Integer tableType) {
        this.tableType = tableType;
    }
    public String getTableTypeName() {
        return tableTypeName;
    }
    public void setTableTypeName(String tableTypeName) {
        this.tableTypeName = tableTypeName;
    }
    public Integer getOperateType() {
        return operateType;
    }
    public void setOperateType(Integer operateType) {
        this.operateType = operateType;
    }
    public List<VendorTableGroupDTO> getTableGroupList() {
        return tableGroupList;
    }
    public void setTableGroupList(List<VendorTableGroupDTO> tableGroupList) {
        this.tableGroupList = tableGroupList;
    }




    @Override
    public String toString() {
        return "VendorTableDeleteDTO{" + "tableType=" + tableType + "," + "tableTypeName=" + tableTypeName + "," + "operateType=" + operateType + "," + "tableGroupList=" + tableGroupList + "}";
    }
}
