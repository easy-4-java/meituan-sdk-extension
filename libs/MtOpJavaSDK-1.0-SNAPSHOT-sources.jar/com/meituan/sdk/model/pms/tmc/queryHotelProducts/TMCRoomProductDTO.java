package com.meituan.sdk.model.pms.tmc.queryHotelProducts;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 产品列表
* This file was automatically generated.
*/
public class TMCRoomProductDTO {
    /**
    * 产品代码
    */
    @SerializedName("productCode")
    private String productCode;
    /**
    * 产品名称
    */
    @SerializedName("productName")
    private String productName;
    /**
    * 价格计划代码
    */
    @SerializedName("ratePlanCode")
    private String ratePlanCode;
    /**
    * 价格计划名称
    */
    @SerializedName("ratePlanName")
    private String ratePlanName;
    /**
    * 物理房型ID
    */
    @SerializedName("physicalRoomTypeId")
    private String physicalRoomTypeId;
    /**
    * 物理房型名称
    */
    @SerializedName("physicalRoomTypeName")
    private String physicalRoomTypeName;
    /**
    * 早餐份数
    */
    @SerializedName("breakfastNum")
    private Integer breakfastNum;
    /**
    * 预订规则
    */
    @SerializedName("bookingRule")
    private TMCBookingRuleDTO bookingRule;
    /**
    * 取消规则
    */
    @SerializedName("cancelRule")
    private TMCCancelRuleDTO cancelRule;
    /**
    * 产品状态 2-上线，3-下线
    */
    @SerializedName("status")
    private Integer status;
    /**
    * 入住类型，Normal-全天房，Hour4-时租四小时，详见CheckinType字典
    */
    @SerializedName("checkinType")
    private String checkinType;
    /**
    * 支持发票类型，Regular-普票，Special-专票，详见InvoiceVatTypeEnum字典
    */
    @SerializedName("invoiceVatTypeList")
    private List<String> invoiceVatTypeList;
    /**
    * 协议公司
    */
    @SerializedName("contractorList")
    private List<TMCContractorDTO> contractorList;

    public String getProductCode() {
        return productCode;
    }
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public String getRatePlanCode() {
        return ratePlanCode;
    }
    public void setRatePlanCode(String ratePlanCode) {
        this.ratePlanCode = ratePlanCode;
    }
    public String getRatePlanName() {
        return ratePlanName;
    }
    public void setRatePlanName(String ratePlanName) {
        this.ratePlanName = ratePlanName;
    }
    public String getPhysicalRoomTypeId() {
        return physicalRoomTypeId;
    }
    public void setPhysicalRoomTypeId(String physicalRoomTypeId) {
        this.physicalRoomTypeId = physicalRoomTypeId;
    }
    public String getPhysicalRoomTypeName() {
        return physicalRoomTypeName;
    }
    public void setPhysicalRoomTypeName(String physicalRoomTypeName) {
        this.physicalRoomTypeName = physicalRoomTypeName;
    }
    public Integer getBreakfastNum() {
        return breakfastNum;
    }
    public void setBreakfastNum(Integer breakfastNum) {
        this.breakfastNum = breakfastNum;
    }
    public TMCBookingRuleDTO getBookingRule() {
        return bookingRule;
    }
    public void setBookingRule(TMCBookingRuleDTO bookingRule) {
        this.bookingRule = bookingRule;
    }
    public TMCCancelRuleDTO getCancelRule() {
        return cancelRule;
    }
    public void setCancelRule(TMCCancelRuleDTO cancelRule) {
        this.cancelRule = cancelRule;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getCheckinType() {
        return checkinType;
    }
    public void setCheckinType(String checkinType) {
        this.checkinType = checkinType;
    }
    public List<String> getInvoiceVatTypeList() {
        return invoiceVatTypeList;
    }
    public void setInvoiceVatTypeList(List<String> invoiceVatTypeList) {
        this.invoiceVatTypeList = invoiceVatTypeList;
    }
    public List<TMCContractorDTO> getContractorList() {
        return contractorList;
    }
    public void setContractorList(List<TMCContractorDTO> contractorList) {
        this.contractorList = contractorList;
    }




    @Override
    public String toString() {
        return "TMCRoomProductDTO{" + "productCode=" + productCode + "," + "productName=" + productName + "," + "ratePlanCode=" + ratePlanCode + "," + "ratePlanName=" + ratePlanName + "," + "physicalRoomTypeId=" + physicalRoomTypeId + "," + "physicalRoomTypeName=" + physicalRoomTypeName + "," + "breakfastNum=" + breakfastNum + "," + "bookingRule=" + bookingRule + "," + "cancelRule=" + cancelRule + "," + "status=" + status + "," + "checkinType=" + checkinType + "," + "invoiceVatTypeList=" + invoiceVatTypeList + "," + "contractorList=" + contractorList + "}";
    }
}
