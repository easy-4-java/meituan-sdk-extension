package com.meituan.sdk.model.pms.tmc.getPhysicalRoomtypes;

import com.google.gson.annotations.SerializedName;

/**
* 床位类型列表
* This file was automatically generated.
*/
public class BedTypeDTO {
    /**
    * 床的类型
    */
    @SerializedName("bedType")
    private String bedType;
    /**
    * 床的尺寸
    */
    @SerializedName("bedSize")
    private String bedSize;

    public String getBedType() {
        return bedType;
    }
    public void setBedType(String bedType) {
        this.bedType = bedType;
    }
    public String getBedSize() {
        return bedSize;
    }
    public void setBedSize(String bedSize) {
        this.bedSize = bedSize;
    }




    @Override
    public String toString() {
        return "BedTypeDTO{" + "bedType=" + bedType + "," + "bedSize=" + bedSize + "}";
    }
}
