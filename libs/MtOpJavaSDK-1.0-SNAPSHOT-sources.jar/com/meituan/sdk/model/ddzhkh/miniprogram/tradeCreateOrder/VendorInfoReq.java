package com.meituan.sdk.model.ddzhkh.miniprogram.tradeCreateOrder;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-9c2eea3a-3cd6-407f-9c92-2e9099068b93">三方商户订单信息</p>
* This file was automatically generated.
*/
public class VendorInfoReq {
    /**
    * <p data-diff-id="ct-diff-id-e07a22fd-1246-4b4e-98a1-e0d5f6af7fc0">三方商户订单号<span style="color: #f5222d">（注意：每次调用下单均要变更）</span></p>
    */
    @NotBlank(message = "vendorOrderId不能为空")
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * <p data-diff-id="ct-diff-id-fa77f26c-557b-48c0-9981-56a7099607b6">用户在三方商户侧的下单时间（<span style="color: rgb(245, 34, 45)">毫秒时间戳）</span></p>
    */
    @NotNull(message = "vendorOrderTime不能为空")
    @SerializedName("vendorOrderTime")
    private Long vendorOrderTime;
    /**
    * <p data-diff-id="ct-diff-id-20a43483-2b0c-4dcb-ad5f-e693591de4b5">三方商户支付Id</p>
    */
    @NotBlank(message = "vendorPaymentId不能为空")
    @SerializedName("vendorPaymentId")
    private String vendorPaymentId;
    /**
    * <p data-diff-id="ct-diff-id-b619edd3-c655-4f13-9032-5c8417bc5490">三方透传自定义支付参数，支付结果通知三方时回传；长度限制2048</p>
    */
    @SerializedName("vendorPayInfo")
    private String vendorPayInfo;

    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public Long getVendorOrderTime() {
        return vendorOrderTime;
    }
    public void setVendorOrderTime(Long vendorOrderTime) {
        this.vendorOrderTime = vendorOrderTime;
    }
    public String getVendorPaymentId() {
        return vendorPaymentId;
    }
    public void setVendorPaymentId(String vendorPaymentId) {
        this.vendorPaymentId = vendorPaymentId;
    }
    public String getVendorPayInfo() {
        return vendorPayInfo;
    }
    public void setVendorPayInfo(String vendorPayInfo) {
        this.vendorPayInfo = vendorPayInfo;
    }




    @Override
    public String toString() {
        return "VendorInfoReq{" + "vendorOrderId=" + vendorOrderId + "," + "vendorOrderTime=" + vendorOrderTime + "," + "vendorPaymentId=" + vendorPaymentId + "," + "vendorPayInfo=" + vendorPayInfo + "}";
    }
}
