package com.meituan.sdk.model.ddzh.yuding.dealgroupProductQuery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 分页查询门店下的所有团购商品
* This file was automatically generated.
*/
public class DealgroupProductQueryResponse {
    @SerializedName("result")
    private List<RShopDeal> result;

    public List<RShopDeal> getResult() {
        return result;
    }
    public void setResult(List<RShopDeal> result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "DealgroupProductQueryResponse{" + "result=" + result + "}";
    }
}
