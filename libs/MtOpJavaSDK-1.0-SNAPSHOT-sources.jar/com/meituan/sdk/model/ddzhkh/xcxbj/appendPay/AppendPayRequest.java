package com.meituan.sdk.model.ddzhkh.xcxbj.appendPay;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 追加支付
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/xcxbj/append_pay",
    businessId = 59,
    apiVersion = "10000",
    apiName = "append_pay",
    needAuth = true
)
public class AppendPayRequest implements MeituanRequest<AppendPayResponse> {
    /**
    * <p data-diff-id="ct-diff-id-aadd8b5e-f062-4a4c-aed8-50e9d4f85963">前端SDK生成</p>
    */
    @NotBlank(message = "generalBizData不能为空")
    @SerializedName("generalBizData")
    private String generalBizData;
    @NotNull(message = "appendPaySubmitReq不能为空")
    @SerializedName("appendPaySubmitReq")
    private AppendPaySubmitReq appendPaySubmitReq;

    public String getGeneralBizData() {
        return generalBizData;
    }
    public void setGeneralBizData(String generalBizData) {
        this.generalBizData = generalBizData;
    }
    public AppendPaySubmitReq getAppendPaySubmitReq() {
        return appendPaySubmitReq;
    }
    public void setAppendPaySubmitReq(AppendPaySubmitReq appendPaySubmitReq) {
        this.appendPaySubmitReq = appendPaySubmitReq;
    }


    @Override
    public MeituanResponse<AppendPayResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<AppendPayResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "AppendPayRequest{" + "generalBizData=" + generalBizData + "," + "appendPaySubmitReq=" + appendPaySubmitReq + "}";
    }
}
