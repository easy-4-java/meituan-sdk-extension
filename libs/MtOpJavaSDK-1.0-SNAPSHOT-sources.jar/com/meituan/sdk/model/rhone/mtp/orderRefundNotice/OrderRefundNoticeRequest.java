package com.meituan.sdk.model.rhone.mtp.orderRefundNotice;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 订单退款通知
* This file was automatically generated.
*/
@ApiMeta(
    path = "/rhone/mtp/api/order/refund/notice",
    businessId = 66,
    apiVersion = "10021",
    apiName = "order_refund_notice",
    needAuth = false
)
public class OrderRefundNoticeRequest implements MeituanRequest<OrderRefundNoticeResponse> {
    /**
    * <p data-diff-id="ct-diff-id-a25ca952-0d67-4feb-93f8-702140bd463f"><span style="color: ">交互码，必须回传；200为退款成功，601为已退款，602为审批中，604为产品本身不能退款，605为产品不能线上退款，606为申请张数超过可退款张数，607为产品不在可退款时间内，608为退款金额校验失败，699为其它退款错误</span></p>
    */
    @SerializedName("code")
    private Integer code;
    /**
    * <p data-diff-id="ct-diff-id-a923f89c-bf71-400d-bc27-654f3eebf88b"><span style="color: ">合作方ID，必须回传</span></p>
    */
    @SerializedName("partnerId")
    private Integer partnerId;
    /**
    * <p data-diff-id="ct-diff-id-e08f4006-0c88-4cfb-abd7-38eae4423622"><span style="color: ">交互描述，如错误信息等</span></p>
    */
    @SerializedName("describe")
    private String describe;
    /**
    * <p data-diff-id="ct-diff-id-28581165-5625-4fe5-8709-441f77c26265"><span style="color: ">退款通知接口必须返回body数据</span></p>
    */
    @SerializedName("body")
    private Body body;

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public Integer getPartnerId() {
        return partnerId;
    }
    public void setPartnerId(Integer partnerId) {
        this.partnerId = partnerId;
    }
    public String getDescribe() {
        return describe;
    }
    public void setDescribe(String describe) {
        this.describe = describe;
    }
    public Body getBody() {
        return body;
    }
    public void setBody(Body body) {
        this.body = body;
    }


    @Override
    public MeituanResponse<OrderRefundNoticeResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<OrderRefundNoticeResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "OrderRefundNoticeRequest{" + "code=" + code + "," + "partnerId=" + partnerId + "," + "describe=" + describe + "," + "body=" + body + "}";
    }
}
