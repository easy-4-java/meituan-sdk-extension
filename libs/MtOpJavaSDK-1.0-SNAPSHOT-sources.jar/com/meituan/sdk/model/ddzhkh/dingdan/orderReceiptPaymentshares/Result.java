package com.meituan.sdk.model.ddzhkh.dingdan.orderReceiptPaymentshares;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class Result {
    /**
    * 券码
    */
    @SerializedName("receiptCode")
    private String receiptCode;
    /**
    * 分摊金额
    */
    @SerializedName("amount")
    private Double amount;
    /**
    * 分摊金额类型，-1-验证金额（用户实付+平台优惠），2-抵用券，5-积分，6-立减，8-商户抵用券，10-C端美团支付，12-优惠代码，15-美团立减，17-商家立减，18-美团商家立减，21-次卡，22-打折卡，23-B端美团支付，24-全渠道会员券，25-pos支付，26-线下认款平台，28-商家折上折
    */
    @SerializedName("amountType")
    private Integer amountType;
    /**
    * 当前优惠类型中平台分摊金额
    */
    @SerializedName("platformAmount")
    private String platformAmount;
    /**
    * 当前优惠类型中商家分摊金额
    */
    @SerializedName("merchantAmount")
    private String merchantAmount;

    public String getReceiptCode() {
        return receiptCode;
    }
    public void setReceiptCode(String receiptCode) {
        this.receiptCode = receiptCode;
    }
    public Double getAmount() {
        return amount;
    }
    public void setAmount(Double amount) {
        this.amount = amount;
    }
    public Integer getAmountType() {
        return amountType;
    }
    public void setAmountType(Integer amountType) {
        this.amountType = amountType;
    }
    public String getPlatformAmount() {
        return platformAmount;
    }
    public void setPlatformAmount(String platformAmount) {
        this.platformAmount = platformAmount;
    }
    public String getMerchantAmount() {
        return merchantAmount;
    }
    public void setMerchantAmount(String merchantAmount) {
        this.merchantAmount = merchantAmount;
    }




    @Override
    public String toString() {
        return "Result{" + "receiptCode=" + receiptCode + "," + "amount=" + amount + "," + "amountType=" + amountType + "," + "platformAmount=" + platformAmount + "," + "merchantAmount=" + merchantAmount + "}";
    }
}
