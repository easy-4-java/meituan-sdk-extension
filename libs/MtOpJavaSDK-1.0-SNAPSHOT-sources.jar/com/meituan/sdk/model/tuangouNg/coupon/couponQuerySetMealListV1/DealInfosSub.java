package com.meituan.sdk.model.tuangouNg.coupon.couponQuerySetMealListV1;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class DealInfosSub {
    /**
    * 项目结束时间戳，单位是秒
    */
    @SerializedName("dealEndTime")
    private Long dealEndTime;
    /**
    * 项目ID
    */
    @SerializedName("dealId")
    private Long dealId;
    /**
    * 市场价格
    */
    @SerializedName("dealValue")
    private Double dealValue;
    /**
    * 项目名称
    */
    @SerializedName("dealTitle")
    private String dealTitle;
    /**
    * 项目开始时间戳，单位是秒
    */
    @SerializedName("beginTime")
    private Long beginTime;
    /**
    * 售卖价格
    */
    @SerializedName("dealPrice")
    private Double dealPrice;
    /**
    * json字符串数组
    */
    @SerializedName("dealMenu")
    private String dealMenu;
    /**
    * 是否是代金券，true为代金券，false为套餐
    */
    @SerializedName("isVoucher")
    private Boolean isVoucher;
    /**
    * C端项目名称
    */
    @SerializedName("platformDealTitle")
    private String platformDealTitle;
    /**
    * 是否隐藏
    */
    @SerializedName("isHide")
    private Boolean isHide;
    /**
    * 售卖状态
    */
    @SerializedName("saleStatus")
    private Integer saleStatus;
    /**
    * 券有效期模式  0表示按券结束日期，1表示按购买之后couponValidDays天有效
    */
    @SerializedName("couponDateType")
    private Integer couponDateType;
    /**
    * 券有效期固定结束时间 单位分
    */
    @SerializedName("couponEndTime")
    private Long couponEndTime;
    /**
    * 券有效期多少天有效
    */
    @SerializedName("couponValidDays")
    private Integer couponValidDays;
    /**
    * C端场景中提单页、支付结果页、查看券码和订单页面的项目标题以及经营宝核销后展示的标题。C端场景包括美团App，点评App，美团小程序
    */
    @SerializedName("shortAttrTitle")
    private String shortAttrTitle;
    /**
    * 经营宝商品列表标题
    */
    @SerializedName("platformTitle")
    private String platformTitle;
    /**
    * 第三方商品ID(三方上单填入)
    */
    @SerializedName("thirdProductId")
    private String thirdProductId;
    /**
    * 门店隐藏状态配置（0:隐藏，1:展示）
    */
    @SerializedName("poiShowStatus")
    private Integer poiShowStatus;

    public Long getDealEndTime() {
        return dealEndTime;
    }
    public void setDealEndTime(Long dealEndTime) {
        this.dealEndTime = dealEndTime;
    }
    public Long getDealId() {
        return dealId;
    }
    public void setDealId(Long dealId) {
        this.dealId = dealId;
    }
    public Double getDealValue() {
        return dealValue;
    }
    public void setDealValue(Double dealValue) {
        this.dealValue = dealValue;
    }
    public String getDealTitle() {
        return dealTitle;
    }
    public void setDealTitle(String dealTitle) {
        this.dealTitle = dealTitle;
    }
    public Long getBeginTime() {
        return beginTime;
    }
    public void setBeginTime(Long beginTime) {
        this.beginTime = beginTime;
    }
    public Double getDealPrice() {
        return dealPrice;
    }
    public void setDealPrice(Double dealPrice) {
        this.dealPrice = dealPrice;
    }
    public String getDealMenu() {
        return dealMenu;
    }
    public void setDealMenu(String dealMenu) {
        this.dealMenu = dealMenu;
    }
    public Boolean getIsVoucher() {
        return isVoucher;
    }
    public void setIsVoucher(Boolean isVoucher) {
        this.isVoucher = isVoucher;
    }
    public String getPlatformDealTitle() {
        return platformDealTitle;
    }
    public void setPlatformDealTitle(String platformDealTitle) {
        this.platformDealTitle = platformDealTitle;
    }
    public Boolean getIsHide() {
        return isHide;
    }
    public void setIsHide(Boolean isHide) {
        this.isHide = isHide;
    }
    public Integer getSaleStatus() {
        return saleStatus;
    }
    public void setSaleStatus(Integer saleStatus) {
        this.saleStatus = saleStatus;
    }
    public Integer getCouponDateType() {
        return couponDateType;
    }
    public void setCouponDateType(Integer couponDateType) {
        this.couponDateType = couponDateType;
    }
    public Long getCouponEndTime() {
        return couponEndTime;
    }
    public void setCouponEndTime(Long couponEndTime) {
        this.couponEndTime = couponEndTime;
    }
    public Integer getCouponValidDays() {
        return couponValidDays;
    }
    public void setCouponValidDays(Integer couponValidDays) {
        this.couponValidDays = couponValidDays;
    }
    public String getShortAttrTitle() {
        return shortAttrTitle;
    }
    public void setShortAttrTitle(String shortAttrTitle) {
        this.shortAttrTitle = shortAttrTitle;
    }
    public String getPlatformTitle() {
        return platformTitle;
    }
    public void setPlatformTitle(String platformTitle) {
        this.platformTitle = platformTitle;
    }
    public String getThirdProductId() {
        return thirdProductId;
    }
    public void setThirdProductId(String thirdProductId) {
        this.thirdProductId = thirdProductId;
    }
    public Integer getPoiShowStatus() {
        return poiShowStatus;
    }
    public void setPoiShowStatus(Integer poiShowStatus) {
        this.poiShowStatus = poiShowStatus;
    }




    @Override
    public String toString() {
        return "DealInfosSub{" + "dealEndTime=" + dealEndTime + "," + "dealId=" + dealId + "," + "dealValue=" + dealValue + "," + "dealTitle=" + dealTitle + "," + "beginTime=" + beginTime + "," + "dealPrice=" + dealPrice + "," + "dealMenu=" + dealMenu + "," + "isVoucher=" + isVoucher + "," + "platformDealTitle=" + platformDealTitle + "," + "isHide=" + isHide + "," + "saleStatus=" + saleStatus + "," + "couponDateType=" + couponDateType + "," + "couponEndTime=" + couponEndTime + "," + "couponValidDays=" + couponValidDays + "," + "shortAttrTitle=" + shortAttrTitle + "," + "platformTitle=" + platformTitle + "," + "thirdProductId=" + thirdProductId + "," + "poiShowStatus=" + poiShowStatus + "}";
    }
}
