package com.meituan.sdk.model.ddzhkh.xcx3csmzl.syncOrder;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* 
* This file was automatically generated.
*/
public class OrderDataChangeReq {
    /**
    * <p data-diff-id="ct-diff-id-76325808-bd0a-459a-9be6-715ee44a67b8"><span style="color: rgba(0, 0, 0, 0.65)">美团订单号，与三方商户订单号二选一</span></p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-f46975e3-f176-48a8-9caa-fd09bc367d2d"><span style="color: rgba(0, 0, 0, 0.65)">三方商户订单号，与美团订单号二选一</span></p>
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * <p data-diff-id="ct-diff-id-0dd909dc-a52e-4d08-ade5-476e48dae170"><span style="color: rgba(0, 0, 0, 0.65)">订单状态是否变更</span></p>
    */
    @NotNull(message = "hasStatusChange不能为空")
    @SerializedName("hasStatusChange")
    private Boolean hasStatusChange;
    /**
    * <p data-diff-id="ct-diff-id-4f567692-dd1c-4bf2-bb56-f8484ee66c60"><span style="color: rgba(0, 0, 0, 0.65)">版本号，保障接口幂等，低于当前版本不处理</span></p>
    */
    @NotNull(message = "version不能为空")
    @SerializedName("version")
    private Long version;
    /**
    * <p data-diff-id="ct-diff-id-ba57d1d5-b49e-489d-9ee7-1970e761dbaf">商户订单原状态。<span style="color: rgba(0, 0, 0, 0.65)">hasStatusChange为true时必传，为false时不可传递。</span></p><p data-diff-id="ct-diff-id-98dc2259-0991-4534-a68d-c21ca2f7e75b">行业枚举:</p><table data-borderwidth="1" data-diff-id="ct-diff-id-3107a0fb-dd47-447f-ba8c-9df0dad9d48a"><tbody><tr data-row-diff-id="c4c9021a-465e-4a07-bef5-3d38460339b4"><th data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-00bc39e4-e547-481b-94da-cef350feb5f1"><p data-diff-id="ct-diff-id-73263ff7-85ee-41fd-86c6-0960eec737d6">状态代码</p></th><th data-colwidth="166" width="166" data-cell-diff-id="ct-cell-diff-id-dc740e4a-567e-4722-ab6c-ee9bcacbb530"><p data-diff-id="ct-diff-id-d8f451c7-ec6f-4fa2-b316-82bc2ee547ce">状态值</p></th><th data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-0551b9c9-dddf-43f4-bffe-460c6a7086b7"><p data-diff-id="ct-diff-id-b2c9ebbd-201f-4439-9e36-5c494eeef0a4">状态描述</p></th><th data-colwidth="231" width="231" data-cell-diff-id="ct-cell-diff-id-39c660fe-9527-4835-b7de-100008e1e3da"><p data-diff-id="ct-diff-id-2224f0c5-2bcb-495c-9670-3b2d6c3ec00a">备注</p></th></tr><tr data-row-diff-id="513eaa40-67d4-4b34-93fe-f50972e8d9e8"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-67bf2a48-43f5-4fd0-984a-f4b640a0f8a2"><p data-diff-id="ct-diff-id-edb166c2-b917-43db-b260-0e0f232098b9">1</p></td><td data-colwidth="166" width="166" data-cell-diff-id="ct-cell-diff-id-90720f06-e564-41ee-ab04-fb440d4b7a1b"><p data-diff-id="ct-diff-id-bc74a63e-83be-4023-b7cf-74042cb10cc3">INIT</p></td><td data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-e3f7d14f-ce05-43e0-9dcd-837f22669feb"><p data-diff-id="ct-diff-id-ace764ff-f535-4f93-a236-4458515aeefd">初始化</p></td><td data-colwidth="231" width="231" data-cell-diff-id="ct-cell-diff-id-0d58107e-c471-44e7-9b3a-ef9f899487fb"><p data-diff-id="ct-diff-id-1c5e52a5-48fc-41d9-ba0c-d3ab9ffb34c8"></p></td></tr><tr data-row-diff-id="6420c3bc-c945-4853-9fa8-61f8df19d027"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-837bc08d-a2da-4c9f-bf87-85c090e2f7bb"><p data-diff-id="ct-diff-id-af1e61ec-268d-4a5c-9674-a135fde99f39">2</p></td><td data-colwidth="166" width="166" data-cell-diff-id="ct-cell-diff-id-f2a18b6c-5384-4b36-bb72-7bda55f181e0"><p data-diff-id="ct-diff-id-8a2ca4a7-42ca-4a07-b340-52acbae23339">CANCELLED</p></td><td data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-a7393608-4085-4a24-b037-9ac278f52de7"><p data-diff-id="ct-diff-id-6c4d0e76-cc5e-44a7-b637-3345b83c865a">已取消</p></td><td data-colwidth="231" width="231" data-cell-diff-id="ct-cell-diff-id-7229903e-38fb-407e-84ea-f57ab99498e0"><p data-diff-id="ct-diff-id-3c6582ce-8bdf-4e51-a1db-3dc0d97d9573"></p></td></tr><tr data-row-diff-id="2248987e-3f3d-4164-a792-26361a52fb91"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-7f2c5e92-04ce-4bdf-bbe6-ed2a45b50f12"><p data-diff-id="ct-diff-id-12c8508d-633a-438e-97dd-098ecc297d76">3</p></td><td data-colwidth="166" width="166" data-cell-diff-id="ct-cell-diff-id-ec02cecb-e0a8-4995-9376-36649147f4dc"><p data-diff-id="ct-diff-id-90cd762c-af22-46f3-ad78-4f80e56d1169">UNDER_REVIEW</p></td><td data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-fade0754-072d-4940-9d5e-2c778c359514"><p data-diff-id="ct-diff-id-a94b0c53-360f-4603-97d9-a5b3cbdfc784">审核中</p></td><td data-colwidth="231" width="231" data-cell-diff-id="ct-cell-diff-id-4871817e-b4d3-4b79-8bfe-1d50c3af60df"><p data-diff-id="ct-diff-id-33854bb8-0206-49b0-89fa-51652edda484"></p></td></tr><tr data-row-diff-id="08d743c8-edbf-49b5-9fb8-6d7dd7051733"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-bebd76ab-861a-48ce-a23c-66e5cd60f99d"><p data-diff-id="ct-diff-id-77f1a480-ff6f-4957-89e5-a6efda0b015c">4</p></td><td data-colwidth="166" width="166" data-cell-diff-id="ct-cell-diff-id-116a4cbe-b3c9-44a0-ad34-0a3476df5261"><p data-diff-id="ct-diff-id-fd3be5f2-1853-4a50-b6ae-54aca228cce5">WAITING_PAYMENT</p></td><td data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-755350ae-462d-4aea-b973-f7cb1eec0190"><p data-diff-id="ct-diff-id-dcb96e62-dcc6-4532-9dc1-b8a80fb5e70c">待支付</p></td><td data-colwidth="231" width="231" data-cell-diff-id="ct-cell-diff-id-5ddcfb45-00c2-450f-9c36-d7a302d3a873"><p data-diff-id="ct-diff-id-b4cf1d75-6c70-46d7-bdd7-c186211f2c4e">美团代扣依赖订单状态=待支付</p></td></tr><tr data-row-diff-id="04897972-3824-4fe3-a0a5-0ae550ddfcb1"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-61dc6033-6bac-4bef-9cdd-6e881a889f7d"><p data-diff-id="ct-diff-id-76a8f88c-22ad-4913-b3db-4dc21ad3e473">5</p></td><td data-colwidth="166" width="166" data-cell-diff-id="ct-cell-diff-id-303b1289-db80-439c-b3bf-3e7f6e29a5e9"><p data-diff-id="ct-diff-id-98a3b619-ef17-4d84-b996-3a191c20fdfa">PAYMENT_OVERDUE</p></td><td data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-93b648c8-ed6d-40a3-819d-81308e6775a7"><p data-diff-id="ct-diff-id-05e75c9c-bf0f-4357-b74c-005617d38d32">支付已逾期</p></td><td data-colwidth="231" width="231" data-cell-diff-id="ct-cell-diff-id-c076047c-ff52-4ea2-9b30-d6952b7af7e9"><p data-diff-id="ct-diff-id-8d4a3167-c25f-485f-a3b3-cd10981f1e64"></p></td></tr><tr data-row-diff-id="f23eedfc-d1df-443d-88a5-4f9c18d3dc11"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-0474834e-75a4-4f64-aa39-af9d7d4a77d0"><p data-diff-id="ct-diff-id-831930b8-792b-4471-93ad-e3e0610c5012">6</p></td><td data-colwidth="166" width="166" data-cell-diff-id="ct-cell-diff-id-b2b48f75-b88c-4434-a3ad-71c21b4907c3"><p data-diff-id="ct-diff-id-75897b94-c646-462c-a3df-a67aa3ee9ea5">WAITING_SHIPMENT</p></td><td data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-31a430c5-4055-46a8-b32a-66572cf178d2"><p data-diff-id="ct-diff-id-49d9486f-e30d-4c5c-945a-c430a8340b3a">待发货</p></td><td data-colwidth="231" width="231" data-cell-diff-id="ct-cell-diff-id-ca40f79f-362e-4405-8a0e-40ff84a24101"><p data-diff-id="ct-diff-id-cbddf82c-de83-4897-bf69-c3e672079e49"></p></td></tr><tr data-row-diff-id="8f248cc8-05db-4ff0-9f17-aed698da942f"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-64ee5f0d-0835-437c-9bf9-0a5b7dc4c624"><p data-diff-id="ct-diff-id-bc4d346c-9e3a-4726-ab2c-b49e5e8296df">7</p></td><td data-colwidth="166" width="166" data-cell-diff-id="ct-cell-diff-id-58935cf0-546f-4af7-9ab2-2f6252e73bb8"><p data-diff-id="ct-diff-id-60f3d392-c65a-4197-b9a8-13ba5d10e6c0">SHIPPED</p></td><td data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-9b7c8a9d-74fa-485c-ab81-737f5415db22"><p data-diff-id="ct-diff-id-b8ba099d-6121-4a52-9318-329e2b5e6936">已发货</p></td><td data-colwidth="231" width="231" data-cell-diff-id="ct-cell-diff-id-807d7a12-2da3-4637-af8a-a6154dab7aaa"><p data-diff-id="ct-diff-id-26228801-ddf9-4cc8-95ce-11f5ba7f4912"></p></td></tr><tr data-row-diff-id="ca732b5d-da9c-4685-8f76-85f79e7cfd77"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-f975fa86-1738-42a1-84c9-f176d48a77e6"><p data-diff-id="ct-diff-id-21cc0c75-432c-4a5f-b98b-ad9b23cf1f2c">8</p></td><td data-colwidth="166" width="166" data-cell-diff-id="ct-cell-diff-id-328d34af-c590-45cb-bc7f-c9d24898b135"><p data-diff-id="ct-diff-id-a2c96cee-7a9d-47cc-9d4b-9bb9df1f70b7">IN_RENTAL</p></td><td data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-7f193a4f-b446-4b6b-b0d8-674bed5bf2e1"><p data-diff-id="ct-diff-id-777deaba-a55e-46fb-bb37-cc2190983a1f">租赁中</p></td><td data-colwidth="231" width="231" data-cell-diff-id="ct-cell-diff-id-7829e3db-9535-41bc-af43-bc956da077b6"><p data-diff-id="ct-diff-id-9f7ef7bc-1513-40b9-9a9a-2544333021d0"></p></td></tr><tr data-row-diff-id="aa22244f-4df1-4258-a675-94970d0e526e"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-4404ae33-8481-469c-83b5-8b9c05af61a7"><p data-diff-id="ct-diff-id-0a6472a4-f0a8-4b71-8d49-b899d2238808">9</p></td><td data-colwidth="166" width="166" data-cell-diff-id="ct-cell-diff-id-b1dfcccf-8ea4-4798-bc07-a56a319fa315"><p data-diff-id="ct-diff-id-2628e9d5-8a32-4311-bfc8-ab506a79236d">PENDING_RETURN</p></td><td data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-2ffcbdcf-7aea-4948-b2d2-090ecd90dbd8"><p data-diff-id="ct-diff-id-2b520f9b-04a4-460e-b501-9d8d3557a9c2">待归还</p></td><td data-colwidth="231" width="231" data-cell-diff-id="ct-cell-diff-id-6319136a-5826-44a9-9058-d0ad27f5615c"><p data-diff-id="ct-diff-id-577ee009-b7e6-495e-8666-8c9295e63194"></p></td></tr><tr data-row-diff-id="bdfcffec-d68f-4266-a97d-184b18a98d29"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-1b7150b9-c67a-48d3-a1df-5f49cb60f54e"><p data-diff-id="ct-diff-id-dd3da7bb-7574-4ff1-a405-6690b355825d">10</p></td><td data-colwidth="166" width="166" data-cell-diff-id="ct-cell-diff-id-ec7e5004-5b60-42d3-8407-ef05f637ef83"><p data-diff-id="ct-diff-id-c8a92b46-d64f-4736-9b95-3510d54a5553">RETURN_OVERDUE</p></td><td data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-4f7e49f1-22b0-4ea5-b75f-1842e21dffd9"><p data-diff-id="ct-diff-id-8cd977ff-8c81-4336-84e6-889168778ad1">归还已逾期</p></td><td data-colwidth="231" width="231" data-cell-diff-id="ct-cell-diff-id-41fc3ab8-6ecb-48ab-8908-b8893b510d80"><p data-diff-id="ct-diff-id-46d94cde-833a-4792-bbc2-e17a045332fe"></p></td></tr><tr data-row-diff-id="a6885f94-fab7-46ae-b4ab-63976a7011d2"><td data-colwidth="81" width="81" data-cell-diff-id="ct-cell-diff-id-79be8486-2f54-49ab-8094-6c793fa11941"><p data-diff-id="ct-diff-id-e2cc3bb8-01c0-4dd2-990f-5e89ac875aa0">11</p></td><td data-colwidth="166" width="166" data-cell-diff-id="ct-cell-diff-id-8f89628f-6b03-4696-964d-8ff83c336776"><p data-diff-id="ct-diff-id-b896517a-3f59-465e-9cb9-4c1d1b5f03de">COMPLETED</p></td><td data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-bbac457f-3cce-4ed6-827d-fd3f0506c4a0"><p data-diff-id="ct-diff-id-302c0f6b-055a-4b65-be54-31e113b014a8">已完成</p></td><td data-colwidth="231" width="231" data-cell-diff-id="ct-cell-diff-id-cc43aeef-84eb-409d-a9d2-c27d26586773"><p data-diff-id="ct-diff-id-9c9a86b9-e802-4116-bcbb-10dd26e2ff1b"></p></td></tr></tbody></table>
    */
    @SerializedName("fromStatus")
    private String fromStatus;
    /**
    * <p data-diff-id="ct-diff-id-837c0ca3-a876-40c7-8aec-9825e0a9ee4b"><span style="color: rgba(0, 0, 0, 0.65)">商户订单新状态。hasStatusChange为true时必传，为false时不可传递，状态机同fromStatus</span></p>
    */
    @SerializedName("toStatus")
    private String toStatus;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public Boolean getHasStatusChange() {
        return hasStatusChange;
    }
    public void setHasStatusChange(Boolean hasStatusChange) {
        this.hasStatusChange = hasStatusChange;
    }
    public Long getVersion() {
        return version;
    }
    public void setVersion(Long version) {
        this.version = version;
    }
    public String getFromStatus() {
        return fromStatus;
    }
    public void setFromStatus(String fromStatus) {
        this.fromStatus = fromStatus;
    }
    public String getToStatus() {
        return toStatus;
    }
    public void setToStatus(String toStatus) {
        this.toStatus = toStatus;
    }




    @Override
    public String toString() {
        return "OrderDataChangeReq{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "," + "hasStatusChange=" + hasStatusChange + "," + "version=" + version + "," + "fromStatus=" + fromStatus + "," + "toStatus=" + toStatus + "}";
    }
}
