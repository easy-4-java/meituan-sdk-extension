package com.meituan.sdk.model.pms.priceinve.getRoomStatus;


/**
* <p data-diff-id="ct-diff-id-c2db1472-b87d-491a-96ee-1d4b84964daa">房间号</p>
* This file was automatically generated.
*/
public class RoomNumbersSub {





}
