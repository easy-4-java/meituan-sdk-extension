package com.meituan.sdk.model.mlive.streams.getPushUrlsV2;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取推流地址，集采场景
* This file was automatically generated.
*/
@ApiMeta(
    path = "/mlive/streams/getPushUrls/v2",
    businessId = 50,
    apiVersion = "10015",
    apiName = "get_push_urls_v2",
    needAuth = false
)
public class GetPushUrlsV2Request implements MeituanRequest<List<LiveStreamDTO>> {
    /**
    * <p data-diff-id="ct-diff-id-6678fef0-591f-4c98-8c00-2a1c8e24d256"><span style="color: #333">直播id</span></p>
    */
    @NotNull(message = "liveId不能为空")
    @SerializedName("liveId")
    private Long liveId;
    /**
    * <p data-diff-id="ct-diff-id-802a2f57-3616-4376-9aed-dce11f63bedd"><span style="color: ">用户设备id</span></p>
    */
    @SerializedName("deviceId")
    private String deviceId;
    /**
    * <p data-diff-id="ct-diff-id-1ebdf474-26bd-4530-ab66-610080ecae07"><span style="color: ">0-正式直播，1-测试直播（美团直播助手创建测试直播，仅分享用户可见）</span></p>
    */
    @SerializedName("liveModel")
    private Integer liveModel;
    /**
    * <p data-diff-id="ct-diff-id-38ff57ad-2a81-4bd0-b4a1-db75e814b4ee">主播id</p>
    */
    @NotNull(message = "anchorId不能为空")
    @SerializedName("anchorId")
    private Long anchorId;

    public Long getLiveId() {
        return liveId;
    }
    public void setLiveId(Long liveId) {
        this.liveId = liveId;
    }
    public String getDeviceId() {
        return deviceId;
    }
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
    public Integer getLiveModel() {
        return liveModel;
    }
    public void setLiveModel(Integer liveModel) {
        this.liveModel = liveModel;
    }
    public Long getAnchorId() {
        return anchorId;
    }
    public void setAnchorId(Long anchorId) {
        this.anchorId = anchorId;
    }


    @Override
    public MeituanResponse<List<LiveStreamDTO>> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<List<LiveStreamDTO>>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GetPushUrlsV2Request{" + "liveId=" + liveId + "," + "deviceId=" + deviceId + "," + "liveModel=" + liveModel + "," + "anchorId=" + anchorId + "}";
    }
}
