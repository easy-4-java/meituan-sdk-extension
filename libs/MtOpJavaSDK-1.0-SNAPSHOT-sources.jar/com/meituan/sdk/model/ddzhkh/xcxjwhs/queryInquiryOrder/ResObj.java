package com.meituan.sdk.model.ddzhkh.xcxjwhs.queryInquiryOrder;

import com.google.gson.annotations.SerializedName;

/**
* 业务交互结果
* This file was automatically generated.
*/
public class ResObj {
    @SerializedName("code")
    private Integer code;
    @SerializedName("msg")
    private String msg;
    /**
    * 请求结果
    */
    @SerializedName("data")
    private QueyInquiryOrderRes data;

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public QueyInquiryOrderRes getData() {
        return data;
    }
    public void setData(QueyInquiryOrderRes data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "ResObj{" + "code=" + code + "," + "msg=" + msg + "," + "data=" + data + "}";
    }
}
