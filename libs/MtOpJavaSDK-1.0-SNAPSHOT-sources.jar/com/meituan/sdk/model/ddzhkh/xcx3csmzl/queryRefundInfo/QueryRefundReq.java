package com.meituan.sdk.model.ddzhkh.xcx3csmzl.queryRefundInfo;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class QueryRefundReq {
    /**
    * <p data-diff-id="ct-diff-id-ffd51d01-436e-4902-ac1d-ca0c345b7073"><em><span style="color: rgba(0, 0, 0, 0.65)">美团订单号，与三方订单号二选一</span></em></p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-89d7f442-1ade-4ef2-9880-97833540c159"><em><span style="color: rgba(0, 0, 0, 0.65)">三方订单号，与美团订单号二选一</span></em></p>
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * <p data-diff-id="ct-diff-id-ff8b0b20-93a1-4736-a4c3-54b1960705c3"><em><span style="color: rgba(0, 0, 0, 0.65)">商户退款号</span></em></p>
    */
    @SerializedName("vendorRefundId")
    private String vendorRefundId;
    /**
    * <p data-diff-id="ct-diff-id-ac626613-2d67-49aa-8e5a-7710d28af8ef"><em><span style="color: rgba(0, 0, 0, 0.65)">美团退款单号</span></em></p>
    */
    @SerializedName("refundId")
    private String refundId;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public String getVendorRefundId() {
        return vendorRefundId;
    }
    public void setVendorRefundId(String vendorRefundId) {
        this.vendorRefundId = vendorRefundId;
    }
    public String getRefundId() {
        return refundId;
    }
    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }




    @Override
    public String toString() {
        return "QueryRefundReq{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "," + "vendorRefundId=" + vendorRefundId + "," + "refundId=" + refundId + "}";
    }
}
