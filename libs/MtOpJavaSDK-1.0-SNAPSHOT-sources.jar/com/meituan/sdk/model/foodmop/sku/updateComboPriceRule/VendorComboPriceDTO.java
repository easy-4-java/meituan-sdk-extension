package com.meituan.sdk.model.foodmop.sku.updateComboPriceRule;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-0c6902a9-e9cf-4f9a-88d1-49f6bed0e391"><span style="color: rgb(102, 102, 102)">套餐价格实体</span></p>
* This file was automatically generated.
*/
public class VendorComboPriceDTO {
    /**
    * <p data-diff-id="ct-diff-id-c8006514-6290-4add-94bf-3332dd981db4"><span style="color: rgb(102, 102, 102)">价格维度</span></p>
    */
    @NotNull(message = "priceBusinessDimensionDTO不能为空")
    @SerializedName("priceBusinessDimensionDTO")
    private PriceBusinessDimensionDTO priceBusinessDimensionDTO;
    /**
    * <p data-diff-id="ct-diff-id-523aecbc-3ac8-4dec-ab94-10f2b0296f78"><span style="color: rgb(102, 102, 102)">价格信息 基础价格和加价规则 如果需要更新必须同时传（如果只有固定分组可以不传加价规则） 基础价格和加价规则、分摊规则不能都为空 新建套餐时，都需要传</span></p>
    */
    @NotNull(message = "priceModule不能为空")
    @SerializedName("priceModule")
    private ComboPriceModule priceModule;

    public PriceBusinessDimensionDTO getPriceBusinessDimensionDTO() {
        return priceBusinessDimensionDTO;
    }
    public void setPriceBusinessDimensionDTO(PriceBusinessDimensionDTO priceBusinessDimensionDTO) {
        this.priceBusinessDimensionDTO = priceBusinessDimensionDTO;
    }
    public ComboPriceModule getPriceModule() {
        return priceModule;
    }
    public void setPriceModule(ComboPriceModule priceModule) {
        this.priceModule = priceModule;
    }




    @Override
    public String toString() {
        return "VendorComboPriceDTO{" + "priceBusinessDimensionDTO=" + priceBusinessDimensionDTO + "," + "priceModule=" + priceModule + "}";
    }
}
