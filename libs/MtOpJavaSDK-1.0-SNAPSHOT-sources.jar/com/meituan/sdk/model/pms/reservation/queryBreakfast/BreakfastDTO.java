package com.meituan.sdk.model.pms.reservation.queryBreakfast;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class BreakfastDTO {
    /**
    * 日期，格式yyyy-MM-dd
    */
    @SerializedName("bizDay")
    private String bizDay;
    /**
    * 早餐类型
    */
    @SerializedName("typeId")
    private String typeId;
    /**
    * 早餐类型描述：includeInPrice:房包早, complimentary:complimentary, purchased:购早, coupon:早餐兑换券
    */
    @SerializedName("typeName")
    private String typeName;
    /**
    * 可用早餐数量
    */
    @SerializedName("nums")
    private Integer nums;

    public String getBizDay() {
        return bizDay;
    }
    public void setBizDay(String bizDay) {
        this.bizDay = bizDay;
    }
    public String getTypeId() {
        return typeId;
    }
    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }
    public String getTypeName() {
        return typeName;
    }
    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }
    public Integer getNums() {
        return nums;
    }
    public void setNums(Integer nums) {
        this.nums = nums;
    }




    @Override
    public String toString() {
        return "BreakfastDTO{" + "bizDay=" + bizDay + "," + "typeId=" + typeId + "," + "typeName=" + typeName + "," + "nums=" + nums + "}";
    }
}
