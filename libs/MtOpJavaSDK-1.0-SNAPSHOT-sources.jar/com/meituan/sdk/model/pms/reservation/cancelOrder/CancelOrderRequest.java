package com.meituan.sdk.model.pms.reservation.cancelOrder;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 取消预订单
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/reservation/cancelOrder",
    businessId = 57,
    apiVersion = "10019",
    apiName = "cancel_order",
    needAuth = true
)
public class CancelOrderRequest implements MeituanRequest<CancelOrderResponse> {
    /**
    * <p data-diff-id="ct-diff-id-56d01981-a659-42e3-be37-8e28b41fe193">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-0cc1b01b-d41c-4023-8ff6-6a672ce771d3">订单ID</p>
    */
    @NotNull(message = "orderId不能为空")
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-4b330d73-d585-48b9-8725-4f74e40ed09a">取消原因</p>
    */
    @NotBlank(message = "memo不能为空")
    @SerializedName("memo")
    private String memo;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getMemo() {
        return memo;
    }
    public void setMemo(String memo) {
        this.memo = memo;
    }


    @Override
    public MeituanResponse<CancelOrderResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<CancelOrderResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "CancelOrderRequest{" + "hotelId=" + hotelId + "," + "orderId=" + orderId + "," + "memo=" + memo + "}";
    }
}
