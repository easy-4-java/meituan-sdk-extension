package com.meituan.sdk.model.pms.priceinve.getRoomStatus;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询酒店房态信息
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/priceinve/getRoomStatus",
    businessId = 57,
    apiVersion = "10009",
    apiName = "get_room_status",
    needAuth = true
)
public class GetRoomStatusRequest implements MeituanRequest<GetRoomStatusResponse> {
    /**
    * <p data-diff-id="ct-diff-id-ff858eb0-bca1-4540-868c-b37fb7eac87e">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-c2db1472-b87d-491a-96ee-1d4b84964daa">房间号</p>
    */
    @SerializedName("roomNumbers")
    private List<RoomNumbersSub> roomNumbers;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public List<RoomNumbersSub> getRoomNumbers() {
        return roomNumbers;
    }
    public void setRoomNumbers(List<RoomNumbersSub> roomNumbers) {
        this.roomNumbers = roomNumbers;
    }


    @Override
    public MeituanResponse<GetRoomStatusResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<GetRoomStatusResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GetRoomStatusRequest{" + "hotelId=" + hotelId + "," + "roomNumbers=" + roomNumbers + "}";
    }
}
