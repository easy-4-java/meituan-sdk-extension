package com.meituan.sdk.model.ddzhkh.dingdan.orderBookBatchQuery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 订单信息列表
* This file was automatically generated.
*/
public class OrderInfo {
    /**
    * 订单基本信息
    */
    @SerializedName("order")
    private Order order;
    /**
    * 商品信息
    */
    @SerializedName("productDTO")
    private Product productDTO;
    /**
    * 退款申请单列表
    */
    @SerializedName("refundApplicationList")
    private List<RefundApplication> refundApplicationList;

    public Order getOrder() {
        return order;
    }
    public void setOrder(Order order) {
        this.order = order;
    }
    public Product getProductDTO() {
        return productDTO;
    }
    public void setProductDTO(Product productDTO) {
        this.productDTO = productDTO;
    }
    public List<RefundApplication> getRefundApplicationList() {
        return refundApplicationList;
    }
    public void setRefundApplicationList(List<RefundApplication> refundApplicationList) {
        this.refundApplicationList = refundApplicationList;
    }




    @Override
    public String toString() {
        return "OrderInfo{" + "order=" + order + "," + "productDTO=" + productDTO + "," + "refundApplicationList=" + refundApplicationList + "}";
    }
}
