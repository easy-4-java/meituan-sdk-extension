package com.meituan.sdk.model.dcpd.queueShop.onlineQueueConfigUpdate;

import java.util.List;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-22cd276e-3bd3-4ba2-b158-df13ee0008a2">限制取号时间段设置</p>
* This file was automatically generated.
*/
public class TimePeriod {
    /**
    * <p data-diff-id="ct-diff-id-8e193cac-ae0a-4376-89cf-0402df94101a">当limitType=1或3时填写，不可跨天，11:00</p>
    */
    @SerializedName("timeBegin")
    private String timeBegin;
    /**
    * <p data-diff-id="ct-diff-id-7eca7931-c689-4df3-8833-906a812e5f18">当limitType=1或3时填写，不可跨天，14:00</p>
    */
    @SerializedName("timeEnd")
    private String timeEnd;
    /**
    * <p data-diff-id="ct-diff-id-0f66f70e-e298-47ca-ad52-c12c5c3481e2">[1,1,1,1,1,1,1]，按照星期进行库存配置，分别代表周日、周一、周二……周六</p>
    */
    @NotEmpty(message = "weekdayBits不能为空")
    @SerializedName("weekdayBits")
    private List<Integer> weekdayBits;

    public String getTimeBegin() {
        return timeBegin;
    }
    public void setTimeBegin(String timeBegin) {
        this.timeBegin = timeBegin;
    }
    public String getTimeEnd() {
        return timeEnd;
    }
    public void setTimeEnd(String timeEnd) {
        this.timeEnd = timeEnd;
    }
    public List<Integer> getWeekdayBits() {
        return weekdayBits;
    }
    public void setWeekdayBits(List<Integer> weekdayBits) {
        this.weekdayBits = weekdayBits;
    }




    @Override
    public String toString() {
        return "TimePeriod{" + "timeBegin=" + timeBegin + "," + "timeEnd=" + timeEnd + "," + "weekdayBits=" + weekdayBits + "}";
    }
}
