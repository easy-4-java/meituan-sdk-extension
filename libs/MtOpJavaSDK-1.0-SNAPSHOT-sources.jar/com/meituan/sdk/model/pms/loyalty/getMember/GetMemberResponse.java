package com.meituan.sdk.model.pms.loyalty.getMember;

import com.google.gson.annotations.SerializedName;

/**
* 根据会员ID、手机号、证件号等查询会员
* This file was automatically generated.
*/
public class GetMemberResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    @SerializedName("data")
    private MemberInfoDTO data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public MemberInfoDTO getData() {
        return data;
    }
    public void setData(MemberInfoDTO data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "GetMemberResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
