package com.meituan.sdk.model.ddzhkh.miniprogram.tradeOrderDataChange;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 订单数据同步
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/miniprogram/trade/order_data_change",
    businessId = 59,
    apiVersion = "10018",
    apiName = "trade_order_data_change",
    needAuth = true
)
public class TradeOrderDataChangeRequest implements MeituanRequest<TradeOrderDataChangeResponse> {
    @NotBlank(message = "generalBizData不能为空")
    @SerializedName("generalBizData")
    private String generalBizData;
    /**
    * <p data-diff-id="ct-diff-id-98c3e072-d193-4dd1-8119-ad03b340d962">订单数据同步请求体</p>
    */
    @NotNull(message = "orderDataChangeReq不能为空")
    @SerializedName("orderDataChangeReq")
    private OrderDataChangeReq orderDataChangeReq;

    public String getGeneralBizData() {
        return generalBizData;
    }
    public void setGeneralBizData(String generalBizData) {
        this.generalBizData = generalBizData;
    }
    public OrderDataChangeReq getOrderDataChangeReq() {
        return orderDataChangeReq;
    }
    public void setOrderDataChangeReq(OrderDataChangeReq orderDataChangeReq) {
        this.orderDataChangeReq = orderDataChangeReq;
    }


    @Override
    public MeituanResponse<TradeOrderDataChangeResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<TradeOrderDataChangeResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TradeOrderDataChangeRequest{" + "generalBizData=" + generalBizData + "," + "orderDataChangeReq=" + orderDataChangeReq + "}";
    }
}
