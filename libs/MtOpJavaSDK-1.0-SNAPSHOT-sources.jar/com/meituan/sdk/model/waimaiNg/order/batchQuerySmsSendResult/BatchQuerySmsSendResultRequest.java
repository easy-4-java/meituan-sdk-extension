package com.meituan.sdk.model.waimaiNg.order.batchQuerySmsSendResult;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询短信发送结果
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/order/batchQuerySMSSendResult",
    businessId = 2,
    apiVersion = "10161",
    apiName = "batch_query_sms_send_result",
    needAuth = true
)
public class BatchQuerySmsSendResultRequest implements MeituanRequest<BatchQuerySmsSendResultResponse> {
    /**
    * <p data-diff-id="ct-diff-id-2340ad3b-b8e6-4a56-8882-32e29035615f">消息id列表，最多同时支持20个</p>
    */
    @NotBlank(message = "msgIds不能为空")
    @SerializedName("msgIds")
    private String msgIds;

    public String getMsgIds() {
        return msgIds;
    }
    public void setMsgIds(String msgIds) {
        this.msgIds = msgIds;
    }


    @Override
    public MeituanResponse<BatchQuerySmsSendResultResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<BatchQuerySmsSendResultResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "BatchQuerySmsSendResultRequest{" + "msgIds=" + msgIds + "}";
    }
}
