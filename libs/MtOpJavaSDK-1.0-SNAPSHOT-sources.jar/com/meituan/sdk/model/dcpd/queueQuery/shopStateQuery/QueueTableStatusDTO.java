package com.meituan.sdk.model.dcpd.queueQuery.shopStateQuery;

import com.google.gson.annotations.SerializedName;

/**
* 桌型状态列表
* This file was automatically generated.
*/
public class QueueTableStatusDTO {
    /**
    * 桌型id
    */
    @SerializedName("tableTypeId")
    private Integer tableTypeId;
    /**
    * 桌型名称
    */
    @SerializedName("tableTypeName")
    private String tableTypeName;
    /**
    * 最小容纳人数
    */
    @SerializedName("minCapacity")
    private Integer minCapacity;
    /**
    * 最大容纳人数
    */
    @SerializedName("maxCapacity")
    private Integer maxCapacity;
    /**
    * 当前等位桌数
    */
    @SerializedName("waitCount")
    private Integer waitCount;

    public Integer getTableTypeId() {
        return tableTypeId;
    }
    public void setTableTypeId(Integer tableTypeId) {
        this.tableTypeId = tableTypeId;
    }
    public String getTableTypeName() {
        return tableTypeName;
    }
    public void setTableTypeName(String tableTypeName) {
        this.tableTypeName = tableTypeName;
    }
    public Integer getMinCapacity() {
        return minCapacity;
    }
    public void setMinCapacity(Integer minCapacity) {
        this.minCapacity = minCapacity;
    }
    public Integer getMaxCapacity() {
        return maxCapacity;
    }
    public void setMaxCapacity(Integer maxCapacity) {
        this.maxCapacity = maxCapacity;
    }
    public Integer getWaitCount() {
        return waitCount;
    }
    public void setWaitCount(Integer waitCount) {
        this.waitCount = waitCount;
    }




    @Override
    public String toString() {
        return "QueueTableStatusDTO{" + "tableTypeId=" + tableTypeId + "," + "tableTypeName=" + tableTypeName + "," + "minCapacity=" + minCapacity + "," + "maxCapacity=" + maxCapacity + "," + "waitCount=" + waitCount + "}";
    }
}
