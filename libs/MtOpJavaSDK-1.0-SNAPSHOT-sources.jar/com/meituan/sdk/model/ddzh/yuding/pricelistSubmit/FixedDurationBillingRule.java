package com.meituan.sdk.model.ddzh.yuding.pricelistSubmit;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-743921f5-20c5-4f52-9077-1f408a14f624">按固定时长房间计费规则</p>
* This file was automatically generated.
*/
public class FixedDurationBillingRule {
    /**
    * <p data-diff-id="ct-diff-id-f9537c4c-4030-4000-bc6d-49d8c6512d18">美团点评房间ID</p>
    */
    @NotNull(message = "mtRoomId不能为空")
    @SerializedName("mtRoomId")
    private Long mtRoomId;
    /**
    * <p data-diff-id="ct-diff-id-9cb9ea08-36bc-4c8d-8a5b-f3fda5f520fa">美团点评套餐ID</p>
    */
    @NotEmpty(message = "mtPackageIds不能为空")
    @SerializedName("mtPackageIds")
    private List<Long> mtPackageIds;
    /**
    * <p data-diff-id="ct-diff-id-5619c2a0-2105-49ac-addb-f571809cbf72">商品时段时间信息</p>
    */
    @NotEmpty(message = "periodDays不能为空")
    @SerializedName("periodDays")
    private List<PeriodDay> periodDays;
    /**
    * <p data-diff-id="ct-diff-id-706dacd5-25ec-455d-a288-4663adb0e9b5">预订时长（单位：时）</p>
    */
    @NotNull(message = "duration不能为空")
    @SerializedName("duration")
    private Integer duration;
    /**
    * <p data-diff-id="ct-diff-id-082a98aa-e848-4205-aa81-341fe11a0c77">售卖价格</p>
    */
    @NotBlank(message = "price不能为空")
    @SerializedName("price")
    private String price;
    /**
    * <table data-borderwidth="1" data-diff-id="ct-diff-id-9acbf4f1-7622-4e42-9235-e80f2e933b9c"><tbody><tr data-row-diff-id="ct-tr-diff-id-87e58042-7563-43d7-96fd-d6023d35797a"><th data-colwidth="148" width="148" data-cell-diff-id="ct-cell-diff-id-9a146656-4ae2-4fda-ad3e-5e14a69e573b"><p data-diff-id="ct-diff-id-328a9181-2525-4cd4-92fa-a1d46ffe55a6">attributeName</p></th><th data-colwidth="147" width="147" data-cell-diff-id="ct-cell-diff-id-f634926a-7a87-465b-bb6a-9f89a0a1073c"><p data-diff-id="ct-diff-id-250ce492-50a8-4f40-b742-591d3c5a302f">含义</p></th><th data-colwidth="211" width="211" data-cell-diff-id="ct-cell-diff-id-8b9150f6-b784-4879-aca9-4a5b751a2ca3"><p data-diff-id="ct-diff-id-ae969735-a9f1-40be-8a71-4f7296ac33b7">attributeValue</p></th></tr><tr data-row-diff-id="ct-tr-diff-id-76c75cd2-05cd-4af4-a66d-2213a79ca061"><td data-colwidth="148" width="148" style="background-color: white;" data-cell-diff-id="ct-cell-diff-id-2fd59399-a09c-4f3e-8f2a-8e77d306db4a"><p data-diff-id="ct-diff-id-41ac3deb-cb67-4712-87c7-f72a5d620207">singHours</p></td><td data-colwidth="147" width="147" style="background-color: white;" data-cell-diff-id="ct-cell-diff-id-d2f5fa37-ecc1-4c19-81ac-2ce93d69b0bc"><p data-diff-id="ct-diff-id-6789a0c7-8e41-4554-ae89-767d505fbf7e">欢唱时长</p></td><td data-colwidth="211" width="211" style="background-color: white;" data-cell-diff-id="ct-cell-diff-id-26db3b9b-494a-4f9e-9294-b40745a008d5"><p data-diff-id="ct-diff-id-1e9e4877-d588-4b15-919d-e707c4031ba3">例如："1"，代表1小时</p></td></tr><tr data-row-diff-id="ct-tr-diff-id-aace21d6-8ebf-4772-a0e2-4ce931b49fc9"><td data-colwidth="148" width="148" style="background-color: white;" data-cell-diff-id="ct-cell-diff-id-e212e09c-9748-4090-b4e8-cc9e466bfabb"><p data-diff-id="ct-diff-id-0992c9b1-a2c9-4ba4-bc5e-b3dd99661b1d">saleType</p></td><td data-colwidth="147" width="147" style="background-color: white;" data-cell-diff-id="ct-cell-diff-id-bac4c963-a28c-4699-951a-4f75ecfaed3e"><p data-diff-id="ct-diff-id-6eaf1447-e064-4e13-99be-d958ebbafb45">售卖类型</p></td><td data-colwidth="211" width="211" style="background-color: white;" data-cell-diff-id="ct-cell-diff-id-791df8b2-d2d8-45c6-a505-c5d80ae87f2a"><p data-diff-id="ct-diff-id-54b041ba-94eb-415e-900a-8a5a8f886ef1">"1"-按房间售卖;</p><p data-diff-id="ct-diff-id-aff2e8f6-c92c-417c-892c-d4b7ac448648">"2"-按人数售卖;</p></td></tr><tr data-row-diff-id="ct-tr-diff-id-23bd3fbb-8ead-46fc-96c6-a10cb2d02c8c"><td data-colwidth="148" width="148" style="background-color: white;" data-cell-diff-id="ct-cell-diff-id-efb4e721-406a-4a2b-b518-82bf6591b869"><p data-diff-id="ct-diff-id-591568ab-504e-40a3-a58a-f64dbf93d0c3">minOrderNum</p></td><td data-colwidth="147" width="147" style="background-color: white;" data-cell-diff-id="ct-cell-diff-id-f963a88b-da7c-4c54-8ac9-2bddc98431eb"><p data-diff-id="ct-diff-id-6f97004d-88af-4e1c-92e1-dcf0a126e9ee">x人起订</p></td><td data-colwidth="211" width="211" style="background-color: white;" data-cell-diff-id="ct-cell-diff-id-0d032944-135e-49bf-bcf3-fc5c7cc57f43"><p data-diff-id="ct-diff-id-ce0ab389-9b90-4fce-8b90-51ca89a2f6d8">例如："1"，代表1人起订</p></td></tr></tbody></table>
    */
    @SerializedName("ext")
    private List<ExtensionAttribute> ext;

    public Long getMtRoomId() {
        return mtRoomId;
    }
    public void setMtRoomId(Long mtRoomId) {
        this.mtRoomId = mtRoomId;
    }
    public List<Long> getMtPackageIds() {
        return mtPackageIds;
    }
    public void setMtPackageIds(List<Long> mtPackageIds) {
        this.mtPackageIds = mtPackageIds;
    }
    public List<PeriodDay> getPeriodDays() {
        return periodDays;
    }
    public void setPeriodDays(List<PeriodDay> periodDays) {
        this.periodDays = periodDays;
    }
    public Integer getDuration() {
        return duration;
    }
    public void setDuration(Integer duration) {
        this.duration = duration;
    }
    public String getPrice() {
        return price;
    }
    public void setPrice(String price) {
        this.price = price;
    }
    public List<ExtensionAttribute> getExt() {
        return ext;
    }
    public void setExt(List<ExtensionAttribute> ext) {
        this.ext = ext;
    }




    @Override
    public String toString() {
        return "FixedDurationBillingRule{" + "mtRoomId=" + mtRoomId + "," + "mtPackageIds=" + mtPackageIds + "," + "periodDays=" + periodDays + "," + "duration=" + duration + "," + "price=" + price + "," + "ext=" + ext + "}";
    }
}
