package com.meituan.sdk.model.ddzh.yuding.dealgroupRelateRoom;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-f98bb969-420c-4c9d-94af-e3d6145acada">关联包型列表</p>
* This file was automatically generated.
*/
public class PRoomInfo {
    /**
    * <p data-diff-id="ct-diff-id-7558aa59-29d1-4295-8156-d66959b28f25">包型ID</p>
    */
    @NotBlank(message = "roomTypeCode不能为空")
    @SerializedName("roomTypeCode")
    private String roomTypeCode;
    /**
    * <p data-diff-id="ct-diff-id-acf5f667-26f6-4a92-a99b-b124d80909a2">关联包间列表</p>
    */
    @NotEmpty(message = "roomBaseCodeList不能为空")
    @SerializedName("roomBaseCodeList")
    private List<Long> roomBaseCodeList;

    public String getRoomTypeCode() {
        return roomTypeCode;
    }
    public void setRoomTypeCode(String roomTypeCode) {
        this.roomTypeCode = roomTypeCode;
    }
    public List<Long> getRoomBaseCodeList() {
        return roomBaseCodeList;
    }
    public void setRoomBaseCodeList(List<Long> roomBaseCodeList) {
        this.roomBaseCodeList = roomBaseCodeList;
    }




    @Override
    public String toString() {
        return "PRoomInfo{" + "roomTypeCode=" + roomTypeCode + "," + "roomBaseCodeList=" + roomBaseCodeList + "}";
    }
}
