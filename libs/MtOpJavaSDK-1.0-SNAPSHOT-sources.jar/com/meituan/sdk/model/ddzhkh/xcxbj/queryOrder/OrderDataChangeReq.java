package com.meituan.sdk.model.ddzhkh.xcxbj.queryOrder;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class OrderDataChangeReq {
    /**
    * <p data-diff-id="ct-diff-id-f119aedd-701e-42e3-87e0-0804b4d2dc9a"><em><span style="color: rgba(0, 0, 0, 0.65)">美团订单号</span></em></p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-a7cd47a8-48f5-4c6d-a83d-943ef52a6a87"><em><span style="color: rgba(0, 0, 0, 0.65)">三方订单号，可填</span></em></p>
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }




    @Override
    public String toString() {
        return "OrderDataChangeReq{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "}";
    }
}
