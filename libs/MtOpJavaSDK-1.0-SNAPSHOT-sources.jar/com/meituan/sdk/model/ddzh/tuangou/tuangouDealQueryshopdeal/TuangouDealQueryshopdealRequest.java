package com.meituan.sdk.model.ddzh.tuangou.tuangouDealQueryshopdeal;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取团购信息
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/tuangou/deal/queryshopdeal",
    businessId = 58,
    apiVersion = "10087",
    apiName = "tuangou_deal_queryshopdeal",
    needAuth = true
)
public class TuangouDealQueryshopdealRequest implements MeituanRequest<TuangouDealQueryshopdealResponse> {
    /**
    * <p data-diff-id="ct-diff-id-864044d3-2d25-4ded-85ec-a901aa152dd1"><span style="color: rgb(31, 45, 61)">页码，起始值为1。查第一页传1，第二页传2</span></p>
    */
    @NotNull(message = "offset不能为空")
    @SerializedName("offset")
    private Integer offset;
    /**
    * <p data-diff-id="ct-diff-id-cf34d6e4-faf3-4501-a914-234da007cab2"><span style="color: rgb(31, 45, 61)">页大小，默认值为100，不能超过100。</span></p>
    */
    @NotNull(message = "limit不能为空")
    @SerializedName("limit")
    private Integer limit;
    /**
    * <p data-diff-id="ct-diff-id-c7b14759-03b1-4cf6-88fd-efb420afa666"><span style="color: rgb(31, 45, 61)">售卖平台。1-大众点评，2-美团。默认为1</span></p>
    */
    @NotNull(message = "source不能为空")
    @SerializedName("source")
    private Integer source;

    public Integer getOffset() {
        return offset;
    }
    public void setOffset(Integer offset) {
        this.offset = offset;
    }
    public Integer getLimit() {
        return limit;
    }
    public void setLimit(Integer limit) {
        this.limit = limit;
    }
    public Integer getSource() {
        return source;
    }
    public void setSource(Integer source) {
        this.source = source;
    }


    @Override
    public MeituanResponse<TuangouDealQueryshopdealResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<TuangouDealQueryshopdealResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TuangouDealQueryshopdealRequest{" + "offset=" + offset + "," + "limit=" + limit + "," + "source=" + source + "}";
    }
}
