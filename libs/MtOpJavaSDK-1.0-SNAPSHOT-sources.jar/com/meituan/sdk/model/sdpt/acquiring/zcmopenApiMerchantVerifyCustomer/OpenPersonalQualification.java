package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiMerchantVerifyCustomer;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class OpenPersonalQualification {
    /**
    * <p data-diff-id="ct-diff-id-d77a19f2-42c2-4005-bf17-5a221cce8689"><span style="color: ">证件图片正面</span></p>
    */
    @NotBlank(message = "idcardFrontPhoto不能为空")
    @SerializedName("idcardFrontPhoto")
    private String idcardFrontPhoto;
    /**
    * <p data-diff-id="ct-diff-id-509d4da5-4a6b-4ba7-8c62-5cfb3cf9deb0"><span style="color: ">证件图片反面</span></p>
    */
    @NotBlank(message = "idcardBackPhoto不能为空")
    @SerializedName("idcardBackPhoto")
    private String idcardBackPhoto;
    /**
    * <p data-diff-id="ct-diff-id-307f5312-2579-429b-be0d-b018ecf60f11">证件截止日期.</p><p style="text-align: start;" data-diff-id="ct-diff-id-17f9acd5-1816-4034-acb3-0d8eed5ba2c3"><span style="color: rgb(0, 0, 0)">当永久有效时，截止日期写成2099-01-01</span></p>
    */
    @NotBlank(message = "idcardDeadLineDate不能为空")
    @SerializedName("idcardDeadLineDate")
    private String idcardDeadLineDate;

    public String getIdcardFrontPhoto() {
        return idcardFrontPhoto;
    }
    public void setIdcardFrontPhoto(String idcardFrontPhoto) {
        this.idcardFrontPhoto = idcardFrontPhoto;
    }
    public String getIdcardBackPhoto() {
        return idcardBackPhoto;
    }
    public void setIdcardBackPhoto(String idcardBackPhoto) {
        this.idcardBackPhoto = idcardBackPhoto;
    }
    public String getIdcardDeadLineDate() {
        return idcardDeadLineDate;
    }
    public void setIdcardDeadLineDate(String idcardDeadLineDate) {
        this.idcardDeadLineDate = idcardDeadLineDate;
    }




    @Override
    public String toString() {
        return "OpenPersonalQualification{" + "idcardFrontPhoto=" + idcardFrontPhoto + "," + "idcardBackPhoto=" + idcardBackPhoto + "," + "idcardDeadLineDate=" + idcardDeadLineDate + "}";
    }
}
