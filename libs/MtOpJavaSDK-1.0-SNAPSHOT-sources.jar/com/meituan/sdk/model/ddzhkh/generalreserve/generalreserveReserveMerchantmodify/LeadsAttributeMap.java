package com.meituan.sdk.model.ddzhkh.generalreserve.generalreserveReserveMerchantmodify;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-e2763371-b409-43a0-a86e-fb5cd442f7dd"><span style="color: rgb(31, 45, 61)">属性信息</span></p>
* This file was automatically generated.
*/
public class LeadsAttributeMap {
    /**
    * <p data-diff-id="ct-diff-id-fbefa127-d25e-4141-8a8b-c934b3307518">【<span style="color: rgb(31, 45, 61)">体检</span>】必填</p><p data-diff-id="ct-diff-id-458d4d75-1540-4a43-b980-211d7cda42c1">是否开通号码保护</p><p style="text-align: start;" data-diff-id="ct-diff-id-cd6710d5-7a3b-4077-bc9c-0a2dadadf010">true：开通 false：未开通</p>
    */
    @SerializedName("isPhoneProtect")
    private Boolean isPhoneProtect;
    /**
    * <p data-diff-id="ct-diff-id-e9e87296-3702-4eec-858f-2c97c0c227cc">【<span style="color: rgb(31, 45, 61)">体检、丽人</span>】必填</p><p data-diff-id="ct-diff-id-0cd33199-8c36-4804-89f0-a145827ccaf7"><span style="color: rgb(31, 45, 61)">商品名称</span></p>
    */
    @SerializedName("userDetailDealName")
    private String userDetailDealName;
    /**
    * <p data-diff-id="ct-diff-id-ae5b57a5-1d8a-491e-b788-7ba23a1f916f">【<span style="color: rgb(31, 45, 61)">体检</span>】必填</p><p data-diff-id="ct-diff-id-33d17ea3-f584-4c88-87fe-1c06f35c7f74">是否已婚</p><p style="text-align: start;" data-diff-id="ct-diff-id-8a8ca2be-6881-4cae-820a-f1cd6520b3c4">0：不限 1：已婚 2：未婚</p>
    */
    @SerializedName("userMarried")
    private Integer userMarried;
    /**
    * <p data-diff-id="ct-diff-id-c7ca5ea7-9878-43a0-85a4-4b1735dec664">【<span style="color: rgb(31, 45, 61)">体检</span>】必填</p><p data-diff-id="ct-diff-id-896ed825-6707-441f-bfeb-17515e316101">证件类型</p><p style="text-align: start;" data-diff-id="ct-diff-id-1e4586d6-14cc-40a6-b381-0ad8b80402ca">1：身份证</p><p style="text-align: start;" data-diff-id="ct-diff-id-14c6d244-ddee-4b0a-b77a-85e02c78c4e9">2：护照</p><p style="text-align: start;" data-diff-id="ct-diff-id-13d6a57b-1a60-491c-879b-58c322b1911c">3：港澳通行证</p><p style="text-align: start;" data-diff-id="ct-diff-id-fafe86f5-8011-4e0a-9d69-d85d519d4055">4：台胞证</p>
    */
    @SerializedName("userIdNumberType")
    private Integer userIdNumberType;
    /**
    * <p data-diff-id="ct-diff-id-a86921fe-3929-4090-9a4e-6b50f96878cc">【<span style="color: rgb(31, 45, 61)">体检</span>】必填</p><p data-diff-id="ct-diff-id-5e2bc389-eed7-4904-bb48-ed5fbbe90447"><span style="color: rgb(31, 45, 61)">证件号</span></p>
    */
    @SerializedName("userIdNumber")
    private String userIdNumber;
    /**
    * <p data-diff-id="ct-diff-id-60fdcdb7-c046-40f6-97d5-67b07124d4b8">【<span style="color: rgb(31, 45, 61)">体检</span>】必填</p><p data-diff-id="ct-diff-id-c01d2e0a-d094-4e9e-ba65-17be3c81f20c">附加项附属信息</p><p style="text-align: start;" data-diff-id="ct-diff-id-e599dcb7-d575-4d01-8279-240b0c593f2a"><strong><span style="color: red">C 端个检可忽略，团检加项内容固定显示在此处</span></strong></p><p style="text-align: start;" data-diff-id="ct-diff-id-ece7907e-2811-4057-a8d0-6235df930ba0">velue：[{"productId":商品ID,"extraName":"项目名","price":"价格","spuId":标品ID}]</p><p style="text-align: start;" data-diff-id="ct-diff-id-6de96115-88a0-43e4-8aa4-c6870cd8af91">关注spuId即可</p>
    */
    @SerializedName("spuProductExtraInfo")
    private String spuProductExtraInfo;
    /**
    * <p data-diff-id="ct-diff-id-11a31bee-8644-40fe-859b-0bb8c6d07209">【<span style="color: rgb(31, 45, 61)">体检</span>】必填</p><p data-diff-id="ct-diff-id-aa155ee7-23b6-491b-833d-cc0436d5ce5a"><span style="color: rgb(31, 45, 61)">预约人姓名</span></p>
    */
    @SerializedName("resvUserName")
    private String resvUserName;
    /**
    * <p data-diff-id="ct-diff-id-349bbd58-d9ab-4e56-b23f-13d84edecbd1">【<span style="color: rgb(31, 45, 61)">体检</span>】必填</p><p data-diff-id="ct-diff-id-60966687-bb82-40ed-b764-87b7bc3f8d29">用户性别</p><p style="text-align: start;" data-diff-id="ct-diff-id-3045a8cb-fe0d-4a30-b8b3-3e9a5df13063">1：男 2：女</p>
    */
    @SerializedName("userGender")
    private Integer userGender;
    /**
    * <p data-diff-id="ct-diff-id-fcdd7b4e-da67-46aa-b7f4-0d581e758bbd">【<span style="color: rgb(31, 45, 61)">丽人</span>】必填</p><p data-diff-id="ct-diff-id-5bef2e3e-45df-4c24-9c4e-9138e9210cc3"><span style="color: rgb(31, 45, 61)">服务时长</span></p>
    */
    @SerializedName("orderDuration")
    private Long orderDuration;

    public Boolean getIsPhoneProtect() {
        return isPhoneProtect;
    }
    public void setIsPhoneProtect(Boolean isPhoneProtect) {
        this.isPhoneProtect = isPhoneProtect;
    }
    public String getUserDetailDealName() {
        return userDetailDealName;
    }
    public void setUserDetailDealName(String userDetailDealName) {
        this.userDetailDealName = userDetailDealName;
    }
    public Integer getUserMarried() {
        return userMarried;
    }
    public void setUserMarried(Integer userMarried) {
        this.userMarried = userMarried;
    }
    public Integer getUserIdNumberType() {
        return userIdNumberType;
    }
    public void setUserIdNumberType(Integer userIdNumberType) {
        this.userIdNumberType = userIdNumberType;
    }
    public String getUserIdNumber() {
        return userIdNumber;
    }
    public void setUserIdNumber(String userIdNumber) {
        this.userIdNumber = userIdNumber;
    }
    public String getSpuProductExtraInfo() {
        return spuProductExtraInfo;
    }
    public void setSpuProductExtraInfo(String spuProductExtraInfo) {
        this.spuProductExtraInfo = spuProductExtraInfo;
    }
    public String getResvUserName() {
        return resvUserName;
    }
    public void setResvUserName(String resvUserName) {
        this.resvUserName = resvUserName;
    }
    public Integer getUserGender() {
        return userGender;
    }
    public void setUserGender(Integer userGender) {
        this.userGender = userGender;
    }
    public Long getOrderDuration() {
        return orderDuration;
    }
    public void setOrderDuration(Long orderDuration) {
        this.orderDuration = orderDuration;
    }




    @Override
    public String toString() {
        return "LeadsAttributeMap{" + "isPhoneProtect=" + isPhoneProtect + "," + "userDetailDealName=" + userDetailDealName + "," + "userMarried=" + userMarried + "," + "userIdNumberType=" + userIdNumberType + "," + "userIdNumber=" + userIdNumber + "," + "spuProductExtraInfo=" + spuProductExtraInfo + "," + "resvUserName=" + resvUserName + "," + "userGender=" + userGender + "," + "orderDuration=" + orderDuration + "}";
    }
}
