package com.meituan.sdk.model.pms.hotel.getHotelBuildingInfo;

import com.google.gson.annotations.SerializedName;

/**
* 楼层列表
* This file was automatically generated.
*/
public class HotelFloorDTO {
    /**
    * 楼层ID
    */
    @SerializedName("floorId")
    private Long floorId;
    /**
    * 楼层名称
    */
    @SerializedName("floorName")
    private String floorName;
    /**
    * 楼层锁号
    */
    @SerializedName("floorLockNo")
    private String floorLockNo;
    /**
    * 楼层排序，升序
    */
    @SerializedName("sort")
    private Integer sort;

    public Long getFloorId() {
        return floorId;
    }
    public void setFloorId(Long floorId) {
        this.floorId = floorId;
    }
    public String getFloorName() {
        return floorName;
    }
    public void setFloorName(String floorName) {
        this.floorName = floorName;
    }
    public String getFloorLockNo() {
        return floorLockNo;
    }
    public void setFloorLockNo(String floorLockNo) {
        this.floorLockNo = floorLockNo;
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }




    @Override
    public String toString() {
        return "HotelFloorDTO{" + "floorId=" + floorId + "," + "floorName=" + floorName + "," + "floorLockNo=" + floorLockNo + "," + "sort=" + sort + "}";
    }
}
