package com.meituan.sdk.model.ddzh.technician.technicianTechinfoSycnstock;


/**
* 同步结果，key：手艺人id，  value：Obj对象(technicianId手艺人id,success是否成功,msg响应信息)
* This file was automatically generated.
*/
public class Map {





}
