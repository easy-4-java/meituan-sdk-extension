package com.meituan.sdk.model.tuangouNg.atomgoods.productSpuUpdate;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-0b3c4713-d977-496f-a22a-4c200c318040">分组下的加料，至少有一个</p>
* This file was automatically generated.
*/
public class PDcSideDish {
    /**
    * <p data-diff-id="ct-diff-id-c5275f09-deb9-4460-b9cb-f75de43cddaf">三方加料id</p>
    */
    @NotBlank(message = "sideDishId不能为空")
    @SerializedName("sideDishId")
    private String sideDishId;
    /**
    * <p data-diff-id="ct-diff-id-e3123a51-c133-4be3-b040-6e11396c5044">加料名称，不重复</p>
    */
    @NotBlank(message = "sideDishName不能为空")
    @SerializedName("sideDishName")
    private String sideDishName;
    /**
    * <p data-diff-id="ct-diff-id-307d5248-6e91-4b8a-8e8e-3b9fc858c1a5">加料描述</p>
    */
    @SerializedName("sideDishDesc")
    private String sideDishDesc;
    /**
    * <p data-diff-id="ct-diff-id-115bd712-29cd-4a19-bc99-5833d7dfc763">加料状态，0-不可用，1-可用。默认为1</p>
    */
    @SerializedName("status")
    private Long status;
    /**
    * <p data-diff-id="ct-diff-id-dbef1409-1f5a-4a0b-9e17-61051a445ac7">加料价格，单位是分，不可以为负，默认为0</p>
    */
    @SerializedName("price")
    private Integer price;
    /**
    * <p data-diff-id="ct-diff-id-6c051e2c-06ed-47a7-a5cb-8d6b84d34c22">其他价格</p>
    */
    @SerializedName("extraPriceList")
    private List<PDcPrice> extraPriceList;
    /**
    * <p data-diff-id="ct-diff-id-105b50d8-d20d-4d3f-a96a-dce91833f024">图片url</p>
    */
    @SerializedName("pictureList")
    private List<String> pictureList;
    /**
    * <p data-diff-id="ct-diff-id-24143f0b-acf9-4f72-8b43-a9e2a174682b">标签列表</p>
    */
    @SerializedName("tagList")
    private List<PDcTag> tagList;
    /**
    * <p data-diff-id="ct-diff-id-db179b63-4d0f-4620-89a9-f0a8b9e07910">是否单独售卖，默认为0，0-不单独售卖，1-单独售卖</p>
    */
    @SerializedName("saleIndependently")
    private Integer saleIndependently;
    /**
    * <p data-diff-id="ct-diff-id-3cadccba-31cc-4bfe-a272-41b8c25daec8"><span style="color: #333">0-总部下发，1-门店自建（如果是门店菜，必传）</span></p>
    */
    @SerializedName("publishType")
    private Integer publishType;
    /**
    * <p data-diff-id="ct-diff-id-d18a9c48-55cd-4b37-916c-2efaea3f3982"><span style="color: #333">关联的总部加料id（如果门店菜是总部下发，必传）</span></p>
    */
    @SerializedName("chainSideDishId")
    private String chainSideDishId;
    /**
    * <p data-diff-id="ct-diff-id-ca39f779-f3bc-4127-91f1-2e5088e2a6d9"><span style="color: #333">总部code（如果门店菜是总部下发，必传）</span></p>
    */
    @SerializedName("vendorChainId")
    private String vendorChainId;
    /**
    * <p data-diff-id="ct-diff-id-2fc9e01e-5dda-4def-980b-595b1d163094"><span style="color: #333">三方加料菜品分组id</span></p>
    */
    @SerializedName("sideDishGroupId")
    private String sideDishGroupId;

    public String getSideDishId() {
        return sideDishId;
    }
    public void setSideDishId(String sideDishId) {
        this.sideDishId = sideDishId;
    }
    public String getSideDishName() {
        return sideDishName;
    }
    public void setSideDishName(String sideDishName) {
        this.sideDishName = sideDishName;
    }
    public String getSideDishDesc() {
        return sideDishDesc;
    }
    public void setSideDishDesc(String sideDishDesc) {
        this.sideDishDesc = sideDishDesc;
    }
    public Long getStatus() {
        return status;
    }
    public void setStatus(Long status) {
        this.status = status;
    }
    public Integer getPrice() {
        return price;
    }
    public void setPrice(Integer price) {
        this.price = price;
    }
    public List<PDcPrice> getExtraPriceList() {
        return extraPriceList;
    }
    public void setExtraPriceList(List<PDcPrice> extraPriceList) {
        this.extraPriceList = extraPriceList;
    }
    public List<String> getPictureList() {
        return pictureList;
    }
    public void setPictureList(List<String> pictureList) {
        this.pictureList = pictureList;
    }
    public List<PDcTag> getTagList() {
        return tagList;
    }
    public void setTagList(List<PDcTag> tagList) {
        this.tagList = tagList;
    }
    public Integer getSaleIndependently() {
        return saleIndependently;
    }
    public void setSaleIndependently(Integer saleIndependently) {
        this.saleIndependently = saleIndependently;
    }
    public Integer getPublishType() {
        return publishType;
    }
    public void setPublishType(Integer publishType) {
        this.publishType = publishType;
    }
    public String getChainSideDishId() {
        return chainSideDishId;
    }
    public void setChainSideDishId(String chainSideDishId) {
        this.chainSideDishId = chainSideDishId;
    }
    public String getVendorChainId() {
        return vendorChainId;
    }
    public void setVendorChainId(String vendorChainId) {
        this.vendorChainId = vendorChainId;
    }
    public String getSideDishGroupId() {
        return sideDishGroupId;
    }
    public void setSideDishGroupId(String sideDishGroupId) {
        this.sideDishGroupId = sideDishGroupId;
    }




    @Override
    public String toString() {
        return "PDcSideDish{" + "sideDishId=" + sideDishId + "," + "sideDishName=" + sideDishName + "," + "sideDishDesc=" + sideDishDesc + "," + "status=" + status + "," + "price=" + price + "," + "extraPriceList=" + extraPriceList + "," + "pictureList=" + pictureList + "," + "tagList=" + tagList + "," + "saleIndependently=" + saleIndependently + "," + "publishType=" + publishType + "," + "chainSideDishId=" + chainSideDishId + "," + "vendorChainId=" + vendorChainId + "," + "sideDishGroupId=" + sideDishGroupId + "}";
    }
}
