package com.meituan.sdk.model.ddzhkh.xcx3csmzl.queryPayToken;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class QueryPayTokenReq {
    /**
    * <p data-diff-id="ct-diff-id-76325808-bd0a-459a-9be6-715ee44a67b8"><span style="color: rgba(0, 0, 0, 0.65)">美团订单号，与三方商户订单号二选一</span></p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-f46975e3-f176-48a8-9caa-fd09bc367d2d"><span style="color: rgba(0, 0, 0, 0.65)">三方商户订单号，与美团订单号二选一</span></p>
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * <p data-diff-id="ct-diff-id-04070692-7d7b-4fbf-87d8-b040c2bb32cd">三方支持id</p>
    */
    @SerializedName("vendorPaymentId")
    private String vendorPaymentId;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public String getVendorPaymentId() {
        return vendorPaymentId;
    }
    public void setVendorPaymentId(String vendorPaymentId) {
        this.vendorPaymentId = vendorPaymentId;
    }




    @Override
    public String toString() {
        return "QueryPayTokenReq{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "," + "vendorPaymentId=" + vendorPaymentId + "}";
    }
}
