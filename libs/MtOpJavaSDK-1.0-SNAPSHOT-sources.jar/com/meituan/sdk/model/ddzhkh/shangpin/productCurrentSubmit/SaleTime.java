package com.meituan.sdk.model.ddzhkh.shangpin.productCurrentSubmit;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-28057475-5d7f-4042-ad48-b116302fe054">售卖时间</p>
* This file was automatically generated.
*/
public class SaleTime {
    /**
    * <p data-diff-id="ct-diff-id-b70eeb35-3b1e-44f6-9ed6-a667356415c9">售卖开始时间，yyyy-MM-dd</p>
    */
    @SerializedName("saleStartTime")
    private String saleStartTime;
    /**
    * <p data-diff-id="ct-diff-id-2cfebff4-01d5-40fb-9d4d-65b3d1badc06">售卖结束时间，yyyy-MM-dd</p>
    */
    @SerializedName("saleEndTime")
    private String saleEndTime;
    /**
    * <p data-diff-id="ct-diff-id-84792f81-bf16-4d28-9a53-3162437f9128">售卖开始时间模式，1-审核通过立即上架 2-指定时间</p>
    */
    @NotNull(message = "saleStartTimeMode不能为空")
    @SerializedName("saleStartTimeMode")
    private Integer saleStartTimeMode;
    /**
    * <p data-diff-id="ct-diff-id-54960b75-4825-490b-9143-0560a08702ca"><span style="color: ">售卖结束时间模式，1-自动延期 2-指定时间下架</span></p>
    */
    @SerializedName("saleEndTimeMode")
    private Integer saleEndTimeMode;

    public String getSaleStartTime() {
        return saleStartTime;
    }
    public void setSaleStartTime(String saleStartTime) {
        this.saleStartTime = saleStartTime;
    }
    public String getSaleEndTime() {
        return saleEndTime;
    }
    public void setSaleEndTime(String saleEndTime) {
        this.saleEndTime = saleEndTime;
    }
    public Integer getSaleStartTimeMode() {
        return saleStartTimeMode;
    }
    public void setSaleStartTimeMode(Integer saleStartTimeMode) {
        this.saleStartTimeMode = saleStartTimeMode;
    }
    public Integer getSaleEndTimeMode() {
        return saleEndTimeMode;
    }
    public void setSaleEndTimeMode(Integer saleEndTimeMode) {
        this.saleEndTimeMode = saleEndTimeMode;
    }




    @Override
    public String toString() {
        return "SaleTime{" + "saleStartTime=" + saleStartTime + "," + "saleEndTime=" + saleEndTime + "," + "saleStartTimeMode=" + saleStartTimeMode + "," + "saleEndTimeMode=" + saleEndTimeMode + "}";
    }
}
