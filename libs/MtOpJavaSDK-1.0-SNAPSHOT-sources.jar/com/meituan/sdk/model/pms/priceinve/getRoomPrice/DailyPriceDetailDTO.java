package com.meituan.sdk.model.pms.priceinve.getRoomPrice;

import com.google.gson.annotations.SerializedName;

/**
* 每日价格详情
* This file was automatically generated.
*/
public class DailyPriceDetailDTO {
    /**
    * 日期
    */
    @SerializedName("date")
    private String date;
    /**
    * 原价
    */
    @SerializedName("originPrice")
    private String originPrice;
    /**
    * 优惠价
    */
    @SerializedName("actualPrice")
    private String actualPrice;

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getOriginPrice() {
        return originPrice;
    }
    public void setOriginPrice(String originPrice) {
        this.originPrice = originPrice;
    }
    public String getActualPrice() {
        return actualPrice;
    }
    public void setActualPrice(String actualPrice) {
        this.actualPrice = actualPrice;
    }




    @Override
    public String toString() {
        return "DailyPriceDetailDTO{" + "date=" + date + "," + "originPrice=" + originPrice + "," + "actualPrice=" + actualPrice + "}";
    }
}
