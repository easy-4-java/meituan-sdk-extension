package com.meituan.sdk.model.wmoperNg.food.toppingList;

import com.google.gson.annotations.SerializedName;

/**
* 关联商品
* This file was automatically generated.
*/
public class OpenSpuToppingRel {
    /**
    * 商品code
    */
    @SerializedName("spuCode")
    private String spuCode;

    public String getSpuCode() {
        return spuCode;
    }
    public void setSpuCode(String spuCode) {
        this.spuCode = spuCode;
    }




    @Override
    public String toString() {
        return "OpenSpuToppingRel{" + "spuCode=" + spuCode + "}";
    }
}
