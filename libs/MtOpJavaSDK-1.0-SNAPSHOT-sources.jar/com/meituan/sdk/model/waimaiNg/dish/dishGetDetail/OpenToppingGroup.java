package com.meituan.sdk.model.waimaiNg.dish.dishGetDetail;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 单品关联的小料组
* This file was automatically generated.
*/
public class OpenToppingGroup {
    /**
    * 小料名称
    */
    @SerializedName("name")
    private String name;
    /**
    * 小料组code
    */
    @SerializedName("toppingGroupCode")
    private String toppingGroupCode;
    /**
    * 小料组偏移id
    */
    @SerializedName("mtToppingGroupId")
    private Long mtToppingGroupId;
    /**
    * 是否可重复选  该字段只能填写0、1；0-不可重复选择、1-可重复选择
    */
    @SerializedName("repeatSelect")
    private Integer repeatSelect;
    /**
    * 是否可多选  该字段只能填写0、1；0-不可多选、1-可多选
    */
    @SerializedName("multiSelect")
    private Integer multiSelect;
    /**
    * 小料组序号
    */
    @SerializedName("sequence")
    private Integer sequence;
    /**
    * 最大可选数量
    */
    @SerializedName("maxSelect")
    private Integer maxSelect;
    /**
    * 关联的小料
    */
    @SerializedName("toppingList")
    private List<OpenToppingGroupRel> toppingList;
    /**
    * 最小购买数量
    */
    @SerializedName("minSelect")
    private Integer minSelect;
    /**
    * 是否必选，只能填0、1，0非必选，1必选
    */
    @SerializedName("mandatory")
    private Integer mandatory;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getToppingGroupCode() {
        return toppingGroupCode;
    }
    public void setToppingGroupCode(String toppingGroupCode) {
        this.toppingGroupCode = toppingGroupCode;
    }
    public Long getMtToppingGroupId() {
        return mtToppingGroupId;
    }
    public void setMtToppingGroupId(Long mtToppingGroupId) {
        this.mtToppingGroupId = mtToppingGroupId;
    }
    public Integer getRepeatSelect() {
        return repeatSelect;
    }
    public void setRepeatSelect(Integer repeatSelect) {
        this.repeatSelect = repeatSelect;
    }
    public Integer getMultiSelect() {
        return multiSelect;
    }
    public void setMultiSelect(Integer multiSelect) {
        this.multiSelect = multiSelect;
    }
    public Integer getSequence() {
        return sequence;
    }
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    public Integer getMaxSelect() {
        return maxSelect;
    }
    public void setMaxSelect(Integer maxSelect) {
        this.maxSelect = maxSelect;
    }
    public List<OpenToppingGroupRel> getToppingList() {
        return toppingList;
    }
    public void setToppingList(List<OpenToppingGroupRel> toppingList) {
        this.toppingList = toppingList;
    }
    public Integer getMinSelect() {
        return minSelect;
    }
    public void setMinSelect(Integer minSelect) {
        this.minSelect = minSelect;
    }
    public Integer getMandatory() {
        return mandatory;
    }
    public void setMandatory(Integer mandatory) {
        this.mandatory = mandatory;
    }




    @Override
    public String toString() {
        return "OpenToppingGroup{" + "name=" + name + "," + "toppingGroupCode=" + toppingGroupCode + "," + "mtToppingGroupId=" + mtToppingGroupId + "," + "repeatSelect=" + repeatSelect + "," + "multiSelect=" + multiSelect + "," + "sequence=" + sequence + "," + "maxSelect=" + maxSelect + "," + "toppingList=" + toppingList + "," + "minSelect=" + minSelect + "," + "mandatory=" + mandatory + "}";
    }
}
