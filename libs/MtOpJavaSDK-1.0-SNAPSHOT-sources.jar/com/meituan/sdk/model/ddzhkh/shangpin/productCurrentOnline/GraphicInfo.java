package com.meituan.sdk.model.ddzhkh.shangpin.productCurrentOnline;

import java.util.List;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-c7b1cfd5-9162-4f89-85f1-ad26487799af"><span style="color: ">图文信息</span></p>
* This file was automatically generated.
*/
public class GraphicInfo {
    /**
    * <p data-diff-id="ct-diff-id-df4fd0fc-2518-4125-b701-6fbfb95b9772">图片列表，<span style="color: red">图片内容请使用「</span><span style="color: rgba(0, 0, 0, 0.65)"><a class="ct-link" href="https://developer.meituan.com/docs/api/ddzhkh-shangpin-image-upload" data-auto_update="0">图片上传接口</a></span><span style="color: red">」返回的data替代图片内容</span></p>
    */
    @NotEmpty(message = "imageUrls不能为空")
    @SerializedName("imageUrls")
    private List<String> imageUrls;
    /**
    * <p data-diff-id="ct-diff-id-993fa4e2-863b-4ce6-a99b-126e1d3bc208">图文内容</p>
    */
    @SerializedName("text")
    private String text;

    public List<String> getImageUrls() {
        return imageUrls;
    }
    public void setImageUrls(List<String> imageUrls) {
        this.imageUrls = imageUrls;
    }
    public String getText() {
        return text;
    }
    public void setText(String text) {
        this.text = text;
    }




    @Override
    public String toString() {
        return "GraphicInfo{" + "imageUrls=" + imageUrls + "," + "text=" + text + "}";
    }
}
