package com.meituan.sdk.model.tuangouNg.atomgoods.productSpuUpdate;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-e59c1032-6ab6-4c00-bcea-16661246ed6a">菜品归属的前台类目（可以有多个，至少有一个）（里面排序是这个菜在对应类目下的排序）</p>
* This file was automatically generated.
*/
public class PDcCategory {
    /**
    * <p data-diff-id="ct-diff-id-b14c9d20-981a-4cf4-816c-8684a64c4a34">三方前台分类id</p>
    */
    @NotBlank(message = "categoryId不能为空")
    @SerializedName("categoryId")
    private String categoryId;
    /**
    * <p data-diff-id="ct-diff-id-477b1bc2-7217-4375-89bf-17c788b58e86">三方前台分类名称</p>
    */
    @NotBlank(message = "categoryName不能为空")
    @SerializedName("categoryName")
    private String categoryName;
    /**
    * <p data-diff-id="ct-diff-id-a0568ab0-0071-4929-ad3b-660c09ebbef6">spu在这个category下的排序，从小到大排序，大于等于1</p>
    */
    @NotNull(message = "sort不能为空")
    @SerializedName("sort")
    private Long sort;
    /**
    * <p data-diff-id="ct-diff-id-a0e43d79-78d0-4864-ac12-9cc03eab9a64">适用渠道,可以控制部分菜品在点餐展示<br>（不传默认为1-基础渠道）<br>1-基础渠道2-智能点餐</p>
    */
    @SerializedName("channel")
    private Integer channel;
    /**
    * <p data-diff-id="ct-diff-id-bf844d43-4ada-434e-8c23-17d50b115da2">超过2层目录，level必传<br>类目层级</p>
    */
    @SerializedName("level")
    private Long level;
    /**
    * <p data-diff-id="ct-diff-id-7dd556ac-d33e-4445-b105-39962f4fddde">类目状态，0-不生效，1-生效中，默认1</p>
    */
    @SerializedName("status")
    private Integer status;
    /**
    * <p data-diff-id="ct-diff-id-8e9452d3-9961-427a-bf22-a087766fd848"><span style="color: rgb(51, 51, 51)">0-总部下发，1-门店自建</span><span style="color: #333">（如果是门店菜，必传）</span></p>
    */
    @SerializedName("publishType")
    private Integer publishType;
    /**
    * <p data-diff-id="ct-diff-id-277544ea-d4f6-4963-91bd-53a10d690d29"><span style="color: #333">关联的总部前台类目id（如果门店菜是总部下发，必传）</span></p>
    */
    @SerializedName("chainCategoryId")
    private String chainCategoryId;
    /**
    * <p data-diff-id="ct-diff-id-62dc6bdf-07a2-45f0-8696-56d7f529eb1f"><span style="color: #333">总部code（如果门店菜是总部下发，必传）</span></p>
    */
    @SerializedName("vendorChainId")
    private String vendorChainId;
    /**
    * <p data-diff-id="ct-diff-id-791f4650-6c20-4e98-9b7a-bb1619a60425"><span style="color: #333">父级类目id，如果不存在，为nul</span></p>
    */
    @SerializedName("vendorParentCategoryId")
    private String vendorParentCategoryId;
    /**
    * <p data-diff-id="ct-diff-id-e4dd5927-7780-4411-b48d-3d3c5ab17ef5">分类的顺序，字段值越小，排序越靠前</p>
    */
    @SerializedName("cateSort")
    private Long cateSort;

    public String getCategoryId() {
        return categoryId;
    }
    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }
    public String getCategoryName() {
        return categoryName;
    }
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    public Long getSort() {
        return sort;
    }
    public void setSort(Long sort) {
        this.sort = sort;
    }
    public Integer getChannel() {
        return channel;
    }
    public void setChannel(Integer channel) {
        this.channel = channel;
    }
    public Long getLevel() {
        return level;
    }
    public void setLevel(Long level) {
        this.level = level;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getPublishType() {
        return publishType;
    }
    public void setPublishType(Integer publishType) {
        this.publishType = publishType;
    }
    public String getChainCategoryId() {
        return chainCategoryId;
    }
    public void setChainCategoryId(String chainCategoryId) {
        this.chainCategoryId = chainCategoryId;
    }
    public String getVendorChainId() {
        return vendorChainId;
    }
    public void setVendorChainId(String vendorChainId) {
        this.vendorChainId = vendorChainId;
    }
    public String getVendorParentCategoryId() {
        return vendorParentCategoryId;
    }
    public void setVendorParentCategoryId(String vendorParentCategoryId) {
        this.vendorParentCategoryId = vendorParentCategoryId;
    }
    public Long getCateSort() {
        return cateSort;
    }
    public void setCateSort(Long cateSort) {
        this.cateSort = cateSort;
    }




    @Override
    public String toString() {
        return "PDcCategory{" + "categoryId=" + categoryId + "," + "categoryName=" + categoryName + "," + "sort=" + sort + "," + "channel=" + channel + "," + "level=" + level + "," + "status=" + status + "," + "publishType=" + publishType + "," + "chainCategoryId=" + chainCategoryId + "," + "vendorChainId=" + vendorChainId + "," + "vendorParentCategoryId=" + vendorParentCategoryId + "," + "cateSort=" + cateSort + "}";
    }
}
