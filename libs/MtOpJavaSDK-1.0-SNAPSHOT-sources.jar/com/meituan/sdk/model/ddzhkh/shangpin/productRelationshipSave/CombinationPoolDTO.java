package com.meituan.sdk.model.ddzhkh.shangpin.productRelationshipSave;

import java.util.List;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-672e05e6-f915-4a06-8f7f-9170f385d67d">子品/搭售品集合</p><p data-diff-id="ct-diff-id-decc9948-f48d-4f62-8819-81d0f02290b3"><br></p>
* This file was automatically generated.
*/
public class CombinationPoolDTO {
    /**
    * <p data-diff-id="ct-diff-id-90a74c76-c1ff-4dcd-9017-10f34fcd704d">几选几</p><p data-diff-id="ct-diff-id-e5baaa31-d416-4309-9420-40ac47929f98"><br></p>
    */
    @SerializedName("optionalCount")
    private Integer optionalCount;
    /**
    * <p data-diff-id="ct-diff-id-9ed8dce1-0063-4f28-89a4-34fa02286e93">组合池-子品集合</p><p data-diff-id="ct-diff-id-b7319d76-921c-4c32-b64d-21fdee970086"><br></p>
    */
    @NotEmpty(message = "combinationUnits不能为空")
    @SerializedName("combinationUnits")
    private List<CombinationUnitDTO> combinationUnits;

    public Integer getOptionalCount() {
        return optionalCount;
    }
    public void setOptionalCount(Integer optionalCount) {
        this.optionalCount = optionalCount;
    }
    public List<CombinationUnitDTO> getCombinationUnits() {
        return combinationUnits;
    }
    public void setCombinationUnits(List<CombinationUnitDTO> combinationUnits) {
        this.combinationUnits = combinationUnits;
    }




    @Override
    public String toString() {
        return "CombinationPoolDTO{" + "optionalCount=" + optionalCount + "," + "combinationUnits=" + combinationUnits + "}";
    }
}
