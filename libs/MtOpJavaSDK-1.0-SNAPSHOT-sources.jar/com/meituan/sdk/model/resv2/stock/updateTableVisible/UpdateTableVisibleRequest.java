package com.meituan.sdk.model.resv2.stock.updateTableVisible;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 清台/锁台
* This file was automatically generated.
*/
@ApiMeta(
    path = "/resv2/stock/supply/updateTableVisible",
    businessId = 7,
    apiVersion = "10004",
    apiName = "update_table_visible",
    needAuth = true
)
public class UpdateTableVisibleRequest implements MeituanRequest<Boolean> {
    @NotNull(message = "vendorSpuDTO不能为空")
    @SerializedName("vendorSpuDTO")
    private VendorSpuDTO vendorSpuDTO;
    @SerializedName("uuid")
    private String uuid;

    public VendorSpuDTO getVendorSpuDTO() {
        return vendorSpuDTO;
    }
    public void setVendorSpuDTO(VendorSpuDTO vendorSpuDTO) {
        this.vendorSpuDTO = vendorSpuDTO;
    }
    public String getUuid() {
        return uuid;
    }
    public void setUuid(String uuid) {
        this.uuid = uuid;
    }


    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "UpdateTableVisibleRequest{" + "vendorSpuDTO=" + vendorSpuDTO + "," + "uuid=" + uuid + "}";
    }
}
