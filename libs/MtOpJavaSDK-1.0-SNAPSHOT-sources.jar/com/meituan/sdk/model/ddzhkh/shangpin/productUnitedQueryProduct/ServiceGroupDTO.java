package com.meituan.sdk.model.ddzhkh.shangpin.productUnitedQueryProduct;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 服务项目组列表
* This file was automatically generated.
*/
public class ServiceGroupDTO {
    /**
    * 服务项目组名称
    */
    @SerializedName("groupName")
    private String groupName;
    /**
    * 服务项目子项列表
    */
    @SerializedName("serviceItems")
    private List<ServiceItemDTO> serviceItems;
    /**
    * 可选数量
    */
    @SerializedName("optionalCount")
    private Integer optionalCount;
    /**
    * 是否可重复选择
    */
    @SerializedName("optionalRepeatable")
    private Boolean optionalRepeatable;

    public String getGroupName() {
        return groupName;
    }
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
    public List<ServiceItemDTO> getServiceItems() {
        return serviceItems;
    }
    public void setServiceItems(List<ServiceItemDTO> serviceItems) {
        this.serviceItems = serviceItems;
    }
    public Integer getOptionalCount() {
        return optionalCount;
    }
    public void setOptionalCount(Integer optionalCount) {
        this.optionalCount = optionalCount;
    }
    public Boolean getOptionalRepeatable() {
        return optionalRepeatable;
    }
    public void setOptionalRepeatable(Boolean optionalRepeatable) {
        this.optionalRepeatable = optionalRepeatable;
    }




    @Override
    public String toString() {
        return "ServiceGroupDTO{" + "groupName=" + groupName + "," + "serviceItems=" + serviceItems + "," + "optionalCount=" + optionalCount + "," + "optionalRepeatable=" + optionalRepeatable + "}";
    }
}
