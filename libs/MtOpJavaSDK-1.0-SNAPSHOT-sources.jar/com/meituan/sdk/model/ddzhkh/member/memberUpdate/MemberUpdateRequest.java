package com.meituan.sdk.model.ddzhkh.member.memberUpdate;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 会员信息更新接口
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/member/update",
    businessId = 59,
    apiVersion = "10016",
    apiName = "member_update",
    needAuth = true
)
public class MemberUpdateRequest implements MeituanRequest<MemberUpdateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-2969d750-ba94-4bc8-9213-329e3ac4dae1">会员卡号</p>
    */
    @NotBlank(message = "memberCard不能为空")
    @SerializedName("memberCard")
    private String memberCard;
    /**
    * <p data-diff-id="ct-diff-id-d67cf934-f699-42cd-ad55-c4ce5c502abe"><span style="color: rgb(31, 45, 61)">互通的会员等级，三方与美团指定合作等级</span><br><span style="color: rgb(31, 45, 61)">传参时传对应等级1、2、3、4、5...</span><br><span style="color: rgb(255, 0, 0)">注意：最低等级是1</span><br><span style="color: rgb(31, 45, 61)">传参示例：</span><br><span style="color: rgb(31, 45, 61)">等级：普卡（传参：1）</span><br><span style="color: rgb(31, 45, 61)">等级：银卡（传参：2）</span><br><span style="color: rgb(31, 45, 61)">等级：金卡（传参：3）</span></p>
    */
    @SerializedName("level")
    private Integer level;
    /**
    * <p data-diff-id="ct-diff-id-9f9e852a-85cf-4103-a0b3-1f8465c4587c">会员名称</p>
    */
    @SerializedName("name")
    private String name;
    /**
    * <p data-diff-id="ct-diff-id-0d5d2c31-149d-44ba-a315-8e219a6c7a87"><span style="color: rgb(31, 45, 61)">需要进行更新的字段</span><br><span style="color: rgb(31, 45, 61)">当前可更新字段["level","newMember"]</span></p>
    */
    @SerializedName("updateFieldSet")
    private List<String> updateFieldSet;
    /**
    * <p data-diff-id="ct-diff-id-cba41578-4b87-473a-9bf6-47f8e4f5aa45"><span style="color: rgb(31, 45, 61)">会员成长值</span></p>
    */
    @SerializedName("growthValue")
    private String growthValue;
    /**
    * <p data-diff-id="ct-diff-id-eb4b3e00-7f5f-4f18-ad4d-fbb59cf45158">积分</p>
    */
    @SerializedName("points")
    private String points;
    /**
    * <p data-diff-id="ct-diff-id-3b7ae8c0-e81a-44f9-be99-86025532d9fc">账号余额</p>
    */
    @SerializedName("accountBalance")
    private String accountBalance;
    /**
    * <p data-diff-id="ct-diff-id-78ba1bf0-d29a-408b-ad58-7de1696d8e33">业务线来源</p><p style="text-align: start;" data-diff-id="ct-diff-id-bc4bf414-93d7-4f04-a4e9-c2ea12d6d07c">未知：-1<br>商场会员：9<br>休闲娱乐-亲子：10<br>足洗KTV：13</p><p style="text-align: start;" data-diff-id="ct-diff-id-b1481301-a19e-407a-9028-a06ad7f0f433"><span style="color: rgb(0, 0, 0)">到综其他行业：14</span></p>
    */
    @NotNull(message = "bizCode不能为空")
    @SerializedName("bizCode")
    private Integer bizCode;
    /**
    * <p data-diff-id="ct-diff-id-602d1220-7f20-42ea-9dde-e5ebbbdd7472"><br>是否为新会员（true表示是，false表示否）</p><p data-diff-id="ct-diff-id-b8317f9f-b401-44e7-b7ca-12d5252fca17"><br></p>
    */
    @SerializedName("newMember")
    private Boolean newMember;

    public String getMemberCard() {
        return memberCard;
    }
    public void setMemberCard(String memberCard) {
        this.memberCard = memberCard;
    }
    public Integer getLevel() {
        return level;
    }
    public void setLevel(Integer level) {
        this.level = level;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public List<String> getUpdateFieldSet() {
        return updateFieldSet;
    }
    public void setUpdateFieldSet(List<String> updateFieldSet) {
        this.updateFieldSet = updateFieldSet;
    }
    public String getGrowthValue() {
        return growthValue;
    }
    public void setGrowthValue(String growthValue) {
        this.growthValue = growthValue;
    }
    public String getPoints() {
        return points;
    }
    public void setPoints(String points) {
        this.points = points;
    }
    public String getAccountBalance() {
        return accountBalance;
    }
    public void setAccountBalance(String accountBalance) {
        this.accountBalance = accountBalance;
    }
    public Integer getBizCode() {
        return bizCode;
    }
    public void setBizCode(Integer bizCode) {
        this.bizCode = bizCode;
    }
    public Boolean getNewMember() {
        return newMember;
    }
    public void setNewMember(Boolean newMember) {
        this.newMember = newMember;
    }


    @Override
    public MeituanResponse<MemberUpdateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<MemberUpdateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "MemberUpdateRequest{" + "memberCard=" + memberCard + "," + "level=" + level + "," + "name=" + name + "," + "updateFieldSet=" + updateFieldSet + "," + "growthValue=" + growthValue + "," + "points=" + points + "," + "accountBalance=" + accountBalance + "," + "bizCode=" + bizCode + "," + "newMember=" + newMember + "}";
    }
}
