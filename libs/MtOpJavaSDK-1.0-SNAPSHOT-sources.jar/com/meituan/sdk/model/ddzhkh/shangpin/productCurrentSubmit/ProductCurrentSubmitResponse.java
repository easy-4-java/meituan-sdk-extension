package com.meituan.sdk.model.ddzhkh.shangpin.productCurrentSubmit;

import com.google.gson.annotations.SerializedName;

/**
* 提交商品
* This file was automatically generated.
*/
public class ProductCurrentSubmitResponse {
    /**
    * 商品ID
    */
    @SerializedName("productId")
    private Long productId;

    public Long getProductId() {
        return productId;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }




    @Override
    public String toString() {
        return "ProductCurrentSubmitResponse{" + "productId=" + productId + "}";
    }
}
