package com.meituan.sdk.model.ddzh.common.transferOpenShopUuidToOpPoiId;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* open_shop_uuid转换为op_poi_id
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/common/transfer/openShopUuidToOpPoiId",
    businessId = 58,
    apiVersion = "10000",
    apiName = "transfer_open_shop_uuid_to_op_poi_id",
    needAuth = false
)
public class TransferOpenShopUuidToOpPoiIdRequest implements MeituanRequest<List<ShopToOpenShopMappingDTO>> {
    /**
    * <p data-diff-id="ct-diff-id-7027aa76-6a51-4dec-9411-94bdd8b38da6">原北极星的AppKey</p>
    */
    @NotBlank(message = "appKey不能为空")
    @SerializedName("appKey")
    private String appKey;
    /**
    * <p data-diff-id="ct-diff-id-d6962398-96df-428c-97bd-6c003f6de424">原北极星门店id，支持批量</p>
    */
    @NotEmpty(message = "openShopUuids不能为空")
    @SerializedName("openShopUuids")
    private List<String> openShopUuids;

    public String getAppKey() {
        return appKey;
    }
    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }
    public List<String> getOpenShopUuids() {
        return openShopUuids;
    }
    public void setOpenShopUuids(List<String> openShopUuids) {
        this.openShopUuids = openShopUuids;
    }


    @Override
    public MeituanResponse<List<ShopToOpenShopMappingDTO>> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<List<ShopToOpenShopMappingDTO>>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TransferOpenShopUuidToOpPoiIdRequest{" + "appKey=" + appKey + "," + "openShopUuids=" + openShopUuids + "}";
    }
}
