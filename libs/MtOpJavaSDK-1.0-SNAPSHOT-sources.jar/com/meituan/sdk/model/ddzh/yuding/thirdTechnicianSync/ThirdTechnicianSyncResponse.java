package com.meituan.sdk.model.ddzh.yuding.thirdTechnicianSync;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 三方手艺人信息同步
* This file was automatically generated.
*/
public class ThirdTechnicianSyncResponse {
    /**
    * 成功数量
    */
    @SerializedName("successCount")
    private Integer successCount;
    /**
    * 失败数量
    */
    @SerializedName("failCount")
    private Integer failCount;
    /**
    * 错误信息列表
    */
    @SerializedName("failList")
    private List<RFailItem> failList;

    public Integer getSuccessCount() {
        return successCount;
    }
    public void setSuccessCount(Integer successCount) {
        this.successCount = successCount;
    }
    public Integer getFailCount() {
        return failCount;
    }
    public void setFailCount(Integer failCount) {
        this.failCount = failCount;
    }
    public List<RFailItem> getFailList() {
        return failList;
    }
    public void setFailList(List<RFailItem> failList) {
        this.failList = failList;
    }




    @Override
    public String toString() {
        return "ThirdTechnicianSyncResponse{" + "successCount=" + successCount + "," + "failCount=" + failCount + "," + "failList=" + failList + "}";
    }
}
