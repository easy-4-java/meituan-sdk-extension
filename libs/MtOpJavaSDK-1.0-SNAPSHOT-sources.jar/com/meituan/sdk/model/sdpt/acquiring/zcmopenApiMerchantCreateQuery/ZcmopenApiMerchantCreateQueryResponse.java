package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiMerchantCreateQuery;

import com.google.gson.annotations.SerializedName;

/**
* [入件]查询商户入件结果
* This file was automatically generated.
*/
public class ZcmopenApiMerchantCreateQueryResponse {
    @SerializedName("status")
    private String status;
    @SerializedName("errCode")
    private String errCode;
    @SerializedName("errMsg")
    private String errMsg;
    /**
    * 子错误码（status 为失败的时候有）
    */
    @SerializedName("subCode")
    private String subCode;
    /**
    * 子错误码的描述（status 为失败的时候有）
    */
    @SerializedName("subMsg")
    private String subMsg;
    /**
    * 商户入件状态：WAIT: 入件中ALREADY: 已经入件REJECT: 入件失败
    */
    @SerializedName("merchantStatus")
    private String merchantStatus;
    /**
    * 如果查不到商户，则该字段返回空
    */
    @SerializedName("merchantId")
    private Integer merchantId;
    /**
    * 资质审核状态   1：待提审  8：待总部审核   32：总部审核通过   64：总部审核驳回  128： 等待签署中  256：合同/授权书驳回
    */
    @SerializedName("auditStatus")
    private Integer auditStatus;
    /**
    * 驳回原因  会展示 机审+人审 驳回原因
    */
    @SerializedName("rejectReason")
    private String rejectReason;

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getErrCode() {
        return errCode;
    }
    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }
    public String getErrMsg() {
        return errMsg;
    }
    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
    public String getSubCode() {
        return subCode;
    }
    public void setSubCode(String subCode) {
        this.subCode = subCode;
    }
    public String getSubMsg() {
        return subMsg;
    }
    public void setSubMsg(String subMsg) {
        this.subMsg = subMsg;
    }
    public String getMerchantStatus() {
        return merchantStatus;
    }
    public void setMerchantStatus(String merchantStatus) {
        this.merchantStatus = merchantStatus;
    }
    public Integer getMerchantId() {
        return merchantId;
    }
    public void setMerchantId(Integer merchantId) {
        this.merchantId = merchantId;
    }
    public Integer getAuditStatus() {
        return auditStatus;
    }
    public void setAuditStatus(Integer auditStatus) {
        this.auditStatus = auditStatus;
    }
    public String getRejectReason() {
        return rejectReason;
    }
    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }




    @Override
    public String toString() {
        return "ZcmopenApiMerchantCreateQueryResponse{" + "status=" + status + "," + "errCode=" + errCode + "," + "errMsg=" + errMsg + "," + "subCode=" + subCode + "," + "subMsg=" + subMsg + "," + "merchantStatus=" + merchantStatus + "," + "merchantId=" + merchantId + "," + "auditStatus=" + auditStatus + "," + "rejectReason=" + rejectReason + "}";
    }
}
