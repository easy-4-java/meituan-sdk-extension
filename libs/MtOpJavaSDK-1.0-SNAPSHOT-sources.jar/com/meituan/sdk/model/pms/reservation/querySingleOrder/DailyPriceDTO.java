package com.meituan.sdk.model.pms.reservation.querySingleOrder;

import com.google.gson.annotations.SerializedName;

/**
* 首日房价
* This file was automatically generated.
*/
public class DailyPriceDTO {
    /**
    * 每日占房ID
    */
    @SerializedName("occupationDailyId")
    private Long occupationDailyId;
    /**
    * 日期
    */
    @SerializedName("date")
    private String date;
    /**
    * 原价：门市价
    */
    @SerializedName("originPrice")
    private String originPrice;
    /**
    * 实际价格：优惠价
    */
    @SerializedName("actualPrice")
    private String actualPrice;
    /**
    * 每日占房是否删除
    */
    @SerializedName("deleted")
    private Boolean deleted;

    public Long getOccupationDailyId() {
        return occupationDailyId;
    }
    public void setOccupationDailyId(Long occupationDailyId) {
        this.occupationDailyId = occupationDailyId;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getOriginPrice() {
        return originPrice;
    }
    public void setOriginPrice(String originPrice) {
        this.originPrice = originPrice;
    }
    public String getActualPrice() {
        return actualPrice;
    }
    public void setActualPrice(String actualPrice) {
        this.actualPrice = actualPrice;
    }
    public Boolean getDeleted() {
        return deleted;
    }
    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }




    @Override
    public String toString() {
        return "DailyPriceDTO{" + "occupationDailyId=" + occupationDailyId + "," + "date=" + date + "," + "originPrice=" + originPrice + "," + "actualPrice=" + actualPrice + "," + "deleted=" + deleted + "}";
    }
}
