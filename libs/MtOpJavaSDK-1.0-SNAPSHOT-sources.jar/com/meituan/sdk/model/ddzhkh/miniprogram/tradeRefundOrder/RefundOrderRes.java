package com.meituan.sdk.model.ddzhkh.miniprogram.tradeRefundOrder;

import com.google.gson.annotations.SerializedName;

/**
* 申请退款响应数据
* This file was automatically generated.
*/
public class RefundOrderRes {
    /**
    * 美团订单id
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * 三方商户订单号
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * 美团支付id
    */
    @SerializedName("refundId")
    private String refundId;
    /**
    * 三方商户支付Id
    */
    @SerializedName("vendorRefundId")
    private String vendorRefundId;
    /**
    * 退给用户实付金额，单位：分
    */
    @SerializedName("totalRefundAmount")
    private Long totalRefundAmount;
    /**
    * 退款申请时间，时间戳，精度毫秒
    */
    @SerializedName("createTime")
    private Long createTime;
    /**
    * 外部传入的自定义数据
    */
    @SerializedName("refundExt")
    private String refundExt;
    @SerializedName("tradeInActivityResult")
    private TradeInActivityResult tradeInActivityResult;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public String getRefundId() {
        return refundId;
    }
    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }
    public String getVendorRefundId() {
        return vendorRefundId;
    }
    public void setVendorRefundId(String vendorRefundId) {
        this.vendorRefundId = vendorRefundId;
    }
    public Long getTotalRefundAmount() {
        return totalRefundAmount;
    }
    public void setTotalRefundAmount(Long totalRefundAmount) {
        this.totalRefundAmount = totalRefundAmount;
    }
    public Long getCreateTime() {
        return createTime;
    }
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
    public String getRefundExt() {
        return refundExt;
    }
    public void setRefundExt(String refundExt) {
        this.refundExt = refundExt;
    }
    public TradeInActivityResult getTradeInActivityResult() {
        return tradeInActivityResult;
    }
    public void setTradeInActivityResult(TradeInActivityResult tradeInActivityResult) {
        this.tradeInActivityResult = tradeInActivityResult;
    }




    @Override
    public String toString() {
        return "RefundOrderRes{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "," + "refundId=" + refundId + "," + "vendorRefundId=" + vendorRefundId + "," + "totalRefundAmount=" + totalRefundAmount + "," + "createTime=" + createTime + "," + "refundExt=" + refundExt + "," + "tradeInActivityResult=" + tradeInActivityResult + "}";
    }
}
