package com.meituan.sdk.model.pms.accounting.searchGuaranteeItems;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 查询预授权
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/accounting/searchGuaranteeItems",
    businessId = 57,
    apiVersion = "10021",
    apiName = "search_guarantee_items",
    needAuth = true
)
public class SearchGuaranteeItemsRequest implements MeituanRequest<SearchGuaranteeItemsResponse> {
    /**
    * <p data-diff-id="ct-diff-id-77ef5d4c-67f4-458c-af3a-0f0ad2d9c5c0">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-2e5e93a8-7268-4c79-a80e-d1ebe5fec523">账套ID</p>
    */
    @NotEmpty(message = "billIds不能为空")
    @SerializedName("billIds")
    private List<Long> billIds;
    /**
    * <p data-diff-id="ct-diff-id-c3c3877d-572f-4e9a-b2eb-9ab6e43ae80e">页码</p>
    */
    @SerializedName("pageIndex")
    private Long pageIndex;
    /**
    * <p data-diff-id="ct-diff-id-35a29daa-4283-41a3-a00f-cafd3827f473">分页大小</p>
    */
    @SerializedName("pageSize")
    private Long pageSize;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public List<Long> getBillIds() {
        return billIds;
    }
    public void setBillIds(List<Long> billIds) {
        this.billIds = billIds;
    }
    public Long getPageIndex() {
        return pageIndex;
    }
    public void setPageIndex(Long pageIndex) {
        this.pageIndex = pageIndex;
    }
    public Long getPageSize() {
        return pageSize;
    }
    public void setPageSize(Long pageSize) {
        this.pageSize = pageSize;
    }


    @Override
    public MeituanResponse<SearchGuaranteeItemsResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<SearchGuaranteeItemsResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "SearchGuaranteeItemsRequest{" + "hotelId=" + hotelId + "," + "billIds=" + billIds + "," + "pageIndex=" + pageIndex + "," + "pageSize=" + pageSize + "}";
    }
}
