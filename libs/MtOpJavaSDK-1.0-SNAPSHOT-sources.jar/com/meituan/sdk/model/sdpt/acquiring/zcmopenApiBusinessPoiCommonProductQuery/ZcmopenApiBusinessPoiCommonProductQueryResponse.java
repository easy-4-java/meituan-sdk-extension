package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiBusinessPoiCommonProductQuery;

import com.google.gson.annotations.SerializedName;

/**
* [产品]产品开通状态查询
* This file was automatically generated.
*/
public class ZcmopenApiBusinessPoiCommonProductQueryResponse {
    @SerializedName("status")
    private String status;
    @SerializedName("errCode")
    private String errCode;
    @SerializedName("errMsg")
    private String errMsg;
    @SerializedName("subCode")
    private String subCode;
    @SerializedName("subMsg")
    private String subMsg;
    /**
    * AUDITING          开通中（未审核）  AUDIT_FAIL       开通失败（审核驳回）  AUDIT_PASS      开通成功（审核通过）  ONLINE              上线成功  注意：  （1）ONLINE   这个状态，代表产品可以使用了。  （2）申请开通产品后，一般两个小时就能得到终态AUDIT_FAIL 和  ONLINE，否则视为有问题。
    */
    @SerializedName("productStatus")
    private String productStatus;

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getErrCode() {
        return errCode;
    }
    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }
    public String getErrMsg() {
        return errMsg;
    }
    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
    public String getSubCode() {
        return subCode;
    }
    public void setSubCode(String subCode) {
        this.subCode = subCode;
    }
    public String getSubMsg() {
        return subMsg;
    }
    public void setSubMsg(String subMsg) {
        this.subMsg = subMsg;
    }
    public String getProductStatus() {
        return productStatus;
    }
    public void setProductStatus(String productStatus) {
        this.productStatus = productStatus;
    }




    @Override
    public String toString() {
        return "ZcmopenApiBusinessPoiCommonProductQueryResponse{" + "status=" + status + "," + "errCode=" + errCode + "," + "errMsg=" + errMsg + "," + "subCode=" + subCode + "," + "subMsg=" + subMsg + "," + "productStatus=" + productStatus + "}";
    }
}
