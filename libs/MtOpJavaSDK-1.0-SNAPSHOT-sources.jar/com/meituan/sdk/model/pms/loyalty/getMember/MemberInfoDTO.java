package com.meituan.sdk.model.pms.loyalty.getMember;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class MemberInfoDTO {
    /**
    * 会员ID
    */
    @SerializedName("memberId")
    private String memberId;
    /**
    * 会员姓名
    */
    @SerializedName("name")
    private String name;
    /**
    * 性别
    */
    @SerializedName("gender")
    private EnumDTO gender;
    /**
    * 手机号
    */
    @SerializedName("mobile")
    private String mobile;
    /**
    * 手机号加密字段
    */
    @SerializedName("mobileEncryption")
    private String mobileEncryption;
    /**
    * 证件类型
    */
    @SerializedName("personalCredentialType")
    private EnumDTO personalCredentialType;
    /**
    * 证件号码
    */
    @SerializedName("idCardNumber")
    private String idCardNumber;
    /**
    * 证件号加密字段
    */
    @SerializedName("idCardNumberEncryption")
    private String idCardNumberEncryption;
    /**
    * 会员卡号ID
    */
    @SerializedName("memberCardId")
    private String memberCardId;
    /**
    * 会员状态
    */
    @SerializedName("memberStatus")
    private EnumDTO memberStatus;
    /**
    * 会员级别
    */
    @SerializedName("memberLevel")
    private EnumDTO memberLevel;
    /**
    * 储值余额
    */
    @SerializedName("value")
    private String value;
    /**
    * 积分余额
    */
    @SerializedName("point")
    private String point;
    /**
    * 注册来源门店ID
    */
    @SerializedName("sourceHotelId")
    private Long sourceHotelId;
    /**
    * 会员卡号
    */
    @SerializedName("extCardNo")
    private String extCardNo;
    /**
    * 邮箱
    */
    @SerializedName("email")
    private String email;
    /**
    * 地址
    */
    @SerializedName("address")
    private String address;
    /**
    * 生日，格式yyyy-MM-dd
    */
    @SerializedName("birthday")
    private String birthday;

    public String getMemberId() {
        return memberId;
    }
    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public EnumDTO getGender() {
        return gender;
    }
    public void setGender(EnumDTO gender) {
        this.gender = gender;
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    public String getMobileEncryption() {
        return mobileEncryption;
    }
    public void setMobileEncryption(String mobileEncryption) {
        this.mobileEncryption = mobileEncryption;
    }
    public EnumDTO getPersonalCredentialType() {
        return personalCredentialType;
    }
    public void setPersonalCredentialType(EnumDTO personalCredentialType) {
        this.personalCredentialType = personalCredentialType;
    }
    public String getIdCardNumber() {
        return idCardNumber;
    }
    public void setIdCardNumber(String idCardNumber) {
        this.idCardNumber = idCardNumber;
    }
    public String getIdCardNumberEncryption() {
        return idCardNumberEncryption;
    }
    public void setIdCardNumberEncryption(String idCardNumberEncryption) {
        this.idCardNumberEncryption = idCardNumberEncryption;
    }
    public String getMemberCardId() {
        return memberCardId;
    }
    public void setMemberCardId(String memberCardId) {
        this.memberCardId = memberCardId;
    }
    public EnumDTO getMemberStatus() {
        return memberStatus;
    }
    public void setMemberStatus(EnumDTO memberStatus) {
        this.memberStatus = memberStatus;
    }
    public EnumDTO getMemberLevel() {
        return memberLevel;
    }
    public void setMemberLevel(EnumDTO memberLevel) {
        this.memberLevel = memberLevel;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public String getPoint() {
        return point;
    }
    public void setPoint(String point) {
        this.point = point;
    }
    public Long getSourceHotelId() {
        return sourceHotelId;
    }
    public void setSourceHotelId(Long sourceHotelId) {
        this.sourceHotelId = sourceHotelId;
    }
    public String getExtCardNo() {
        return extCardNo;
    }
    public void setExtCardNo(String extCardNo) {
        this.extCardNo = extCardNo;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getBirthday() {
        return birthday;
    }
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }




    @Override
    public String toString() {
        return "MemberInfoDTO{" + "memberId=" + memberId + "," + "name=" + name + "," + "gender=" + gender + "," + "mobile=" + mobile + "," + "mobileEncryption=" + mobileEncryption + "," + "personalCredentialType=" + personalCredentialType + "," + "idCardNumber=" + idCardNumber + "," + "idCardNumberEncryption=" + idCardNumberEncryption + "," + "memberCardId=" + memberCardId + "," + "memberStatus=" + memberStatus + "," + "memberLevel=" + memberLevel + "," + "value=" + value + "," + "point=" + point + "," + "sourceHotelId=" + sourceHotelId + "," + "extCardNo=" + extCardNo + "," + "email=" + email + "," + "address=" + address + "," + "birthday=" + birthday + "}";
    }
}
