package com.meituan.sdk.model.ddzh.common.grayQueryHitSessionGrayPoi;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 查询命中session灰度的门店
* This file was automatically generated.
*/
public class GrayQueryHitSessionGrayPoiResponse {
    /**
    * 总数
    */
    @SerializedName("total")
    private Integer total;
    /**
    * 命中灰度的门店列表
    */
    @SerializedName("hitSessionGrayPoiTOS")
    private List<HitSessionGrayPoiTO> hitSessionGrayPoiTOS;

    public Integer getTotal() {
        return total;
    }
    public void setTotal(Integer total) {
        this.total = total;
    }
    public List<HitSessionGrayPoiTO> getHitSessionGrayPoiTOS() {
        return hitSessionGrayPoiTOS;
    }
    public void setHitSessionGrayPoiTOS(List<HitSessionGrayPoiTO> hitSessionGrayPoiTOS) {
        this.hitSessionGrayPoiTOS = hitSessionGrayPoiTOS;
    }




    @Override
    public String toString() {
        return "GrayQueryHitSessionGrayPoiResponse{" + "total=" + total + "," + "hitSessionGrayPoiTOS=" + hitSessionGrayPoiTOS + "}";
    }
}
