package com.meituan.sdk.model.ddzh.chargefulfill.reserveOrderFeeSync;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 充电占位费订单同步
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/chargefulfill/reservefee/sync",
    businessId = 58,
    apiVersion = "10000",
    apiName = "reserve_order_fee_sync",
    needAuth = true
)
public class ReserveOrderFeeSyncRequest implements MeituanRequest<ReserveOrderFeeSyncResponse> {
    /**
    * <p data-diff-id="ct-diff-id-54ab4fdf-26f4-4f78-896b-07cd651e61d9">三方占位费订单ID</p>
    */
    @NotBlank(message = "thirdReserveOrderSeq不能为空")
    @SerializedName("thirdReserveOrderSeq")
    private String thirdReserveOrderSeq;
    /**
    * <p data-diff-id="ct-diff-id-69b3c450-d97b-42b6-9243-557c2fc896b0">美团充电订单号</p>
    */
    @NotBlank(message = "startChargeSeq不能为空")
    @SerializedName("startChargeSeq")
    private String startChargeSeq;
    /**
    * <p data-diff-id="ct-diff-id-b5557536-eb11-466c-ade3-7eef393c39a9">占位开始时间戳，毫秒</p>
    */
    @NotNull(message = "startTime不能为空")
    @SerializedName("startTime")
    private Long startTime;
    /**
    * <p data-diff-id="ct-diff-id-3bb7f742-ca9d-4bca-a9e6-d198f859103b">占位结束时间戳，毫秒</p>
    */
    @NotNull(message = "endTime不能为空")
    @SerializedName("endTime")
    private Long endTime;
    /**
    * <p data-diff-id="ct-diff-id-bef6cf71-4ec6-42f8-9be8-cfc25812ce57">实际占位费用，单位元，小数点2位</p>
    */
    @NotNull(message = "reserveFee不能为空")
    @SerializedName("reserveFee")
    private Double reserveFee;
    /**
    * <p data-diff-id="ct-diff-id-b154920a-4dd2-4da3-a6be-a07b9d3c135c">充电枪接口编码</p>
    */
    @SerializedName("connectorId")
    private String connectorId;
    /**
    * <p data-diff-id="ct-diff-id-2811ff97-bb96-44f5-bf05-26b3d5d105f3">占位订单类型，<span style="color: rgb(0, 0, 0)">0-降地锁创建，1-插枪创建</span></p>
    */
    @SerializedName("reserveType")
    private Integer reserveType;
    /**
    * <p data-diff-id="ct-diff-id-3c480154-1c2f-48d9-bfc3-cbfa283fae2c">基础减免时长，单位s</p>
    */
    @SerializedName("baseReductionTime")
    private Integer baseReductionTime;
    /**
    * <p data-diff-id="ct-diff-id-6676e66b-23d3-4a43-bbc8-5d2123c8b173">充电减免时长，单位s</p>
    */
    @SerializedName("chargeReductionTime")
    private Integer chargeReductionTime;
    /**
    * <p data-diff-id="ct-diff-id-215e2024-c699-49aa-983e-7f8793e9902e">额外减免时长，单位秒</p>
    */
    @SerializedName("extraReductionTime")
    private Integer extraReductionTime;
    /**
    * <p data-diff-id="ct-diff-id-4fd1e0bc-d5c9-4c44-915b-e28437bf6a10">占位时长，单位s</p>
    */
    @SerializedName("reserveTime")
    private Integer reserveTime;
    /**
    * <p data-diff-id="ct-diff-id-fd61e6a9-d980-4f3e-be66-4ef434b64ea1"><span style="color: rgb(0, 0, 0)">占位订单状态，5-已关闭，10-正常结束</span></p>
    */
    @SerializedName("reserveStatus")
    private Integer reserveStatus;
    /**
    * <p data-diff-id="ct-diff-id-4c2bde74-e71d-4dd2-b8fe-de4b08563a8d">占位费上限，单位元小数点2位</p>
    */
    @SerializedName("reserveFeeUpperLimit")
    private Double reserveFeeUpperLimit;
    /**
    * <p data-diff-id="ct-diff-id-4613cc56-6791-4e70-b26d-916dbb9aa71f">占位费不同时段明细列表</p>
    */
    @SerializedName("reserveDetailInfoList")
    private List<DetailInfo> reserveDetailInfoList;

    public String getThirdReserveOrderSeq() {
        return thirdReserveOrderSeq;
    }
    public void setThirdReserveOrderSeq(String thirdReserveOrderSeq) {
        this.thirdReserveOrderSeq = thirdReserveOrderSeq;
    }
    public String getStartChargeSeq() {
        return startChargeSeq;
    }
    public void setStartChargeSeq(String startChargeSeq) {
        this.startChargeSeq = startChargeSeq;
    }
    public Long getStartTime() {
        return startTime;
    }
    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }
    public Long getEndTime() {
        return endTime;
    }
    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }
    public Double getReserveFee() {
        return reserveFee;
    }
    public void setReserveFee(Double reserveFee) {
        this.reserveFee = reserveFee;
    }
    public String getConnectorId() {
        return connectorId;
    }
    public void setConnectorId(String connectorId) {
        this.connectorId = connectorId;
    }
    public Integer getReserveType() {
        return reserveType;
    }
    public void setReserveType(Integer reserveType) {
        this.reserveType = reserveType;
    }
    public Integer getBaseReductionTime() {
        return baseReductionTime;
    }
    public void setBaseReductionTime(Integer baseReductionTime) {
        this.baseReductionTime = baseReductionTime;
    }
    public Integer getChargeReductionTime() {
        return chargeReductionTime;
    }
    public void setChargeReductionTime(Integer chargeReductionTime) {
        this.chargeReductionTime = chargeReductionTime;
    }
    public Integer getExtraReductionTime() {
        return extraReductionTime;
    }
    public void setExtraReductionTime(Integer extraReductionTime) {
        this.extraReductionTime = extraReductionTime;
    }
    public Integer getReserveTime() {
        return reserveTime;
    }
    public void setReserveTime(Integer reserveTime) {
        this.reserveTime = reserveTime;
    }
    public Integer getReserveStatus() {
        return reserveStatus;
    }
    public void setReserveStatus(Integer reserveStatus) {
        this.reserveStatus = reserveStatus;
    }
    public Double getReserveFeeUpperLimit() {
        return reserveFeeUpperLimit;
    }
    public void setReserveFeeUpperLimit(Double reserveFeeUpperLimit) {
        this.reserveFeeUpperLimit = reserveFeeUpperLimit;
    }
    public List<DetailInfo> getReserveDetailInfoList() {
        return reserveDetailInfoList;
    }
    public void setReserveDetailInfoList(List<DetailInfo> reserveDetailInfoList) {
        this.reserveDetailInfoList = reserveDetailInfoList;
    }


    @Override
    public MeituanResponse<ReserveOrderFeeSyncResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ReserveOrderFeeSyncResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ReserveOrderFeeSyncRequest{" + "thirdReserveOrderSeq=" + thirdReserveOrderSeq + "," + "startChargeSeq=" + startChargeSeq + "," + "startTime=" + startTime + "," + "endTime=" + endTime + "," + "reserveFee=" + reserveFee + "," + "connectorId=" + connectorId + "," + "reserveType=" + reserveType + "," + "baseReductionTime=" + baseReductionTime + "," + "chargeReductionTime=" + chargeReductionTime + "," + "extraReductionTime=" + extraReductionTime + "," + "reserveTime=" + reserveTime + "," + "reserveStatus=" + reserveStatus + "," + "reserveFeeUpperLimit=" + reserveFeeUpperLimit + "," + "reserveDetailInfoList=" + reserveDetailInfoList + "}";
    }
}
