package com.meituan.sdk.model.pms.hotel.commonGetalladministrativedivisions;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 获取所有行政区划
* This file was automatically generated.
*/
public class CommonGetalladministrativedivisionsResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    @SerializedName("data")
    private List<AdministrativeDivisionDTO> data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public List<AdministrativeDivisionDTO> getData() {
        return data;
    }
    public void setData(List<AdministrativeDivisionDTO> data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "CommonGetalladministrativedivisionsResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
