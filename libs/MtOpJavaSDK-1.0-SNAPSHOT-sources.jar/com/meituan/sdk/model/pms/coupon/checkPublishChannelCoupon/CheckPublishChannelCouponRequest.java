package com.meituan.sdk.model.pms.coupon.checkPublishChannelCoupon;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 检查发布渠道优惠券
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/coupon/checkForPublishChannelCoupon",
    businessId = 57,
    apiVersion = "10010",
    apiName = "check_publish_channel_coupon",
    needAuth = true
)
public class CheckPublishChannelCouponRequest implements MeituanRequest<CheckPublishChannelCouponResponse> {
    /**
    * <p data-diff-id="ct-diff-id-5f3212cf-0474-450e-acec-b863a01f2fc0">优惠券模版id</p>
    */
    @SerializedName("templateId")
    private Long templateId;
    /**
    * <p data-diff-id="ct-diff-id-245ebd5b-73cc-44a9-bf82-279631da9333">会员id</p>
    */
    @SerializedName("memberId")
    private Long memberId;
    /**
    * <p data-diff-id="ct-diff-id-4013cf5d-d0f3-41f2-99ec-bea0c6f5d67a">数量</p>
    */
    @SerializedName("count")
    private Integer count;

    public Long getTemplateId() {
        return templateId;
    }
    public void setTemplateId(Long templateId) {
        this.templateId = templateId;
    }
    public Long getMemberId() {
        return memberId;
    }
    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }
    public Integer getCount() {
        return count;
    }
    public void setCount(Integer count) {
        this.count = count;
    }


    @Override
    public MeituanResponse<CheckPublishChannelCouponResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<CheckPublishChannelCouponResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "CheckPublishChannelCouponRequest{" + "templateId=" + templateId + "," + "memberId=" + memberId + "," + "count=" + count + "}";
    }
}
