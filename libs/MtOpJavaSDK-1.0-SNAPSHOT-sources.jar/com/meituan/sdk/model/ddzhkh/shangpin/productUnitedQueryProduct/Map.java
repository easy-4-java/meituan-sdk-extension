package com.meituan.sdk.model.ddzhkh.shangpin.productUnitedQueryProduct;


/**
* 服务项目子项值
* This file was automatically generated.
*/
public class Map {





}
