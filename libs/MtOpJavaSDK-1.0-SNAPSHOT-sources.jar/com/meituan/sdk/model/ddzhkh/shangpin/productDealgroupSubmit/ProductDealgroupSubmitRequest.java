package com.meituan.sdk.model.ddzhkh.shangpin.productDealgroupSubmit;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 提交团单
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/shangpin/dealgroup/submit",
    businessId = 59,
    apiVersion = "10192",
    apiName = "product_dealgroup_submit",
    needAuth = true
)
public class ProductDealgroupSubmitRequest implements MeituanRequest<ProductDealgroupSubmitResponse> {
    /**
    * <p data-diff-id="ct-diff-id-4338a08c-25d2-4de7-865c-a996092cb61b"><span style="color: ">DealGroupDataDTO的json序列化后字符串形式</span></p>
    */
    @NotBlank(message = "data不能为空")
    @SerializedName("data")
    private String data;
    /**
    * <p data-diff-id="ct-diff-id-54aef63a-6d0a-46ca-a417-e033809a3781"><span style="color: ">来源，体检 : physical_examination</span></p>
    */
    @NotBlank(message = "source不能为空")
    @SerializedName("source")
    private String source;
    /**
    * <p data-diff-id="ct-diff-id-449b702e-5ec8-43b3-bd82-7faad1ca7be5">美团店铺id列表</p>
    */
    @NotEmpty(message = "opPoiIds不能为空")
    @SerializedName("opPoiIds")
    private List<String> opPoiIds;
    /**
    * <p data-diff-id="ct-diff-id-2d0ea7ac-8b4c-43b2-bb5f-8742db86083b">团单id（即将下线）</p>
    */
    @SerializedName("dealGroupId")
    private Long dealGroupId;
    /**
    * <p data-diff-id="ct-diff-id-a59f1164-51ca-4728-abee-ba242c1f6d1b">团单id（使用该字段）</p>
    */
    @SerializedName("longDealGroupId")
    private Long longDealGroupId;

    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }
    public String getSource() {
        return source;
    }
    public void setSource(String source) {
        this.source = source;
    }
    public List<String> getOpPoiIds() {
        return opPoiIds;
    }
    public void setOpPoiIds(List<String> opPoiIds) {
        this.opPoiIds = opPoiIds;
    }
    public Long getDealGroupId() {
        return dealGroupId;
    }
    public void setDealGroupId(Long dealGroupId) {
        this.dealGroupId = dealGroupId;
    }
    public Long getLongDealGroupId() {
        return longDealGroupId;
    }
    public void setLongDealGroupId(Long longDealGroupId) {
        this.longDealGroupId = longDealGroupId;
    }


    @Override
    public MeituanResponse<ProductDealgroupSubmitResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ProductDealgroupSubmitResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ProductDealgroupSubmitRequest{" + "data=" + data + "," + "source=" + source + "," + "opPoiIds=" + opPoiIds + "," + "dealGroupId=" + dealGroupId + "," + "longDealGroupId=" + longDealGroupId + "}";
    }
}
