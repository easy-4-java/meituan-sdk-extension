package com.meituan.sdk.model.tuangouNg.atomgoods.productSpuUpdate;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 新增/更新菜品数据
* This file was automatically generated.
*/
@ApiMeta(
    path = "/tuangou/ng/atomgoods/product/spu/update",
    businessId = 1,
    apiVersion = "10034",
    apiName = "product_spu_update",
    needAuth = true
)
public class ProductSpuUpdateRequest implements MeituanRequest<ProductSpuUpdateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-2abf0b95-2dd5-4c86-a9fb-a2b0266f9f07">附件信息/加价属性类型，1-总部, 2-门店</p>
    */
    @NotNull(message = "scope不能为空")
    @SerializedName("scope")
    private Integer scope;
    /**
    * <p data-diff-id="ct-diff-id-4824d4a1-9965-4ef2-87d5-afda517af6f3">总部code，当scope = 1时必填</p>
    */
    @SerializedName("vendorChainId")
    private String vendorChainId;
    /**
    * <p data-diff-id="ct-diff-id-d169fe64-f675-4e3d-839c-2555acb19109">门店code，当scope = 2时必填</p>
    */
    @SerializedName("vendorShopId")
    private String vendorShopId;
    /**
    * <p data-diff-id="ct-diff-id-d9c13801-9762-4349-a431-b1db61b04d13">菜品列表</p>
    */
    @NotEmpty(message = "dishSpuList不能为空")
    @SerializedName("dishSpuList")
    private List<PDcDishSpu> dishSpuList;

    public Integer getScope() {
        return scope;
    }
    public void setScope(Integer scope) {
        this.scope = scope;
    }
    public String getVendorChainId() {
        return vendorChainId;
    }
    public void setVendorChainId(String vendorChainId) {
        this.vendorChainId = vendorChainId;
    }
    public String getVendorShopId() {
        return vendorShopId;
    }
    public void setVendorShopId(String vendorShopId) {
        this.vendorShopId = vendorShopId;
    }
    public List<PDcDishSpu> getDishSpuList() {
        return dishSpuList;
    }
    public void setDishSpuList(List<PDcDishSpu> dishSpuList) {
        this.dishSpuList = dishSpuList;
    }


    @Override
    public MeituanResponse<ProductSpuUpdateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ProductSpuUpdateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ProductSpuUpdateRequest{" + "scope=" + scope + "," + "vendorChainId=" + vendorChainId + "," + "vendorShopId=" + vendorShopId + "," + "dishSpuList=" + dishSpuList + "}";
    }
}
