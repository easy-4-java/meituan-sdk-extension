package com.meituan.sdk.model.ddzhkh.shangpin.productSearchSupplyDiagnostics;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 商品优化推荐
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/shangpin/product/search/supply/diagnostics",
    businessId = 59,
    apiVersion = "10103",
    apiName = "product_search_supply_diagnostics",
    needAuth = true
)
public class ProductSearchSupplyDiagnosticsRequest implements MeituanRequest<ProductSearchSupplyDiagnosticsResponse> {
    /**
    * <p data-diff-id="ct-diff-id-6ad0503f-2f4a-4db9-a62c-5b250bb56e12">美团门店id集合</p>
    */
    @SerializedName("mtShopIds")
    private List<Long> mtShopIds;

    public List<Long> getMtShopIds() {
        return mtShopIds;
    }
    public void setMtShopIds(List<Long> mtShopIds) {
        this.mtShopIds = mtShopIds;
    }


    @Override
    public MeituanResponse<ProductSearchSupplyDiagnosticsResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ProductSearchSupplyDiagnosticsResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ProductSearchSupplyDiagnosticsRequest{" + "mtShopIds=" + mtShopIds + "}";
    }
}
