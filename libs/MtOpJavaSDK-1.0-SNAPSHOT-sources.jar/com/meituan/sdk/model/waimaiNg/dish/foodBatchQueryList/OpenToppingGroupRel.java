package com.meituan.sdk.model.waimaiNg.dish.foodBatchQueryList;

import com.google.gson.annotations.SerializedName;

/**
* 关联的小料
* This file was automatically generated.
*/
public class OpenToppingGroupRel {
    /**
    * 顺序
    */
    @SerializedName("sequence")
    private Integer sequence;
    /**
    * 小料信息
    */
    @SerializedName("topping")
    private OpenTopping topping;
    /**
    * 默认选购数量，1或0
    */
    @SerializedName("defaultQuantity")
    private Integer defaultQuantity;

    public Integer getSequence() {
        return sequence;
    }
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    public OpenTopping getTopping() {
        return topping;
    }
    public void setTopping(OpenTopping topping) {
        this.topping = topping;
    }
    public Integer getDefaultQuantity() {
        return defaultQuantity;
    }
    public void setDefaultQuantity(Integer defaultQuantity) {
        this.defaultQuantity = defaultQuantity;
    }




    @Override
    public String toString() {
        return "OpenToppingGroupRel{" + "sequence=" + sequence + "," + "topping=" + topping + "," + "defaultQuantity=" + defaultQuantity + "}";
    }
}
