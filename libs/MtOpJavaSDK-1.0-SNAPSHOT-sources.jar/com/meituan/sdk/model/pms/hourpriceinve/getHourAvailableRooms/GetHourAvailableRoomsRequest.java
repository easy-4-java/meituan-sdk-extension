package com.meituan.sdk.model.pms.hourpriceinve.getHourAvailableRooms;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取酒店可用房间（钟点房）
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/hourpriceinve/getHourAvailableRooms",
    businessId = 57,
    apiVersion = "10002",
    apiName = "get_hour_available_rooms",
    needAuth = true
)
public class GetHourAvailableRoomsRequest implements MeituanRequest<GetHourAvailableRoomsResponse> {
    /**
    * <p data-diff-id="ct-diff-id-e0be872d-c3c3-4219-843d-0ea9952b581e">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-064f5138-fc91-49af-9aab-55ae021db0cc"><span style="color: rgba(0, 0, 0, 0.65)">预抵时间，格式yyyy-MM-dd HH:mm:ss</span></p>
    */
    @NotBlank(message = "estimatedArriveTime不能为空")
    @SerializedName("estimatedArriveTime")
    private String estimatedArriveTime;
    /**
    * <p data-diff-id="ct-diff-id-0e529e86-3321-4977-a9f0-f82cd147a356">钟点房类型，详见CheckinType字典</p>
    */
    @NotBlank(message = "checkinType不能为空")
    @SerializedName("checkinType")
    private String checkinType;
    /**
    * <p data-diff-id="ct-diff-id-153486ee-e6a1-4ce5-af0b-587e193a295e">房型编号</p>
    */
    @SerializedName("roomTypeIds")
    private List<String> roomTypeIds;
    /**
    * <p data-diff-id="ct-diff-id-4bf07cab-7b0c-491c-b1ad-a0ae7ea50785">房态，房态编码详见RoomStatus字典</p>
    */
    @SerializedName("roomStatus")
    private List<String> roomStatus;
    /**
    * <p data-diff-id="ct-diff-id-0e0a5c1b-c526-40b2-8f34-166a11fbae8c">楼栋ID</p>
    */
    @SerializedName("hallIds")
    private List<Long> hallIds;
    /**
    * <p data-diff-id="ct-diff-id-fd8967e9-5924-4381-a619-f95918da4700">楼层ID</p>
    */
    @SerializedName("floorIds")
    private List<Long> floorIds;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getEstimatedArriveTime() {
        return estimatedArriveTime;
    }
    public void setEstimatedArriveTime(String estimatedArriveTime) {
        this.estimatedArriveTime = estimatedArriveTime;
    }
    public String getCheckinType() {
        return checkinType;
    }
    public void setCheckinType(String checkinType) {
        this.checkinType = checkinType;
    }
    public List<String> getRoomTypeIds() {
        return roomTypeIds;
    }
    public void setRoomTypeIds(List<String> roomTypeIds) {
        this.roomTypeIds = roomTypeIds;
    }
    public List<String> getRoomStatus() {
        return roomStatus;
    }
    public void setRoomStatus(List<String> roomStatus) {
        this.roomStatus = roomStatus;
    }
    public List<Long> getHallIds() {
        return hallIds;
    }
    public void setHallIds(List<Long> hallIds) {
        this.hallIds = hallIds;
    }
    public List<Long> getFloorIds() {
        return floorIds;
    }
    public void setFloorIds(List<Long> floorIds) {
        this.floorIds = floorIds;
    }


    @Override
    public MeituanResponse<GetHourAvailableRoomsResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<GetHourAvailableRoomsResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GetHourAvailableRoomsRequest{" + "hotelId=" + hotelId + "," + "estimatedArriveTime=" + estimatedArriveTime + "," + "checkinType=" + checkinType + "," + "roomTypeIds=" + roomTypeIds + "," + "roomStatus=" + roomStatus + "," + "hallIds=" + hallIds + "," + "floorIds=" + floorIds + "}";
    }
}
