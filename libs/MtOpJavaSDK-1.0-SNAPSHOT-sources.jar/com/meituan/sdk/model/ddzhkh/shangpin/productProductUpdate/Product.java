package com.meituan.sdk.model.ddzhkh.shangpin.productProductUpdate;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-ba74cd34-91cc-417f-9fbf-02aa0c4d1119">商品信息</p>
* This file was automatically generated.
*/
public class Product {
    /**
    * <p data-diff-id="ct-diff-id-545932b5-ec7f-4b07-aaa2-c61be0a8d3a2"><span style="color: rgb(31, 45, 61)">美团商品名称，长度限制&lt;=30</span></p>
    */
    @NotBlank(message = "productName不能为空")
    @SerializedName("productName")
    private String productName;
    /**
    * <p data-diff-id="ct-diff-id-e6df8fac-69fc-4e53-968d-d52383badff4"><span style="color: rgb(31, 45, 61)">三方商品ID</span>（注意:<span style="color: rgb(245, 34, 45)">场馆预订</span>行业该字段值必须是<span style="color: rgb(245, 34, 45)">纯数字</span>）</p>
    */
    @NotBlank(message = "appProductId不能为空")
    @SerializedName("appProductId")
    private String appProductId;
    /**
    * <p data-diff-id="ct-diff-id-c8f1e370-2977-4ca5-a83b-cfc9babf18cd"><span style="color: rgb(31, 45, 61)">美团商品品类列表，三方需确定要接入商品品类和品类ID，例如体检预订：[100016,735]，场馆预订：[100060,1650],化妆品电商[100048,1005]</span></p>
    */
    @NotEmpty(message = "categoryIds不能为空")
    @SerializedName("categoryIds")
    private List<Long> categoryIds;
    /**
    * <p data-diff-id="ct-diff-id-6cecc8a3-bc1f-47b4-ae55-7ef6e73392cb"><span style="color: rgb(31, 45, 61)">美团店铺ID列表</span></p>
    */
    @NotEmpty(message = "opPoiIds不能为空")
    @SerializedName("opPoiIds")
    private List<String> opPoiIds;
    /**
    * <p data-diff-id="ct-diff-id-b6185cec-9a43-46d6-8eb2-3e9585a2c444"><span style="color: rgb(31, 45, 61)">商品属性，Map&lt;Long,List&lt;String&gt;&gt;格式</span></p>
    */
    @NotBlank(message = "attributes不能为空")
    @SerializedName("attributes")
    private String attributes;
    /**
    * <p data-diff-id="ct-diff-id-22c957b4-e848-4154-9599-21989c8aab37"><span style="color: rgb(31, 45, 61)">售卖SKU列表</span></p>
    */
    @NotEmpty(message = "items不能为空")
    @SerializedName("items")
    private List<Item> items;
    /**
    * <p data-diff-id="ct-diff-id-639cd3b9-ebc4-473e-88ed-0b96fe86a323"><span style="color: rgb(31, 45, 61)">美团商品ID</span></p>
    */
    @NotNull(message = "productId不能为空")
    @SerializedName("productId")
    private Long productId;

    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public String getAppProductId() {
        return appProductId;
    }
    public void setAppProductId(String appProductId) {
        this.appProductId = appProductId;
    }
    public List<Long> getCategoryIds() {
        return categoryIds;
    }
    public void setCategoryIds(List<Long> categoryIds) {
        this.categoryIds = categoryIds;
    }
    public List<String> getOpPoiIds() {
        return opPoiIds;
    }
    public void setOpPoiIds(List<String> opPoiIds) {
        this.opPoiIds = opPoiIds;
    }
    public String getAttributes() {
        return attributes;
    }
    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }
    public List<Item> getItems() {
        return items;
    }
    public void setItems(List<Item> items) {
        this.items = items;
    }
    public Long getProductId() {
        return productId;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }




    @Override
    public String toString() {
        return "Product{" + "productName=" + productName + "," + "appProductId=" + appProductId + "," + "categoryIds=" + categoryIds + "," + "opPoiIds=" + opPoiIds + "," + "attributes=" + attributes + "," + "items=" + items + "," + "productId=" + productId + "}";
    }
}
