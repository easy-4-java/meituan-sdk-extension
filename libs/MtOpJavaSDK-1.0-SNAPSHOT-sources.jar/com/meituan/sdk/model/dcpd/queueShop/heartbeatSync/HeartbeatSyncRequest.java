package com.meituan.sdk.model.dcpd.queueShop.heartbeatSync;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 批量同步心跳
* This file was automatically generated.
*/
@ApiMeta(
    path = "/dcpd/queue/shop/heartbeat/sync",
    businessId = 49,
    apiVersion = "10002",
    apiName = "heartbeat_sync",
    needAuth = true
)
public class HeartbeatSyncRequest implements MeituanRequest<Boolean> {
    /**
    * <p data-diff-id="ct-diff-id-9bcb0c13-a934-4939-973a-aaf4fc2aff70">门店列表</p>
    */
    @NotEmpty(message = "data不能为空")
    @SerializedName("data")
    private List<Long> data;

    public List<Long> getData() {
        return data;
    }
    public void setData(List<Long> data) {
        this.data = data;
    }


    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this.data);
    }


    @Override
    public String toString() {
        return "HeartbeatSyncRequest{" + "data=" + data + "}";
    }
}
