package com.meituan.sdk.model.wmoperNg.order.innovativeOrderQuery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class OrdersSub {
    /**
    * 订单创建时间。单位是秒
    */
    @SerializedName("cTime")
    private Long cTime;
    /**
    * 城市id
    */
    @SerializedName("cityId")
    private Long cityId;
    /**
    * 用户预计送达时间，“立即送达”时为0 整性数据，单位是秒, 如取餐类型为到店自取，则该时间为用户自选的到店自取时间
    */
    @SerializedName("deliveryTime")
    private Long deliveryTime;
    @SerializedName("detail")
    private List<DetailSub> detail;
    /**
    * 三方系统中的主门店Id
    */
    @SerializedName("ePoiId")
    private String ePoiId;
    /**
    * 预计送达时间
    */
    @SerializedName("estimateArrivalTime")
    private Long estimateArrivalTime;
    @SerializedName("extras")
    private List<ExtrasSub> extras;
    /**
    * 是否需要开发票。1-需要开发票，2-无需开发票，0-降级
    */
    @SerializedName("needSqtInvoice")
    private String needSqtInvoice;
    @SerializedName("orderId")
    private Long orderId;
    @SerializedName("orderIdView")
    private Long orderIdView;
    @SerializedName("originalPrice")
    private Double originalPrice;
    @SerializedName("payType")
    private Long payType;
    @SerializedName("pickType")
    private Long pickType;
    @SerializedName("poiAddress")
    private String poiAddress;
    @SerializedName("poiId")
    private Long poiId;
    @SerializedName("poiName")
    private String poiName;
    @SerializedName("poiPhone")
    private String poiPhone;
    @SerializedName("poiReceiveDetail")
    private PoiReceiveDetail poiReceiveDetail;
    @SerializedName("recipientAddress")
    private String recipientAddress;
    @SerializedName("recipientAddressDesensitization")
    private String recipientAddressDesensitization;
    @SerializedName("recipientName")
    private String recipientName;
    @SerializedName("recipientPhone")
    private String recipientPhone;
    @SerializedName("sgjExtraInfo")
    private SgjExtraInfo sgjExtraInfo;
    @SerializedName("shippingFee")
    private Long shippingFee;
    @SerializedName("sqtOrder")
    private String sqtOrder;
    @SerializedName("status")
    private Long status;
    @SerializedName("total")
    private Long total;
    @SerializedName("wmPoiReceiveCent")
    private Long wmPoiReceiveCent;

    public Long getCTime() {
        return cTime;
    }
    public void setCTime(Long cTime) {
        this.cTime = cTime;
    }
    public Long getCityId() {
        return cityId;
    }
    public void setCityId(Long cityId) {
        this.cityId = cityId;
    }
    public Long getDeliveryTime() {
        return deliveryTime;
    }
    public void setDeliveryTime(Long deliveryTime) {
        this.deliveryTime = deliveryTime;
    }
    public List<DetailSub> getDetail() {
        return detail;
    }
    public void setDetail(List<DetailSub> detail) {
        this.detail = detail;
    }
    public String getEPoiId() {
        return ePoiId;
    }
    public void setEPoiId(String ePoiId) {
        this.ePoiId = ePoiId;
    }
    public Long getEstimateArrivalTime() {
        return estimateArrivalTime;
    }
    public void setEstimateArrivalTime(Long estimateArrivalTime) {
        this.estimateArrivalTime = estimateArrivalTime;
    }
    public List<ExtrasSub> getExtras() {
        return extras;
    }
    public void setExtras(List<ExtrasSub> extras) {
        this.extras = extras;
    }
    public String getNeedSqtInvoice() {
        return needSqtInvoice;
    }
    public void setNeedSqtInvoice(String needSqtInvoice) {
        this.needSqtInvoice = needSqtInvoice;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public Long getOrderIdView() {
        return orderIdView;
    }
    public void setOrderIdView(Long orderIdView) {
        this.orderIdView = orderIdView;
    }
    public Double getOriginalPrice() {
        return originalPrice;
    }
    public void setOriginalPrice(Double originalPrice) {
        this.originalPrice = originalPrice;
    }
    public Long getPayType() {
        return payType;
    }
    public void setPayType(Long payType) {
        this.payType = payType;
    }
    public Long getPickType() {
        return pickType;
    }
    public void setPickType(Long pickType) {
        this.pickType = pickType;
    }
    public String getPoiAddress() {
        return poiAddress;
    }
    public void setPoiAddress(String poiAddress) {
        this.poiAddress = poiAddress;
    }
    public Long getPoiId() {
        return poiId;
    }
    public void setPoiId(Long poiId) {
        this.poiId = poiId;
    }
    public String getPoiName() {
        return poiName;
    }
    public void setPoiName(String poiName) {
        this.poiName = poiName;
    }
    public String getPoiPhone() {
        return poiPhone;
    }
    public void setPoiPhone(String poiPhone) {
        this.poiPhone = poiPhone;
    }
    public PoiReceiveDetail getPoiReceiveDetail() {
        return poiReceiveDetail;
    }
    public void setPoiReceiveDetail(PoiReceiveDetail poiReceiveDetail) {
        this.poiReceiveDetail = poiReceiveDetail;
    }
    public String getRecipientAddress() {
        return recipientAddress;
    }
    public void setRecipientAddress(String recipientAddress) {
        this.recipientAddress = recipientAddress;
    }
    public String getRecipientAddressDesensitization() {
        return recipientAddressDesensitization;
    }
    public void setRecipientAddressDesensitization(String recipientAddressDesensitization) {
        this.recipientAddressDesensitization = recipientAddressDesensitization;
    }
    public String getRecipientName() {
        return recipientName;
    }
    public void setRecipientName(String recipientName) {
        this.recipientName = recipientName;
    }
    public String getRecipientPhone() {
        return recipientPhone;
    }
    public void setRecipientPhone(String recipientPhone) {
        this.recipientPhone = recipientPhone;
    }
    public SgjExtraInfo getSgjExtraInfo() {
        return sgjExtraInfo;
    }
    public void setSgjExtraInfo(SgjExtraInfo sgjExtraInfo) {
        this.sgjExtraInfo = sgjExtraInfo;
    }
    public Long getShippingFee() {
        return shippingFee;
    }
    public void setShippingFee(Long shippingFee) {
        this.shippingFee = shippingFee;
    }
    public String getSqtOrder() {
        return sqtOrder;
    }
    public void setSqtOrder(String sqtOrder) {
        this.sqtOrder = sqtOrder;
    }
    public Long getStatus() {
        return status;
    }
    public void setStatus(Long status) {
        this.status = status;
    }
    public Long getTotal() {
        return total;
    }
    public void setTotal(Long total) {
        this.total = total;
    }
    public Long getWmPoiReceiveCent() {
        return wmPoiReceiveCent;
    }
    public void setWmPoiReceiveCent(Long wmPoiReceiveCent) {
        this.wmPoiReceiveCent = wmPoiReceiveCent;
    }




    @Override
    public String toString() {
        return "OrdersSub{" + "cTime=" + cTime + "," + "cityId=" + cityId + "," + "deliveryTime=" + deliveryTime + "," + "detail=" + detail + "," + "ePoiId=" + ePoiId + "," + "estimateArrivalTime=" + estimateArrivalTime + "," + "extras=" + extras + "," + "needSqtInvoice=" + needSqtInvoice + "," + "orderId=" + orderId + "," + "orderIdView=" + orderIdView + "," + "originalPrice=" + originalPrice + "," + "payType=" + payType + "," + "pickType=" + pickType + "," + "poiAddress=" + poiAddress + "," + "poiId=" + poiId + "," + "poiName=" + poiName + "," + "poiPhone=" + poiPhone + "," + "poiReceiveDetail=" + poiReceiveDetail + "," + "recipientAddress=" + recipientAddress + "," + "recipientAddressDesensitization=" + recipientAddressDesensitization + "," + "recipientName=" + recipientName + "," + "recipientPhone=" + recipientPhone + "," + "sgjExtraInfo=" + sgjExtraInfo + "," + "shippingFee=" + shippingFee + "," + "sqtOrder=" + sqtOrder + "," + "status=" + status + "," + "total=" + total + "," + "wmPoiReceiveCent=" + wmPoiReceiveCent + "}";
    }
}
