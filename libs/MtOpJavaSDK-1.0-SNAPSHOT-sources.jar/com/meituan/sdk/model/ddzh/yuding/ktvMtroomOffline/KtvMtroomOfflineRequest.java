package com.meituan.sdk.model.ddzh.yuding.ktvMtroomOffline;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* ktv一键下线套餐（将某天某时段内价格低于阈值的套餐下线）
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/ktv/mtroom/offline",
    businessId = 58,
    apiVersion = "10053",
    apiName = "ktv_mtroom_offline",
    needAuth = true
)
public class KtvMtroomOfflineRequest implements MeituanRequest<KtvMtroomOfflineResponse> {
    /**
    * <p data-diff-id="ct-diff-id-b6b5f855-97c5-4725-8d02-e8b592688a19">美团房型id</p>
    */
    @SerializedName("mtRoomId")
    private Long mtRoomId;
    /**
    * <p data-diff-id="ct-diff-id-536f71f8-9261-4477-b725-ad2ae5795bbe">美团时段id</p>
    */
    @SerializedName("mtPeriodId")
    private Long mtPeriodId;
    /**
    * <p data-diff-id="ct-diff-id-ac677716-5d49-45de-8d97-9173014837e9">日期 //2024-07-05</p>
    */
    @NotBlank(message = "date不能为空")
    @SerializedName("date")
    private String date;
    /**
    * <p data-diff-id="ct-diff-id-1e8d622b-290e-488c-90de-507216c15c55">价格阈值</p>
    */
    @NotNull(message = "price不能为空")
    @SerializedName("price")
    private Integer price;
    /**
    * <p data-diff-id="ct-diff-id-4d0554a3-53a1-4876-9f7f-92e4f57a09fc">0:下线、1:上线</p>
    */
    @NotNull(message = "type不能为空")
    @SerializedName("type")
    private Integer type;

    public Long getMtRoomId() {
        return mtRoomId;
    }
    public void setMtRoomId(Long mtRoomId) {
        this.mtRoomId = mtRoomId;
    }
    public Long getMtPeriodId() {
        return mtPeriodId;
    }
    public void setMtPeriodId(Long mtPeriodId) {
        this.mtPeriodId = mtPeriodId;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public Integer getPrice() {
        return price;
    }
    public void setPrice(Integer price) {
        this.price = price;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }


    @Override
    public MeituanResponse<KtvMtroomOfflineResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<KtvMtroomOfflineResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "KtvMtroomOfflineRequest{" + "mtRoomId=" + mtRoomId + "," + "mtPeriodId=" + mtPeriodId + "," + "date=" + date + "," + "price=" + price + "," + "type=" + type + "}";
    }
}
