package com.meituan.sdk.model.ddzh.technician.technicianTechinfoUpdateorderextrac;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 手艺人订单扩展信息修改
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/technician/techinfo/updateorderextrac",
    businessId = 58,
    apiVersion = "10004",
    apiName = "technician_techinfo_updateorderextrac",
    needAuth = true
)
public class TechnicianTechinfoUpdateorderextracRequest implements MeituanRequest<TechnicianTechinfoUpdateorderextracResponse> {
    /**
    * <p data-diff-id="ct-diff-id-9b1f7c45-d12c-4950-810a-633e646876c5">更新订单扩展字段请求,最多传入20个</p>
    */
    @NotEmpty(message = "orderUpdateList不能为空")
    @SerializedName("orderUpdateList")
    private List<OrderUpdateExtraFiledModel> orderUpdateList;

    public List<OrderUpdateExtraFiledModel> getOrderUpdateList() {
        return orderUpdateList;
    }
    public void setOrderUpdateList(List<OrderUpdateExtraFiledModel> orderUpdateList) {
        this.orderUpdateList = orderUpdateList;
    }


    @Override
    public MeituanResponse<TechnicianTechinfoUpdateorderextracResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<TechnicianTechinfoUpdateorderextracResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TechnicianTechinfoUpdateorderextracRequest{" + "orderUpdateList=" + orderUpdateList + "}";
    }
}
