package com.meituan.sdk.model.ddzh.common.transferBidToOpCustomerId;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 原北极星加密客户id转换为合作中心加密客户id
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/common/transfer/bidToOpCustomerId",
    businessId = 58,
    apiVersion = "10000",
    apiName = "transfer_bid_to_op_customer_id",
    needAuth = false
)
public class TransferBidToOpCustomerIdRequest implements MeituanRequest<TransferBidToOpCustomerIdResponse> {
    /**
    * <p data-diff-id="ct-diff-id-f220b7f1-4cae-4198-8eec-a3cc8f3930e2">原北极星加密客户id</p>
    */
    @NotBlank(message = "bid不能为空")
    @SerializedName("bid")
    private String bid;

    public String getBid() {
        return bid;
    }
    public void setBid(String bid) {
        this.bid = bid;
    }


    @Override
    public MeituanResponse<TransferBidToOpCustomerIdResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<TransferBidToOpCustomerIdResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TransferBidToOpCustomerIdRequest{" + "bid=" + bid + "}";
    }
}
