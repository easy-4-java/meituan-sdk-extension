package com.meituan.sdk.model.waimaiNg.diancan.diancanShopconfigQuery;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 门店配置查询
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/diancan/shop/queryShops",
    businessId = 2,
    apiVersion = "10009",
    apiName = "diancan_shopconfig_query",
    needAuth = true
)
public class DiancanShopconfigQueryRequest implements MeituanRequest<List<ShopQueryResult>> {
    /**
    * <p data-diff-id="ct-diff-id-027b604b-6256-41d6-928b-bac7a82b68b3"><font style="font-size:14px;line-height:22px" data-size="14">厂商门店ID列表，用,隔开，比如 123,300</font></p>
    */
    @NotBlank(message = "appPoiCodes不能为空")
    @SerializedName("appPoiCodes")
    private String appPoiCodes;

    public String getAppPoiCodes() {
        return appPoiCodes;
    }
    public void setAppPoiCodes(String appPoiCodes) {
        this.appPoiCodes = appPoiCodes;
    }


    @Override
    public MeituanResponse<List<ShopQueryResult>> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<List<ShopQueryResult>>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "DiancanShopconfigQueryRequest{" + "appPoiCodes=" + appPoiCodes + "}";
    }
}
