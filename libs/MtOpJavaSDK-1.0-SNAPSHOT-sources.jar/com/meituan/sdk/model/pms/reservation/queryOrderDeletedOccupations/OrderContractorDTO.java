package com.meituan.sdk.model.pms.reservation.queryOrderDeletedOccupations;

import com.google.gson.annotations.SerializedName;

/**
* 定价人（中介或协议公司信息）
* This file was automatically generated.
*/
public class OrderContractorDTO {
    /**
    * 中介/协议公司ID
    */
    @SerializedName("id")
    private Long id;
    /**
    * 中介/协议公司名称
    */
    @SerializedName("name")
    private String name;
    /**
    * 中介/协议公司类型
    */
    @SerializedName("type")
    private String type;
    /**
    * 中介/协议公司级别
    */
    @SerializedName("level")
    private String level;
    /**
    * 佣金级别
    */
    @SerializedName("commissionLevel")
    private String commissionLevel;
    /**
    * 级别描述
    */
    @SerializedName("levelDesc")
    private String levelDesc;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getLevel() {
        return level;
    }
    public void setLevel(String level) {
        this.level = level;
    }
    public String getCommissionLevel() {
        return commissionLevel;
    }
    public void setCommissionLevel(String commissionLevel) {
        this.commissionLevel = commissionLevel;
    }
    public String getLevelDesc() {
        return levelDesc;
    }
    public void setLevelDesc(String levelDesc) {
        this.levelDesc = levelDesc;
    }




    @Override
    public String toString() {
        return "OrderContractorDTO{" + "id=" + id + "," + "name=" + name + "," + "type=" + type + "," + "level=" + level + "," + "commissionLevel=" + commissionLevel + "," + "levelDesc=" + levelDesc + "}";
    }
}
