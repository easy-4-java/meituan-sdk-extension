package com.meituan.sdk.model.ddzh.tuangou.tuangouProductStockQuery;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 团购商品库存查询
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/tuangou/product/stockquery",
    businessId = 58,
    apiVersion = "10094",
    apiName = "tuangou_product_stock_query",
    needAuth = true
)
public class TuangouProductStockQueryRequest implements MeituanRequest<TuangouProductStockQueryResponse> {
    /**
    * <p data-diff-id="ct-diff-id-6766f87d-7eac-4055-acd4-8799ceca22cd">三方商品SKUID列表</p>
    */
    @NotEmpty(message = "thirdPartySkuIds不能为空")
    @SerializedName("thirdPartySkuIds")
    private List<String> thirdPartySkuIds;

    public List<String> getThirdPartySkuIds() {
        return thirdPartySkuIds;
    }
    public void setThirdPartySkuIds(List<String> thirdPartySkuIds) {
        this.thirdPartySkuIds = thirdPartySkuIds;
    }


    @Override
    public MeituanResponse<TuangouProductStockQueryResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<TuangouProductStockQueryResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TuangouProductStockQueryRequest{" + "thirdPartySkuIds=" + thirdPartySkuIds + "}";
    }
}
