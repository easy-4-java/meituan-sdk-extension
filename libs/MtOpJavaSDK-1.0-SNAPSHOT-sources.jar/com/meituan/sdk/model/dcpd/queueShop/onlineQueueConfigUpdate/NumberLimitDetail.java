package com.meituan.sdk.model.dcpd.queueShop.onlineQueueConfigUpdate;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-afc3d4da-3e28-4024-b086-7e39025a8d2b">取号数量限制明细</p>
* This file was automatically generated.
*/
public class NumberLimitDetail {
    /**
    * <p data-diff-id="ct-diff-id-d9125315-c7be-4d56-a670-5addc79d4764">排队侧的桌型id，0表示全部</p>
    */
    @NotNull(message = "tableType不能为空")
    @SerializedName("tableType")
    private Integer tableType;
    /**
    * <p data-diff-id="ct-diff-id-c4e9b04d-ea5a-481e-9b77-6811442d0f00">限制的取号数量，范围0-999，0就是一直不允许</p>
    */
    @NotNull(message = "stock不能为空")
    @SerializedName("stock")
    private Integer stock;
    /**
    * <p data-diff-id="ct-diff-id-22cd276e-3bd3-4ba2-b158-df13ee0008a2">限制取号时间段设置</p>
    */
    @NotNull(message = "timePeriod不能为空")
    @SerializedName("timePeriod")
    private TimePeriod timePeriod;

    public Integer getTableType() {
        return tableType;
    }
    public void setTableType(Integer tableType) {
        this.tableType = tableType;
    }
    public Integer getStock() {
        return stock;
    }
    public void setStock(Integer stock) {
        this.stock = stock;
    }
    public TimePeriod getTimePeriod() {
        return timePeriod;
    }
    public void setTimePeriod(TimePeriod timePeriod) {
        this.timePeriod = timePeriod;
    }




    @Override
    public String toString() {
        return "NumberLimitDetail{" + "tableType=" + tableType + "," + "stock=" + stock + "," + "timePeriod=" + timePeriod + "}";
    }
}
