package com.meituan.sdk.model.waimaiNg.dish.toppingCodeBindByName;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 根据小料名称绑定小料code接口
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/dish/topping/bindToppingCodeByName",
    businessId = 2,
    apiVersion = "10113",
    apiName = "topping_code_bind_by_name",
    needAuth = true
)
public class ToppingCodeBindByNameRequest implements MeituanRequest<String> {
    /**
    * <p data-diff-id="ct-diff-id-0aa859f2-05d7-41f5-a52e-cd74d357cd73">一次最多20,即将绑定小料的code及name</p>
    */
    @NotEmpty(message = "toppings不能为空")
    @SerializedName("toppings")
    private List<OpenTopping> toppings;

    public List<OpenTopping> getToppings() {
        return toppings;
    }
    public void setToppings(List<OpenTopping> toppings) {
        this.toppings = toppings;
    }


    @Override
    public MeituanResponse<String> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<String>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ToppingCodeBindByNameRequest{" + "toppings=" + toppings + "}";
    }
}
