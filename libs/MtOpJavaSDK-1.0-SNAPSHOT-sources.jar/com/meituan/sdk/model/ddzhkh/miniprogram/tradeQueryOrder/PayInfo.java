package com.meituan.sdk.model.ddzhkh.miniprogram.tradeQueryOrder;

import com.google.gson.annotations.SerializedName;

/**
* 支付信息列表
* This file was automatically generated.
*/
public class PayInfo {
    /**
    * 订单id
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * 三方商户订单id
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * 美团支付单id
    */
    @SerializedName("orderPaymentId")
    private String orderPaymentId;
    /**
    * 三方支付单id
    */
    @SerializedName("vendorPaymentId")
    private String vendorPaymentId;
    /**
    * payAmount
    */
    @SerializedName("payAmount")
    private Long payAmount;
    /**
    * 支付状态
    */
    @SerializedName("payStatus")
    private String payStatus;
    /**
    * 支付方式描述
    */
    @SerializedName("payTypeTxt")
    private String payTypeTxt;
    /**
    * 支付成功时间
    */
    @SerializedName("successTime")
    private Long successTime;
    /**
    * 美团流水号
    */
    @SerializedName("tradeNo")
    private String tradeNo;
    /**
    * 美团支付单id
    */
    @SerializedName("paymentId")
    private String paymentId;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public String getOrderPaymentId() {
        return orderPaymentId;
    }
    public void setOrderPaymentId(String orderPaymentId) {
        this.orderPaymentId = orderPaymentId;
    }
    public String getVendorPaymentId() {
        return vendorPaymentId;
    }
    public void setVendorPaymentId(String vendorPaymentId) {
        this.vendorPaymentId = vendorPaymentId;
    }
    public Long getPayAmount() {
        return payAmount;
    }
    public void setPayAmount(Long payAmount) {
        this.payAmount = payAmount;
    }
    public String getPayStatus() {
        return payStatus;
    }
    public void setPayStatus(String payStatus) {
        this.payStatus = payStatus;
    }
    public String getPayTypeTxt() {
        return payTypeTxt;
    }
    public void setPayTypeTxt(String payTypeTxt) {
        this.payTypeTxt = payTypeTxt;
    }
    public Long getSuccessTime() {
        return successTime;
    }
    public void setSuccessTime(Long successTime) {
        this.successTime = successTime;
    }
    public String getTradeNo() {
        return tradeNo;
    }
    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }
    public String getPaymentId() {
        return paymentId;
    }
    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }




    @Override
    public String toString() {
        return "PayInfo{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "," + "orderPaymentId=" + orderPaymentId + "," + "vendorPaymentId=" + vendorPaymentId + "," + "payAmount=" + payAmount + "," + "payStatus=" + payStatus + "," + "payTypeTxt=" + payTypeTxt + "," + "successTime=" + successTime + "," + "tradeNo=" + tradeNo + "," + "paymentId=" + paymentId + "}";
    }
}
