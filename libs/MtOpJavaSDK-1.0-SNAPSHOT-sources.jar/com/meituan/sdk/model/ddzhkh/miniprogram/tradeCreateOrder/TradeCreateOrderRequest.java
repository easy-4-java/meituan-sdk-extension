package com.meituan.sdk.model.ddzhkh.miniprogram.tradeCreateOrder;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 下单（包含预支付）
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/miniprogram/trade/create_order",
    businessId = 59,
    apiVersion = "10022",
    apiName = "trade_create_order",
    needAuth = true
)
public class TradeCreateOrderRequest implements MeituanRequest<TradeCreateOrderResponse> {
    @NotBlank(message = "generalBizData不能为空")
    @SerializedName("generalBizData")
    private String generalBizData;
    @NotNull(message = "createOrderReq不能为空")
    @SerializedName("createOrderReq")
    private CreateOrderReq createOrderReq;

    public String getGeneralBizData() {
        return generalBizData;
    }
    public void setGeneralBizData(String generalBizData) {
        this.generalBizData = generalBizData;
    }
    public CreateOrderReq getCreateOrderReq() {
        return createOrderReq;
    }
    public void setCreateOrderReq(CreateOrderReq createOrderReq) {
        this.createOrderReq = createOrderReq;
    }


    @Override
    public MeituanResponse<TradeCreateOrderResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<TradeCreateOrderResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TradeCreateOrderRequest{" + "generalBizData=" + generalBizData + "," + "createOrderReq=" + createOrderReq + "}";
    }
}
