package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiMerchantPoiChangeQualification;

import com.google.gson.annotations.SerializedName;

/**
* [变更]修改主体资质
* This file was automatically generated.
*/
public class ZcmopenApiMerchantPoiChangeQualificationResponse {
    /**
    * 请求状态
    */
    @SerializedName("status")
    private String status;
    /**
    * 错误code
    */
    @SerializedName("errCode")
    private String errCode;
    /**
    * 错误信息
    */
    @SerializedName("errMsg")
    private String errMsg;
    /**
    * 变更id  根据变更id查询变更结果
    */
    @SerializedName("changeId")
    private Integer changeId;

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getErrCode() {
        return errCode;
    }
    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }
    public String getErrMsg() {
        return errMsg;
    }
    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
    public Integer getChangeId() {
        return changeId;
    }
    public void setChangeId(Integer changeId) {
        this.changeId = changeId;
    }




    @Override
    public String toString() {
        return "ZcmopenApiMerchantPoiChangeQualificationResponse{" + "status=" + status + "," + "errCode=" + errCode + "," + "errMsg=" + errMsg + "," + "changeId=" + changeId + "}";
    }
}
