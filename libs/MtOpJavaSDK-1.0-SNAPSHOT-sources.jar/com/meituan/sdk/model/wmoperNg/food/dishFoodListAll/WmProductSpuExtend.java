package com.meituan.sdk.model.wmoperNg.food.dishFoodListAll;

import com.google.gson.annotations.SerializedName;

/**
* 类目属性list
* This file was automatically generated.
*/
public class WmProductSpuExtend {
    /**
    * 后台类目对应模板下属性ID 没有参数则填字段默认值
    */
    @SerializedName("code")
    private String code;
    /**
    * 是否叶子节点, 1-叶子节点，2-非叶子节点
    */
    @SerializedName("is_leaf")
    private Integer isLeaf;
    /**
    * 层级
    */
    @SerializedName("level")
    private Integer level;
    /**
    * 后台类目对应模板下属性名称 没有参数则填字段默认值
    */
    @SerializedName("name")
    private String name;
    /**
    * 后台类目对应模板下属性父ID 没有参数则填字段默认值
    */
    @SerializedName("parent_property_id")
    private Long parentPropertyId;
    /**
    * 排序
    */
    @SerializedName("sequence")
    private Integer sequence;
    /**
    * 模板ID
    */
    @SerializedName("template_id")
    private Long templateId;
    /**
    * 后台类目对应模板下属性填的值 没有参数则填字段默认值
    */
    @SerializedName("value")
    private String value;
    /**
    * 后台类目对应模板下属性填的值的ID 没有参数则填字段默认值
    */
    @SerializedName("value_id")
    private Long valueId;

    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public Integer getIsLeaf() {
        return isLeaf;
    }
    public void setIsLeaf(Integer isLeaf) {
        this.isLeaf = isLeaf;
    }
    public Integer getLevel() {
        return level;
    }
    public void setLevel(Integer level) {
        this.level = level;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Long getParentPropertyId() {
        return parentPropertyId;
    }
    public void setParentPropertyId(Long parentPropertyId) {
        this.parentPropertyId = parentPropertyId;
    }
    public Integer getSequence() {
        return sequence;
    }
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    public Long getTemplateId() {
        return templateId;
    }
    public void setTemplateId(Long templateId) {
        this.templateId = templateId;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public Long getValueId() {
        return valueId;
    }
    public void setValueId(Long valueId) {
        this.valueId = valueId;
    }




    @Override
    public String toString() {
        return "WmProductSpuExtend{" + "code=" + code + "," + "isLeaf=" + isLeaf + "," + "level=" + level + "," + "name=" + name + "," + "parentPropertyId=" + parentPropertyId + "," + "sequence=" + sequence + "," + "templateId=" + templateId + "," + "value=" + value + "," + "valueId=" + valueId + "}";
    }
}
