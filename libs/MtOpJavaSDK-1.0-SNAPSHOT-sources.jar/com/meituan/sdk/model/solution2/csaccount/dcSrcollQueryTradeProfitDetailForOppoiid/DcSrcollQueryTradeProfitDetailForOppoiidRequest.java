package com.meituan.sdk.model.solution2.csaccount.dcSrcollQueryTradeProfitDetailForOppoiid;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 游标查询交易结算流水(服务商使用)
* This file was automatically generated.
*/
@ApiMeta(
    path = "/solution2/csaccount/scrollQueryTradeProfitDetailOpPoiId",
    businessId = 86,
    apiVersion = "10010",
    apiName = "dc_srcoll_query_trade_profit_detail_for_oppoiid",
    needAuth = true
)
public class DcSrcollQueryTradeProfitDetailForOppoiidRequest implements MeituanRequest<DcSrcollQueryTradeProfitDetailForOppoiidResponse> {
    /**
    * <p data-diff-id="ct-diff-id-5d322b47-ed92-444f-ba55-f466596b6a26"><em><span style="color: rgba(0, 0, 0, 0.65)">业务类型</span></em></p><p data-diff-id="ct-diff-id-33fd08d2-0142-4e15-9922-751cc89ec9d9"><em><span style="color: rgba(0, 0, 0, 0.65)">当前支持传</span></em>1=团购 16=在线点 </p>
    */
    @NotNull(message = "bizType不能为空")
    @SerializedName("bizType")
    private Integer bizType;
    /**
    * <p data-diff-id="ct-diff-id-40dc32d5-6846-47b8-9c17-11e13ca596ab"><em><span style="color: rgba(0, 0, 0, 0.65)">美团混淆门店ID列表</span></em></p>
    */
    @SerializedName("opPoiIdList")
    private List<String> opPoiIdList;
    /**
    * <p data-diff-id="ct-diff-id-795c5703-cdc4-4ab0-80c7-534f217b2d02"><em><span style="color: ">账单开始时间戳（毫秒）</span></em></p>
    */
    @NotNull(message = "startTime不能为空")
    @SerializedName("startTime")
    private Long startTime;
    /**
    * <p data-diff-id="ct-diff-id-f85aa880-66d1-4f2d-b973-ef073a576d5a"><em><span style="color: ">账单结束时间戳（毫秒）</span></em></p>
    */
    @NotNull(message = "endTime不能为空")
    @SerializedName("endTime")
    private Long endTime;
    /**
    * <p data-diff-id="ct-diff-id-9405e7e1-c0f3-4335-934d-b02696f9e424"><em><span style="color: ">游标ID, 首次查询传1</span></em></p>
    */
    @NotNull(message = "scrollId不能为空")
    @SerializedName("scrollId")
    private Long scrollId;
    /**
    * <p data-diff-id="ct-diff-id-7e5adead-11c9-4243-b794-cba9aecb3efa"><em><span style="color: ">查询数量</span></em></p>
    */
    @SerializedName("pageSize")
    private Integer pageSize;

    public Integer getBizType() {
        return bizType;
    }
    public void setBizType(Integer bizType) {
        this.bizType = bizType;
    }
    public List<String> getOpPoiIdList() {
        return opPoiIdList;
    }
    public void setOpPoiIdList(List<String> opPoiIdList) {
        this.opPoiIdList = opPoiIdList;
    }
    public Long getStartTime() {
        return startTime;
    }
    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }
    public Long getEndTime() {
        return endTime;
    }
    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }
    public Long getScrollId() {
        return scrollId;
    }
    public void setScrollId(Long scrollId) {
        this.scrollId = scrollId;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }


    @Override
    public MeituanResponse<DcSrcollQueryTradeProfitDetailForOppoiidResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<DcSrcollQueryTradeProfitDetailForOppoiidResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "DcSrcollQueryTradeProfitDetailForOppoiidRequest{" + "bizType=" + bizType + "," + "opPoiIdList=" + opPoiIdList + "," + "startTime=" + startTime + "," + "endTime=" + endTime + "," + "scrollId=" + scrollId + "," + "pageSize=" + pageSize + "}";
    }
}
