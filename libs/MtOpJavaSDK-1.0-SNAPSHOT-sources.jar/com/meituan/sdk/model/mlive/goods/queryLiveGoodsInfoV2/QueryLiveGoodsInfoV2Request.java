package com.meituan.sdk.model.mlive.goods.queryLiveGoodsInfoV2;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询直播间商品，集采场景
* This file was automatically generated.
*/
@ApiMeta(
    path = "/mlive/goods/query/v2",
    businessId = 50,
    apiVersion = "10009",
    apiName = "query_live_goods_info_v2",
    needAuth = false
)
public class QueryLiveGoodsInfoV2Request implements MeituanRequest<List<LiveRoomGoodsDTO>> {
    /**
    * <p data-diff-id="ct-diff-id-cd1a4334-e36a-47a0-92e3-c9e42d9e728f">直播场次Id</p>
    */
    @NotNull(message = "liveId不能为空")
    @SerializedName("liveId")
    private Long liveId;
    /**
    * <p data-diff-id="ct-diff-id-cba4f37b-8e91-4ac6-bcaa-989c9b863a71">主播id</p>
    */
    @NotNull(message = "anchorId不能为空")
    @SerializedName("anchorId")
    private Long anchorId;

    public Long getLiveId() {
        return liveId;
    }
    public void setLiveId(Long liveId) {
        this.liveId = liveId;
    }
    public Long getAnchorId() {
        return anchorId;
    }
    public void setAnchorId(Long anchorId) {
        this.anchorId = anchorId;
    }


    @Override
    public MeituanResponse<List<LiveRoomGoodsDTO>> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<List<LiveRoomGoodsDTO>>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "QueryLiveGoodsInfoV2Request{" + "liveId=" + liveId + "," + "anchorId=" + anchorId + "}";
    }
}
