package com.meituan.sdk.model.ddzhkh.merchantreceipt.merchantreceiptQueryVerifyreceipthistory;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 商家券查询验券历史
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/merchantreceipt/query/verifyreceipthistory",
    businessId = 59,
    apiVersion = "10025",
    apiName = "merchantreceipt_query_verifyreceipthistory",
    needAuth = true
)
public class MerchantreceiptQueryVerifyreceipthistoryRequest implements MeituanRequest<MerchantreceiptQueryVerifyreceipthistoryResponse> {
    /**
    * <p data-diff-id="ct-diff-id-32f1387a-2710-4724-b723-e932df32db97">开始时间yyyy-MM-dd HH:mm:ss，不填取当天0点</p><p data-diff-id="ct-diff-id-7bc1ae18-a56d-4ed6-9f62-848201eefcbd"><br></p>
    */
    @SerializedName("beginDate")
    private String beginDate;
    /**
    * <p data-diff-id="ct-diff-id-1db3163e-6541-4d42-b00e-da907c6adc85">结束时间yyyy-MM-dd HH:mm:ss，不填取当前时间（开始结束时间间隔不超6小时）</p>
    */
    @SerializedName("endDate")
    private String endDate;
    /**
    * <p data-diff-id="ct-diff-id-a7a16985-f880-4c63-bcb5-c42a084e34d7">当前页</p><p data-diff-id="ct-diff-id-0f376112-3806-4c96-b985-1101a0b94ca2"><br></p>
    */
    @NotNull(message = "offSet不能为空")
    @SerializedName("offSet")
    private Long offSet;
    /**
    * <p data-diff-id="ct-diff-id-6c857a5b-b029-40fa-beab-6446f837c5dd">第三方团单id，同其他接口中的app_deal_id</p><p data-diff-id="ct-diff-id-c036dadf-08c6-4c50-9c06-98103caaae02"><br></p>
    */
    @NotBlank(message = "dealId不能为空")
    @SerializedName("dealId")
    private String dealId;
    /**
    * <p data-diff-id="ct-diff-id-5ac4b398-29df-4721-a5a9-4fc6f76c9ab8">页大小</p><p data-diff-id="ct-diff-id-03feebba-a704-4556-81a4-20f8426ff853"><br></p>
    */
    @NotNull(message = "limit不能为空")
    @SerializedName("limit")
    private Integer limit;

    public String getBeginDate() {
        return beginDate;
    }
    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }
    public String getEndDate() {
        return endDate;
    }
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    public Long getOffSet() {
        return offSet;
    }
    public void setOffSet(Long offSet) {
        this.offSet = offSet;
    }
    public String getDealId() {
        return dealId;
    }
    public void setDealId(String dealId) {
        this.dealId = dealId;
    }
    public Integer getLimit() {
        return limit;
    }
    public void setLimit(Integer limit) {
        this.limit = limit;
    }


    @Override
    public MeituanResponse<MerchantreceiptQueryVerifyreceipthistoryResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<MerchantreceiptQueryVerifyreceipthistoryResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "MerchantreceiptQueryVerifyreceipthistoryRequest{" + "beginDate=" + beginDate + "," + "endDate=" + endDate + "," + "offSet=" + offSet + "," + "dealId=" + dealId + "," + "limit=" + limit + "}";
    }
}
