package com.meituan.sdk.model.waimaiNg.special.specialFoodSaveComboMainProduct;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.NotEmpty;

/**
* 商品集合数据，不能为空，单次不能超过20个商品
* This file was automatically generated.
*/
public class FoodData {
    /**
    * APP方商品ID，商品唯一标识，最大长度128字符，如果存在就修改，不存在就新增，仅允许操作套餐主商品
    */
    @NotBlank(message = "appFoodCode不能为空")
    @SerializedName("app_food_code")
    private String appFoodCode;
    /**
    * 商品名称，最大长度30字符
    */
    @NotBlank(message = "name不能为空")
    @SerializedName("name")
    private String name;
    /**
    * 商品分类名称，必须是美团拼好饭商品类目叶子名称，通过获取后台类目接口获取
    */
    @NotBlank(message = "categoryName不能为空")
    @SerializedName("category_name")
    private String categoryName;
    /**
    * 商品上下架状态，0：上架，1：下架
    */
    @NotNull(message = "isSoldOut不能为空")
    @SerializedName("is_sold_out")
    private Integer isSoldOut;
    /**
    * 商品描述，最多长度200字符
    */
    @SerializedName("description")
    private String description;
    /**
    * <p data-diff-id="ct-diff-id-2b707dab-dbd4-4f59-9726-a9047832e0db">商品图片Url，通过“上传图片”接口上传获得Url，1-5张，多张图片用“;”(英文分号)分隔。图片尺寸需大于600x450px，宽高比4:3；图片大小不能超过5M；支持扩展名：.png，.jpeg，.jpg，.gif</p>
    */
    @NotBlank(message = "pictures不能为空")
    @SerializedName("pictures")
    private String pictures;
    /**
    * 分时段售卖信息，不填时，默认为全时段售卖
    */
    @SerializedName("shipping_time_x")
    private ShippingData shippingTimeX;
    /**
    * APP方商品skus，不能为空，套餐主品的sku数量有且仅能有1个
    */
    @NotEmpty(message = "skus不能为空")
    @SerializedName("skus")
    private List<SkusData> skus;

    public String getAppFoodCode() {
        return appFoodCode;
    }
    public void setAppFoodCode(String appFoodCode) {
        this.appFoodCode = appFoodCode;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCategoryName() {
        return categoryName;
    }
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    public Integer getIsSoldOut() {
        return isSoldOut;
    }
    public void setIsSoldOut(Integer isSoldOut) {
        this.isSoldOut = isSoldOut;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getPictures() {
        return pictures;
    }
    public void setPictures(String pictures) {
        this.pictures = pictures;
    }
    public ShippingData getShippingTimeX() {
        return shippingTimeX;
    }
    public void setShippingTimeX(ShippingData shippingTimeX) {
        this.shippingTimeX = shippingTimeX;
    }
    public List<SkusData> getSkus() {
        return skus;
    }
    public void setSkus(List<SkusData> skus) {
        this.skus = skus;
    }




    @Override
    public String toString() {
        return "FoodData{" + "appFoodCode=" + appFoodCode + "," + "name=" + name + "," + "categoryName=" + categoryName + "," + "isSoldOut=" + isSoldOut + "," + "description=" + description + "," + "pictures=" + pictures + "," + "shippingTimeX=" + shippingTimeX + "," + "skus=" + skus + "}";
    }
}
