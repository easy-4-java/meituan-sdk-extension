package com.meituan.sdk.model.ddzhkh.dingdan.orderReserveorderquery;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class ResultSub {
    /**
    * 预约单id     
    */
    @SerializedName("reserveOrderId")
    private Long reserveOrderId;
    /**
    * 统一订单id
    */
    @SerializedName("uniOrderId")
    private String uniOrderId;
    /**
    * 门店名称
    */
    @SerializedName("shopName")
    private String shopName;
    /**
    * 预约单主状态，1-待接单，2-已接单，3-预约失败，4-取消中 5-已取消，6-预约改期中，7-商家已服务 8-已消费
    */
    @SerializedName("status")
    private Integer status;
    /**
    * 预约单履约状态
    */
    @SerializedName("fulfilStatus")
    private Integer fulfilStatus;
    /**
    * 预约单预约开始时间
    */
    @SerializedName("bookStartTime")
    private Long bookStartTime;
    /**
    * 预约单预约结束时间
    */
    @SerializedName("bookEndTime")
    private Long bookEndTime;
    /**
    * 商品名称
    */
    @SerializedName("productName")
    private String productName;
    /**
    * 下单平台,1-大众点评，2-美团
    */
    @SerializedName("platform")
    private Integer platform;
    /**
    * 预约数量
    */
    @SerializedName("reserveNum")
    private Long reserveNum;
    /**
    * 券码信息
    */
    @SerializedName("serialNumbers")
    private String serialNumbers;
    /**
    * 订单总价
    */
    @SerializedName("totalPrice")
    private Double totalPrice;
    /**
    * 履约信息
    */
    @SerializedName("fulfilInfoMap")
    private FulfilInfoMap fulfilInfoMap;

    public Long getReserveOrderId() {
        return reserveOrderId;
    }
    public void setReserveOrderId(Long reserveOrderId) {
        this.reserveOrderId = reserveOrderId;
    }
    public String getUniOrderId() {
        return uniOrderId;
    }
    public void setUniOrderId(String uniOrderId) {
        this.uniOrderId = uniOrderId;
    }
    public String getShopName() {
        return shopName;
    }
    public void setShopName(String shopName) {
        this.shopName = shopName;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getFulfilStatus() {
        return fulfilStatus;
    }
    public void setFulfilStatus(Integer fulfilStatus) {
        this.fulfilStatus = fulfilStatus;
    }
    public Long getBookStartTime() {
        return bookStartTime;
    }
    public void setBookStartTime(Long bookStartTime) {
        this.bookStartTime = bookStartTime;
    }
    public Long getBookEndTime() {
        return bookEndTime;
    }
    public void setBookEndTime(Long bookEndTime) {
        this.bookEndTime = bookEndTime;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public Integer getPlatform() {
        return platform;
    }
    public void setPlatform(Integer platform) {
        this.platform = platform;
    }
    public Long getReserveNum() {
        return reserveNum;
    }
    public void setReserveNum(Long reserveNum) {
        this.reserveNum = reserveNum;
    }
    public String getSerialNumbers() {
        return serialNumbers;
    }
    public void setSerialNumbers(String serialNumbers) {
        this.serialNumbers = serialNumbers;
    }
    public Double getTotalPrice() {
        return totalPrice;
    }
    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }
    public FulfilInfoMap getFulfilInfoMap() {
        return fulfilInfoMap;
    }
    public void setFulfilInfoMap(FulfilInfoMap fulfilInfoMap) {
        this.fulfilInfoMap = fulfilInfoMap;
    }




    @Override
    public String toString() {
        return "ResultSub{" + "reserveOrderId=" + reserveOrderId + "," + "uniOrderId=" + uniOrderId + "," + "shopName=" + shopName + "," + "status=" + status + "," + "fulfilStatus=" + fulfilStatus + "," + "bookStartTime=" + bookStartTime + "," + "bookEndTime=" + bookEndTime + "," + "productName=" + productName + "," + "platform=" + platform + "," + "reserveNum=" + reserveNum + "," + "serialNumbers=" + serialNumbers + "," + "totalPrice=" + totalPrice + "," + "fulfilInfoMap=" + fulfilInfoMap + "}";
    }
}
