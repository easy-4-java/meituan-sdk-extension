package com.meituan.sdk.model.ddzhkh.xcxpw.prePay;

import com.google.gson.annotations.SerializedName;

/**
* 预支付
* This file was automatically generated.
*/
public class PrePayResponse {
    /**
    * 系统交互结果
    */
    @SerializedName("extra")
    private ExtraObj extra;
    /**
    * 业务交互结果
    */
    @SerializedName("res")
    private ResObj res;

    public ExtraObj getExtra() {
        return extra;
    }
    public void setExtra(ExtraObj extra) {
        this.extra = extra;
    }
    public ResObj getRes() {
        return res;
    }
    public void setRes(ResObj res) {
        this.res = res;
    }




    @Override
    public String toString() {
        return "PrePayResponse{" + "extra=" + extra + "," + "res=" + res + "}";
    }
}
