package com.meituan.sdk.model.ddzhkh.shangpin.imageUpload;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 图片上传
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/shangpin/image/upload",
    businessId = 59,
    apiVersion = "10102",
    apiName = "image_upload",
    needAuth = true
)
public class ImageUploadRequest implements MeituanRequest<ImageUploadResponse> {
    /**
    * <p data-diff-id="ct-diff-id-ae2671a5-8d26-4a49-a0a8-25d99f7d8cee"><span style="color: rgba(0, 0, 0, 0.65)">图片二进制流，使用Base64编码，最大不超过5M</span></p>
    */
    @NotBlank(message = "imageContent不能为空")
    @SerializedName("imageContent")
    private String imageContent;

    public String getImageContent() {
        return imageContent;
    }
    public void setImageContent(String imageContent) {
        this.imageContent = imageContent;
    }


    @Override
    public MeituanResponse<ImageUploadResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ImageUploadResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ImageUploadRequest{" + "imageContent=" + imageContent + "}";
    }
}
