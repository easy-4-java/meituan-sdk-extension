package com.meituan.sdk.model.pms.accounting.createOrderBillItem;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-fed3779e-6bb1-48b9-a806-1432a9bea6bd"><span style="color: ">会员卡信息，科目代码为</span>C0401，C0402时必填</p>
* This file was automatically generated.
*/
public class CreateBillItemMembershipCardDTO {
    /**
    * <p data-diff-id="ct-diff-id-b29d4e00-bbd8-401c-8216-842b0f360adf"><span style="color: rgb(51, 51, 51)">会员ID</span></p>
    */
    @SerializedName("memberId")
    private Long memberId;
    /**
    * <p data-diff-id="ct-diff-id-dfb86f9f-f093-4c08-b5d0-235bfcd16c88"><span style="color: rgb(51, 51, 51)">会员卡ID</span></p>
    */
    @SerializedName("membershipCardId")
    private Long membershipCardId;

    public Long getMemberId() {
        return memberId;
    }
    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }
    public Long getMembershipCardId() {
        return membershipCardId;
    }
    public void setMembershipCardId(Long membershipCardId) {
        this.membershipCardId = membershipCardId;
    }




    @Override
    public String toString() {
        return "CreateBillItemMembershipCardDTO{" + "memberId=" + memberId + "," + "membershipCardId=" + membershipCardId + "}";
    }
}
