package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiTerminalBoundasync;

import com.google.gson.annotations.SerializedName;

/**
* 绑定设备信息
* This file was automatically generated.
*/
public class BoundTerminalInfo {
    /**
    * 设备ID
    */
    @SerializedName("terminalId")
    private Integer terminalId;
    /**
    * 产品实例ID
    */
    @SerializedName("productInstanceId")
    private Integer productInstanceId;
    /**
    * 门店ID
    */
    @SerializedName("merchantId")
    private Long merchantId;
    /**
    * 绑定时间
    */
    @SerializedName("bindTime")
    private Long bindTime;
    /**
    * 创建时间
    */
    @SerializedName("createTime")
    private Long createTime;
    /**
    * 更新时间
    */
    @SerializedName("updateTime")
    private Long updateTime;
    /**
    * pos/盒子为sn   码为uuid
    */
    @SerializedName("terminalSn")
    private String terminalSn;
    /**
    * pos/盒子为型号  码为桌台号
    */
    @SerializedName("terminalMode")
    private String terminalMode;
    /**
    * 绑定状态:   0:待绑定  1:已绑定   2:终止合作
    */
    @SerializedName("terminalBoundStatus")
    private Integer terminalBoundStatus;
    /**
    * 产品类型
    */
    @SerializedName("productType")
    private Integer productType;

    public Integer getTerminalId() {
        return terminalId;
    }
    public void setTerminalId(Integer terminalId) {
        this.terminalId = terminalId;
    }
    public Integer getProductInstanceId() {
        return productInstanceId;
    }
    public void setProductInstanceId(Integer productInstanceId) {
        this.productInstanceId = productInstanceId;
    }
    public Long getMerchantId() {
        return merchantId;
    }
    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }
    public Long getBindTime() {
        return bindTime;
    }
    public void setBindTime(Long bindTime) {
        this.bindTime = bindTime;
    }
    public Long getCreateTime() {
        return createTime;
    }
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
    public Long getUpdateTime() {
        return updateTime;
    }
    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }
    public String getTerminalSn() {
        return terminalSn;
    }
    public void setTerminalSn(String terminalSn) {
        this.terminalSn = terminalSn;
    }
    public String getTerminalMode() {
        return terminalMode;
    }
    public void setTerminalMode(String terminalMode) {
        this.terminalMode = terminalMode;
    }
    public Integer getTerminalBoundStatus() {
        return terminalBoundStatus;
    }
    public void setTerminalBoundStatus(Integer terminalBoundStatus) {
        this.terminalBoundStatus = terminalBoundStatus;
    }
    public Integer getProductType() {
        return productType;
    }
    public void setProductType(Integer productType) {
        this.productType = productType;
    }




    @Override
    public String toString() {
        return "BoundTerminalInfo{" + "terminalId=" + terminalId + "," + "productInstanceId=" + productInstanceId + "," + "merchantId=" + merchantId + "," + "bindTime=" + bindTime + "," + "createTime=" + createTime + "," + "updateTime=" + updateTime + "," + "terminalSn=" + terminalSn + "," + "terminalMode=" + terminalMode + "," + "terminalBoundStatus=" + terminalBoundStatus + "," + "productType=" + productType + "}";
    }
}
