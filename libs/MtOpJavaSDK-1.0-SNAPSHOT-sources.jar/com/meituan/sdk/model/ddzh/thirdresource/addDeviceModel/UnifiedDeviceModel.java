package com.meituan.sdk.model.ddzh.thirdresource.addDeviceModel;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-43b57349-3812-4b6a-874d-8c80d1e9a594"><span style="color: #333">新增设备型号列表</span></p>
* This file was automatically generated.
*/
public class UnifiedDeviceModel {
    /**
    * <p data-diff-id="ct-diff-id-ddb35f22-8446-43c1-b65c-505b3ad61366"><span style="color: #333">设备类目编码</span></p>
    */
    @NotBlank(message = "categoryCode不能为空")
    @SerializedName("categoryCode")
    private String categoryCode;
    /**
    * <p data-diff-id="ct-diff-id-7c16532a-22b9-42a7-9828-b110f12fe33c">三方型号编码，设备型号在商家侧的唯一标识</p>
    */
    @NotBlank(message = "deviceModelCode不能为空")
    @SerializedName("deviceModelCode")
    private String deviceModelCode;
    /**
    * <p data-diff-id="ct-diff-id-f00134f3-fbba-4d6b-aa90-edd121bfbc44"><span style="color: #333">型号名称</span></p>
    */
    @NotBlank(message = "deviceModelName不能为空")
    @SerializedName("deviceModelName")
    private String deviceModelName;
    /**
    * <p data-diff-id="ct-diff-id-632036b1-0be0-4664-b998-aa1f0164261e"><span style="color: ">型号图片列表</span></p>
    */
    @SerializedName("deviceModelImgs")
    private List<String> deviceModelImgs;
    /**
    * <p data-diff-id="ct-diff-id-1f079dd5-3e92-41fa-89c4-d673c55e6b69"><span style="color: ">是否为联网设备：0-否、1-是</span></p>
    */
    @SerializedName("connectedNetwork")
    private Integer connectedNetwork;
    /**
    * <p data-diff-id="ct-diff-id-4713e35d-c82c-490d-a6df-c598b827da72"><span style="color: ">长，单位cm</span></p>
    */
    @SerializedName("length")
    private Double length;
    /**
    * <p data-diff-id="ct-diff-id-61f99fcc-f772-45e6-96de-ff9de9adbe46">宽，单位cm</p>
    */
    @SerializedName("width")
    private Double width;
    /**
    * <p data-diff-id="ct-diff-id-a82fac8b-3aa4-47fc-8f8c-12bcd3150dc9"><span style="color: ">高，单位cm</span></p>
    */
    @SerializedName("height")
    private Double height;
    /**
    * <p data-diff-id="ct-diff-id-2b770bfe-1a93-4683-9317-798c138234bb"><span style="color: ">上市时间，毫秒级时间戳</span></p>
    */
    @NotNull(message = "launchDate不能为空")
    @SerializedName("launchDate")
    private Long launchDate;
    /**
    * <p data-diff-id="ct-diff-id-d6c07ed2-0d5b-43a0-9cfc-6b7d98f6b4bd"><span style="color: ">可以使用操作的列表：1-继续、2-暂停</span></p>
    */
    @SerializedName("operations")
    private List<Integer> operations;
    /**
    * <p data-diff-id="ct-diff-id-7a928279-9e9d-4e9b-b43b-bfd7c08394a5"><span style="color: ">特征标签列表</span></p>
    */
    @SerializedName("deviceFeatureTags")
    private List<Integer> deviceFeatureTags;
    /**
    * <p data-diff-id="ct-diff-id-ab4744b3-cfc5-48bc-b2a8-b9375ff294d8">相关规则列表</p>
    */
    @SerializedName("rules")
    private DeviceModelRules rules;
    /**
    * <p data-diff-id="ct-diff-id-043b94a5-9fd9-4d5d-b5b1-9f0ef9e0f918">扩展信息列表</p>
    */
    @SerializedName("attrs")
    private List<Attribute> attrs;

    public String getCategoryCode() {
        return categoryCode;
    }
    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }
    public String getDeviceModelCode() {
        return deviceModelCode;
    }
    public void setDeviceModelCode(String deviceModelCode) {
        this.deviceModelCode = deviceModelCode;
    }
    public String getDeviceModelName() {
        return deviceModelName;
    }
    public void setDeviceModelName(String deviceModelName) {
        this.deviceModelName = deviceModelName;
    }
    public List<String> getDeviceModelImgs() {
        return deviceModelImgs;
    }
    public void setDeviceModelImgs(List<String> deviceModelImgs) {
        this.deviceModelImgs = deviceModelImgs;
    }
    public Integer getConnectedNetwork() {
        return connectedNetwork;
    }
    public void setConnectedNetwork(Integer connectedNetwork) {
        this.connectedNetwork = connectedNetwork;
    }
    public Double getLength() {
        return length;
    }
    public void setLength(Double length) {
        this.length = length;
    }
    public Double getWidth() {
        return width;
    }
    public void setWidth(Double width) {
        this.width = width;
    }
    public Double getHeight() {
        return height;
    }
    public void setHeight(Double height) {
        this.height = height;
    }
    public Long getLaunchDate() {
        return launchDate;
    }
    public void setLaunchDate(Long launchDate) {
        this.launchDate = launchDate;
    }
    public List<Integer> getOperations() {
        return operations;
    }
    public void setOperations(List<Integer> operations) {
        this.operations = operations;
    }
    public List<Integer> getDeviceFeatureTags() {
        return deviceFeatureTags;
    }
    public void setDeviceFeatureTags(List<Integer> deviceFeatureTags) {
        this.deviceFeatureTags = deviceFeatureTags;
    }
    public DeviceModelRules getRules() {
        return rules;
    }
    public void setRules(DeviceModelRules rules) {
        this.rules = rules;
    }
    public List<Attribute> getAttrs() {
        return attrs;
    }
    public void setAttrs(List<Attribute> attrs) {
        this.attrs = attrs;
    }




    @Override
    public String toString() {
        return "UnifiedDeviceModel{" + "categoryCode=" + categoryCode + "," + "deviceModelCode=" + deviceModelCode + "," + "deviceModelName=" + deviceModelName + "," + "deviceModelImgs=" + deviceModelImgs + "," + "connectedNetwork=" + connectedNetwork + "," + "length=" + length + "," + "width=" + width + "," + "height=" + height + "," + "launchDate=" + launchDate + "," + "operations=" + operations + "," + "deviceFeatureTags=" + deviceFeatureTags + "," + "rules=" + rules + "," + "attrs=" + attrs + "}";
    }
}
