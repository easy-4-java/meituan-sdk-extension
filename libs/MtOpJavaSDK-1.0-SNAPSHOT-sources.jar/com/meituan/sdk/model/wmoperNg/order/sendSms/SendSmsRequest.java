package com.meituan.sdk.model.wmoperNg.order.sendSms;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 发送短信
* This file was automatically generated.
*/
@ApiMeta(
    path = "/wmoper/ng/order/sendSMS",
    businessId = 16,
    apiVersion = "10088",
    apiName = "send_sms",
    needAuth = true
)
public class SendSmsRequest implements MeituanRequest<SendSmsResponse> {
    /**
    * <p data-diff-id="ct-diff-id-ca87ac10-95df-4145-9b0f-48f5e9e1be1c">接收目标类型，1为订单场景收货人，2为订单场景预订人</p>
    */
    @NotNull(message = "targetType不能为空")
    @SerializedName("targetType")
    private Integer targetType;
    /**
    * <p data-diff-id="ct-diff-id-f31989ab-a696-4b88-a82e-39e51123b6b1">当targetType为1或2时，该参数含义为为订单id，此时会校验合法性</p>
    */
    @NotNull(message = "orderId不能为空")
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-d9069440-f4fe-492b-ae75-f2c567c3738b">短信场景编码，需联系业务获取具体枚举，配置后使用</p>
    */
    @NotNull(message = "sceneCode不能为空")
    @SerializedName("sceneCode")
    private Integer sceneCode;
    /**
    * <p data-diff-id="ct-diff-id-e73e83d5-2d71-4cd9-8054-4408822238c7">短信模板id，需联系业务注册短信模板，配置后使用</p>
    */
    @NotNull(message = "templateId不能为空")
    @SerializedName("templateId")
    private Integer templateId;
    /**
    * <p data-diff-id="ct-diff-id-bbd665ae-b1ec-471e-a109-3c37d4054eaa">模板参数，kv结构。数量上限50个</p>
    */
    @SerializedName("templateParam")
    private String templateParam;

    public Integer getTargetType() {
        return targetType;
    }
    public void setTargetType(Integer targetType) {
        this.targetType = targetType;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public Integer getSceneCode() {
        return sceneCode;
    }
    public void setSceneCode(Integer sceneCode) {
        this.sceneCode = sceneCode;
    }
    public Integer getTemplateId() {
        return templateId;
    }
    public void setTemplateId(Integer templateId) {
        this.templateId = templateId;
    }
    public String getTemplateParam() {
        return templateParam;
    }
    public void setTemplateParam(String templateParam) {
        this.templateParam = templateParam;
    }


    @Override
    public MeituanResponse<SendSmsResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<SendSmsResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "SendSmsRequest{" + "targetType=" + targetType + "," + "orderId=" + orderId + "," + "sceneCode=" + sceneCode + "," + "templateId=" + templateId + "," + "templateParam=" + templateParam + "}";
    }
}
