package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptQuerylistbydate;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 验券记录
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/tuangou/receipt/querylistbydate",
    businessId = 58,
    apiVersion = "10108",
    apiName = "tuangou_receipt_querylistbydate",
    needAuth = true
)
public class TuangouReceiptQuerylistbydateRequest implements MeituanRequest<TuangouReceiptQuerylistbydateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-d35c7ed1-8b13-4927-aa7c-8800e96e8749"><span style="color: rgb(31, 45, 61)">日期（如2016-01-01)</span></p>
    */
    @NotBlank(message = "date不能为空")
    @SerializedName("date")
    private String date;
    /**
    * <p data-diff-id="ct-diff-id-00cc9c90-b87c-4cef-b5f1-3b72bcca2844"><span style="color: rgb(31, 45, 61)">业务类型：</span>0-普通团购 ，205-次卡，203-拼团，206-预订</p>
    */
    @SerializedName("bizType")
    private Integer bizType;
    /**
    * <p data-diff-id="ct-diff-id-99865859-3bfa-486f-a9af-129edcf78a76"><span style="color: rgb(31, 45, 61)">查询起始位置，从0开始</span></p>
    */
    @NotNull(message = "offset不能为空")
    @SerializedName("offset")
    private Integer offset;
    /**
    * <p data-diff-id="ct-diff-id-e4b38d84-1876-4eb0-8438-d77789ec048f"><span style="color: rgb(31, 45, 61)">0：验券记录  ；1  撤销验券记录</span></p>
    */
    @NotNull(message = "type不能为空")
    @SerializedName("type")
    private Integer type;
    /**
    * <p data-diff-id="ct-diff-id-2773b8c2-8c19-4013-bf2c-cb23a0f374ed"><span style="color: rgb(31, 45, 61)">查询条数，最大300</span></p>
    */
    @NotNull(message = "limit不能为空")
    @SerializedName("limit")
    private Integer limit;

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public Integer getBizType() {
        return bizType;
    }
    public void setBizType(Integer bizType) {
        this.bizType = bizType;
    }
    public Integer getOffset() {
        return offset;
    }
    public void setOffset(Integer offset) {
        this.offset = offset;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getLimit() {
        return limit;
    }
    public void setLimit(Integer limit) {
        this.limit = limit;
    }


    @Override
    public MeituanResponse<TuangouReceiptQuerylistbydateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<TuangouReceiptQuerylistbydateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TuangouReceiptQuerylistbydateRequest{" + "date=" + date + "," + "bizType=" + bizType + "," + "offset=" + offset + "," + "type=" + type + "," + "limit=" + limit + "}";
    }
}
