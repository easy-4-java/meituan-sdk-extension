package com.meituan.sdk.model.waimaiNg.dish.foodBatchQueryList;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class DnaInfo {
    /**
    * 类目id
    */
    @SerializedName("categoryId")
    private Long categoryId;
    /**
    * 类目属性list
    */
    @SerializedName("wmProductSpuExtendList")
    private List<WmProductSpuExtend> wmProductSpuExtendList;

    public Long getCategoryId() {
        return categoryId;
    }
    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }
    public List<WmProductSpuExtend> getWmProductSpuExtendList() {
        return wmProductSpuExtendList;
    }
    public void setWmProductSpuExtendList(List<WmProductSpuExtend> wmProductSpuExtendList) {
        this.wmProductSpuExtendList = wmProductSpuExtendList;
    }




    @Override
    public String toString() {
        return "DnaInfo{" + "categoryId=" + categoryId + "," + "wmProductSpuExtendList=" + wmProductSpuExtendList + "}";
    }
}
