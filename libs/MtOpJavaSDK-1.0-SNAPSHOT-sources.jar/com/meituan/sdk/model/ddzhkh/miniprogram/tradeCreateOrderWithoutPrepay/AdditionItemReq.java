package com.meituan.sdk.model.ddzhkh.miniprogram.tradeCreateOrderWithoutPrepay;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-e63f6c28-4f70-4156-90fe-53cb3a99ab28">附加项列表</p>
* This file was automatically generated.
*/
public class AdditionItemReq {
    /**
    * <p data-diff-id="ct-diff-id-2644bd93-1f72-44dd-b4a4-f9aae62fd636">附加项id</p>
    */
    @NotBlank(message = "additionItemId不能为空")
    @SerializedName("additionItemId")
    private String additionItemId;
    /**
    * <p data-diff-id="ct-diff-id-881b97f3-7040-4eaf-9790-bd894530fb2e">附加项名称</p>
    */
    @NotBlank(message = "additionItemName不能为空")
    @SerializedName("additionItemName")
    private String additionItemName;
    /**
    * <p data-diff-id="ct-diff-id-6ba44634-6ecd-4470-998a-1dc0908a5544">附加项的数量</p>
    */
    @NotNull(message = "quantity不能为空")
    @SerializedName("quantity")
    private Integer quantity;
    /**
    * <p data-diff-id="ct-diff-id-2a6ea0cd-d50f-4d06-b1e1-aec0be18aa81">附加项的总价<span style="color: rgb(245, 34, 45)">（单位：分）</span></p>
    */
    @NotNull(message = "totalAmount不能为空")
    @SerializedName("totalAmount")
    private Long totalAmount;

    public String getAdditionItemId() {
        return additionItemId;
    }
    public void setAdditionItemId(String additionItemId) {
        this.additionItemId = additionItemId;
    }
    public String getAdditionItemName() {
        return additionItemName;
    }
    public void setAdditionItemName(String additionItemName) {
        this.additionItemName = additionItemName;
    }
    public Integer getQuantity() {
        return quantity;
    }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
    public Long getTotalAmount() {
        return totalAmount;
    }
    public void setTotalAmount(Long totalAmount) {
        this.totalAmount = totalAmount;
    }




    @Override
    public String toString() {
        return "AdditionItemReq{" + "additionItemId=" + additionItemId + "," + "additionItemName=" + additionItemName + "," + "quantity=" + quantity + "," + "totalAmount=" + totalAmount + "}";
    }
}
