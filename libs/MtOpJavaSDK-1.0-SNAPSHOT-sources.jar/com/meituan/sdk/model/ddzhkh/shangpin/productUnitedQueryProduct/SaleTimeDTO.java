package com.meituan.sdk.model.ddzhkh.shangpin.productUnitedQueryProduct;

import com.google.gson.annotations.SerializedName;

/**
* 售卖时间
* This file was automatically generated.
*/
public class SaleTimeDTO {
    /**
    * 售卖开始时间模式，1-审核通过立即上架 2-指定时间
    */
    @SerializedName("saleStartTimeMode")
    private Integer saleStartTimeMode;
    /**
    * 售卖开始时间
    */
    @SerializedName("saleStartTime")
    private String saleStartTime;
    /**
    * 售卖结束时间模式，1-自动延期 2-指定时间下架
    */
    @SerializedName("saleEndTimeMode")
    private Integer saleEndTimeMode;
    /**
    * 售卖结束时间
    */
    @SerializedName("saleEndTime")
    private String saleEndTime;

    public Integer getSaleStartTimeMode() {
        return saleStartTimeMode;
    }
    public void setSaleStartTimeMode(Integer saleStartTimeMode) {
        this.saleStartTimeMode = saleStartTimeMode;
    }
    public String getSaleStartTime() {
        return saleStartTime;
    }
    public void setSaleStartTime(String saleStartTime) {
        this.saleStartTime = saleStartTime;
    }
    public Integer getSaleEndTimeMode() {
        return saleEndTimeMode;
    }
    public void setSaleEndTimeMode(Integer saleEndTimeMode) {
        this.saleEndTimeMode = saleEndTimeMode;
    }
    public String getSaleEndTime() {
        return saleEndTime;
    }
    public void setSaleEndTime(String saleEndTime) {
        this.saleEndTime = saleEndTime;
    }




    @Override
    public String toString() {
        return "SaleTimeDTO{" + "saleStartTimeMode=" + saleStartTimeMode + "," + "saleStartTime=" + saleStartTime + "," + "saleEndTimeMode=" + saleEndTimeMode + "," + "saleEndTime=" + saleEndTime + "}";
    }
}
