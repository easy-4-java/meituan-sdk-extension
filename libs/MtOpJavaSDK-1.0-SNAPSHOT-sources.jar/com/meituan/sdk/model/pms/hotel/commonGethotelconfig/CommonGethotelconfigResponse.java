package com.meituan.sdk.model.pms.hotel.commonGethotelconfig;

import com.google.gson.annotations.SerializedName;

/**
* 获取系统配置
* This file was automatically generated.
*/
public class CommonGethotelconfigResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    /**
    * 系统参数配置，返回结果类型详见入参说明
    */
    @SerializedName("data")
    private String data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "CommonGethotelconfigResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
