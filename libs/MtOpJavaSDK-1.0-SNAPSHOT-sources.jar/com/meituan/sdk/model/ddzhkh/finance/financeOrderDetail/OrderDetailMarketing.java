package com.meituan.sdk.model.ddzhkh.finance.financeOrderDetail;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 商家营销
* This file was automatically generated.
*/
public class OrderDetailMarketing {
    /**
    *  总额
    */
    @SerializedName("totalAmount")
    private String totalAmount;
    /**
    * 营销明细（已废弃）
    */
    @SerializedName("marketingDetails")
    private MarketingDetail marketingDetails;
    /**
    * 供应商佣金金额
    */
    @SerializedName("supplierCommissionAmount")
    private String supplierCommissionAmount;
    /**
    * 营销明细-新
    */
    @SerializedName("promotionDetails")
    private List<PromotionDetail> promotionDetails;

    public String getTotalAmount() {
        return totalAmount;
    }
    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }
    public MarketingDetail getMarketingDetails() {
        return marketingDetails;
    }
    public void setMarketingDetails(MarketingDetail marketingDetails) {
        this.marketingDetails = marketingDetails;
    }
    public String getSupplierCommissionAmount() {
        return supplierCommissionAmount;
    }
    public void setSupplierCommissionAmount(String supplierCommissionAmount) {
        this.supplierCommissionAmount = supplierCommissionAmount;
    }
    public List<PromotionDetail> getPromotionDetails() {
        return promotionDetails;
    }
    public void setPromotionDetails(List<PromotionDetail> promotionDetails) {
        this.promotionDetails = promotionDetails;
    }




    @Override
    public String toString() {
        return "OrderDetailMarketing{" + "totalAmount=" + totalAmount + "," + "marketingDetails=" + marketingDetails + "," + "supplierCommissionAmount=" + supplierCommissionAmount + "," + "promotionDetails=" + promotionDetails + "}";
    }
}
