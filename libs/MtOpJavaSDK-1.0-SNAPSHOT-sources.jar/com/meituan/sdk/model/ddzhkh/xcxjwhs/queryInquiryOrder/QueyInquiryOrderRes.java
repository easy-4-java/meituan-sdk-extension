package com.meituan.sdk.model.ddzhkh.xcxjwhs.queryInquiryOrder;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 请求结果
* This file was automatically generated.
*/
public class QueyInquiryOrderRes {
    /**
    * spu id
    */
    @SerializedName("spuId")
    private Long spuId;
    /**
    * 下单用户的MD5加密，三方用来做风控
    */
    @SerializedName("userIdMD5")
    private String userIdMD5;
    /**
    * 经度
    */
    @SerializedName("lng")
    private String lng;
    /**
    * 纬度
    */
    @SerializedName("lat")
    private String lat;
    /**
    * 行政区
    */
    @SerializedName("districtId")
    private String districtId;
    /**
    * 问卷版本
    */
    @SerializedName("qaAnwserVersion")
    private String qaAnwserVersion;
    /**
    * 模板版本
    */
    @SerializedName("spuVersion")
    private String spuVersion;
    /**
    * 详情
    */
    @SerializedName("qaDetail")
    private List<InquiryOrderRes> qaDetail;

    public Long getSpuId() {
        return spuId;
    }
    public void setSpuId(Long spuId) {
        this.spuId = spuId;
    }
    public String getUserIdMD5() {
        return userIdMD5;
    }
    public void setUserIdMD5(String userIdMD5) {
        this.userIdMD5 = userIdMD5;
    }
    public String getLng() {
        return lng;
    }
    public void setLng(String lng) {
        this.lng = lng;
    }
    public String getLat() {
        return lat;
    }
    public void setLat(String lat) {
        this.lat = lat;
    }
    public String getDistrictId() {
        return districtId;
    }
    public void setDistrictId(String districtId) {
        this.districtId = districtId;
    }
    public String getQaAnwserVersion() {
        return qaAnwserVersion;
    }
    public void setQaAnwserVersion(String qaAnwserVersion) {
        this.qaAnwserVersion = qaAnwserVersion;
    }
    public String getSpuVersion() {
        return spuVersion;
    }
    public void setSpuVersion(String spuVersion) {
        this.spuVersion = spuVersion;
    }
    public List<InquiryOrderRes> getQaDetail() {
        return qaDetail;
    }
    public void setQaDetail(List<InquiryOrderRes> qaDetail) {
        this.qaDetail = qaDetail;
    }




    @Override
    public String toString() {
        return "QueyInquiryOrderRes{" + "spuId=" + spuId + "," + "userIdMD5=" + userIdMD5 + "," + "lng=" + lng + "," + "lat=" + lat + "," + "districtId=" + districtId + "," + "qaAnwserVersion=" + qaAnwserVersion + "," + "spuVersion=" + spuVersion + "," + "qaDetail=" + qaDetail + "}";
    }
}
