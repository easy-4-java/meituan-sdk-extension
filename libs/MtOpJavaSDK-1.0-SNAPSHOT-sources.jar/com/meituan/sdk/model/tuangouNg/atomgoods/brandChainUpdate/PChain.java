package com.meituan.sdk.model.tuangouNg.atomgoods.brandChainUpdate;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-593c08c2-3649-413c-923b-508b368585ad">批量更新的总部信息</p>
* This file was automatically generated.
*/
public class PChain {
    /**
    * <p data-diff-id="ct-diff-id-78f2336f-f036-46fa-a75d-23e31e97a163">总部id</p>
    */
    @NotBlank(message = "vendorChainId不能为空")
    @SerializedName("vendorChainId")
    private String vendorChainId;
    /**
    * <p data-diff-id="ct-diff-id-1da73e76-66d0-4057-b369-8be5f1480a2f">总部名称</p>
    */
    @NotBlank(message = "vendorChainName不能为空")
    @SerializedName("vendorChainName")
    private String vendorChainName;
    /**
    * <p data-diff-id="ct-diff-id-069d2d68-7754-4f22-a3bc-0b2eef981a28">父级总部id，如果不存在，为null</p>
    */
    @SerializedName("vendorParentChainId")
    private String vendorParentChainId;
    /**
    * <p data-diff-id="ct-diff-id-b4a01223-4cc5-4cfe-b7ba-e4d8a1d00809">状态，1-绑定，2-作废</p>
    */
    @NotNull(message = "status不能为空")
    @SerializedName("status")
    private Integer status;

    public String getVendorChainId() {
        return vendorChainId;
    }
    public void setVendorChainId(String vendorChainId) {
        this.vendorChainId = vendorChainId;
    }
    public String getVendorChainName() {
        return vendorChainName;
    }
    public void setVendorChainName(String vendorChainName) {
        this.vendorChainName = vendorChainName;
    }
    public String getVendorParentChainId() {
        return vendorParentChainId;
    }
    public void setVendorParentChainId(String vendorParentChainId) {
        this.vendorParentChainId = vendorParentChainId;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }




    @Override
    public String toString() {
        return "PChain{" + "vendorChainId=" + vendorChainId + "," + "vendorChainName=" + vendorChainName + "," + "vendorParentChainId=" + vendorParentChainId + "," + "status=" + status + "}";
    }
}
