package com.meituan.sdk.model.ddzhkh.generalreserve.generalreserveReserveMerchantmodify;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 商家改约
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/generalreserve/reserve/merchantmodify",
    businessId = 59,
    apiVersion = "10004",
    apiName = "generalreserve_reserve_merchantmodify",
    needAuth = true
)
public class GeneralreserveReserveMerchantmodifyRequest implements MeituanRequest<GeneralreserveReserveMerchantmodifyResponse> {
    /**
    * <p data-diff-id="ct-diff-id-f5f0cd45-472f-4549-9647-7dbf1aab173c"><span style="color: rgb(31, 45, 61)">预约单id</span></p>
    */
    @NotNull(message = "leadsId不能为空")
    @SerializedName("leadsId")
    private Long leadsId;
    /**
    * <p data-diff-id="ct-diff-id-ccf18289-ddde-4d82-a995-a4f95172f3d3"><span style="color: rgb(31, 45, 61)">电话号码</span></p>
    */
    @SerializedName("phone")
    private String phone;
    /**
    * <p data-diff-id="ct-diff-id-d98e0402-9737-4a3e-9820-b7bca32d3051">美团门店id</p><p data-diff-id="ct-diff-id-4350cad9-5bd1-4fde-b8e1-de4f1783232e"><span style="color: rgba(0, 0, 0, 0.87)">该字段是混淆字段，实际值类型为混淆后的字符串类型</span></p>
    */
    @NotBlank(message = "opPoiId不能为空")
    @SerializedName("opPoiId")
    private String opPoiId;
    /**
    * <p data-diff-id="ct-diff-id-6cbab819-5a81-479d-a824-6df5744c1eed"><span style="color: rgb(31, 45, 61)">联系方式</span></p>
    */
    @SerializedName("otherContact")
    private String otherContact;
    /**
    * <p data-diff-id="ct-diff-id-ba963aa9-7fd9-4591-86aa-e7a17eac1e0b"><span style="color: rgb(31, 45, 61)">联系方式类型（0：无联系(未授权联系方式) 1：虚拟号 2：真实手机号）</span></p>
    */
    @SerializedName("otherContactType")
    private Integer otherContactType;
    /**
    * <p data-diff-id="ct-diff-id-9c89f0be-cff2-4ad8-ad04-aa8e1e585023"><span style="color: rgb(31, 45, 61)">业务来源ID</span></p>
    */
    @SerializedName("bizSourceId")
    private String bizSourceId;
    /**
    * <p data-diff-id="ct-diff-id-9ccb2f06-dae3-4a52-99ec-5c57b1b48259"><span style="color: rgb(31, 45, 61)">预约开始时间</span></p>
    */
    @SerializedName("bookingStartTime")
    private Long bookingStartTime;
    /**
    * <p data-diff-id="ct-diff-id-70fee25c-b6f5-435b-a713-a4894996b51c"><span style="color: rgb(31, 45, 61)">预约结束时间</span></p>
    */
    @SerializedName("bookingEndTime")
    private Long bookingEndTime;
    /**
    * <p data-diff-id="ct-diff-id-e2763371-b409-43a0-a86e-fb5cd442f7dd"><span style="color: rgb(31, 45, 61)">属性信息</span></p>
    */
    @SerializedName("leadsAttributeList")
    private LeadsAttributeMap leadsAttributeList;
    /**
    * <p data-diff-id="ct-diff-id-244199e5-d3ce-449d-b295-4fc815134530"><span style="color: rgb(31, 45, 61)">订单属性列表</span></p>
    */
    @SerializedName("leadsReferList")
    private List<ThirdReferDTO> leadsReferList;
    /**
    * <p data-diff-id="ct-diff-id-b8bc264c-d42e-43a8-ad60-f06dcdb27fb7"><span style="color: rgb(31, 45, 61)">商户备注</span></p>
    */
    @SerializedName("merchantRemark")
    private String merchantRemark;
    /**
    * <p data-diff-id="ct-diff-id-a02f33f5-26d4-4248-94f4-a66dadf0fdd7"><span style="color: rgb(31, 45, 61)">扩展字段</span></p>
    */
    @SerializedName("extraMap")
    private String extraMap;

    public Long getLeadsId() {
        return leadsId;
    }
    public void setLeadsId(Long leadsId) {
        this.leadsId = leadsId;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getOpPoiId() {
        return opPoiId;
    }
    public void setOpPoiId(String opPoiId) {
        this.opPoiId = opPoiId;
    }
    public String getOtherContact() {
        return otherContact;
    }
    public void setOtherContact(String otherContact) {
        this.otherContact = otherContact;
    }
    public Integer getOtherContactType() {
        return otherContactType;
    }
    public void setOtherContactType(Integer otherContactType) {
        this.otherContactType = otherContactType;
    }
    public String getBizSourceId() {
        return bizSourceId;
    }
    public void setBizSourceId(String bizSourceId) {
        this.bizSourceId = bizSourceId;
    }
    public Long getBookingStartTime() {
        return bookingStartTime;
    }
    public void setBookingStartTime(Long bookingStartTime) {
        this.bookingStartTime = bookingStartTime;
    }
    public Long getBookingEndTime() {
        return bookingEndTime;
    }
    public void setBookingEndTime(Long bookingEndTime) {
        this.bookingEndTime = bookingEndTime;
    }
    public LeadsAttributeMap getLeadsAttributeList() {
        return leadsAttributeList;
    }
    public void setLeadsAttributeList(LeadsAttributeMap leadsAttributeList) {
        this.leadsAttributeList = leadsAttributeList;
    }
    public List<ThirdReferDTO> getLeadsReferList() {
        return leadsReferList;
    }
    public void setLeadsReferList(List<ThirdReferDTO> leadsReferList) {
        this.leadsReferList = leadsReferList;
    }
    public String getMerchantRemark() {
        return merchantRemark;
    }
    public void setMerchantRemark(String merchantRemark) {
        this.merchantRemark = merchantRemark;
    }
    public String getExtraMap() {
        return extraMap;
    }
    public void setExtraMap(String extraMap) {
        this.extraMap = extraMap;
    }


    @Override
    public MeituanResponse<GeneralreserveReserveMerchantmodifyResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<GeneralreserveReserveMerchantmodifyResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GeneralreserveReserveMerchantmodifyRequest{" + "leadsId=" + leadsId + "," + "phone=" + phone + "," + "opPoiId=" + opPoiId + "," + "otherContact=" + otherContact + "," + "otherContactType=" + otherContactType + "," + "bizSourceId=" + bizSourceId + "," + "bookingStartTime=" + bookingStartTime + "," + "bookingEndTime=" + bookingEndTime + "," + "leadsAttributeList=" + leadsAttributeList + "," + "leadsReferList=" + leadsReferList + "," + "merchantRemark=" + merchantRemark + "," + "extraMap=" + extraMap + "}";
    }
}
