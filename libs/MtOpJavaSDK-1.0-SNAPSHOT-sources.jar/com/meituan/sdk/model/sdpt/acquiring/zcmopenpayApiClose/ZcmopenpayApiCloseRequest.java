package com.meituan.sdk.model.sdpt.acquiring.zcmopenpayApiClose;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 美团收单[扫码支付]订单关闭接口
* This file was automatically generated.
*/
@ApiMeta(
    path = "/sdpt/acquiring/api/close",
    businessId = 52,
    apiVersion = "10115",
    apiName = "zcmopenpay_api_close",
    needAuth = false
)
public class ZcmopenpayApiCloseRequest implements MeituanRequest<ZcmopenpayApiCloseResponse> {
    /**
    * <p data-diff-id="ct-diff-id-9abe1594-702b-42cd-8e9c-b380d944adca"><span style="color: ">接入方订单号</span></p>
    */
    @NotBlank(message = "outTradeNo不能为空")
    @SerializedName("outTradeNo")
    private String outTradeNo;
    /**
    * <p data-diff-id="ct-diff-id-d645b796-d0dc-4693-9173-b844542a609c"><span style="color: ">开放平台分配的商户id, 目前是 美团POI ID</span></p>
    */
    @NotNull(message = "merchantId不能为空")
    @SerializedName("merchantId")
    private Integer merchantId;

    public String getOutTradeNo() {
        return outTradeNo;
    }
    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }
    public Integer getMerchantId() {
        return merchantId;
    }
    public void setMerchantId(Integer merchantId) {
        this.merchantId = merchantId;
    }


    @Override
    public MeituanResponse<ZcmopenpayApiCloseResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ZcmopenpayApiCloseResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ZcmopenpayApiCloseRequest{" + "outTradeNo=" + outTradeNo + "," + "merchantId=" + merchantId + "}";
    }
}
