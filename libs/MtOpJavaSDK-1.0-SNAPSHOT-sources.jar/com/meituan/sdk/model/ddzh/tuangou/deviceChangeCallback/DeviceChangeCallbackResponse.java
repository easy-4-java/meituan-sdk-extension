package com.meituan.sdk.model.ddzh.tuangou.deviceChangeCallback;

import com.google.gson.annotations.SerializedName;

/**
* 设备启动/操作的结果回调
* This file was automatically generated.
*/
public class DeviceChangeCallbackResponse {
    /**
    * 是否同步成功
    */
    @SerializedName("isSuccess")
    private Boolean isSuccess;

    public Boolean getIsSuccess() {
        return isSuccess;
    }
    public void setIsSuccess(Boolean isSuccess) {
        this.isSuccess = isSuccess;
    }




    @Override
    public String toString() {
        return "DeviceChangeCallbackResponse{" + "isSuccess=" + isSuccess + "}";
    }
}
