package com.meituan.sdk.model.tuangouNg.atomgoods.productSubjectStatusUpdate;


/**
* 更新菜品主体售卖状态
* This file was automatically generated.
*/
public class ProductSubjectStatusUpdateResponse {





}
