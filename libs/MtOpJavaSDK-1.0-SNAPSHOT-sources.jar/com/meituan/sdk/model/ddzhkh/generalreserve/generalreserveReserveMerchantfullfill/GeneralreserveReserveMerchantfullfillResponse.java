package com.meituan.sdk.model.ddzhkh.generalreserve.generalreserveReserveMerchantfullfill;

import com.google.gson.annotations.SerializedName;

/**
* 商家履约
* This file was automatically generated.
*/
public class GeneralreserveReserveMerchantfullfillResponse {
    /**
    * 成功/失败
    */
    @SerializedName("result")
    private Boolean result;

    public Boolean getResult() {
        return result;
    }
    public void setResult(Boolean result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "GeneralreserveReserveMerchantfullfillResponse{" + "result=" + result + "}";
    }
}
