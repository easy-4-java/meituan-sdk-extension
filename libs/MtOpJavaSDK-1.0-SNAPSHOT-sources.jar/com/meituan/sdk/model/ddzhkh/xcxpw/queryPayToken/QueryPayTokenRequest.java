package com.meituan.sdk.model.ddzhkh.xcxpw.queryPayToken;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询支付token
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/xcxpw/query_pay_token",
    businessId = 59,
    apiVersion = "10018",
    apiName = "query_pay_token",
    needAuth = true
)
public class QueryPayTokenRequest implements MeituanRequest<QueryPayTokenResponse> {
    @NotBlank(message = "generalBizData不能为空")
    @SerializedName("generalBizData")
    private String generalBizData;
    @NotNull(message = "queryPayTokenReq不能为空")
    @SerializedName("queryPayTokenReq")
    private QueryPayTokenReq queryPayTokenReq;

    public String getGeneralBizData() {
        return generalBizData;
    }
    public void setGeneralBizData(String generalBizData) {
        this.generalBizData = generalBizData;
    }
    public QueryPayTokenReq getQueryPayTokenReq() {
        return queryPayTokenReq;
    }
    public void setQueryPayTokenReq(QueryPayTokenReq queryPayTokenReq) {
        this.queryPayTokenReq = queryPayTokenReq;
    }


    @Override
    public MeituanResponse<QueryPayTokenResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<QueryPayTokenResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "QueryPayTokenRequest{" + "generalBizData=" + generalBizData + "," + "queryPayTokenReq=" + queryPayTokenReq + "}";
    }
}
