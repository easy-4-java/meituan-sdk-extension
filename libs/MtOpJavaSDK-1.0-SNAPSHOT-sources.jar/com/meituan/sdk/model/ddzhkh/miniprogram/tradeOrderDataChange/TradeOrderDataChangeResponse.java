package com.meituan.sdk.model.ddzhkh.miniprogram.tradeOrderDataChange;

import com.google.gson.annotations.SerializedName;

/**
* 订单数据同步
* This file was automatically generated.
*/
public class TradeOrderDataChangeResponse {
    /**
    * 系统交互结果
    */
    @SerializedName("extra")
    private ExtraData extra;
    /**
    * 业务交互结果
    */
    @SerializedName("res")
    private TradeInwardRes res;

    public ExtraData getExtra() {
        return extra;
    }
    public void setExtra(ExtraData extra) {
        this.extra = extra;
    }
    public TradeInwardRes getRes() {
        return res;
    }
    public void setRes(TradeInwardRes res) {
        this.res = res;
    }




    @Override
    public String toString() {
        return "TradeOrderDataChangeResponse{" + "extra=" + extra + "," + "res=" + res + "}";
    }
}
