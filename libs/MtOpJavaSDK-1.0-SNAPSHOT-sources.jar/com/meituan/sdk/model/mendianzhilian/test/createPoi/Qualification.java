package com.meituan.sdk.model.mendianzhilian.test.createPoi;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-49b69b2e-7cf6-486a-8846-4f46baef6193">资质举证列表</p>
* This file was automatically generated.
*/
public class Qualification {
    /**
    * <p data-diff-id="ct-diff-id-9c7c22af-03c3-4422-9df7-590153fdcae6">资质类型。当前可用的取值：</p><ol data-diff-id="ct-diff-id-93ae4615-1f15-43e9-8913-b6d5dbc35298"><li data-list-item-diff-id="ct-list-item-diff-id-f74bf3fa-9e2a-4bb0-b88d-04c8f0ba8416"><p data-diff-id="ct-diff-id-d54a7c39-e1db-4c2a-b3a3-7f1bc1ea8c32"><span style="color: rgb(6, 125, 23)">frontPic：门头图</span></p></li><li data-list-item-diff-id="ct-list-item-diff-id-08269697-bf32-46f2-b6e8-dc9293404de1"><p data-diff-id="ct-diff-id-c6f0917b-6896-4013-8676-6edb50ec34ff"><span style="color: rgb(6, 125, 23)">bizLicense：营业执照</span></p></li><li data-list-item-diff-id="ct-list-item-diff-id-99f088ca-5587-4963-a1cd-db3ae01d49fc"><p data-diff-id="ct-diff-id-2d30e912-4948-413e-bb53-5a5547921a88"><span style="color: rgb(6, 125, 23)">brandAuthorization：品牌授权书</span></p></li></ol>
    */
    @SerializedName("type")
    private String type;
    /**
    * <p data-diff-id="ct-diff-id-755c5913-76f4-4ec4-b1e0-0ebfaaf564b9">资质内容, 通常为图片链接.</p>
    */
    @SerializedName("content")
    private String content;

    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }




    @Override
    public String toString() {
        return "Qualification{" + "type=" + type + "," + "content=" + content + "}";
    }
}
