package com.meituan.sdk.model.ddzhkh.shangpin.productProductCreate;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-68403f96-c932-4688-83be-f5b7d83e49c0">商品信息</p>
* This file was automatically generated.
*/
public class Product {
    /**
    * <p data-diff-id="ct-diff-id-545932b5-ec7f-4b07-aaa2-c61be0a8d3a2"><span style="color: rgb(31, 45, 61)">美团商品名称，长度限制&lt;=30</span></p>
    */
    @NotBlank(message = "productName不能为空")
    @SerializedName("productName")
    private String productName;
    /**
    * <p data-diff-id="ct-diff-id-e6df8fac-69fc-4e53-968d-d52383badff4"><span style="color: rgb(31, 45, 61)">三方商品ID</span>（注意:<span style="color: rgb(245, 34, 45)">场馆预订</span>行业该字段值必须是<span style="color: rgb(245, 34, 45)">纯数字</span>）</p>
    */
    @NotBlank(message = "appProductId不能为空")
    @SerializedName("appProductId")
    private String appProductId;
    /**
    * <p data-diff-id="ct-diff-id-2220185f-8f42-4068-9938-a4fd983d0a2b"><span style="color: rgb(51, 51, 51)">美团商品品类列表，三方需确定要接入商品品类和品类ID，例如</span>医美预付<span style="color: rgb(51, 51, 51)">：[</span>100028<span style="color: rgb(51, 51, 51)">,</span>850<span style="color: rgb(51, 51, 51)">]，场馆预订：[100060,1650],</span>酒吧选座预订<span style="color: rgb(51, 51, 51)">[</span>100004<span style="color: rgb(51, 51, 51)">,</span>2000327<span style="color: rgb(51, 51, 51)">]，请参考下面品类列表，或查询商品信息接口</span> <a class="ct-link" href="https://developer.meituan.com/docs/api/ddzhkh-shangpin-product-loadproduct" data-auto_update="0">https://developer.meituan.com/docs/api/ddzhkh-shangpin-product-loadproduct</a> <span style="color: rgb(51, 51, 51)">业务响应参数categoryIds字段值</span></p><p data-diff-id="ct-diff-id-40fd46c3-6472-479c-b0d2-c0a98fa846c8"><span style="color: rgb(31, 45, 61)">品类列表</span></p><table class="responsive" data-borderwidth="1" data-diff-id="ct-diff-id-950b1498-4926-4570-817a-11cf6a1fddd9"><tbody><tr data-row-diff-id="ct-tr-diff-id-f11521ce-eb5f-4a92-8f7d-f925acc47714"><th data-colwidth="96" width="96" data-cell-diff-id="ct-cell-diff-id-070ed6ab-9265-45d5-8d4d-f54191704cf7"><p data-diff-id="ct-diff-id-a50b9611-66ab-49a2-bfc4-f4743bb2c794">一级品类</p></th><th data-colwidth="91" width="91" data-cell-diff-id="ct-cell-diff-id-a54a127a-ca45-45dc-82ea-fd5d85aeb948"><p data-diff-id="ct-diff-id-39964d28-f765-4620-b8eb-b1abd04b55ef">二级类目</p></th><th data-colwidth="114" width="114" data-cell-diff-id="ct-cell-diff-id-cb6d4654-2edf-466a-b874-9e9f6d32e895"><p data-diff-id="ct-diff-id-aeea3ce5-67f7-49c3-a7b1-eeed669a26e4">二级类目名称</p></th></tr><tr data-row-diff-id="ct-tr-diff-id-d75d7476-0a9c-49c4-9506-eea24255cbcd"><td data-colwidth="96" width="96" style="background-color: rgb(250, 250, 250);vertical-align:middle;" data-cell-diff-id="ct-cell-diff-id-7ecb2903-4eca-4d0c-ad74-429775b10c43"><p data-diff-id="ct-diff-id-3d8281a8-a3ae-4314-9b95-1531b7b10a68">100028</p></td><td data-colwidth="91" width="91" style="background-color: rgb(250, 250, 250);vertical-align:middle;" data-cell-diff-id="ct-cell-diff-id-3be2a67a-1557-4bd5-989f-ee035948b057"><p data-diff-id="ct-diff-id-0a27e452-fa48-46f1-bed0-c743775a54e6">850</p></td><td data-colwidth="114" width="114" style="background-color: rgb(250, 250, 250);vertical-align:middle;" data-cell-diff-id="ct-cell-diff-id-b6f5acb4-e00c-4013-9b7d-3ea575a553f7"><p data-diff-id="ct-diff-id-64e03982-0b1f-4c63-8747-2abd11f74457">医美预付</p></td></tr><tr data-row-diff-id="ct-tr-diff-id-70e1e138-6d64-40a2-941f-1743859f052e"><td data-colwidth="96" width="96" style="vertical-align:middle;" data-cell-diff-id="ct-cell-diff-id-e263a891-17be-447b-a302-ce7b4f37d661"><p data-diff-id="ct-diff-id-de096aa2-f3f8-4006-82a7-517c2a64e63a">100060</p></td><td data-colwidth="91" width="91" style="vertical-align:middle;" data-cell-diff-id="ct-cell-diff-id-d791672b-9b29-48aa-af53-3ae91f410819"><p data-diff-id="ct-diff-id-871ce7a3-8ca6-40f6-a876-72e0504e91b1">1650</p></td><td data-colwidth="114" width="114" style="vertical-align:middle;" data-cell-diff-id="ct-cell-diff-id-87577169-c610-4ada-9338-555dd1c9cabd"><p data-diff-id="ct-diff-id-ee811fb8-313f-4472-87e0-9fc5630970f1">场馆预订</p></td></tr><tr data-row-diff-id="ct-tr-diff-id-292e23ec-27d1-4022-8757-fced84809dfd"><td data-colwidth="96" width="96" style="vertical-align:middle;" data-cell-diff-id="ct-cell-diff-id-7ad63be7-f2a3-4bf6-9f18-d574ab6086fa"><p data-diff-id="ct-diff-id-7d6fbaaf-7ddc-4068-8166-c6c221f9a9a9">100004</p></td><td data-colwidth="91" width="91" style="vertical-align:middle;" data-cell-diff-id="ct-cell-diff-id-65266b93-36cd-47dc-8b22-ab9e268e94c9"><p data-diff-id="ct-diff-id-0ac197c9-79ac-4866-92bc-bef24b0ed61b">2000327</p></td><td data-colwidth="114" width="114" style="vertical-align:middle;" data-cell-diff-id="ct-cell-diff-id-2efb08b5-96fb-4fd3-bf8b-e8d7daba4c44"><p data-diff-id="ct-diff-id-8b4b78ea-203e-4b7c-8c4c-f1673fec8159">酒吧选座预订</p></td></tr><tr data-row-diff-id="ct-tr-diff-id-e06434c8-3181-442c-b145-8885d0351d8f"><td data-colwidth="96" width="96" style="vertical-align:middle;" data-cell-diff-id="ct-cell-diff-id-177fae2d-e1bc-4727-abe6-21168d0d0f2a"><p data-diff-id="ct-diff-id-bdf181c7-7d48-480c-ba0d-86fc1145f67a">1000007</p></td><td data-colwidth="91" width="91" style="vertical-align:middle;" data-cell-diff-id="ct-cell-diff-id-1883667b-aa7d-4270-b0b2-ce0c68c19ec5"><p data-diff-id="ct-diff-id-45e50007-64cd-46a8-8bbe-f33d77f421b8">2000601</p></td><td data-colwidth="114" width="114" style="vertical-align:middle;" data-cell-diff-id="ct-cell-diff-id-cf601ec8-d4e3-4dac-9d3c-031b003494aa"><p data-diff-id="ct-diff-id-bae57dfd-c3b7-4ffb-8476-12334167cb24">体检加项</p></td></tr></tbody></table>
    */
    @NotEmpty(message = "categoryIds不能为空")
    @SerializedName("categoryIds")
    private List<Long> categoryIds;
    /**
    * <p data-diff-id="ct-diff-id-6cecc8a3-bc1f-47b4-ae55-7ef6e73392cb"><span style="color: rgb(31, 45, 61)">美团店铺id列表</span></p>
    */
    @NotEmpty(message = "opPoiIds不能为空")
    @SerializedName("opPoiIds")
    private List<String> opPoiIds;
    /**
    * <p data-diff-id="ct-diff-id-b6185cec-9a43-46d6-8eb2-3e9585a2c444"><span style="color: rgb(31, 45, 61)">商品属性，Map&lt;Long,List&lt;String&gt;&gt;格式</span></p>
    */
    @NotBlank(message = "attributes不能为空")
    @SerializedName("attributes")
    private String attributes;
    /**
    * <p data-diff-id="ct-diff-id-22c957b4-e848-4154-9599-21989c8aab37"><span style="color: rgb(31, 45, 61)">售卖SKU列表</span></p>
    */
    @NotEmpty(message = "items不能为空")
    @SerializedName("items")
    private List<Item> items;

    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public String getAppProductId() {
        return appProductId;
    }
    public void setAppProductId(String appProductId) {
        this.appProductId = appProductId;
    }
    public List<Long> getCategoryIds() {
        return categoryIds;
    }
    public void setCategoryIds(List<Long> categoryIds) {
        this.categoryIds = categoryIds;
    }
    public List<String> getOpPoiIds() {
        return opPoiIds;
    }
    public void setOpPoiIds(List<String> opPoiIds) {
        this.opPoiIds = opPoiIds;
    }
    public String getAttributes() {
        return attributes;
    }
    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }
    public List<Item> getItems() {
        return items;
    }
    public void setItems(List<Item> items) {
        this.items = items;
    }




    @Override
    public String toString() {
        return "Product{" + "productName=" + productName + "," + "appProductId=" + appProductId + "," + "categoryIds=" + categoryIds + "," + "opPoiIds=" + opPoiIds + "," + "attributes=" + attributes + "," + "items=" + items + "}";
    }
}
