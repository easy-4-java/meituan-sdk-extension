package com.meituan.sdk.model.ddzh.thirdresource.addDeviceModel;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 新增设备型号信息
* This file was automatically generated.
*/
public class AddDeviceModelResponse {
    /**
    * 上传失败数量
    */
    @SerializedName("failureCount")
    private Integer failureCount;
    /**
    * 上传失败的具体信息
    */
    @SerializedName("failureDetails")
    private List<RFailedDetail> failureDetails;

    public Integer getFailureCount() {
        return failureCount;
    }
    public void setFailureCount(Integer failureCount) {
        this.failureCount = failureCount;
    }
    public List<RFailedDetail> getFailureDetails() {
        return failureDetails;
    }
    public void setFailureDetails(List<RFailedDetail> failureDetails) {
        this.failureDetails = failureDetails;
    }




    @Override
    public String toString() {
        return "AddDeviceModelResponse{" + "failureCount=" + failureCount + "," + "failureDetails=" + failureDetails + "}";
    }
}
