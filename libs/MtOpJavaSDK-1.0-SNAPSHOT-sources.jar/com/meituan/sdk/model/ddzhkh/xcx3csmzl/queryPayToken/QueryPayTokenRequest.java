package com.meituan.sdk.model.ddzhkh.xcx3csmzl.queryPayToken;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询支付token
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/xcx3csmzl/query_pay_token",
    businessId = 59,
    apiVersion = "10019",
    apiName = "query_pay_token",
    needAuth = true
)
public class QueryPayTokenRequest implements MeituanRequest<QueryPayTokenResponse> {
    /**
    * <p data-diff-id="ct-diff-id-97aab001-ca89-4de3-af0c-77d1881df833">用前端SDK生成</p>
    */
    @NotBlank(message = "generalBizData不能为空")
    @SerializedName("generalBizData")
    private String generalBizData;
    @NotNull(message = "queryPayTokenReq不能为空")
    @SerializedName("queryPayTokenReq")
    private QueryPayTokenReq queryPayTokenReq;

    public String getGeneralBizData() {
        return generalBizData;
    }
    public void setGeneralBizData(String generalBizData) {
        this.generalBizData = generalBizData;
    }
    public QueryPayTokenReq getQueryPayTokenReq() {
        return queryPayTokenReq;
    }
    public void setQueryPayTokenReq(QueryPayTokenReq queryPayTokenReq) {
        this.queryPayTokenReq = queryPayTokenReq;
    }


    @Override
    public MeituanResponse<QueryPayTokenResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<QueryPayTokenResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "QueryPayTokenRequest{" + "generalBizData=" + generalBizData + "," + "queryPayTokenReq=" + queryPayTokenReq + "}";
    }
}
