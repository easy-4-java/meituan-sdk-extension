package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiBusinessPoiCommonProductApply;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p style="text-align: start;" data-diff-id="ct-diff-id-2e9e0e37-75f7-4a57-83f1-cbbaf84c0823">服务费率列表。<span style="color: rgb(245, 34, 45)">不参与签名。</span></p>
* This file was automatically generated.
*/
public class Rate {
    /**
    * <p data-diff-id="ct-diff-id-8665129b-df1f-436c-90b4-8592abcc59fc">服务类型</p><p style="text-align: start;" data-diff-id="ct-diff-id-b0ec27ea-b27e-40b2-9542-f4785732c18b">1：借记卡</p><p style="text-align: start;" data-diff-id="ct-diff-id-3043b527-fb05-48ed-9875-9f38351a872a">2：贷记卡</p><p style="text-align: start;" data-diff-id="ct-diff-id-6efc24d2-15e5-4a21-b1ca-02117cdf0be1">3：微信</p><p style="text-align: start;" data-diff-id="ct-diff-id-99f650be-151f-4e32-a1bf-a5b12371885d">4：支付宝</p><p style="text-align: start;" data-diff-id="ct-diff-id-194a684e-4ded-4b90-a686-c19147944306">5：  美团支付</p><p style="text-align: start;" data-diff-id="ct-diff-id-7d32740d-bbe4-43aa-a805-2f78fb71e151">6：银联二维码-借记卡</p><p style="text-align: start;" data-diff-id="ct-diff-id-d70a4394-2de0-487b-9923-aaeb09fca358">7：银联二维码-贷记卡</p>
    */
    @NotNull(message = "serviceType不能为空")
    @SerializedName("serviceType")
    private Integer serviceType;
    /**
    * <p data-diff-id="ct-diff-id-65b8a27e-3e0d-4a9d-acde-9c79ac805ec9">费率</p><p style="text-align: start;" data-diff-id="ct-diff-id-b4685685-89e7-45c0-aaf2-ffe35e0579d1">大于等于0，小于等于0.01</p>
    */
    @NotNull(message = "rate不能为空")
    @SerializedName("rate")
    private Double rate;
    /**
    * <p data-diff-id="ct-diff-id-eab0bbaf-9702-4d7d-9e9a-b0fc7a25d5af"><span style="color: #333">1 不封顶，2 封顶</span></p>
    */
    @SerializedName("deductionType")
    private Integer deductionType;
    /**
    * <p data-diff-id="ct-diff-id-9e4f88aa-1ad3-4650-8490-c89b5e21f4e2"><span style="color: #333">封顶金额，设置了封顶上限时必传</span></p>
    */
    @SerializedName("cappingMoney")
    private String cappingMoney;

    public Integer getServiceType() {
        return serviceType;
    }
    public void setServiceType(Integer serviceType) {
        this.serviceType = serviceType;
    }
    public Double getRate() {
        return rate;
    }
    public void setRate(Double rate) {
        this.rate = rate;
    }
    public Integer getDeductionType() {
        return deductionType;
    }
    public void setDeductionType(Integer deductionType) {
        this.deductionType = deductionType;
    }
    public String getCappingMoney() {
        return cappingMoney;
    }
    public void setCappingMoney(String cappingMoney) {
        this.cappingMoney = cappingMoney;
    }




    @Override
    public String toString() {
        return "Rate{" + "serviceType=" + serviceType + "," + "rate=" + rate + "," + "deductionType=" + deductionType + "," + "cappingMoney=" + cappingMoney + "}";
    }
}
