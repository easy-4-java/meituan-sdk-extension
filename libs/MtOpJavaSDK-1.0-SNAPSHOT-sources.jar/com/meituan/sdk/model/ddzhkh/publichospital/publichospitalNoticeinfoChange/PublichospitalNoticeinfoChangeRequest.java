package com.meituan.sdk.model.ddzhkh.publichospital.publichospitalNoticeinfoChange;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 医院、科室变更同步
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/publichospital/noticeinfo/change",
    businessId = 59,
    apiVersion = "10015",
    apiName = "publichospital_noticeinfo_change",
    needAuth = false
)
public class PublichospitalNoticeinfoChangeRequest implements MeituanRequest<PublichospitalNoticeinfoChangeResponse> {
    @NotNull(message = "noticeRequest不能为空")
    @SerializedName("noticeRequest")
    private NoticeInfoChangeRequest noticeRequest;

    public NoticeInfoChangeRequest getNoticeRequest() {
        return noticeRequest;
    }
    public void setNoticeRequest(NoticeInfoChangeRequest noticeRequest) {
        this.noticeRequest = noticeRequest;
    }


    @Override
    public MeituanResponse<PublichospitalNoticeinfoChangeResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<PublichospitalNoticeinfoChangeResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "PublichospitalNoticeinfoChangeRequest{" + "noticeRequest=" + noticeRequest + "}";
    }
}
