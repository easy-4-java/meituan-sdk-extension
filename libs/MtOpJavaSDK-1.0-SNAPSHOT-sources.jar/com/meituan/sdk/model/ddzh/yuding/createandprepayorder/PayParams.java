package com.meituan.sdk.model.ddzh.yuding.createandprepayorder;

import com.google.gson.annotations.SerializedName;

/**
* 支付参数
* This file was automatically generated.
*/
public class PayParams {
    /**
    * 订单号 
    */
    @SerializedName("unifiedOrderId")
    private String unifiedOrderId;
    /**
    * 降级状态
    */
    @SerializedName("degradeStatus")
    private Boolean degradeStatus;
    /**
    * 微信支付参数          
    */
    @SerializedName("wxPayUrl")
    private String wxPayUrl;
    /**
    * 美团支付流水号
    */
    @SerializedName("tradeNO")
    private String tradeNO;
    /**
    * 是否需要重定向
    */
    @SerializedName("needRedirect")
    private Boolean needRedirect;
    /**
    * 美团支付token 
    */
    @SerializedName("payToken")
    private String payToken;
    /**
    * 降级信息
    */
    @SerializedName("degradeInfo")
    private DegradeInfo degradeInfo;

    public String getUnifiedOrderId() {
        return unifiedOrderId;
    }
    public void setUnifiedOrderId(String unifiedOrderId) {
        this.unifiedOrderId = unifiedOrderId;
    }
    public Boolean getDegradeStatus() {
        return degradeStatus;
    }
    public void setDegradeStatus(Boolean degradeStatus) {
        this.degradeStatus = degradeStatus;
    }
    public String getWxPayUrl() {
        return wxPayUrl;
    }
    public void setWxPayUrl(String wxPayUrl) {
        this.wxPayUrl = wxPayUrl;
    }
    public String getTradeNO() {
        return tradeNO;
    }
    public void setTradeNO(String tradeNO) {
        this.tradeNO = tradeNO;
    }
    public Boolean getNeedRedirect() {
        return needRedirect;
    }
    public void setNeedRedirect(Boolean needRedirect) {
        this.needRedirect = needRedirect;
    }
    public String getPayToken() {
        return payToken;
    }
    public void setPayToken(String payToken) {
        this.payToken = payToken;
    }
    public DegradeInfo getDegradeInfo() {
        return degradeInfo;
    }
    public void setDegradeInfo(DegradeInfo degradeInfo) {
        this.degradeInfo = degradeInfo;
    }




    @Override
    public String toString() {
        return "PayParams{" + "unifiedOrderId=" + unifiedOrderId + "," + "degradeStatus=" + degradeStatus + "," + "wxPayUrl=" + wxPayUrl + "," + "tradeNO=" + tradeNO + "," + "needRedirect=" + needRedirect + "," + "payToken=" + payToken + "," + "degradeInfo=" + degradeInfo + "}";
    }
}
