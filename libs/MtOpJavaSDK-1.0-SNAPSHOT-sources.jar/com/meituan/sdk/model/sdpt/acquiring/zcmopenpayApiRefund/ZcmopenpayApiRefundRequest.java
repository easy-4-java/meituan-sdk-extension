package com.meituan.sdk.model.sdpt.acquiring.zcmopenpayApiRefund;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 美团收单[扫码支付]订单退款接口
* This file was automatically generated.
*/
@ApiMeta(
    path = "/sdpt/acquiring/api/refund",
    businessId = 52,
    apiVersion = "10102",
    apiName = "zcmopenpay_api_refund",
    needAuth = false
)
public class ZcmopenpayApiRefundRequest implements MeituanRequest<ZcmopenpayApiRefundResponse> {
    /**
    * <p data-diff-id="ct-diff-id-1c698a78-0ca3-4168-8622-daf0e7adf0d8"><span style="color: ">接入方订单号</span></p>
    */
    @NotBlank(message = "outTradeNo不能为空")
    @SerializedName("outTradeNo")
    private String outTradeNo;
    /**
    * <p data-diff-id="ct-diff-id-16f75cf5-a8a3-475b-97b1-dacb3228dba7"><span style="color: ">退款金额，单位为分</span></p>
    */
    @NotNull(message = "refundFee不能为空")
    @SerializedName("refundFee")
    private Integer refundFee;
    /**
    * <p data-diff-id="ct-diff-id-ae45da64-2ed6-4525-b5a4-f3d17f26ed91"><span style="color: ">商户退款号，标识一次退款请求，同一笔交易多次退款需要保证唯一</span></p>
    */
    @NotBlank(message = "refundNo不能为空")
    @SerializedName("refundNo")
    private String refundNo;
    /**
    * <p data-diff-id="ct-diff-id-6aea4ccf-36e9-49ea-970a-b5959fc65128"><span style="color: ">退款原因</span></p>
    */
    @NotBlank(message = "refundReason不能为空")
    @SerializedName("refundReason")
    private String refundReason;
    /**
    * <p data-diff-id="ct-diff-id-7397c8dd-8b8c-4800-b2d2-25bd58c01db8"><span style="color: ">开放平台分配的商户id, 目前是 美团POI ID</span></p>
    */
    @NotNull(message = "merchantId不能为空")
    @SerializedName("merchantId")
    private Integer merchantId;

    public String getOutTradeNo() {
        return outTradeNo;
    }
    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }
    public Integer getRefundFee() {
        return refundFee;
    }
    public void setRefundFee(Integer refundFee) {
        this.refundFee = refundFee;
    }
    public String getRefundNo() {
        return refundNo;
    }
    public void setRefundNo(String refundNo) {
        this.refundNo = refundNo;
    }
    public String getRefundReason() {
        return refundReason;
    }
    public void setRefundReason(String refundReason) {
        this.refundReason = refundReason;
    }
    public Integer getMerchantId() {
        return merchantId;
    }
    public void setMerchantId(Integer merchantId) {
        this.merchantId = merchantId;
    }


    @Override
    public MeituanResponse<ZcmopenpayApiRefundResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ZcmopenpayApiRefundResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ZcmopenpayApiRefundRequest{" + "outTradeNo=" + outTradeNo + "," + "refundFee=" + refundFee + "," + "refundNo=" + refundNo + "," + "refundReason=" + refundReason + "," + "merchantId=" + merchantId + "}";
    }
}
