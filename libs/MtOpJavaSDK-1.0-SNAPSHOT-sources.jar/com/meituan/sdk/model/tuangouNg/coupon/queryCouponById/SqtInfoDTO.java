package com.meituan.sdk.model.tuangouNg.coupon.queryCouponById;

import com.google.gson.annotations.SerializedName;

/**
* 商企通有关的业务信息
* This file was automatically generated.
*/
public class SqtInfoDTO {
    /**
    * 是否是商企通订单:1是商企通订单;2非商企通;0降级
    */
    @SerializedName("sqtOrder")
    private Integer sqtOrder;
    /**
    * 是否需要通过美团企业版给企业开票:1需要,即商家无需给顾客开票;2不需要,即商家直接给顾客开票;0降级
    */
    @SerializedName("sqtNeedInvoice")
    private Integer sqtNeedInvoice;

    public Integer getSqtOrder() {
        return sqtOrder;
    }
    public void setSqtOrder(Integer sqtOrder) {
        this.sqtOrder = sqtOrder;
    }
    public Integer getSqtNeedInvoice() {
        return sqtNeedInvoice;
    }
    public void setSqtNeedInvoice(Integer sqtNeedInvoice) {
        this.sqtNeedInvoice = sqtNeedInvoice;
    }




    @Override
    public String toString() {
        return "SqtInfoDTO{" + "sqtOrder=" + sqtOrder + "," + "sqtNeedInvoice=" + sqtNeedInvoice + "}";
    }
}
