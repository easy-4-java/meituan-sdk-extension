package com.meituan.sdk.model.pms.hotel.commonGetdictionaryitems;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 获取数据字典
* This file was automatically generated.
*/
public class CommonGetdictionaryitemsResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    @SerializedName("data")
    private List<EnumDTO> data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public List<EnumDTO> getData() {
        return data;
    }
    public void setData(List<EnumDTO> data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "CommonGetdictionaryitemsResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
