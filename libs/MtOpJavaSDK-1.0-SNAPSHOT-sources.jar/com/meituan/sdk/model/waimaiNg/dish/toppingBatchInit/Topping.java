package com.meituan.sdk.model.waimaiNg.dish.toppingBatchInit;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-0aa859f2-05d7-41f5-a52e-cd74d357cd73">新建/更新小料列表，存在即更新，不存在的话新建。一次最多100个，可能部分成功部分失败。</p>
* This file was automatically generated.
*/
public class Topping {
    /**
    * <p data-diff-id="ct-diff-id-427e1f84-15c6-4426-b74b-a68b6174775d">小料编码，最大16</p>
    */
    @NotBlank(message = "toppingCode不能为空")
    @SerializedName("toppingCode")
    private String toppingCode;
    /**
    * <p data-diff-id="ct-diff-id-d9a7e128-3aba-43c0-8b47-a473cdb4d006">小料名称，最大16</p>
    */
    @NotBlank(message = "name不能为空")
    @SerializedName("name")
    private String name;
    /**
    * <p data-diff-id="ct-diff-id-9bd6dc7f-b9ee-4464-bea6-1f07461b9d73">价格，小数点后最多两位</p>
    */
    @NotBlank(message = "price不能为空")
    @SerializedName("price")
    private String price;
    /**
    * <p data-diff-id="ct-diff-id-e8e770d9-3984-40ae-9b5d-e3e64ddadacb">最大库存</p>
    */
    @SerializedName("maxStock")
    private Integer maxStock;
    /**
    * <p data-diff-id="ct-diff-id-f8c45b93-f9f2-4500-b0c6-4b9565dc6c4b">当前库存，-1代表无限库存，该字段为-1时，maxStock，autoRefresh不再使用，且查询时maxStock会返回-1</p>
    */
    @SerializedName("stock")
    private Integer stock;
    /**
    * <p data-diff-id="ct-diff-id-afd6ab31-7f8d-4095-a8da-cb4a66e2aa86">是否自动补足，1:是，0:否</p>
    */
    @SerializedName("autoRefresh")
    private Integer autoRefresh;

    public String getToppingCode() {
        return toppingCode;
    }
    public void setToppingCode(String toppingCode) {
        this.toppingCode = toppingCode;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPrice() {
        return price;
    }
    public void setPrice(String price) {
        this.price = price;
    }
    public Integer getMaxStock() {
        return maxStock;
    }
    public void setMaxStock(Integer maxStock) {
        this.maxStock = maxStock;
    }
    public Integer getStock() {
        return stock;
    }
    public void setStock(Integer stock) {
        this.stock = stock;
    }
    public Integer getAutoRefresh() {
        return autoRefresh;
    }
    public void setAutoRefresh(Integer autoRefresh) {
        this.autoRefresh = autoRefresh;
    }




    @Override
    public String toString() {
        return "Topping{" + "toppingCode=" + toppingCode + "," + "name=" + name + "," + "price=" + price + "," + "maxStock=" + maxStock + "," + "stock=" + stock + "," + "autoRefresh=" + autoRefresh + "}";
    }
}
