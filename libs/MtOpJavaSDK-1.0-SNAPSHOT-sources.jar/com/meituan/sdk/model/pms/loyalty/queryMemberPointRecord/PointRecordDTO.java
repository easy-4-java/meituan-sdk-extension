package com.meituan.sdk.model.pms.loyalty.queryMemberPointRecord;

import com.google.gson.annotations.SerializedName;

/**
* 积分明细
* This file was automatically generated.
*/
public class PointRecordDTO {
    /**
    * 会员ID
    */
    @SerializedName("memberId")
    private String memberId;
    /**
    * 积分流水号
    */
    @SerializedName("pointTransactionId")
    private Long pointTransactionId;
    /**
    * 积分来源酒店ID
    */
    @SerializedName("sourceHotelId")
    private Long sourceHotelId;
    /**
    * 积分获取渠道名称
    */
    @SerializedName("channelName")
    private String channelName;
    /**
    * 积分类型（获取/消费）
    */
    @SerializedName("typeName")
    private String typeName;
    /**
    * 积分获取或消费方式
    */
    @SerializedName("methodName")
    private String methodName;
    /**
    * 积分
    */
    @SerializedName("point")
    private String point;
    /**
    * 备注
    */
    @SerializedName("remark")
    private String remark;
    /**
    * 积分获取/消费时间，格式yyyy-MM-dd HH:mm:ss
    */
    @SerializedName("createTime")
    private String createTime;

    public String getMemberId() {
        return memberId;
    }
    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
    public Long getPointTransactionId() {
        return pointTransactionId;
    }
    public void setPointTransactionId(Long pointTransactionId) {
        this.pointTransactionId = pointTransactionId;
    }
    public Long getSourceHotelId() {
        return sourceHotelId;
    }
    public void setSourceHotelId(Long sourceHotelId) {
        this.sourceHotelId = sourceHotelId;
    }
    public String getChannelName() {
        return channelName;
    }
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    public String getTypeName() {
        return typeName;
    }
    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }
    public String getMethodName() {
        return methodName;
    }
    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }
    public String getPoint() {
        return point;
    }
    public void setPoint(String point) {
        this.point = point;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public String getCreateTime() {
        return createTime;
    }
    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }




    @Override
    public String toString() {
        return "PointRecordDTO{" + "memberId=" + memberId + "," + "pointTransactionId=" + pointTransactionId + "," + "sourceHotelId=" + sourceHotelId + "," + "channelName=" + channelName + "," + "typeName=" + typeName + "," + "methodName=" + methodName + "," + "point=" + point + "," + "remark=" + remark + "," + "createTime=" + createTime + "}";
    }
}
