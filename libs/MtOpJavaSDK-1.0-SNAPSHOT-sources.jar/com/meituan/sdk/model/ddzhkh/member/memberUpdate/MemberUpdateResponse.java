package com.meituan.sdk.model.ddzhkh.member.memberUpdate;

import com.google.gson.annotations.SerializedName;

/**
* 会员信息更新接口
* This file was automatically generated.
*/
public class MemberUpdateResponse {
    /**
    * 操作状态
    */
    @SerializedName("result")
    private Boolean result;

    public Boolean getResult() {
        return result;
    }
    public void setResult(Boolean result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "MemberUpdateResponse{" + "result=" + result + "}";
    }
}
