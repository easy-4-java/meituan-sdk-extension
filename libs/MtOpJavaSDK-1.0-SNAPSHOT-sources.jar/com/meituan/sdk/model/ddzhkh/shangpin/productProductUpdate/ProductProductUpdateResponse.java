package com.meituan.sdk.model.ddzhkh.shangpin.productProductUpdate;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 更新商品
* This file was automatically generated.
*/
public class ProductProductUpdateResponse {
    /**
    * 售卖SKU属性
    */
    @SerializedName("attributes")
    private String attributes;
    /**
    * 售卖SKU列表
    */
    @SerializedName("items")
    private List<UpdateItem> items;
    /**
    * 美团商品id
    */
    @SerializedName("productId")
    private Long productId;
    /**
    * 美团商品名称，长度限制<=30
    */
    @SerializedName("productName")
    private String productName;
    /**
    * 三方商品ID
    */
    @SerializedName("appProductId")
    private String appProductId;
    /**
    * 美团商品品类列表，三方需确定要接入商品品类和品类ID，例如体检预订：[100016,735]，场馆预订：[100060,1650],化妆品电商[100048,1005]
    */
    @SerializedName("categoryIds")
    private List<Long> categoryIds;
    /**
    * 美团店铺ID列表
    */
    @SerializedName("opPoiIds")
    private List<String> opPoiIds;

    public String getAttributes() {
        return attributes;
    }
    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }
    public List<UpdateItem> getItems() {
        return items;
    }
    public void setItems(List<UpdateItem> items) {
        this.items = items;
    }
    public Long getProductId() {
        return productId;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public String getAppProductId() {
        return appProductId;
    }
    public void setAppProductId(String appProductId) {
        this.appProductId = appProductId;
    }
    public List<Long> getCategoryIds() {
        return categoryIds;
    }
    public void setCategoryIds(List<Long> categoryIds) {
        this.categoryIds = categoryIds;
    }
    public List<String> getOpPoiIds() {
        return opPoiIds;
    }
    public void setOpPoiIds(List<String> opPoiIds) {
        this.opPoiIds = opPoiIds;
    }




    @Override
    public String toString() {
        return "ProductProductUpdateResponse{" + "attributes=" + attributes + "," + "items=" + items + "," + "productId=" + productId + "," + "productName=" + productName + "," + "appProductId=" + appProductId + "," + "categoryIds=" + categoryIds + "," + "opPoiIds=" + opPoiIds + "}";
    }
}
