package com.meituan.sdk.model.waimaiNg.im.queryImSubscribeStatusByEpoi;

import com.google.gson.annotations.SerializedName;

/**
* 查询门店外卖IM消息订阅状态
* This file was automatically generated.
*/
public class QueryImSubscribeStatusByEpoiResponse {
    /**
    * 查询结果编码，0成功，其他失败
    */
    @SerializedName("code")
    private Integer code;
    /**
    * 查询结果描述
    */
    @SerializedName("message")
    private String message;
    /**
    * 门店外卖IM消息订阅状态，0未订阅，1订阅中
    */
    @SerializedName("status")
    private Integer status;

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }




    @Override
    public String toString() {
        return "QueryImSubscribeStatusByEpoiResponse{" + "code=" + code + "," + "message=" + message + "," + "status=" + status + "}";
    }
}
