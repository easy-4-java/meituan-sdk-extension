package com.meituan.sdk.model.resv2.stock.updateTableVisible;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class VendorSpuDTO {
    /**
    * <p data-diff-id="ct-diff-id-8c15cfbb-7697-49c8-8513-4cf97ec42f84"><span style="color: ">日期 秒级时间戳</span></p>
    */
    @SerializedName("day")
    private Integer day;
    /**
    * <p data-diff-id="ct-diff-id-6addd92f-b7ba-4e78-8cf2-363fd0c60631"><span style="color: ">美团桌型ID，推荐该字段必传，或者 「tableType、tableTypeName」两个字段必传</span></p>
    */
    @SerializedName("tableTypeId")
    private Long tableTypeId;
    /**
    * <p data-diff-id="ct-diff-id-4dc195bb-bb7d-4eec-be5f-1472b61a090b"><span style="color: ">桌型类型，0-大厅 1-包间 3-自定义</span></p>
    */
    @SerializedName("tableType")
    private Integer tableType;
    /**
    * <p data-diff-id="ct-diff-id-8d032313-9828-4676-ba3c-699108ed0fcb"><span style="color: ">桌型名称</span></p>
    */
    @SerializedName("tableTypeName")
    private String tableTypeName;
    /**
    * <p data-diff-id="ct-diff-id-c045a2c1-408e-49a0-9ee1-81dcdfa5db3c"><span style="color: ">餐段, 1234早中晚夜</span></p>
    */
    @SerializedName("period")
    private Integer period;
    /**
    * <p data-diff-id="ct-diff-id-87cd0df1-9293-4a19-b3f0-cf7b5e6cc400">1:锁台 2:清台</p>
    */
    @SerializedName("type")
    private Integer type;

    public Integer getDay() {
        return day;
    }
    public void setDay(Integer day) {
        this.day = day;
    }
    public Long getTableTypeId() {
        return tableTypeId;
    }
    public void setTableTypeId(Long tableTypeId) {
        this.tableTypeId = tableTypeId;
    }
    public Integer getTableType() {
        return tableType;
    }
    public void setTableType(Integer tableType) {
        this.tableType = tableType;
    }
    public String getTableTypeName() {
        return tableTypeName;
    }
    public void setTableTypeName(String tableTypeName) {
        this.tableTypeName = tableTypeName;
    }
    public Integer getPeriod() {
        return period;
    }
    public void setPeriod(Integer period) {
        this.period = period;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }




    @Override
    public String toString() {
        return "VendorSpuDTO{" + "day=" + day + "," + "tableTypeId=" + tableTypeId + "," + "tableType=" + tableType + "," + "tableTypeName=" + tableTypeName + "," + "period=" + period + "," + "type=" + type + "}";
    }
}
