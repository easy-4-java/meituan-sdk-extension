package com.meituan.sdk.model.waimaiNg.special.specialFoodSaveComboMainProduct;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.NotEmpty;

/**
* APP方商品skus，不能为空，套餐主品的sku数量有且仅能有1个
* This file was automatically generated.
*/
public class SkusData {
    /**
    * APP方sku唯一标识，最大长度128字符
    */
    @NotBlank(message = "skuId不能为空")
    @SerializedName("sku_id")
    private String skuId;
    /**
    * sku规格
    */
    @NotBlank(message = "spec不能为空")
    @SerializedName("spec")
    private String spec;
    /**
    * sku结算价，不能为负数，最大支持2位小数
    */
    @NotBlank(message = "price不能为空")
    @SerializedName("price")
    private String price;
    /**
    * <p data-diff-id="ct-diff-id-236573d0-6022-499f-810d-c9e380ca0311">库存数量，不能为负数也不能为小数，最大10000，-1为不限制</p>
    */
    @NotNull(message = "stock不能为空")
    @SerializedName("stock")
    private Integer stock;
    /**
    * <p data-diff-id="ct-diff-id-279f03d3-de21-4003-9270-215a7aa47f86">当日最大库存，不能为负数也不能为小数，最大10000</p>
    */
    @NotNull(message = "maxStock不能为空")
    @SerializedName("max_stock")
    private Integer maxStock;
    /**
    * 自动刷新库存，0：否，1：是
    */
    @NotNull(message = "autoRefresh不能为空")
    @SerializedName("auto_refresh")
    private Integer autoRefresh;
    /**
    * <p data-diff-id="ct-diff-id-0dfc1fbb-aec6-4905-a687-ef5339c14b91">套餐分组列表信息<strong>，其中列表元素顺序，代表不同分组在用户端展示的顺序</strong></p>
    */
    @NotEmpty(message = "comboGroupList不能为空")
    @SerializedName("comboGroupList")
    private List<ComboGroupData> comboGroupList;

    public String getSkuId() {
        return skuId;
    }
    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }
    public String getSpec() {
        return spec;
    }
    public void setSpec(String spec) {
        this.spec = spec;
    }
    public String getPrice() {
        return price;
    }
    public void setPrice(String price) {
        this.price = price;
    }
    public Integer getStock() {
        return stock;
    }
    public void setStock(Integer stock) {
        this.stock = stock;
    }
    public Integer getMaxStock() {
        return maxStock;
    }
    public void setMaxStock(Integer maxStock) {
        this.maxStock = maxStock;
    }
    public Integer getAutoRefresh() {
        return autoRefresh;
    }
    public void setAutoRefresh(Integer autoRefresh) {
        this.autoRefresh = autoRefresh;
    }
    public List<ComboGroupData> getComboGroupList() {
        return comboGroupList;
    }
    public void setComboGroupList(List<ComboGroupData> comboGroupList) {
        this.comboGroupList = comboGroupList;
    }




    @Override
    public String toString() {
        return "SkusData{" + "skuId=" + skuId + "," + "spec=" + spec + "," + "price=" + price + "," + "stock=" + stock + "," + "maxStock=" + maxStock + "," + "autoRefresh=" + autoRefresh + "," + "comboGroupList=" + comboGroupList + "}";
    }
}
