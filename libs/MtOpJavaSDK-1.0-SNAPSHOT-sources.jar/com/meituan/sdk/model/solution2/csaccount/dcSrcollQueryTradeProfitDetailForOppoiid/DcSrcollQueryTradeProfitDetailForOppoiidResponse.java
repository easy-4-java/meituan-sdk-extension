package com.meituan.sdk.model.solution2.csaccount.dcSrcollQueryTradeProfitDetailForOppoiid;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 游标查询交易结算流水(服务商使用)
* This file was automatically generated.
*/
public class DcSrcollQueryTradeProfitDetailForOppoiidResponse {
    /**
    * 游标ID
    */
    @SerializedName("scrollId")
    private Long scrollId;
    /**
    * 流水列表
    */
    @SerializedName("traceDetails")
    private List<TraceDetailDTO> traceDetails;

    public Long getScrollId() {
        return scrollId;
    }
    public void setScrollId(Long scrollId) {
        this.scrollId = scrollId;
    }
    public List<TraceDetailDTO> getTraceDetails() {
        return traceDetails;
    }
    public void setTraceDetails(List<TraceDetailDTO> traceDetails) {
        this.traceDetails = traceDetails;
    }




    @Override
    public String toString() {
        return "DcSrcollQueryTradeProfitDetailForOppoiidResponse{" + "scrollId=" + scrollId + "," + "traceDetails=" + traceDetails + "}";
    }
}
