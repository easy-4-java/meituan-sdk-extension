package com.meituan.sdk.model.resv2.stock.supplyStockUpdate;

import java.util.List;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-abf9504d-bef4-4fff-a89c-7dd9c53f7a03">桌位库存实体</p>
* This file was automatically generated.
*/
public class VendorTableGroupStockDTO {
    /**
    * <p data-diff-id="ct-diff-id-ab90098c-13f5-4eda-9d48-f3f3886bc372">该桌位最少可坐的人数</p>
    */
    @SerializedName("minPeople")
    private Integer minPeople;
    /**
    * <p data-diff-id="ct-diff-id-2e44a0f7-4ad4-4aff-b185-49a0e87c6f5a">该桌位最多可坐的人数</p>
    */
    @SerializedName("maxPeople")
    private Integer maxPeople;
    /**
    * <p data-diff-id="ct-diff-id-da78d90e-a737-4ba0-bc02-8be5fb9cce9a">美团桌位id,推荐该字段必传，或者 「minPeople、maxPeople」两个字段必传</p>
    */
    @SerializedName("tableGroupId")
    private Long tableGroupId;
    /**
    * <p data-diff-id="ct-diff-id-1bd7a837-820b-4394-a501-b854661978ab">日期库存实体</p>
    */
    @NotEmpty(message = "vendorStockList不能为空")
    @SerializedName("vendorStockList")
    private List<VendorStockDTO> vendorStockList;

    public Integer getMinPeople() {
        return minPeople;
    }
    public void setMinPeople(Integer minPeople) {
        this.minPeople = minPeople;
    }
    public Integer getMaxPeople() {
        return maxPeople;
    }
    public void setMaxPeople(Integer maxPeople) {
        this.maxPeople = maxPeople;
    }
    public Long getTableGroupId() {
        return tableGroupId;
    }
    public void setTableGroupId(Long tableGroupId) {
        this.tableGroupId = tableGroupId;
    }
    public List<VendorStockDTO> getVendorStockList() {
        return vendorStockList;
    }
    public void setVendorStockList(List<VendorStockDTO> vendorStockList) {
        this.vendorStockList = vendorStockList;
    }




    @Override
    public String toString() {
        return "VendorTableGroupStockDTO{" + "minPeople=" + minPeople + "," + "maxPeople=" + maxPeople + "," + "tableGroupId=" + tableGroupId + "," + "vendorStockList=" + vendorStockList + "}";
    }
}
