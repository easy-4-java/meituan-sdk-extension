package com.meituan.sdk.model.foodmop.order.diancannewOrderQueryOrder;

import com.google.gson.annotations.SerializedName;

/**
* 品牌查询美团的单笔订单
* This file was automatically generated.
*/
public class DiancannewOrderQueryOrderResponse {
    /**
    * 美团侧订单ID
    */
    @SerializedName("mtOrderId")
    private String mtOrderId;
    /**
    * 品牌侧订单ID
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * 订单状态
    */
    @SerializedName("orderStatus")
    private String orderStatus;
    /**
    * 下单时间
    */
    @SerializedName("orderTime")
    private Long orderTime;
    /**
    * 支付时间
    */
    @SerializedName("payTime")
    private Long payTime;
    /**
    * 订单对应平台  10 美团  20 点评
    */
    @SerializedName("platform")
    private Integer platform;
    /**
    * 美团poiId（下单门店）
    */
    @SerializedName("poiId")
    private Long poiId;
    /**
    * 商家门店ID
    */
    @SerializedName("vendorShopId")
    private String vendorShopId;
    /**
    * 业务类型 10-MOP
    */
    @SerializedName("bizCode")
    private Integer bizCode;
    /**
    * 扩展字段Map<String,String>
    */
    @SerializedName("resExt")
    private Map resExt;

    public String getMtOrderId() {
        return mtOrderId;
    }
    public void setMtOrderId(String mtOrderId) {
        this.mtOrderId = mtOrderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public String getOrderStatus() {
        return orderStatus;
    }
    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
    public Long getOrderTime() {
        return orderTime;
    }
    public void setOrderTime(Long orderTime) {
        this.orderTime = orderTime;
    }
    public Long getPayTime() {
        return payTime;
    }
    public void setPayTime(Long payTime) {
        this.payTime = payTime;
    }
    public Integer getPlatform() {
        return platform;
    }
    public void setPlatform(Integer platform) {
        this.platform = platform;
    }
    public Long getPoiId() {
        return poiId;
    }
    public void setPoiId(Long poiId) {
        this.poiId = poiId;
    }
    public String getVendorShopId() {
        return vendorShopId;
    }
    public void setVendorShopId(String vendorShopId) {
        this.vendorShopId = vendorShopId;
    }
    public Integer getBizCode() {
        return bizCode;
    }
    public void setBizCode(Integer bizCode) {
        this.bizCode = bizCode;
    }
    public Map getResExt() {
        return resExt;
    }
    public void setResExt(Map resExt) {
        this.resExt = resExt;
    }




    @Override
    public String toString() {
        return "DiancannewOrderQueryOrderResponse{" + "mtOrderId=" + mtOrderId + "," + "vendorOrderId=" + vendorOrderId + "," + "orderStatus=" + orderStatus + "," + "orderTime=" + orderTime + "," + "payTime=" + payTime + "," + "platform=" + platform + "," + "poiId=" + poiId + "," + "vendorShopId=" + vendorShopId + "," + "bizCode=" + bizCode + "," + "resExt=" + resExt + "}";
    }
}
