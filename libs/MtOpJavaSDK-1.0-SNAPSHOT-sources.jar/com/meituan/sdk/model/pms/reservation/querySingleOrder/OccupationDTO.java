package com.meituan.sdk.model.pms.reservation.querySingleOrder;

import com.google.gson.annotations.SerializedName;

/**
* 占房信息
* This file was automatically generated.
*/
public class OccupationDTO {
    /**
    * 订单ID
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * 占房ID
    */
    @SerializedName("occupationId")
    private Long occupationId;
    /**
    * 物理房型编号
    */
    @SerializedName("physicalRoomTypeId")
    private String physicalRoomTypeId;
    /**
    * 价格房型编号
    */
    @SerializedName("priceRoomTypeId")
    private String priceRoomTypeId;
    /**
    * 占房开始时间
    */
    @SerializedName("occupationStartTime")
    private String occupationStartTime;
    /**
    * 占房结束时间
    */
    @SerializedName("occupationEndTime")
    private String occupationEndTime;
    /**
    * 是否锁定
    */
    @SerializedName("locked")
    private Boolean locked;
    /**
    * 是否会员本人
    */
    @SerializedName("isMemberThemself")
    private Boolean isMemberThemself;
    /**
    * 房间
    */
    @SerializedName("estimatedDepartureTime")
    private String estimatedDepartureTime;
    /**
    * 房间号
    */
    @SerializedName("roomNumber")
    private String roomNumber;
    /**
    * 是否有效
    */
    @SerializedName("isActive")
    private Boolean isActive;
    /**
    * 是否已入住
    */
    @SerializedName("hasCheckin")
    private Boolean hasCheckin;
    /**
    * 入住类型，详见CheckinType字典
    */
    @SerializedName("checkinType")
    private EnumDTO checkinType;
    /**
    * 价格信息
    */
    @SerializedName("priceInfo")
    private OrderPriceInfoDTO priceInfo;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public Long getOccupationId() {
        return occupationId;
    }
    public void setOccupationId(Long occupationId) {
        this.occupationId = occupationId;
    }
    public String getPhysicalRoomTypeId() {
        return physicalRoomTypeId;
    }
    public void setPhysicalRoomTypeId(String physicalRoomTypeId) {
        this.physicalRoomTypeId = physicalRoomTypeId;
    }
    public String getPriceRoomTypeId() {
        return priceRoomTypeId;
    }
    public void setPriceRoomTypeId(String priceRoomTypeId) {
        this.priceRoomTypeId = priceRoomTypeId;
    }
    public String getOccupationStartTime() {
        return occupationStartTime;
    }
    public void setOccupationStartTime(String occupationStartTime) {
        this.occupationStartTime = occupationStartTime;
    }
    public String getOccupationEndTime() {
        return occupationEndTime;
    }
    public void setOccupationEndTime(String occupationEndTime) {
        this.occupationEndTime = occupationEndTime;
    }
    public Boolean getLocked() {
        return locked;
    }
    public void setLocked(Boolean locked) {
        this.locked = locked;
    }
    public Boolean getIsMemberThemself() {
        return isMemberThemself;
    }
    public void setIsMemberThemself(Boolean isMemberThemself) {
        this.isMemberThemself = isMemberThemself;
    }
    public String getEstimatedDepartureTime() {
        return estimatedDepartureTime;
    }
    public void setEstimatedDepartureTime(String estimatedDepartureTime) {
        this.estimatedDepartureTime = estimatedDepartureTime;
    }
    public String getRoomNumber() {
        return roomNumber;
    }
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }
    public Boolean getIsActive() {
        return isActive;
    }
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public Boolean getHasCheckin() {
        return hasCheckin;
    }
    public void setHasCheckin(Boolean hasCheckin) {
        this.hasCheckin = hasCheckin;
    }
    public EnumDTO getCheckinType() {
        return checkinType;
    }
    public void setCheckinType(EnumDTO checkinType) {
        this.checkinType = checkinType;
    }
    public OrderPriceInfoDTO getPriceInfo() {
        return priceInfo;
    }
    public void setPriceInfo(OrderPriceInfoDTO priceInfo) {
        this.priceInfo = priceInfo;
    }




    @Override
    public String toString() {
        return "OccupationDTO{" + "orderId=" + orderId + "," + "occupationId=" + occupationId + "," + "physicalRoomTypeId=" + physicalRoomTypeId + "," + "priceRoomTypeId=" + priceRoomTypeId + "," + "occupationStartTime=" + occupationStartTime + "," + "occupationEndTime=" + occupationEndTime + "," + "locked=" + locked + "," + "isMemberThemself=" + isMemberThemself + "," + "estimatedDepartureTime=" + estimatedDepartureTime + "," + "roomNumber=" + roomNumber + "," + "isActive=" + isActive + "," + "hasCheckin=" + hasCheckin + "," + "checkinType=" + checkinType + "," + "priceInfo=" + priceInfo + "}";
    }
}
