package com.meituan.sdk.model.ddzh.technician.technicianTechinfoQuerytagtree;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 标签数据结构，样例值参考属性文档
* This file was automatically generated.
*/
public class CascadeSelectTagItemBO {
    /**
    * 签实际保存id
    */
    @SerializedName("value")
    private String value;
    /**
    * 标签前端展示文字
    */
    @SerializedName("label")
    private String label;
    /**
    * 是否禁用
    */
    @SerializedName("disabled")
    private Boolean disabled;
    /**
    * 拓展信息
    */
    @SerializedName("ext")
    private Map ext;
    /**
    * 子结构标签
    */
    @SerializedName("children")
    private List<SubCascadeSelectTagItemBO> children;

    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public String getLabel() {
        return label;
    }
    public void setLabel(String label) {
        this.label = label;
    }
    public Boolean getDisabled() {
        return disabled;
    }
    public void setDisabled(Boolean disabled) {
        this.disabled = disabled;
    }
    public Map getExt() {
        return ext;
    }
    public void setExt(Map ext) {
        this.ext = ext;
    }
    public List<SubCascadeSelectTagItemBO> getChildren() {
        return children;
    }
    public void setChildren(List<SubCascadeSelectTagItemBO> children) {
        this.children = children;
    }




    @Override
    public String toString() {
        return "CascadeSelectTagItemBO{" + "value=" + value + "," + "label=" + label + "," + "disabled=" + disabled + "," + "ext=" + ext + "," + "children=" + children + "}";
    }
}
