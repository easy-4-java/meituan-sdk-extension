package com.meituan.sdk.model.pms.hotel.searchHotels;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 检索酒店
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/hotel/searchHotels",
    businessId = 57,
    apiVersion = "10014",
    apiName = "search_hotels",
    needAuth = true
)
public class SearchHotelsRequest implements MeituanRequest<SearchHotelsResponse> {
    /**
    * <p data-diff-id="ct-diff-id-9860c780-a331-440c-8022-20c83598fc5b"><span style="color: rgb(51, 51, 51)">酒店ID列表，传入后会忽略其他查询条件</span></p>
    */
    @SerializedName("hotelIds")
    private List<Long> hotelIds;
    /**
    * <p data-diff-id="ct-diff-id-4bad952e-9bd2-4b1f-8cc3-57e6253fbab3"><span style="color: rgb(51, 51, 51)">酒店编号列表</span></p>
    */
    @SerializedName("hotelSns")
    private List<String> hotelSns;
    /**
    * <p data-diff-id="ct-diff-id-8fb14f34-355d-430e-bc47-f7c64b4dce7e">酒店名称</p>
    */
    @SerializedName("hotelName")
    private String hotelName;
    /**
    * <p data-diff-id="ct-diff-id-0f4a374d-ec16-445c-8d57-a1259b6ff5fd"><span style="color: rgba(0, 0, 0, 0.65)">城市编码</span></p>
    */
    @SerializedName("cityId")
    private String cityId;
    /**
    * <p data-diff-id="ct-diff-id-e766230a-63bd-4061-9ccd-03d1aa3bbca1"><span style="color: rgb(51, 51, 51)">行政区编码</span></p>
    */
    @SerializedName("districtId")
    private String districtId;
    /**
    * <p data-diff-id="ct-diff-id-7921b9e6-8107-4925-b889-7c2cb8c74095"><span style="color: rgb(51, 51, 51)">经度</span></p>
    */
    @SerializedName("longitude")
    private String longitude;
    /**
    * <p data-diff-id="ct-diff-id-d20f16d1-12df-4fee-8113-dabf4a13a1b9">纬度</p>
    */
    @SerializedName("latitude")
    private String latitude;
    /**
    * <p data-diff-id="ct-diff-id-aeebd3f7-261d-4f43-96c6-d34857795394"><span style="color: rgb(51, 51, 51)">距离（米）</span></p>
    */
    @SerializedName("distance")
    private Long distance;
    /**
    * <p data-diff-id="ct-diff-id-f8d325c6-b81f-4ee7-94f2-09dcbb487edd">当前页码</p>
    */
    @SerializedName("currentPageNum")
    private Long currentPageNum;
    /**
    * <p data-diff-id="ct-diff-id-4cae48df-a14f-41f1-ba95-460a4ff06fb7">每页显示数量</p>
    */
    @SerializedName("pageSize")
    private Long pageSize;

    public List<Long> getHotelIds() {
        return hotelIds;
    }
    public void setHotelIds(List<Long> hotelIds) {
        this.hotelIds = hotelIds;
    }
    public List<String> getHotelSns() {
        return hotelSns;
    }
    public void setHotelSns(List<String> hotelSns) {
        this.hotelSns = hotelSns;
    }
    public String getHotelName() {
        return hotelName;
    }
    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }
    public String getCityId() {
        return cityId;
    }
    public void setCityId(String cityId) {
        this.cityId = cityId;
    }
    public String getDistrictId() {
        return districtId;
    }
    public void setDistrictId(String districtId) {
        this.districtId = districtId;
    }
    public String getLongitude() {
        return longitude;
    }
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
    public String getLatitude() {
        return latitude;
    }
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
    public Long getDistance() {
        return distance;
    }
    public void setDistance(Long distance) {
        this.distance = distance;
    }
    public Long getCurrentPageNum() {
        return currentPageNum;
    }
    public void setCurrentPageNum(Long currentPageNum) {
        this.currentPageNum = currentPageNum;
    }
    public Long getPageSize() {
        return pageSize;
    }
    public void setPageSize(Long pageSize) {
        this.pageSize = pageSize;
    }


    @Override
    public MeituanResponse<SearchHotelsResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<SearchHotelsResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "SearchHotelsRequest{" + "hotelIds=" + hotelIds + "," + "hotelSns=" + hotelSns + "," + "hotelName=" + hotelName + "," + "cityId=" + cityId + "," + "districtId=" + districtId + "," + "longitude=" + longitude + "," + "latitude=" + latitude + "," + "distance=" + distance + "," + "currentPageNum=" + currentPageNum + "," + "pageSize=" + pageSize + "}";
    }
}
