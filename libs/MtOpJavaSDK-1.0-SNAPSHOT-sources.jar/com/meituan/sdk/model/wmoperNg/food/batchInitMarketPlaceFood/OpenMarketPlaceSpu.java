package com.meituan.sdk.model.wmoperNg.food.batchInitMarketPlaceFood;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-9057ad2b-2a2e-4d27-baa5-6923497b4015">该场域下创建的场域品信息</p>
* This file was automatically generated.
*/
public class OpenMarketPlaceSpu {
    /**
    * <p data-diff-id="ct-diff-id-132beec2-382c-43cb-98aa-6ab310a4e85d">售卖场景</p><p data-diff-id="ct-diff-id-448324bd-14c7-472f-9156-ae65c9a2a2d2">0.在外卖主站和该场域同时售卖，接口不传的商品信息直接复用外卖品。  </p><p data-diff-id="ct-diff-id-5002bb6b-7ed1-4c78-b334-098d145cd2f9">1.仅在该场域售卖，不会复用外卖商品信息，需要传入完整商品信息。（二期支持）</p>
    */
    @NotNull(message = "sellSceneType不能为空")
    @SerializedName("sellSceneType")
    private Integer sellSceneType;
    /**
    * <p data-diff-id="ct-diff-id-bbfda486-e8f0-4bc2-803d-a21641973bc6">场域与外卖主站的商品差异化信息枚举，sellSceneType传0时使用，用于标识当前场域和外卖差异化的信息有哪些，保存场域品时会根据该字段判断要解析哪些信息。</p><p data-diff-id="ct-diff-id-f3d992f4-4b26-480a-af2a-527e2fb7eee0">例如：["SkuPrice",<del>"TagInfo",</del>"SpuSpecAttr","SpuNonSpecAttr","Description"]</p><ol data-diff-id="ct-diff-id-7ed80afa-d2ed-4434-861c-a95d5be2ab96"><li data-list-item-diff-id="ct-list-item-diff-id-a788b1cf-51ee-48f1-8287-67c3ac30c31b"><p data-diff-id="ct-diff-id-364cb2a5-720f-4268-9505-fd55e43822ec">diffInfo是非必填的。如果不填，那就是要保存一个跟主站完全没有差异的场域商品。</p></li><li data-list-item-diff-id="ct-list-item-diff-id-354fe447-f00e-4a7a-96b0-034df0caebd8"><p data-diff-id="ct-diff-id-8f786fbc-0ca3-48c5-a49e-c913d58d85a9">只有场域跟主站有差异化时，diffInfo才需要传入对应枚举。如果场域要复用主站，那diffInfo就不要传该枚举，每次传入的都是本次要更新后的完整数据。</p></li><li data-list-item-diff-id="ct-list-item-diff-id-4c6c9b6f-c5a1-46ee-b442-de1d186bda54"><p data-diff-id="ct-diff-id-508eea57-897b-414b-8c61-36121271146c">diffInfo如果传入某一个枚举，<strong><span style="color: rgb(255, 74, 71)">对应商品字段内容</span></strong>存在必填和非必填两种情况，必填的情况diffInfo对应的<strong><span style="color: rgb(255, 74, 71)">商品字段</span></strong>必须有值，没有值时拦截报错。非必填的字段，不传时就是要在场域设置成空：</p><ul data-diff-id="ct-diff-id-3b22270a-c445-4ddd-b76d-82da4d29d703"><li data-list-item-diff-id="ct-list-item-diff-id-487acdc3-8642-41a8-9a51-9abb46d05fd1"><p data-diff-id="ct-diff-id-18e255c4-47ca-4d5c-b2c5-d59ee4e6c831">对应值必填的枚举：SkuPrice（对应priceList字段）、TagInfo（对应 tagInfo字段）、SpuSpecAttr（对应spuSpecAttrGroups字段和 sku 的skuAttrs字段）</p></li><li data-list-item-diff-id="ct-list-item-diff-id-e89da951-6468-4f21-bc71-21d48a351ce4"><p data-diff-id="ct-diff-id-5d666981-d03f-4965-9dd9-19e484b3d199">对应值非必填的枚举（即内容可以清空）：SpuNonSpecAttr（对应spuNonSpecAttrGroups字段）<span style="color: rgb(106, 171, 115)">、</span>Description（对应description字段）</p></li></ul></li><li data-list-item-diff-id="ct-list-item-diff-id-42f2cc61-ecb4-4233-987b-16bf32256b08"><p data-diff-id="ct-diff-id-5521a398-1d90-46aa-8d48-16e5f271ecfb">sellSceneType为0时（<strong><span style="color: rgb(255, 74, 71)">本期只支持 0</span></strong>），场域默认是要复用外卖的信息，接口只需要传入差异化信息。差异化信息的解析以diffInfo为准，只有diffInfo里面有枚举，才需要解析枚举对应的商品字段值，否则直接忽略。例如diffInfo中没有传SkuPrice，那就不需要解析priceList字段，直接忽略即可。</p></li><li data-list-item-diff-id="ct-list-item-diff-id-52181487-1420-4222-bbb8-4ef0d743e327"><p data-diff-id="ct-diff-id-72de5b4f-6ad8-4437-a432-230d6579a714">价格差异化场景，需满足两层条件：</p><ol data-diff-id="ct-diff-id-67332b8e-1b45-4995-a3d4-ecbd626b1cc6"><li data-list-item-diff-id="ct-list-item-diff-id-904066b1-80ba-4948-ac94-ccffadbdd8c9"><p data-diff-id="ct-diff-id-55585e3d-3541-4902-be7b-77ab9a09ec7c">第一层：diffInfo 中如果传了"SpuSpecAttr"或者"SpuNonSpecAttr"，必须传“SkuPrice”。</p></li><li data-list-item-diff-id="ct-list-item-diff-id-a010fe12-9038-4ce6-a1b6-acc0bf52d9cc"><p data-diff-id="ct-diff-id-f3eb89c3-66c5-42c2-810a-e4f3e69883a4">第二层：</p><table data-borderwidth="1" data-diff-id="ct-diff-id-8b5cd485-ee2f-4157-a87b-e0acdee77d60"><tbody><tr data-row-diff-id="93f7ce66-8ce2-4b24-9ca4-a0613c2ff279"><th data-colwidth="201" width="201" style="background-color: rgb(204, 204, 204);" data-cell-diff-id="ct-cell-diff-id-c5218d96-0a2a-4335-b21c-c733f11fbba6"><p data-diff-id="ct-diff-id-3409b998-8697-4e35-81fe-6a347fe87c00"><span style="color: rgb(255, 74, 71)">主站</span>商品版本\<span style="color: rgb(255, 74, 71)">入参</span>价格类型</p></th><th data-colwidth="217" width="217" style="background-color: rgb(204, 204, 204);" data-cell-diff-id="ct-cell-diff-id-c2fad9ca-1e14-45f4-9614-90172576b79c"><p data-diff-id="ct-diff-id-ca20019d-a170-4ef2-9999-091596f0b798">只存在 type 为 0</p></th><th data-colwidth="218" width="218" style="background-color: rgb(204, 204, 204);" data-cell-diff-id="ct-cell-diff-id-35d40919-fd77-4975-84a3-b8fca1bd3b3a"><p data-diff-id="ct-diff-id-02eed354-47ab-4901-8b41-60706493629a"> 只存在 type 为 1</p></th><th data-colwidth="227" width="227" style="background-color: rgb(204, 204, 204);" data-cell-diff-id="ct-cell-diff-id-2fbd1b83-edf3-4ae2-8231-e478c41e9a83"><p data-diff-id="ct-diff-id-6a9b4872-a0fd-4de1-9e2f-5b92c1328923"> 存在 type=0 和 type=1 两种情况</p></th><th data-colwidth="127" width="127" style="background-color: rgb(204, 204, 204);" data-cell-diff-id="ct-cell-diff-id-afd75891-b32c-4991-92b7-797a2608e646"><p data-diff-id="ct-diff-id-7bdd708e-7b10-48d0-9919-cf05f3702388">price 没有差异化</p></th></tr><tr data-row-diff-id="86171039-9afc-4cd9-a63d-1821f226566f"><td data-colwidth="201" width="201" style="background-color: rgb(204, 204, 204);" data-cell-diff-id="ct-cell-diff-id-91ef8d49-e6fe-4f07-9681-ff26678e6191"><p data-diff-id="ct-diff-id-296a7a8c-7429-4477-99fe-1ab8b6d983d6"> 1.0 商品（对应主站商品<span style="color: rgb(255, 74, 71)">不存在</span> mode=2 的 spuAttr）</p></td><td data-colwidth="217" width="217" data-cell-diff-id="ct-cell-diff-id-3de42881-7c25-4d0f-a28d-962f38897068"><p data-diff-id="ct-diff-id-3de4608b-4366-4106-a879-7caf8eaf2bac">diffInfo 价格相关的内容<span style="color: rgb(255, 74, 71)">不能</span>有"SpuSpecAttr"和"SpuNonSpecAttr"，仅可存在“SkuPrice”。</p></td><td data-colwidth="218" width="218" data-cell-diff-id="ct-cell-diff-id-1fc00396-5e87-44c3-81ac-4c17f8e37582"><p data-diff-id="ct-diff-id-fcb31c79-03a1-44df-b7c2-f3692ebf5e7d">diffInfo 价格相关的内容<span style="color: rgb(255, 74, 71)">不能</span>有"SpuSpecAttr"和"SpuNonSpecAttr"，仅可存在“SkuPrice”。</p></td><td data-colwidth="227" width="227" data-cell-diff-id="ct-cell-diff-id-955944a2-b167-4c93-b1db-138c6627bd70"><p data-diff-id="ct-diff-id-5c31e5a3-37ca-4a0d-9fd3-4d9e5cda390b">校验不通过</p></td><td data-colwidth="127" width="127" data-cell-diff-id="ct-cell-diff-id-bc25ca9b-c861-4cc4-ae15-efca57226c2b"><p data-diff-id="ct-diff-id-e5589d61-a6b9-4dda-b3de-8ccfa22408dd">不校验</p></td></tr><tr data-row-diff-id="4a921872-297c-443b-9b31-74ec3ee944bd"><td data-colwidth="201" width="201" style="background-color: rgb(204, 204, 204);" data-cell-diff-id="ct-cell-diff-id-60950dfb-53f7-488b-8bf8-2dcabeddecaa"><p data-diff-id="ct-diff-id-5501688d-9cfb-4712-a2a1-8dbc90f7cc6a"> 2.0 商品（对应主站商品<span style="color: rgb(255, 74, 71)">存在 </span>mode=2 的 spuAttr）</p></td><td data-colwidth="217" width="217" data-cell-diff-id="ct-cell-diff-id-a463398f-3823-46d3-83b8-83b176e39c5f"><p data-diff-id="ct-diff-id-38238910-f104-4f9a-bef9-97c8b2d06d22">diffInfo 中<span style="color: rgb(255, 74, 71)">必须</span>"SpuSpecAttr", "SpuNonSpecAttr"，“SkuPrice”这三个一起传入或者都不传，不允许只传一个或两个，保证数据一起写入场域。</p></td><td data-colwidth="218" width="218" data-cell-diff-id="ct-cell-diff-id-ebafc43d-d83a-4249-928b-659007175a86"><p data-diff-id="ct-diff-id-b5b97b9b-f62e-4dec-beff-acf76bd2b1ff">diffInfo 价格相关的内容<span style="color: rgb(255, 74, 71)">不能</span>有"SpuSpecAttr"和"SpuNonSpecAttr"，仅可存在“SkuPrice”。</p></td><td data-colwidth="227" width="227" data-cell-diff-id="ct-cell-diff-id-ccbbce60-af44-4718-bf19-352b85b7b4e4"><p data-diff-id="ct-diff-id-111c7d3e-b216-4fef-92de-dadb9ff9dbd0">校验不通过</p></td><td data-colwidth="127" width="127" data-cell-diff-id="ct-cell-diff-id-5018e194-debe-46f2-a7fa-7360243d556c"><p data-diff-id="ct-diff-id-4bb7a79e-c6fc-4200-913e-a1d51ddc3659">不校验</p></td></tr></tbody></table></li></ol></li></ol>
    */
    @SerializedName("diffInfo")
    private List<String> diffInfo;
    /**
    * <p data-diff-id="ct-diff-id-112f0a56-e77f-46a9-b95f-87c617aac8c5">spu code码，需要跟外卖主站品的appFoodCode保持一致。</p>
    */
    @NotBlank(message = "appFoodCode不能为空")
    @SerializedName("appFoodCode")
    private String appFoodCode;
    /**
    * <p data-diff-id="ct-diff-id-b61ba721-b099-455f-a52d-d2dd38044aa7">商品名称</p>
    */
    @SerializedName("name")
    private String name;
    /**
    * <p data-diff-id="ct-diff-id-910dffb3-8fb9-4492-8d6d-f653dd2d36f9">菜品分类</p>
    */
    @SerializedName("tagInfo")
    private OpenMarketplaceTag tagInfo;
    /**
    * <p data-diff-id="ct-diff-id-f1030cca-e212-4e49-a492-15b985198363">售卖属性组</p>
    */
    @SerializedName("spuSpecAttrGroups")
    private List<OpenMarketplaceSpuAttrGroup> spuSpecAttrGroups;
    /**
    * <p data-diff-id="ct-diff-id-233986f1-cdef-42a9-8b28-dab3df169523">非售卖属性组</p>
    */
    @SerializedName("spuNonSpecAttrGroups")
    private List<OpenMarketplaceSpuAttrGroup> spuNonSpecAttrGroups;
    /**
    * <p data-diff-id="ct-diff-id-64c7172c-b44b-4e67-a190-be77be49256f"><span style="color: ">sku</span></p>
    */
    @SerializedName("skus")
    private List<OpenMarketplaceSku> skus;
    /**
    * <p data-diff-id="ct-diff-id-0e1e709a-b32b-4627-9205-742cee8fe495">商品上下架状态，0.上架 1.下架</p>
    */
    @SerializedName("isSoldOut")
    private Integer isSoldOut;
    /**
    * <p data-diff-id="ct-diff-id-b299c79a-c491-41df-bb91-1ff74b913331">商品排序</p>
    */
    @SerializedName("sequence")
    private Integer sequence;
    /**
    * <p data-diff-id="ct-diff-id-92c8fd5f-dda1-4cce-b119-c93e0f00e876">描述</p>
    */
    @SerializedName("description")
    private String description;

    public Integer getSellSceneType() {
        return sellSceneType;
    }
    public void setSellSceneType(Integer sellSceneType) {
        this.sellSceneType = sellSceneType;
    }
    public List<String> getDiffInfo() {
        return diffInfo;
    }
    public void setDiffInfo(List<String> diffInfo) {
        this.diffInfo = diffInfo;
    }
    public String getAppFoodCode() {
        return appFoodCode;
    }
    public void setAppFoodCode(String appFoodCode) {
        this.appFoodCode = appFoodCode;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public OpenMarketplaceTag getTagInfo() {
        return tagInfo;
    }
    public void setTagInfo(OpenMarketplaceTag tagInfo) {
        this.tagInfo = tagInfo;
    }
    public List<OpenMarketplaceSpuAttrGroup> getSpuSpecAttrGroups() {
        return spuSpecAttrGroups;
    }
    public void setSpuSpecAttrGroups(List<OpenMarketplaceSpuAttrGroup> spuSpecAttrGroups) {
        this.spuSpecAttrGroups = spuSpecAttrGroups;
    }
    public List<OpenMarketplaceSpuAttrGroup> getSpuNonSpecAttrGroups() {
        return spuNonSpecAttrGroups;
    }
    public void setSpuNonSpecAttrGroups(List<OpenMarketplaceSpuAttrGroup> spuNonSpecAttrGroups) {
        this.spuNonSpecAttrGroups = spuNonSpecAttrGroups;
    }
    public List<OpenMarketplaceSku> getSkus() {
        return skus;
    }
    public void setSkus(List<OpenMarketplaceSku> skus) {
        this.skus = skus;
    }
    public Integer getIsSoldOut() {
        return isSoldOut;
    }
    public void setIsSoldOut(Integer isSoldOut) {
        this.isSoldOut = isSoldOut;
    }
    public Integer getSequence() {
        return sequence;
    }
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }




    @Override
    public String toString() {
        return "OpenMarketPlaceSpu{" + "sellSceneType=" + sellSceneType + "," + "diffInfo=" + diffInfo + "," + "appFoodCode=" + appFoodCode + "," + "name=" + name + "," + "tagInfo=" + tagInfo + "," + "spuSpecAttrGroups=" + spuSpecAttrGroups + "," + "spuNonSpecAttrGroups=" + spuNonSpecAttrGroups + "," + "skus=" + skus + "," + "isSoldOut=" + isSoldOut + "," + "sequence=" + sequence + "," + "description=" + description + "}";
    }
}
