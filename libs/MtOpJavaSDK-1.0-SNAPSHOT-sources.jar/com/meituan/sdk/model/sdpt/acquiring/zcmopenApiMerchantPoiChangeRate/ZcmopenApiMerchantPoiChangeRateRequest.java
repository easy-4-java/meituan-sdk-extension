package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiMerchantPoiChangeRate;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* [费率]费率修改
* This file was automatically generated.
*/
@ApiMeta(
    path = "/sdpt/acquiring/api/merchant/poi/change/rate",
    businessId = 52,
    apiVersion = "10130",
    apiName = "zcmopen_api_merchant_poi_change_rate",
    needAuth = false
)
public class ZcmopenApiMerchantPoiChangeRateRequest implements MeituanRequest<ZcmopenApiMerchantPoiChangeRateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-6b65917a-482c-4992-b4a1-e0abc6dc4d01"><span style="color: ">开放平台分配的商户id, 目前是 美团POI ID</span></p>
    */
    @NotNull(message = "merchantId不能为空")
    @SerializedName("merchantId")
    private Long merchantId;
    /**
    * <p data-diff-id="ct-diff-id-d51f9f61-3da6-44ae-a253-7bba762a3c01"><span style="color: ">微信费率 单位万分之一 范围 25-100</span></p>
    */
    @NotNull(message = "wxRate不能为空")
    @SerializedName("wxRate")
    private Integer wxRate;
    /**
    * <p data-diff-id="ct-diff-id-7d0ec56e-7064-49e4-81b4-77291874700d"><span style="color: ">支付宝费率 单位万分之一 范围 25-100</span></p>
    */
    @NotNull(message = "aliRate不能为空")
    @SerializedName("aliRate")
    private Integer aliRate;

    public Long getMerchantId() {
        return merchantId;
    }
    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }
    public Integer getWxRate() {
        return wxRate;
    }
    public void setWxRate(Integer wxRate) {
        this.wxRate = wxRate;
    }
    public Integer getAliRate() {
        return aliRate;
    }
    public void setAliRate(Integer aliRate) {
        this.aliRate = aliRate;
    }


    @Override
    public MeituanResponse<ZcmopenApiMerchantPoiChangeRateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ZcmopenApiMerchantPoiChangeRateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ZcmopenApiMerchantPoiChangeRateRequest{" + "merchantId=" + merchantId + "," + "wxRate=" + wxRate + "," + "aliRate=" + aliRate + "}";
    }
}
