package com.meituan.sdk.model.ddzhkh.shangpin.normalDealgroupQuery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 查正式团单
* This file was automatically generated.
*/
public class NormalDealgroupQueryResponse {
    /**
    *  团单id
    */
    @SerializedName("dealGroupId")
    private Long dealGroupId;
    /**
    * 状态，0-不在线，1-可以购买且可见，2-可以购买但不可见
    */
    @SerializedName("status")
    private Integer status;
    /**
    * 适用美团门店列表
    */
    @SerializedName("opPoiIds")
    private List<String> opPoiIds;
    /**
    * 商品SKU信息
    */
    @SerializedName("dealInfo")
    private List<DealInfo> dealInfo;

    public Long getDealGroupId() {
        return dealGroupId;
    }
    public void setDealGroupId(Long dealGroupId) {
        this.dealGroupId = dealGroupId;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public List<String> getOpPoiIds() {
        return opPoiIds;
    }
    public void setOpPoiIds(List<String> opPoiIds) {
        this.opPoiIds = opPoiIds;
    }
    public List<DealInfo> getDealInfo() {
        return dealInfo;
    }
    public void setDealInfo(List<DealInfo> dealInfo) {
        this.dealInfo = dealInfo;
    }




    @Override
    public String toString() {
        return "NormalDealgroupQueryResponse{" + "dealGroupId=" + dealGroupId + "," + "status=" + status + "," + "opPoiIds=" + opPoiIds + "," + "dealInfo=" + dealInfo + "}";
    }
}
