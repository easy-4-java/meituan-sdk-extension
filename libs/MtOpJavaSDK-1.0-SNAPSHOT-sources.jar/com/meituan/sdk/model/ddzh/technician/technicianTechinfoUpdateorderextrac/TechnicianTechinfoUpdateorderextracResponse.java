package com.meituan.sdk.model.ddzh.technician.technicianTechinfoUpdateorderextrac;

import com.google.gson.annotations.SerializedName;

/**
* 手艺人订单扩展信息修改
* This file was automatically generated.
*/
public class TechnicianTechinfoUpdateorderextracResponse {
    /**
    * 是否全部成功
    */
    @SerializedName("atLeastOneFail")
    private Boolean atLeastOneFail;
    /**
    * 订单修改结果
    */
    @SerializedName("orderId2Result")
    private String orderId2Result;

    public Boolean getAtLeastOneFail() {
        return atLeastOneFail;
    }
    public void setAtLeastOneFail(Boolean atLeastOneFail) {
        this.atLeastOneFail = atLeastOneFail;
    }
    public String getOrderId2Result() {
        return orderId2Result;
    }
    public void setOrderId2Result(String orderId2Result) {
        this.orderId2Result = orderId2Result;
    }




    @Override
    public String toString() {
        return "TechnicianTechinfoUpdateorderextracResponse{" + "atLeastOneFail=" + atLeastOneFail + "," + "orderId2Result=" + orderId2Result + "}";
    }
}
