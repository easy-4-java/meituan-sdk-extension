package com.meituan.sdk.model.rhone.mtp.orderConsumeNotice;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-7e31d107-0db9-4769-8959-2e2ba8df3fd7"><span style="color: ">本次核销的凭证码</span></p>
* This file was automatically generated.
*/
public class VoucherListSub {
    /**
    * <p data-diff-id="ct-diff-id-76aa5a1a-59c2-40ab-8d86-bd7fa70cc81d"><span style="color: ">凭证码</span></p>
    */
    @SerializedName("voucher")
    private String voucher;
    /**
    * <p data-diff-id="ct-diff-id-139897ea-4b27-43f1-b398-ab84075442f7"><span style="color: ">二维码凭证</span></p>
    */
    @SerializedName("voucherPics")
    private String voucherPics;
    /**
    * <p data-diff-id="ct-diff-id-73576dde-dcae-4775-88a0-1a8d6681b18d"><span style="color: ">凭证被消费或者被退款或者凭证最初生效时间;格式:YYYY-MM-DD HH:MM:SS 与status配合使用，status是退款则是退款时间，status是消费则是消费时间，status是未使用则是凭证生效时间</span></p>
    */
    @SerializedName("voucherInvalidTime")
    private String voucherInvalidTime;
    /**
    * <p data-diff-id="ct-diff-id-99fe79ec-e0cb-4d71-bb1f-d0a1d5ea2b22"><span style="color: ">与status配合使用，此状态下的凭证代表的数量</span></p>
    */
    @SerializedName("quantity")
    private Integer quantity;
    /**
    * <p data-diff-id="ct-diff-id-10f747ca-e737-469e-a838-0e450e2b7e32"><span style="color: ">凭证状态，0为未使用，1为已使用，2为已退款，3为已废弃（对应的门票还未消费，但是此凭证码作废了）</span></p>
    */
    @SerializedName("status")
    private Integer status;

    public String getVoucher() {
        return voucher;
    }
    public void setVoucher(String voucher) {
        this.voucher = voucher;
    }
    public String getVoucherPics() {
        return voucherPics;
    }
    public void setVoucherPics(String voucherPics) {
        this.voucherPics = voucherPics;
    }
    public String getVoucherInvalidTime() {
        return voucherInvalidTime;
    }
    public void setVoucherInvalidTime(String voucherInvalidTime) {
        this.voucherInvalidTime = voucherInvalidTime;
    }
    public Integer getQuantity() {
        return quantity;
    }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }




    @Override
    public String toString() {
        return "VoucherListSub{" + "voucher=" + voucher + "," + "voucherPics=" + voucherPics + "," + "voucherInvalidTime=" + voucherInvalidTime + "," + "quantity=" + quantity + "," + "status=" + status + "}";
    }
}
