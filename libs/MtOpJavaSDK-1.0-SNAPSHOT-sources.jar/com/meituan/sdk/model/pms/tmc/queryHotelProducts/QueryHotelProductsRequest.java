package com.meituan.sdk.model.pms.tmc.queryHotelProducts;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取酒店产品列表
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/tmc/queryHotelProducts",
    businessId = 57,
    apiVersion = "10026",
    apiName = "query_hotel_products",
    needAuth = true
)
public class QueryHotelProductsRequest implements MeituanRequest<QueryHotelProductsResponse> {
    /**
    * <p data-diff-id="ct-diff-id-2060fdd2-e8e4-4682-8c86-2e816b082c15"><em><span style="color: rgba(0, 0, 0, 0.65)">酒店ID</span></em></p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-b8f1735b-e838-4fd1-998d-a5fc3c83319b"><span style="color: #333">分页大小</span></p>
    */
    @NotNull(message = "pageSize不能为空")
    @SerializedName("pageSize")
    private Integer pageSize;
    /**
    * <p data-diff-id="ct-diff-id-8d9db952-40dc-4c5d-a84d-9034e1540fa0"><span style="color: #333">页码</span></p>
    */
    @NotNull(message = "currentPageNum不能为空")
    @SerializedName("currentPageNum")
    private Integer currentPageNum;
    /**
    * <p data-diff-id="ct-diff-id-cc978f0e-13d3-49e7-800f-4112d803ec73">状态列表 2-上线，3-下线，不填时默认只查“上线”状态的产品</p>
    */
    @SerializedName("statusList")
    private List<Integer> statusList;
    /**
    * <p data-diff-id="ct-diff-id-8c9ff4d5-0261-4358-9132-eaecf40582c6">渠道，海外渠道时必传，仅支持单渠道，参考值分别为: Agoda、Booking、Expedia</p>
    */
    @SerializedName("channel")
    private String channel;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    public Integer getCurrentPageNum() {
        return currentPageNum;
    }
    public void setCurrentPageNum(Integer currentPageNum) {
        this.currentPageNum = currentPageNum;
    }
    public List<Integer> getStatusList() {
        return statusList;
    }
    public void setStatusList(List<Integer> statusList) {
        this.statusList = statusList;
    }
    public String getChannel() {
        return channel;
    }
    public void setChannel(String channel) {
        this.channel = channel;
    }


    @Override
    public MeituanResponse<QueryHotelProductsResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<QueryHotelProductsResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "QueryHotelProductsRequest{" + "hotelId=" + hotelId + "," + "pageSize=" + pageSize + "," + "currentPageNum=" + currentPageNum + "," + "statusList=" + statusList + "," + "channel=" + channel + "}";
    }
}
