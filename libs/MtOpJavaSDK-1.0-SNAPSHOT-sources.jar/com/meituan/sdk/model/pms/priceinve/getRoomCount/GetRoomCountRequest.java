package com.meituan.sdk.model.pms.priceinve.getRoomCount;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取酒店房量
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/priceinve/getRoomCount",
    businessId = 57,
    apiVersion = "10017",
    apiName = "get_room_count",
    needAuth = true
)
public class GetRoomCountRequest implements MeituanRequest<GetRoomCountResponse> {
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-431be8de-d3f1-4969-8d6b-4e491ddea53e">房型编号列表</p>
    */
    @SerializedName("roomTypeIds")
    private List<String> roomTypeIds;
    /**
    * <p data-diff-id="ct-diff-id-82d32bcd-38aa-42b2-a490-feaf2ac0a8c6">渠道：<br>门店-Hotel、美团-MeiTuanEBK、携程<em>-</em>TRIP、抖音-DOUYIN、飞猪-FLIGGY、微信-WECHAT</p>
    */
    @NotBlank(message = "channel不能为空")
    @SerializedName("channel")
    private String channel;
    /**
    * <p data-diff-id="ct-diff-id-35fbe52b-8632-4a53-9100-df5fe5c15268">预抵时间，格式yyyy-MM-dd HH:mm:ss</p>
    */
    @NotBlank(message = "estimatedArriveTime不能为空")
    @SerializedName("estimatedArriveTime")
    private String estimatedArriveTime;
    /**
    * <p data-diff-id="ct-diff-id-818dfbd7-71b7-4632-821a-5a6d279344b3">预离时间，格式yyyy-MM-dd HH:mm:ss</p>
    */
    @NotBlank(message = "estimatedDepartureTime不能为空")
    @SerializedName("estimatedDepartureTime")
    private String estimatedDepartureTime;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public List<String> getRoomTypeIds() {
        return roomTypeIds;
    }
    public void setRoomTypeIds(List<String> roomTypeIds) {
        this.roomTypeIds = roomTypeIds;
    }
    public String getChannel() {
        return channel;
    }
    public void setChannel(String channel) {
        this.channel = channel;
    }
    public String getEstimatedArriveTime() {
        return estimatedArriveTime;
    }
    public void setEstimatedArriveTime(String estimatedArriveTime) {
        this.estimatedArriveTime = estimatedArriveTime;
    }
    public String getEstimatedDepartureTime() {
        return estimatedDepartureTime;
    }
    public void setEstimatedDepartureTime(String estimatedDepartureTime) {
        this.estimatedDepartureTime = estimatedDepartureTime;
    }


    @Override
    public MeituanResponse<GetRoomCountResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<GetRoomCountResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GetRoomCountRequest{" + "hotelId=" + hotelId + "," + "roomTypeIds=" + roomTypeIds + "," + "channel=" + channel + "," + "estimatedArriveTime=" + estimatedArriveTime + "," + "estimatedDepartureTime=" + estimatedDepartureTime + "}";
    }
}
