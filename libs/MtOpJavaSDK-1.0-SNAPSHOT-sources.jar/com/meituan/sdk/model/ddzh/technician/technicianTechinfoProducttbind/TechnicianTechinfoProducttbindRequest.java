package com.meituan.sdk.model.ddzh.technician.technicianTechinfoProducttbind;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 手艺人人货绑定
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/technician/techinfo/productbind",
    businessId = 58,
    apiVersion = "10004",
    apiName = "technician_techinfo_producttbind",
    needAuth = true
)
public class TechnicianTechinfoProducttbindRequest implements MeituanRequest<TechnicianTechinfoProducttbindResponse> {
    /**
    * <p data-diff-id="ct-diff-id-1504452a-c611-4ba3-8d81-83e91649de06">商品id列表</p>
    */
    @NotEmpty(message = "productIds不能为空")
    @SerializedName("productIds")
    private List<String> productIds;
    /**
    * <p data-diff-id="ct-diff-id-a51a4344-7c9d-4311-8e8b-f68c8458ac45">手艺人id</p>
    */
    @NotNull(message = "technicianId不能为空")
    @SerializedName("technicianId")
    private Integer technicianId;

    public List<String> getProductIds() {
        return productIds;
    }
    public void setProductIds(List<String> productIds) {
        this.productIds = productIds;
    }
    public Integer getTechnicianId() {
        return technicianId;
    }
    public void setTechnicianId(Integer technicianId) {
        this.technicianId = technicianId;
    }


    @Override
    public MeituanResponse<TechnicianTechinfoProducttbindResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<TechnicianTechinfoProducttbindResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TechnicianTechinfoProducttbindRequest{" + "productIds=" + productIds + "," + "technicianId=" + technicianId + "}";
    }
}
