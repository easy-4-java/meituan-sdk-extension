package com.meituan.sdk.model.ddzhkh.shangpin.productDealgroupQuery;

import com.google.gson.annotations.SerializedName;

/**
* 三方信息
* This file was automatically generated.
*/
public class ThirdPartyInfo {
    /**
    * 三方id
    */
    @SerializedName("thirdPartyID")
    private Integer thirdPartyID;
    /**
    * 企业号
    */
    @SerializedName("companySerial")
    private String companySerial;
    /**
    * 三方券id
    */
    @SerializedName("thirdPartyProductNo")
    private String thirdPartyProductNo;

    public Integer getThirdPartyID() {
        return thirdPartyID;
    }
    public void setThirdPartyID(Integer thirdPartyID) {
        this.thirdPartyID = thirdPartyID;
    }
    public String getCompanySerial() {
        return companySerial;
    }
    public void setCompanySerial(String companySerial) {
        this.companySerial = companySerial;
    }
    public String getThirdPartyProductNo() {
        return thirdPartyProductNo;
    }
    public void setThirdPartyProductNo(String thirdPartyProductNo) {
        this.thirdPartyProductNo = thirdPartyProductNo;
    }




    @Override
    public String toString() {
        return "ThirdPartyInfo{" + "thirdPartyID=" + thirdPartyID + "," + "companySerial=" + companySerial + "," + "thirdPartyProductNo=" + thirdPartyProductNo + "}";
    }
}
