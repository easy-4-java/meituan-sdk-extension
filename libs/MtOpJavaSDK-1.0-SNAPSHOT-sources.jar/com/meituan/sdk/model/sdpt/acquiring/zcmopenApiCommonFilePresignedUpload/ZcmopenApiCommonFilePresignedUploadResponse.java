package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiCommonFilePresignedUpload;

import com.google.gson.annotations.SerializedName;

/**
* [基础]生成授权第三方文件上传预签名URL
* This file was automatically generated.
*/
public class ZcmopenApiCommonFilePresignedUploadResponse {
    /**
    * 状态
    */
    @SerializedName("status")
    private String status;
    /**
    * 错误code
    */
    @SerializedName("errCode")
    private String errCode;
    /**
    * 错误描述
    */
    @SerializedName("errMsg")
    private String errMsg;
    /**
    * 子错误码（status 为失败的时候有）
    */
    @SerializedName("subCode")
    private String subCode;
    /**
    * 子错误码的描述（status 为失败的时候有）
    */
    @SerializedName("subMsg")
    private String subMsg;
    /**
    * 第三方直传预签名URL
    */
    @SerializedName("uploadUrl")
    private String uploadUrl;
    /**
    * HTTP上传方法
    */
    @SerializedName("method")
    private String method;
    /**
    * 上传时必须携带的Content-Type
    */
    @SerializedName("contentType")
    private String contentType;
    /**
    * 文件Key
    */
    @SerializedName("fileKey")
    private String fileKey;
    /**
    * 过期时间戳，单位毫秒
    */
    @SerializedName("expiresAt")
    private Integer expiresAt;

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getErrCode() {
        return errCode;
    }
    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }
    public String getErrMsg() {
        return errMsg;
    }
    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
    public String getSubCode() {
        return subCode;
    }
    public void setSubCode(String subCode) {
        this.subCode = subCode;
    }
    public String getSubMsg() {
        return subMsg;
    }
    public void setSubMsg(String subMsg) {
        this.subMsg = subMsg;
    }
    public String getUploadUrl() {
        return uploadUrl;
    }
    public void setUploadUrl(String uploadUrl) {
        this.uploadUrl = uploadUrl;
    }
    public String getMethod() {
        return method;
    }
    public void setMethod(String method) {
        this.method = method;
    }
    public String getContentType() {
        return contentType;
    }
    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
    public String getFileKey() {
        return fileKey;
    }
    public void setFileKey(String fileKey) {
        this.fileKey = fileKey;
    }
    public Integer getExpiresAt() {
        return expiresAt;
    }
    public void setExpiresAt(Integer expiresAt) {
        this.expiresAt = expiresAt;
    }




    @Override
    public String toString() {
        return "ZcmopenApiCommonFilePresignedUploadResponse{" + "status=" + status + "," + "errCode=" + errCode + "," + "errMsg=" + errMsg + "," + "subCode=" + subCode + "," + "subMsg=" + subMsg + "," + "uploadUrl=" + uploadUrl + "," + "method=" + method + "," + "contentType=" + contentType + "," + "fileKey=" + fileKey + "," + "expiresAt=" + expiresAt + "}";
    }
}
