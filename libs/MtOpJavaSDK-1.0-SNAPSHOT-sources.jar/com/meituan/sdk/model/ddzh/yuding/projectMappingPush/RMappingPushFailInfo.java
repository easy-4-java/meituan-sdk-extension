package com.meituan.sdk.model.ddzh.yuding.projectMappingPush;

import com.google.gson.annotations.SerializedName;

/**
* 推送失败错误信息
* This file was automatically generated.
*/
public class RMappingPushFailInfo {
    /**
    * 美团团购Id
    */
    @SerializedName("mtDealGroupId")
    private Long mtDealGroupId;
    /**
    * 错误明细
    */
    @SerializedName("errorMsg")
    private String errorMsg;

    public Long getMtDealGroupId() {
        return mtDealGroupId;
    }
    public void setMtDealGroupId(Long mtDealGroupId) {
        this.mtDealGroupId = mtDealGroupId;
    }
    public String getErrorMsg() {
        return errorMsg;
    }
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }




    @Override
    public String toString() {
        return "RMappingPushFailInfo{" + "mtDealGroupId=" + mtDealGroupId + "," + "errorMsg=" + errorMsg + "}";
    }
}
