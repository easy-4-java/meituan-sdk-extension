package com.meituan.sdk.model.tuangouNg.atomgoods.productSubjectPriceUpdate;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 更新菜品主体价格
* This file was automatically generated.
*/
@ApiMeta(
    path = "/tuangou/ng/atomgoods/product/subject/price/update",
    businessId = 1,
    apiVersion = "10022",
    apiName = "product_subject_price_update",
    needAuth = true
)
public class ProductSubjectPriceUpdateRequest implements MeituanRequest<ProductSubjectPriceUpdateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-cf5c0361-03b8-4bcf-af2f-e8524408fec5">附件信息/加价属性类型，1-总部, 2-门店</p>
    */
    @NotNull(message = "scope不能为空")
    @SerializedName("scope")
    private Integer scope;
    /**
    * <p data-diff-id="ct-diff-id-c9e85242-530d-4d63-9500-ecd4bdab5b49">总部code，当scope = 1时必填</p>
    */
    @SerializedName("vendorChainId")
    private String vendorChainId;
    /**
    * <p data-diff-id="ct-diff-id-9a3304c3-173b-4e1e-943f-ee610b197b40">门店code，当scope = 2时必填</p>
    */
    @SerializedName("vendorShopId")
    private String vendorShopId;
    /**
    * <p data-diff-id="ct-diff-id-b6e8dd86-c51f-467d-bf1e-7e0b29ed9727">主体类型：11-sku，20-加价属性，30-加料，40-餐盒</p>
    */
    @NotNull(message = "subjectType不能为空")
    @SerializedName("subjectType")
    private Integer subjectType;
    /**
    * <p data-diff-id="ct-diff-id-94714b29-4fbb-4818-b143-2413166076c7">批量更新的主体sku价格</p>
    */
    @NotEmpty(message = "subjectPriceList不能为空")
    @SerializedName("subjectPriceList")
    private List<SubjectPriceListSub> subjectPriceList;

    public Integer getScope() {
        return scope;
    }
    public void setScope(Integer scope) {
        this.scope = scope;
    }
    public String getVendorChainId() {
        return vendorChainId;
    }
    public void setVendorChainId(String vendorChainId) {
        this.vendorChainId = vendorChainId;
    }
    public String getVendorShopId() {
        return vendorShopId;
    }
    public void setVendorShopId(String vendorShopId) {
        this.vendorShopId = vendorShopId;
    }
    public Integer getSubjectType() {
        return subjectType;
    }
    public void setSubjectType(Integer subjectType) {
        this.subjectType = subjectType;
    }
    public List<SubjectPriceListSub> getSubjectPriceList() {
        return subjectPriceList;
    }
    public void setSubjectPriceList(List<SubjectPriceListSub> subjectPriceList) {
        this.subjectPriceList = subjectPriceList;
    }


    @Override
    public MeituanResponse<ProductSubjectPriceUpdateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ProductSubjectPriceUpdateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ProductSubjectPriceUpdateRequest{" + "scope=" + scope + "," + "vendorChainId=" + vendorChainId + "," + "vendorShopId=" + vendorShopId + "," + "subjectType=" + subjectType + "," + "subjectPriceList=" + subjectPriceList + "}";
    }
}
