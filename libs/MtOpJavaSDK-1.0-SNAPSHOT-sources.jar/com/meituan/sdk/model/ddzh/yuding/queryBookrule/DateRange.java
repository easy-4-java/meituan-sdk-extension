package com.meituan.sdk.model.ddzh.yuding.queryBookrule;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-14a08fef-b351-4d76-836d-c82fce1bd192">日期范围</p>
* This file was automatically generated.
*/
public class DateRange {
    /**
    * <p data-diff-id="ct-diff-id-53e0b9e3-b7d2-4bec-9385-f5a2fa999f44"><span style="color: #333">结束日期 格式yyyy-MM-dd</span></p>
    */
    @SerializedName("endDate")
    private String endDate;
    /**
    * <p data-diff-id="ct-diff-id-962c386a-332a-4ba4-94c8-5ad1b099c80b"><span style="color: #333">开始日期 格式yyyy-MM-dd</span></p>
    */
    @SerializedName("startDate")
    private String startDate;

    public String getEndDate() {
        return endDate;
    }
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    public String getStartDate() {
        return startDate;
    }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }




    @Override
    public String toString() {
        return "DateRange{" + "endDate=" + endDate + "," + "startDate=" + startDate + "}";
    }
}
