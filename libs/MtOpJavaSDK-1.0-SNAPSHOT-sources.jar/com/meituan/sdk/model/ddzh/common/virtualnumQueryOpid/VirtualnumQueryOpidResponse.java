package com.meituan.sdk.model.ddzh.common.virtualnumQueryOpid;

import com.google.gson.annotations.SerializedName;

/**
* 根据手机号查询对应混淆后ID(隐私号相关)
* This file was automatically generated.
*/
public class VirtualnumQueryOpidResponse {
    @SerializedName("opId")
    private String opId;

    public String getOpId() {
        return opId;
    }
    public void setOpId(String opId) {
        this.opId = opId;
    }




    @Override
    public String toString() {
        return "VirtualnumQueryOpidResponse{" + "opId=" + opId + "}";
    }
}
