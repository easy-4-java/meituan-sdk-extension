package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptGetconsumed;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询已验券信息
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/tuangou/receipt/getconsumed",
    businessId = 58,
    apiVersion = "10116",
    apiName = "tuangou_receipt_getconsumed",
    needAuth = true
)
public class TuangouReceiptGetconsumedRequest implements MeituanRequest<TuangouReceiptGetconsumedResponse> {
    /**
    * <p data-diff-id="ct-diff-id-f9517c0d-5440-4c18-958f-1e6883d39bdb"><span style="color: rgb(31, 45, 61)">团购券码</span></p>
    */
    @NotBlank(message = "receiptCode不能为空")
    @SerializedName("receiptCode")
    private String receiptCode;

    public String getReceiptCode() {
        return receiptCode;
    }
    public void setReceiptCode(String receiptCode) {
        this.receiptCode = receiptCode;
    }


    @Override
    public MeituanResponse<TuangouReceiptGetconsumedResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<TuangouReceiptGetconsumedResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TuangouReceiptGetconsumedRequest{" + "receiptCode=" + receiptCode + "}";
    }
}
