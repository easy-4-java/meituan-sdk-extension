package com.meituan.sdk.model.pms.reservation.addOrderWithCustomPrice;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-83deb49b-21f2-4985-bb25-d3d8ae7790b0">每日价格信息</p>
* This file was automatically generated.
*/
public class RoomPriceDTO {
    /**
    * <p data-diff-id="ct-diff-id-72ecc760-24f4-47f1-bf6e-2dd9680da98a">每天日期，格式yyyy-MM-dd</p>
    */
    @NotBlank(message = "date不能为空")
    @SerializedName("date")
    private String date;
    /**
    * <p data-diff-id="ct-diff-id-376c2008-ec89-4296-9639-9faf6b34abc7">实际价格：优惠价</p>
    */
    @NotBlank(message = "actualPrice不能为空")
    @SerializedName("actualPrice")
    private String actualPrice;

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getActualPrice() {
        return actualPrice;
    }
    public void setActualPrice(String actualPrice) {
        this.actualPrice = actualPrice;
    }




    @Override
    public String toString() {
        return "RoomPriceDTO{" + "date=" + date + "," + "actualPrice=" + actualPrice + "}";
    }
}
