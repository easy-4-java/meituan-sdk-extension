package com.meituan.sdk.model.ddzhkh.xcx3csmzl.refundOrder;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* 
* This file was automatically generated.
*/
public class RefundOrderReq {
    /**
    * <p data-diff-id="ct-diff-id-76325808-bd0a-459a-9be6-715ee44a67b8"><span style="color: rgba(0, 0, 0, 0.65)">美团订单号，与三方商户订单号二选一</span></p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-f46975e3-f176-48a8-9caa-fd09bc367d2d"><span style="color: rgba(0, 0, 0, 0.65)">三方商户订单号，与美团订单号二选一</span></p>
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * <p data-diff-id="ct-diff-id-73b46391-a58a-4084-832e-3ea2fe569e7b"><span style="color: rgba(0, 0, 0, 0.65)">美团订单支付id，与三方商户支付Id二选一，</span><span style="color: rgb(245, 34, 45)">多次支付场景必传</span></p>
    */
    @SerializedName("orderPaymentId")
    private String orderPaymentId;
    /**
    * <p data-diff-id="ct-diff-id-bebea712-3cf1-48bc-bd46-021b1af20901"><span style="color: rgb(102, 102, 102)">三方</span><span style="color: rgba(0, 0, 0, 0.65)">商户</span><span style="color: rgb(102, 102, 102)">支付Id，与美团订单支付id二选一，</span><span style="color: rgb(245, 34, 45)">多次支付场景必传</span></p>
    */
    @SerializedName("vendorPaymentId")
    private String vendorPaymentId;
    /**
    * <p data-diff-id="ct-diff-id-f9aa4c1a-36c0-40b3-9578-2058aa6f8530"><span style="color: rgba(0, 0, 0, 0.65)">商户退款号，长度 &lt;=128 byte</span></p>
    */
    @NotBlank(message = "vendorRefundId不能为空")
    @SerializedName("vendorRefundId")
    private String vendorRefundId;
    /**
    * <p data-diff-id="ct-diff-id-77c111b7-3158-4086-b46d-86c2c20e91df"><span style="color: rgba(0, 0, 0, 0.65)">订单退款金额，单位：分</span></p>
    */
    @NotNull(message = "totalRefundAmount不能为空")
    @SerializedName("totalRefundAmount")
    private Long totalRefundAmount;
    /**
    * <p data-diff-id="ct-diff-id-91d0dac3-4081-4d83-a043-5d83ed775c28"><span style="color: rgba(0, 0, 0, 0.65)">退款原因</span></p>
    */
    @SerializedName("reason")
    private String reason;
    /**
    * <p data-diff-id="ct-diff-id-bb9107d0-22ca-4686-9e7f-6ba959c76dbf"><span style="color: rgba(0, 0, 0, 0.65)">自定义透传字段，不支持二进制，长度 &lt;= 2048 byte</span></p>
    */
    @SerializedName("refundExt")
    private String refundExt;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public String getOrderPaymentId() {
        return orderPaymentId;
    }
    public void setOrderPaymentId(String orderPaymentId) {
        this.orderPaymentId = orderPaymentId;
    }
    public String getVendorPaymentId() {
        return vendorPaymentId;
    }
    public void setVendorPaymentId(String vendorPaymentId) {
        this.vendorPaymentId = vendorPaymentId;
    }
    public String getVendorRefundId() {
        return vendorRefundId;
    }
    public void setVendorRefundId(String vendorRefundId) {
        this.vendorRefundId = vendorRefundId;
    }
    public Long getTotalRefundAmount() {
        return totalRefundAmount;
    }
    public void setTotalRefundAmount(Long totalRefundAmount) {
        this.totalRefundAmount = totalRefundAmount;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }
    public String getRefundExt() {
        return refundExt;
    }
    public void setRefundExt(String refundExt) {
        this.refundExt = refundExt;
    }




    @Override
    public String toString() {
        return "RefundOrderReq{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "," + "orderPaymentId=" + orderPaymentId + "," + "vendorPaymentId=" + vendorPaymentId + "," + "vendorRefundId=" + vendorRefundId + "," + "totalRefundAmount=" + totalRefundAmount + "," + "reason=" + reason + "," + "refundExt=" + refundExt + "}";
    }
}
