package com.meituan.sdk.model.ddzhkh.xcxwy.createOrder;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.NotEmpty;

/**
* 
* This file was automatically generated.
*/
public class PriintingCreateOrderReq {
    @NotNull(message = "vendorInfoReq不能为空")
    @SerializedName("vendorInfoReq")
    private VendorInfoReq vendorInfoReq;
    /**
    * <p data-diff-id="ct-diff-id-0ffc5517-39bd-471d-bd72-dd727674e64b">订单超时时间，时间戳，毫秒值</p>
    */
    @NotNull(message = "expireTime不能为空")
    @SerializedName("expireTime")
    private Long expireTime;
    /**
    * <p data-diff-id="ct-diff-id-202a8ec5-b9bd-4989-a6d5-628cb836864f">用户实际支付金额，单位分</p>
    */
    @NotNull(message = "payAmount不能为空")
    @SerializedName("payAmount")
    private Long payAmount;
    /**
    * <p data-diff-id="ct-diff-id-bc40dfe8-c30b-4fff-95ac-2b83f12b9ddb">用户ip</p>
    */
    @NotBlank(message = "ip不能为空")
    @SerializedName("ip")
    private String ip;
    @NotEmpty(message = "productReqList不能为空")
    @SerializedName("productReqList")
    private List<BaseProductReq> productReqList;

    public VendorInfoReq getVendorInfoReq() {
        return vendorInfoReq;
    }
    public void setVendorInfoReq(VendorInfoReq vendorInfoReq) {
        this.vendorInfoReq = vendorInfoReq;
    }
    public Long getExpireTime() {
        return expireTime;
    }
    public void setExpireTime(Long expireTime) {
        this.expireTime = expireTime;
    }
    public Long getPayAmount() {
        return payAmount;
    }
    public void setPayAmount(Long payAmount) {
        this.payAmount = payAmount;
    }
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }
    public List<BaseProductReq> getProductReqList() {
        return productReqList;
    }
    public void setProductReqList(List<BaseProductReq> productReqList) {
        this.productReqList = productReqList;
    }




    @Override
    public String toString() {
        return "PriintingCreateOrderReq{" + "vendorInfoReq=" + vendorInfoReq + "," + "expireTime=" + expireTime + "," + "payAmount=" + payAmount + "," + "ip=" + ip + "," + "productReqList=" + productReqList + "}";
    }
}
