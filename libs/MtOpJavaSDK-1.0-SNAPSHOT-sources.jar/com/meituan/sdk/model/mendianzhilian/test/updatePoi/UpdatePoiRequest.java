package com.meituan.sdk.model.mendianzhilian.test.updatePoi;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 门店信息更新
* This file was automatically generated.
*/
@ApiMeta(
    path = "/mendianzhilian/test/map/poi/update",
    businessId = 71,
    apiVersion = "10017",
    apiName = "update_poi",
    needAuth = false
)
public class UpdatePoiRequest implements MeituanRequest<Long> {
    /**
    * <p data-diff-id="ct-diff-id-9cfb7d9d-1b60-4863-84e9-aee1f64a1547">外部品牌erp门店编码</p>
    */
    @NotBlank(message = "poiId不能为空")
    @SerializedName("poiId")
    private String poiId;
    /**
    * <p data-diff-id="ct-diff-id-44852de4-30b4-4534-bd45-8305cf832f3b"><span style="color: rgba(0, 0, 0, 0.65)">待变更的门店字段信息，只有需要变更的字段才需要填写，不变更的字段不要填写。</span></p>
    */
    @SerializedName("poiBase")
    private PoiBase poiBase;
    /**
    * <p data-diff-id="ct-diff-id-3f7ada37-fc3e-47c4-8612-add64799453a"><span style="color: rgba(0, 0, 0, 0.65)">资质举证列表</span></p>
    */
    @SerializedName("qualifications")
    private List<Qualification> qualifications;
    /**
    * <p data-diff-id="ct-diff-id-fbc18326-647f-4fb7-a69c-0f8589100bd4"><span style="color: rgba(0, 0, 0, 0.65)">扩展信息</span></p>
    */
    @SerializedName("ext")
    private String ext;

    public String getPoiId() {
        return poiId;
    }
    public void setPoiId(String poiId) {
        this.poiId = poiId;
    }
    public PoiBase getPoiBase() {
        return poiBase;
    }
    public void setPoiBase(PoiBase poiBase) {
        this.poiBase = poiBase;
    }
    public List<Qualification> getQualifications() {
        return qualifications;
    }
    public void setQualifications(List<Qualification> qualifications) {
        this.qualifications = qualifications;
    }
    public String getExt() {
        return ext;
    }
    public void setExt(String ext) {
        this.ext = ext;
    }


    @Override
    public MeituanResponse<Long> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Long>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "UpdatePoiRequest{" + "poiId=" + poiId + "," + "poiBase=" + poiBase + "," + "qualifications=" + qualifications + "," + "ext=" + ext + "}";
    }
}
