package com.meituan.sdk.model.pms.priceinve.changeRoomStatus;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 修改房态
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/priceinve/changeRoomStatus",
    businessId = 57,
    apiVersion = "10008",
    apiName = "change_room_status",
    needAuth = true
)
public class ChangeRoomStatusRequest implements MeituanRequest<ChangeRoomStatusResponse> {
    /**
    * <p data-diff-id="ct-diff-id-858bf054-cef8-43a7-93d6-833d6a4787b3">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-f1103da8-bf26-478e-ba6b-b636da2c0cdd">房间号</p>
    */
    @NotBlank(message = "roomNumber不能为空")
    @SerializedName("roomNumber")
    private String roomNumber;
    /**
    * <p data-diff-id="ct-diff-id-67c90921-238d-44a8-a302-212badd2054b">操作类型：TO_CLEAN:置净，TO_DIRTY:置脏,TO_CHECKIN:入住，TO_CHECKOUT:离店</p>
    */
    @NotBlank(message = "actionType不能为空")
    @SerializedName("actionType")
    private String actionType;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getRoomNumber() {
        return roomNumber;
    }
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }
    public String getActionType() {
        return actionType;
    }
    public void setActionType(String actionType) {
        this.actionType = actionType;
    }


    @Override
    public MeituanResponse<ChangeRoomStatusResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ChangeRoomStatusResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ChangeRoomStatusRequest{" + "hotelId=" + hotelId + "," + "roomNumber=" + roomNumber + "," + "actionType=" + actionType + "}";
    }
}
