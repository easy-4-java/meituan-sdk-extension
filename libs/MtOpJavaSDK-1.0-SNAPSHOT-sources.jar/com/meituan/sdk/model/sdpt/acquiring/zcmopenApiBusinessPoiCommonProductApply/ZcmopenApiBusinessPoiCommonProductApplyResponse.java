package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiBusinessPoiCommonProductApply;

import com.google.gson.annotations.SerializedName;

/**
* [产品]申请开通产品
* This file was automatically generated.
*/
public class ZcmopenApiBusinessPoiCommonProductApplyResponse {
    /**
    * 状态
    */
    @SerializedName("status")
    private String status;
    /**
    * 错误Code
    */
    @SerializedName("errCode")
    private String errCode;
    /**
    * 错误描述
    */
    @SerializedName("errMsg")
    private String errMsg;

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getErrCode() {
        return errCode;
    }
    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }
    public String getErrMsg() {
        return errMsg;
    }
    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }




    @Override
    public String toString() {
        return "ZcmopenApiBusinessPoiCommonProductApplyResponse{" + "status=" + status + "," + "errCode=" + errCode + "," + "errMsg=" + errMsg + "}";
    }
}
