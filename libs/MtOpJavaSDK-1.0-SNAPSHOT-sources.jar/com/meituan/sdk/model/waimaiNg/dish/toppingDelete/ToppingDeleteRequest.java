package com.meituan.sdk.model.waimaiNg.dish.toppingDelete;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 删除小料信息接口
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/dish/topping/delete",
    businessId = 2,
    apiVersion = "10113",
    apiName = "topping_delete",
    needAuth = true
)
public class ToppingDeleteRequest implements MeituanRequest<String> {
    /**
    * <p data-diff-id="ct-diff-id-b26e5db3-caa5-4321-a615-e3674951f390">即将删除的小料的toppingCode</p>
    */
    @NotEmpty(message = "toppingCodes不能为空")
    @SerializedName("toppingCodes")
    private List<String> toppingCodes;

    public List<String> getToppingCodes() {
        return toppingCodes;
    }
    public void setToppingCodes(List<String> toppingCodes) {
        this.toppingCodes = toppingCodes;
    }


    @Override
    public MeituanResponse<String> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<String>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ToppingDeleteRequest{" + "toppingCodes=" + toppingCodes + "}";
    }
}
