package com.meituan.sdk.model.rhone.mtp.orderPayNotice;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-15f12bc1-a137-4e41-9d2d-6969673d3574"><span style="color: ">凭证附加信息</span></p>
* This file was automatically generated.
*/
public class VoucherAdditionalListSub {
    /**
    * <p data-diff-id="ct-diff-id-9ae3fa43-5e4f-4b15-b8c9-a7b60c85c4c9"><span style="color: ">必须存在于MtpOrderPayResponseBody中的vouchers中voucher</span></p>
    */
    @SerializedName("voucher")
    private String voucher;
    /**
    * <p data-diff-id="ct-diff-id-509b2224-8f23-4e74-b7a7-f1eeedf4399e"><span style="color: ">凭证附加信息，key值为“1”，表示为手机尾号后四位，value为手机尾号后四位的值</span></p>
    */
    @SerializedName("additionMap")
    private Map additionMap;

    public String getVoucher() {
        return voucher;
    }
    public void setVoucher(String voucher) {
        this.voucher = voucher;
    }
    public Map getAdditionMap() {
        return additionMap;
    }
    public void setAdditionMap(Map additionMap) {
        this.additionMap = additionMap;
    }




    @Override
    public String toString() {
        return "VoucherAdditionalListSub{" + "voucher=" + voucher + "," + "additionMap=" + additionMap + "}";
    }
}
