package com.meituan.sdk.model.pms.hourpriceinve.getHourRoomPrice;

import com.google.gson.annotations.SerializedName;

/**
* 加收详情
* This file was automatically generated.
*/
public class HotelHourlyRoomSurchargeDetailDTO {
    /**
    * 加收计价单位（分钟）
    */
    @SerializedName("surchargeUnit")
    private Integer surchargeUnit;
    /**
    * 单位计价加收值（元）
    */
    @SerializedName("additionValue")
    private String additionValue;

    public Integer getSurchargeUnit() {
        return surchargeUnit;
    }
    public void setSurchargeUnit(Integer surchargeUnit) {
        this.surchargeUnit = surchargeUnit;
    }
    public String getAdditionValue() {
        return additionValue;
    }
    public void setAdditionValue(String additionValue) {
        this.additionValue = additionValue;
    }




    @Override
    public String toString() {
        return "HotelHourlyRoomSurchargeDetailDTO{" + "surchargeUnit=" + surchargeUnit + "," + "additionValue=" + additionValue + "}";
    }
}
