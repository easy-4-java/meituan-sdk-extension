package com.meituan.sdk.model.design.image.dishGenerate;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 菜品生成
* This file was automatically generated.
*/
@ApiMeta(
    path = "/design/image/dish_generate",
    businessId = 24,
    apiVersion = "10030",
    apiName = "dish_generate",
    needAuth = false
)
public class DishGenerateRequest implements MeituanRequest<DishGenerateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-2a106403-0672-420c-bf14-5edaa19804d8">菜品名称和相关背景、餐具、风格的描述</p>
    */
    @NotBlank(message = "prompt不能为空")
    @SerializedName("prompt")
    private String prompt;
    /**
    * <p data-diff-id="ct-diff-id-e4273996-43bf-4094-aa0a-1dd0e852f85e">图像宽度</p>
    */
    @SerializedName("width")
    private String width;
    /**
    * <p data-diff-id="ct-diff-id-1c704749-f053-4e6c-9d3a-7cbb78585124">图像高度</p>
    */
    @SerializedName("height")
    private String height;

    public String getPrompt() {
        return prompt;
    }
    public void setPrompt(String prompt) {
        this.prompt = prompt;
    }
    public String getWidth() {
        return width;
    }
    public void setWidth(String width) {
        this.width = width;
    }
    public String getHeight() {
        return height;
    }
    public void setHeight(String height) {
        this.height = height;
    }


    @Override
    public MeituanResponse<DishGenerateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<DishGenerateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "DishGenerateRequest{" + "prompt=" + prompt + "," + "width=" + width + "," + "height=" + height + "}";
    }
}
