package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiFinanceSettleQueryByid;

import com.google.gson.annotations.SerializedName;

/**
* 分页参数
* This file was automatically generated.
*/
public class PageInfoDTO {
    /**
    * 当前页码
    */
    @SerializedName("currentPageNo")
    private Integer currentPageNo;
    /**
    * 页大小
    */
    @SerializedName("pageSize")
    private Integer pageSize;
    /**
    * 总数
    */
    @SerializedName("totalCount")
    private Integer totalCount;
    /**
    * 总页数
    */
    @SerializedName("totalPageCount")
    private Integer totalPageCount;

    public Integer getCurrentPageNo() {
        return currentPageNo;
    }
    public void setCurrentPageNo(Integer currentPageNo) {
        this.currentPageNo = currentPageNo;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    public Integer getTotalCount() {
        return totalCount;
    }
    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }
    public Integer getTotalPageCount() {
        return totalPageCount;
    }
    public void setTotalPageCount(Integer totalPageCount) {
        this.totalPageCount = totalPageCount;
    }




    @Override
    public String toString() {
        return "PageInfoDTO{" + "currentPageNo=" + currentPageNo + "," + "pageSize=" + pageSize + "," + "totalCount=" + totalCount + "," + "totalPageCount=" + totalPageCount + "}";
    }
}
