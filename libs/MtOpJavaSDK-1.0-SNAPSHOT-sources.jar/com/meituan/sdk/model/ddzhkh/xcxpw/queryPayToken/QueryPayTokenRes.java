package com.meituan.sdk.model.ddzhkh.xcxpw.queryPayToken;

import com.google.gson.annotations.SerializedName;

/**
* 查询结果
* This file was automatically generated.
*/
public class QueryPayTokenRes {
    /**
    * 美团订单号
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * 三方订单号
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * 日志号
    */
    @SerializedName("tradeNo")
    private String tradeNo;
    /**
    * 收银台支付token
    */
    @SerializedName("payToken")
    private String payToken;
    /**
    * 美团订单支付id
    */
    @SerializedName("orderPaymentId")
    private String orderPaymentId;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public String getTradeNo() {
        return tradeNo;
    }
    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }
    public String getPayToken() {
        return payToken;
    }
    public void setPayToken(String payToken) {
        this.payToken = payToken;
    }
    public String getOrderPaymentId() {
        return orderPaymentId;
    }
    public void setOrderPaymentId(String orderPaymentId) {
        this.orderPaymentId = orderPaymentId;
    }




    @Override
    public String toString() {
        return "QueryPayTokenRes{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "," + "tradeNo=" + tradeNo + "," + "payToken=" + payToken + "," + "orderPaymentId=" + orderPaymentId + "}";
    }
}
