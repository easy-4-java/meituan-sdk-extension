package com.meituan.sdk.model.ddzh.thirdresource.updateDeviceInfo;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-a80c19f9-11d5-4164-9293-ef02228eee83"><span style="color: rgba(0, 0, 0, 0.65)">信息变更设备列表</span></p>
* This file was automatically generated.
*/
public class UnifiedDeviceItem {
    /**
    * <p data-diff-id="ct-diff-id-3c697893-1740-4591-9b20-976cd8aa7244"><span style="color: rgba(0, 0, 0, 0.65)">类目编码</span></p>
    */
    @NotBlank(message = "categoryCode不能为空")
    @SerializedName("categoryCode")
    private String categoryCode;
    /**
    * <p data-diff-id="ct-diff-id-37e022e8-3f5e-4400-8d4b-41a08c8c35d8"><span style="color: rgba(0, 0, 0, 0.65)">三方设备ID，设备在商家侧的唯一标识</span></p>
    */
    @NotBlank(message = "thirdPartyDeviceItemId不能为空")
    @SerializedName("thirdPartyDeviceItemId")
    private String thirdPartyDeviceItemId;
    /**
    * <p data-diff-id="ct-diff-id-236dbc21-8cd8-4ab4-a289-d2a62ea89943"><span style="color: rgba(0, 0, 0, 0.65)">名称</span></p>
    */
    @NotBlank(message = "deviceItemName不能为空")
    @SerializedName("deviceItemName")
    private String deviceItemName;
    /**
    * <p data-diff-id="ct-diff-id-63863dc1-c78a-4333-88c0-1175f9d972b8"><span style="color: rgba(0, 0, 0, 0.65)">描述列表</span></p>
    */
    @SerializedName("deviceItemDescs")
    private List<String> deviceItemDescs;
    /**
    * <p data-diff-id="ct-diff-id-2d46d8ab-93da-48fd-9740-4aa7262af013"><span style="color: rgba(0, 0, 0, 0.65)">是否和门店绑定：true-是、false-否</span></p>
    */
    @NotNull(message = "isBound不能为空")
    @SerializedName("isBound")
    private Boolean isBound;
    /**
    * <p data-diff-id="ct-diff-id-39308824-64d0-4859-a589-128ae1254cde"><span style="color: rgba(0, 0, 0, 0.65)">是否可远程操控：0-不可操控、1-可操控</span></p>
    */
    @NotNull(message = "isOperable不能为空")
    @SerializedName("isOperable")
    private Integer isOperable;
    /**
    * <p data-diff-id="ct-diff-id-fa767cb7-99d8-454d-a90d-abac1d5b2d1f"><span style="color: rgba(0, 0, 0, 0.65)">状态信息</span></p>
    */
    @SerializedName("statusInfo")
    private DeviceStatusInfo statusInfo;
    /**
    * <p data-diff-id="ct-diff-id-4eece75f-f038-4b56-9d38-c24d23055440"><span style="color: rgba(0, 0, 0, 0.65)">铺设/就绪日期</span></p>
    */
    @SerializedName("deviceReadyDate")
    private Long deviceReadyDate;
    /**
    * <p data-diff-id="ct-diff-id-e773ad05-a0ac-44b1-9cfe-59a61da2b026"><span style="color: rgba(0, 0, 0, 0.65)">三方型号编码，设备型号在商家侧的唯一标识</span></p>
    */
    @SerializedName("thirdPartyDeviceModelCode")
    private String thirdPartyDeviceModelCode;
    /**
    * <p data-diff-id="ct-diff-id-a30a6d63-8ce7-4136-a724-f95b8148a824"><span style="color: rgba(0, 0, 0, 0.65)">最近一次维护日志</span></p>
    */
    @SerializedName("maintenanceLogs")
    private List<DeviceMaintenanceLog> maintenanceLogs;
    /**
    * <p data-diff-id="ct-diff-id-ac3bcbf8-fd44-4dfa-9db5-5dd34b2a4793"><span style="color: rgba(0, 0, 0, 0.65)">计费规则</span></p>
    */
    @SerializedName("pricingInfo")
    private DevicePricingInfo pricingInfo;
    /**
    * <p data-diff-id="ct-diff-id-7d7d5a07-2572-4496-8f47-654a0e5e5e54"><span style="color: rgba(0, 0, 0, 0.65)">扩展信息列表</span></p>
    */
    @SerializedName("attrs")
    private List<Attribute> attrs;
    /**
    * <p data-diff-id="ct-diff-id-e663ecaa-9ab1-4867-80d4-5a1ff9a1ef05"><span style="color: rgb(51, 51, 51)">特征标签列表</span></p>
    */
    @SerializedName("deviceFeatureTags")
    private List<Integer> deviceFeatureTags;

    public String getCategoryCode() {
        return categoryCode;
    }
    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }
    public String getThirdPartyDeviceItemId() {
        return thirdPartyDeviceItemId;
    }
    public void setThirdPartyDeviceItemId(String thirdPartyDeviceItemId) {
        this.thirdPartyDeviceItemId = thirdPartyDeviceItemId;
    }
    public String getDeviceItemName() {
        return deviceItemName;
    }
    public void setDeviceItemName(String deviceItemName) {
        this.deviceItemName = deviceItemName;
    }
    public List<String> getDeviceItemDescs() {
        return deviceItemDescs;
    }
    public void setDeviceItemDescs(List<String> deviceItemDescs) {
        this.deviceItemDescs = deviceItemDescs;
    }
    public Boolean getIsBound() {
        return isBound;
    }
    public void setIsBound(Boolean isBound) {
        this.isBound = isBound;
    }
    public Integer getIsOperable() {
        return isOperable;
    }
    public void setIsOperable(Integer isOperable) {
        this.isOperable = isOperable;
    }
    public DeviceStatusInfo getStatusInfo() {
        return statusInfo;
    }
    public void setStatusInfo(DeviceStatusInfo statusInfo) {
        this.statusInfo = statusInfo;
    }
    public Long getDeviceReadyDate() {
        return deviceReadyDate;
    }
    public void setDeviceReadyDate(Long deviceReadyDate) {
        this.deviceReadyDate = deviceReadyDate;
    }
    public String getThirdPartyDeviceModelCode() {
        return thirdPartyDeviceModelCode;
    }
    public void setThirdPartyDeviceModelCode(String thirdPartyDeviceModelCode) {
        this.thirdPartyDeviceModelCode = thirdPartyDeviceModelCode;
    }
    public List<DeviceMaintenanceLog> getMaintenanceLogs() {
        return maintenanceLogs;
    }
    public void setMaintenanceLogs(List<DeviceMaintenanceLog> maintenanceLogs) {
        this.maintenanceLogs = maintenanceLogs;
    }
    public DevicePricingInfo getPricingInfo() {
        return pricingInfo;
    }
    public void setPricingInfo(DevicePricingInfo pricingInfo) {
        this.pricingInfo = pricingInfo;
    }
    public List<Attribute> getAttrs() {
        return attrs;
    }
    public void setAttrs(List<Attribute> attrs) {
        this.attrs = attrs;
    }
    public List<Integer> getDeviceFeatureTags() {
        return deviceFeatureTags;
    }
    public void setDeviceFeatureTags(List<Integer> deviceFeatureTags) {
        this.deviceFeatureTags = deviceFeatureTags;
    }




    @Override
    public String toString() {
        return "UnifiedDeviceItem{" + "categoryCode=" + categoryCode + "," + "thirdPartyDeviceItemId=" + thirdPartyDeviceItemId + "," + "deviceItemName=" + deviceItemName + "," + "deviceItemDescs=" + deviceItemDescs + "," + "isBound=" + isBound + "," + "isOperable=" + isOperable + "," + "statusInfo=" + statusInfo + "," + "deviceReadyDate=" + deviceReadyDate + "," + "thirdPartyDeviceModelCode=" + thirdPartyDeviceModelCode + "," + "maintenanceLogs=" + maintenanceLogs + "," + "pricingInfo=" + pricingInfo + "," + "attrs=" + attrs + "," + "deviceFeatureTags=" + deviceFeatureTags + "}";
    }
}
