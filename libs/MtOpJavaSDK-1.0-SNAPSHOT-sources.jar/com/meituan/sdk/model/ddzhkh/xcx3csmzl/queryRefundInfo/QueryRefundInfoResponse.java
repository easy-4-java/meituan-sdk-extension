package com.meituan.sdk.model.ddzhkh.xcx3csmzl.queryRefundInfo;

import com.google.gson.annotations.SerializedName;

/**
* 查询退款结果
* This file was automatically generated.
*/
public class QueryRefundInfoResponse {
    @SerializedName("extra")
    private Extra extra;
    @SerializedName("res")
    private Res res;

    public Extra getExtra() {
        return extra;
    }
    public void setExtra(Extra extra) {
        this.extra = extra;
    }
    public Res getRes() {
        return res;
    }
    public void setRes(Res res) {
        this.res = res;
    }




    @Override
    public String toString() {
        return "QueryRefundInfoResponse{" + "extra=" + extra + "," + "res=" + res + "}";
    }
}
