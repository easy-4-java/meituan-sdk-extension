package com.meituan.sdk.model.ddzh.yuding.ktvRoomSync;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class KtvRoomDTO4 {
    @SerializedName("roomId")
    private Long roomId;
    @SerializedName("roomName")
    private String roomName;
    @SerializedName("roomCount")
    private Integer roomCount;

    public Long getRoomId() {
        return roomId;
    }
    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }
    public String getRoomName() {
        return roomName;
    }
    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }
    public Integer getRoomCount() {
        return roomCount;
    }
    public void setRoomCount(Integer roomCount) {
        this.roomCount = roomCount;
    }




    @Override
    public String toString() {
        return "KtvRoomDTO4{" + "roomId=" + roomId + "," + "roomName=" + roomName + "," + "roomCount=" + roomCount + "}";
    }
}
