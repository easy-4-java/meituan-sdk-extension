package com.meituan.sdk.model.waimaiNg.diancan.diancanShopStatusUpdate;

import com.google.gson.annotations.SerializedName;

/**
* 门店业务开通
* This file was automatically generated.
*/
public class DiancanShopStatusUpdateResponse {
    /**
    * 结果返回值为Map<String,ResultData>  key：厂商门店ID  value：操作结果状态
    */
    @SerializedName("data")
    private String data;

    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "DiancanShopStatusUpdateResponse{" + "data=" + data + "}";
    }
}
