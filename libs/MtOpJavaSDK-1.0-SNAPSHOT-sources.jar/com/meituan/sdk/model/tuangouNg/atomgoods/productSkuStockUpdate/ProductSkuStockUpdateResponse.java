package com.meituan.sdk.model.tuangouNg.atomgoods.productSkuStockUpdate;


/**
* 更新菜品主体库存
* This file was automatically generated.
*/
public class ProductSkuStockUpdateResponse {





}
