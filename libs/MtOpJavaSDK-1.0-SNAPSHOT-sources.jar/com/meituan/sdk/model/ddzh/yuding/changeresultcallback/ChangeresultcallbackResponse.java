package com.meituan.sdk.model.ddzh.yuding.changeresultcallback;

import com.google.gson.annotations.SerializedName;

/**
* 改约结果回调
* This file was automatically generated.
*/
public class ChangeresultcallbackResponse {
    /**
    * true-成功，false-失败
    */
    @SerializedName("result")
    private Boolean result;

    public Boolean getResult() {
        return result;
    }
    public void setResult(Boolean result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "ChangeresultcallbackResponse{" + "result=" + result + "}";
    }
}
