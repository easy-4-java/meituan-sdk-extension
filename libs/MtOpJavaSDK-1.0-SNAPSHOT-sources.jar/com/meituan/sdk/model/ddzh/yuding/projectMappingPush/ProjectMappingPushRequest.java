package com.meituan.sdk.model.ddzh.yuding.projectMappingPush;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 团购-三方项目Id关联关系推送
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/resource/productmapping",
    businessId = 58,
    apiVersion = "10064",
    apiName = "project_mapping_push",
    needAuth = true
)
public class ProjectMappingPushRequest implements MeituanRequest<ProjectMappingPushResponse> {
    @NotEmpty(message = "projectMappingList不能为空")
    @SerializedName("projectMappingList")
    private List<MappingInfo> projectMappingList;

    public List<MappingInfo> getProjectMappingList() {
        return projectMappingList;
    }
    public void setProjectMappingList(List<MappingInfo> projectMappingList) {
        this.projectMappingList = projectMappingList;
    }


    @Override
    public MeituanResponse<ProjectMappingPushResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ProjectMappingPushResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ProjectMappingPushRequest{" + "projectMappingList=" + projectMappingList + "}";
    }
}
