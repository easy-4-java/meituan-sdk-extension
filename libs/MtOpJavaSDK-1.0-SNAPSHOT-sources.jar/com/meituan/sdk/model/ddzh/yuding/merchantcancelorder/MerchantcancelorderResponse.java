package com.meituan.sdk.model.ddzh.yuding.merchantcancelorder;

import com.google.gson.annotations.SerializedName;

/**
* 商家取消订单
* This file was automatically generated.
*/
public class MerchantcancelorderResponse {
    /**
    * 调用结果
    */
    @SerializedName("result")
    private String result;

    public String getResult() {
        return result;
    }
    public void setResult(String result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "MerchantcancelorderResponse{" + "result=" + result + "}";
    }
}
