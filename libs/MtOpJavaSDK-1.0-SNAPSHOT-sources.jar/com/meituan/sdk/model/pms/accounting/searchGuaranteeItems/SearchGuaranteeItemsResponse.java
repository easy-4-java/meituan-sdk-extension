package com.meituan.sdk.model.pms.accounting.searchGuaranteeItems;

import com.google.gson.annotations.SerializedName;

/**
* 查询预授权
* This file was automatically generated.
*/
public class SearchGuaranteeItemsResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    /**
    * 预授权信息
    */
    @SerializedName("data")
    private TPageResponseData data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public TPageResponseData getData() {
        return data;
    }
    public void setData(TPageResponseData data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "SearchGuaranteeItemsResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
