package com.meituan.sdk.model.pms.reservation.queryRoomRentSurchargeRule;

import com.google.gson.annotations.SerializedName;

/**
* 房费加收明细
* This file was automatically generated.
*/
public class RoomRentSurchargeDetailDTO {
    /**
    * 占房ID
    */
    @SerializedName("occupationId")
    private Long occupationId;
    /**
    * 房间号
    */
    @SerializedName("roomNumber")
    private String roomNumber;
    /**
    * 入住人姓名
    */
    @SerializedName("checkinCustomerName")
    private String checkinCustomerName;
    /**
    * 加收金额
    */
    @SerializedName("amount")
    private String amount;
    /**
    * 是否显示全天房超时按小时加收的选项
    */
    @SerializedName("showHoursSurchargeForDailyRoom")
    private Boolean showHoursSurchargeForDailyRoom;

    public Long getOccupationId() {
        return occupationId;
    }
    public void setOccupationId(Long occupationId) {
        this.occupationId = occupationId;
    }
    public String getRoomNumber() {
        return roomNumber;
    }
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }
    public String getCheckinCustomerName() {
        return checkinCustomerName;
    }
    public void setCheckinCustomerName(String checkinCustomerName) {
        this.checkinCustomerName = checkinCustomerName;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public Boolean getShowHoursSurchargeForDailyRoom() {
        return showHoursSurchargeForDailyRoom;
    }
    public void setShowHoursSurchargeForDailyRoom(Boolean showHoursSurchargeForDailyRoom) {
        this.showHoursSurchargeForDailyRoom = showHoursSurchargeForDailyRoom;
    }




    @Override
    public String toString() {
        return "RoomRentSurchargeDetailDTO{" + "occupationId=" + occupationId + "," + "roomNumber=" + roomNumber + "," + "checkinCustomerName=" + checkinCustomerName + "," + "amount=" + amount + "," + "showHoursSurchargeForDailyRoom=" + showHoursSurchargeForDailyRoom + "}";
    }
}
