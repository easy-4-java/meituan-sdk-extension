package com.meituan.sdk.model.ddzhkh.xcx3csmzl.queryOrder;

import com.google.gson.annotations.SerializedName;

/**
* 业务交互结果业务交互结果
* This file was automatically generated.
*/
public class ResObj {
    @SerializedName("code")
    private Integer code;
    @SerializedName("msg")
    private String msg;
    @SerializedName("data")
    private OrderInfoRes data;

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public OrderInfoRes getData() {
        return data;
    }
    public void setData(OrderInfoRes data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "ResObj{" + "code=" + code + "," + "msg=" + msg + "," + "data=" + data + "}";
    }
}
