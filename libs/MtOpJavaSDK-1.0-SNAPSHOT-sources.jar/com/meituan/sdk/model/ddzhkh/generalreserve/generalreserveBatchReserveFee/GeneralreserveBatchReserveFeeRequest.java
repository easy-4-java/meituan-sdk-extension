package com.meituan.sdk.model.ddzhkh.generalreserve.generalreserveBatchReserveFee;

import com.meituan.sdk.annotations.ApiMeta;
import java.lang.Void;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 批量挂号费设置
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/generalreserve/batch/reserve/fee",
    businessId = 59,
    apiVersion = "10023",
    apiName = "generalreserve_batch_reserve_fee",
    needAuth = true
)
public class GeneralreserveBatchReserveFeeRequest implements MeituanRequest<Void> {
    @NotEmpty(message = "registrationFees不能为空")
    @SerializedName("registrationFees")
    private List<ThirdRegistrationFeeDTO> registrationFees;

    public List<ThirdRegistrationFeeDTO> getRegistrationFees() {
        return registrationFees;
    }
    public void setRegistrationFees(List<ThirdRegistrationFeeDTO> registrationFees) {
        this.registrationFees = registrationFees;
    }


    @Override
    public MeituanResponse<Void> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Void>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GeneralreserveBatchReserveFeeRequest{" + "registrationFees=" + registrationFees + "}";
    }
}
