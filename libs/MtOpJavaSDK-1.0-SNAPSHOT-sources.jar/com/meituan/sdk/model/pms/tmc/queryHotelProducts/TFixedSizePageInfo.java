package com.meituan.sdk.model.pms.tmc.queryHotelProducts;

import com.google.gson.annotations.SerializedName;

/**
* 分页信息
* This file was automatically generated.
*/
public class TFixedSizePageInfo {
    /**
    * 当前页数
    */
    @SerializedName("currentPageNum")
    private Integer currentPageNum;
    /**
    * 每页显示数量
    */
    @SerializedName("pageSize")
    private Integer pageSize;
    /**
    * 总页数
    */
    @SerializedName("totalPageCount")
    private Integer totalPageCount;
    /**
    * 总条数
    */
    @SerializedName("totalCount")
    private Integer totalCount;

    public Integer getCurrentPageNum() {
        return currentPageNum;
    }
    public void setCurrentPageNum(Integer currentPageNum) {
        this.currentPageNum = currentPageNum;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    public Integer getTotalPageCount() {
        return totalPageCount;
    }
    public void setTotalPageCount(Integer totalPageCount) {
        this.totalPageCount = totalPageCount;
    }
    public Integer getTotalCount() {
        return totalCount;
    }
    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }




    @Override
    public String toString() {
        return "TFixedSizePageInfo{" + "currentPageNum=" + currentPageNum + "," + "pageSize=" + pageSize + "," + "totalPageCount=" + totalPageCount + "," + "totalCount=" + totalCount + "}";
    }
}
