package com.meituan.sdk.model.ddzhkh.shangpin.productProductSubmit;

import com.google.gson.annotations.SerializedName;

/**
* 提交商品
* This file was automatically generated.
*/
public class ProductProductSubmitResponse {
    /**
    * 美团商品ID。提交商品成功后，会异步返回商品流程状态变更消息，可能会因为审核等原因上架失败
    */
    @SerializedName("productId")
    private Long productId;

    public Long getProductId() {
        return productId;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }




    @Override
    public String toString() {
        return "ProductProductSubmitResponse{" + "productId=" + productId + "}";
    }
}
