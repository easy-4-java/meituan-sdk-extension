package com.meituan.sdk.model.resv2.rule.supplyRuleSave;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class VendorTimeRuleDTO {
    /**
    * <p data-diff-id="ct-diff-id-198163ad-5051-4bec-825a-86152399becb"><span style="color: rgba(0, 0, 0, 0.65)">星期</span></p>
    */
    @SerializedName("weeDayList")
    private List<Integer> weeDayList;
    /**
    * <p data-diff-id="ct-diff-id-2004ca84-f84a-4838-a652-a242823c00d2"><span style="color: rgba(0, 0, 0, 0.65)">餐段开始结束时间</span></p>
    */
    @SerializedName("vendorTimePeriodDTOList")
    private List<VendorTimePeriodDTO> vendorTimePeriodDTOList;
    /**
    * <p data-diff-id="ct-diff-id-84845b72-dc94-48fc-b49e-b94fc486fb00"><span style="color: rgba(0, 0, 0, 0.65)">提前可订规则</span></p>
    */
    @SerializedName("vendorAdvanceRuleDTO")
    private VendorAdvanceRuleDTO vendorAdvanceRuleDTO;

    public List<Integer> getWeeDayList() {
        return weeDayList;
    }
    public void setWeeDayList(List<Integer> weeDayList) {
        this.weeDayList = weeDayList;
    }
    public List<VendorTimePeriodDTO> getVendorTimePeriodDTOList() {
        return vendorTimePeriodDTOList;
    }
    public void setVendorTimePeriodDTOList(List<VendorTimePeriodDTO> vendorTimePeriodDTOList) {
        this.vendorTimePeriodDTOList = vendorTimePeriodDTOList;
    }
    public VendorAdvanceRuleDTO getVendorAdvanceRuleDTO() {
        return vendorAdvanceRuleDTO;
    }
    public void setVendorAdvanceRuleDTO(VendorAdvanceRuleDTO vendorAdvanceRuleDTO) {
        this.vendorAdvanceRuleDTO = vendorAdvanceRuleDTO;
    }




    @Override
    public String toString() {
        return "VendorTimeRuleDTO{" + "weeDayList=" + weeDayList + "," + "vendorTimePeriodDTOList=" + vendorTimePeriodDTOList + "," + "vendorAdvanceRuleDTO=" + vendorAdvanceRuleDTO + "}";
    }
}
