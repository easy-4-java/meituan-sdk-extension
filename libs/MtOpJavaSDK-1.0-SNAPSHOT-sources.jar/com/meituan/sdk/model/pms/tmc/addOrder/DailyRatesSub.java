package com.meituan.sdk.model.pms.tmc.addOrder;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-ad2a8555-26f2-4d4b-ad04-0effb5eb3a78">每日价格：如2/1入住2/3离店，共两天，每天两间，则dailyRates有4个元素，包括2/1两个间夜的价格+2/2两个间夜的价格。支持单天多间不同价。</p>
* This file was automatically generated.
*/
public class DailyRatesSub {
    /**
    * <p data-diff-id="ct-diff-id-7c8f71ef-5c9f-4e7f-9fa9-c3291dffe877">价格日期</p>
    */
    @NotBlank(message = "date不能为空")
    @SerializedName("date")
    private String date;
    /**
    * <p data-diff-id="ct-diff-id-ab14f1bb-6bcb-4324-ab13-368bab475883">原始价格（单位：元）</p>
    */
    @NotBlank(message = "originPrice不能为空")
    @SerializedName("originPrice")
    private String originPrice;
    /**
    * <p data-diff-id="ct-diff-id-b59d295d-dfd5-4b36-ae14-0312280d296a">促后价格（单位：元）</p>
    */
    @NotBlank(message = "actualPrice不能为空")
    @SerializedName("actualPrice")
    private String actualPrice;

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getOriginPrice() {
        return originPrice;
    }
    public void setOriginPrice(String originPrice) {
        this.originPrice = originPrice;
    }
    public String getActualPrice() {
        return actualPrice;
    }
    public void setActualPrice(String actualPrice) {
        this.actualPrice = actualPrice;
    }




    @Override
    public String toString() {
        return "DailyRatesSub{" + "date=" + date + "," + "originPrice=" + originPrice + "," + "actualPrice=" + actualPrice + "}";
    }
}
