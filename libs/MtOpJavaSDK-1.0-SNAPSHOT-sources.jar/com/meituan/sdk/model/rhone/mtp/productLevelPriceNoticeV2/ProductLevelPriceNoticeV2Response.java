package com.meituan.sdk.model.rhone.mtp.productLevelPriceNoticeV2;

import com.google.gson.annotations.SerializedName;

/**
* 多层价格日历变化通知V2
* This file was automatically generated.
*/
public class ProductLevelPriceNoticeV2Response {
    /**
    * 交互码，200为成功，300为失败
    */
    @SerializedName("code")
    private Integer code;
    /**
    * 响应描述
    */
    @SerializedName("describe")
    private String describe;
    /**
    * 合作方ID
    */
    @SerializedName("partnerId")
    private Integer partnerId;

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getDescribe() {
        return describe;
    }
    public void setDescribe(String describe) {
        this.describe = describe;
    }
    public Integer getPartnerId() {
        return partnerId;
    }
    public void setPartnerId(Integer partnerId) {
        this.partnerId = partnerId;
    }




    @Override
    public String toString() {
        return "ProductLevelPriceNoticeV2Response{" + "code=" + code + "," + "describe=" + describe + "," + "partnerId=" + partnerId + "}";
    }
}
