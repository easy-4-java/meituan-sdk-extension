package com.meituan.sdk.model.wmoperNg.order.wmoperngQueryLogisticsStatus;

import com.google.gson.annotations.SerializedName;

/**
* 获取配送订单状态
* This file was automatically generated.
*/
public class WmoperngQueryLogisticsStatusResponse {
    @SerializedName("result")
    private String result;
    /**
    * 订单ID
    */
    @SerializedName("order_id")
    private Long orderId;
    /**
    * 配送订单状态
    */
    @SerializedName("logistics_status")
    private Integer logisticsStatus;
    /**
    * 配送方名称
    */
    @SerializedName("logistics_name")
    private String logisticsName;
    /**
    * 配送单下单时间
    */
    @SerializedName("send_time")
    private Integer sendTime;
    /**
    * 配送单确认时间
    */
    @SerializedName("confirm_time")
    private Integer confirmTime;
    /**
    * 配送单取消时间
    */
    @SerializedName("cancel_time")
    private Integer cancelTime;
    /**
    * 骑手取单时间
    */
    @SerializedName("fetch_time")
    private Integer fetchTime;
    /**
    * 订单完成时间
    */
    @SerializedName("completed_time")
    private Integer completedTime;
    /**
    * 骑手姓名
    */
    @SerializedName("dispatcher_name")
    private String dispatcherName;
    /**
    * 骑手电话（请兼容13812345678和13812345678_123456两种号码格式，以便对接隐私号订单，最多不超过20位）
    */
    @SerializedName("dispatcher_mobile")
    private String dispatcherMobile;
    /**
    * 商家承担运费
    */
    @SerializedName("poi_shipping_fee")
    private Double poiShippingFee;
    /**
    * 商家承担运费的具体说明
    */
    @SerializedName("shipping_tips")
    private String shippingTips;
    /**
    * 商家给定的小费金额
    */
    @SerializedName("tip_amount")
    private Double tipAmount;
    /**
    * 美团跑腿订单聚合平台可发配送状态，当前返回值只有0，收到此推送时商家可对当前订单发起配送。  0：可发配送
    */
    @SerializedName("delivery_available")
    private Integer deliveryAvailable;
    /**
    * 骑手取货时货品照片，多张图片以逗号隔开，最多支持三张图片。只有在配送状态仅为已取货时可传。
    */
    @SerializedName("fetch_pictures")
    private String fetchPictures;
    /**
    * 骑手送达时货品照片，多张图片以逗号隔开，最多支持三张图片。只有在配送状态仅为已送达时可传。
    */
    @SerializedName("delivery_pictures")
    private String deliveryPictures;
    /**
    * 订单来源 0 无来源 1 美团 2 饿了么 3 百度 4 其他 5京东到家 6 青云自建订单 7歪马微商城
    */
    @SerializedName("order_source")
    private Integer orderSource;
    /**
    * 三方订单号
    */
    @SerializedName("third_order_id")
    private String thirdOrderId;
    /**
    * 取消原因id
    */
    @SerializedName("cancel_reason_id")
    private Integer cancelReasonId;
    /**
    * 取消原因
    */
    @SerializedName("cancel_reason")
    private String cancelReason;
    /**
    * 订单配送距离
    */
    @SerializedName("distance")
    private Integer distance;
    /**
    * 溢价金额
    */
    @SerializedName("premium_fee")
    private Double premiumFee;
    /**
    * 取货码
    */
    @SerializedName("receive_code")
    private String receiveCode;
    /**
    * 取消费用
    */
    @SerializedName("cancel_fee")
    private Double cancelFee;
    /**
    * 惊喜立减金额
    */
    @SerializedName("bml_amount")
    private Double bmlAmount;
    /**
    * 预计送达时间 
    */
    @SerializedName("predict_delivery_time")
    private Long predictDeliveryTime;
    /**
    * 出餐时效，表示该订单的平台要求最晚出餐时间
    */
    @SerializedName("poiMealAssessmentTime")
    private Long poiMealAssessmentTime;
    /**
    * 订单状态  2:新订单-用户支付完成，待商家接单  4:商家已接单  8:订单已完成  9:订单已取消
    */
    @SerializedName("status")
    private Integer status;
    /**
    * 订单完成时间
    */
    @SerializedName("order_completed_time")
    private Long orderCompletedTime;
    /**
    * 门店配送费  履约侧控制美配不给值，自配给值
    */
    @SerializedName("shipping_fee")
    private Float shippingFee;

    public String getResult() {
        return result;
    }
    public void setResult(String result) {
        this.result = result;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public Integer getLogisticsStatus() {
        return logisticsStatus;
    }
    public void setLogisticsStatus(Integer logisticsStatus) {
        this.logisticsStatus = logisticsStatus;
    }
    public String getLogisticsName() {
        return logisticsName;
    }
    public void setLogisticsName(String logisticsName) {
        this.logisticsName = logisticsName;
    }
    public Integer getSendTime() {
        return sendTime;
    }
    public void setSendTime(Integer sendTime) {
        this.sendTime = sendTime;
    }
    public Integer getConfirmTime() {
        return confirmTime;
    }
    public void setConfirmTime(Integer confirmTime) {
        this.confirmTime = confirmTime;
    }
    public Integer getCancelTime() {
        return cancelTime;
    }
    public void setCancelTime(Integer cancelTime) {
        this.cancelTime = cancelTime;
    }
    public Integer getFetchTime() {
        return fetchTime;
    }
    public void setFetchTime(Integer fetchTime) {
        this.fetchTime = fetchTime;
    }
    public Integer getCompletedTime() {
        return completedTime;
    }
    public void setCompletedTime(Integer completedTime) {
        this.completedTime = completedTime;
    }
    public String getDispatcherName() {
        return dispatcherName;
    }
    public void setDispatcherName(String dispatcherName) {
        this.dispatcherName = dispatcherName;
    }
    public String getDispatcherMobile() {
        return dispatcherMobile;
    }
    public void setDispatcherMobile(String dispatcherMobile) {
        this.dispatcherMobile = dispatcherMobile;
    }
    public Double getPoiShippingFee() {
        return poiShippingFee;
    }
    public void setPoiShippingFee(Double poiShippingFee) {
        this.poiShippingFee = poiShippingFee;
    }
    public String getShippingTips() {
        return shippingTips;
    }
    public void setShippingTips(String shippingTips) {
        this.shippingTips = shippingTips;
    }
    public Double getTipAmount() {
        return tipAmount;
    }
    public void setTipAmount(Double tipAmount) {
        this.tipAmount = tipAmount;
    }
    public Integer getDeliveryAvailable() {
        return deliveryAvailable;
    }
    public void setDeliveryAvailable(Integer deliveryAvailable) {
        this.deliveryAvailable = deliveryAvailable;
    }
    public String getFetchPictures() {
        return fetchPictures;
    }
    public void setFetchPictures(String fetchPictures) {
        this.fetchPictures = fetchPictures;
    }
    public String getDeliveryPictures() {
        return deliveryPictures;
    }
    public void setDeliveryPictures(String deliveryPictures) {
        this.deliveryPictures = deliveryPictures;
    }
    public Integer getOrderSource() {
        return orderSource;
    }
    public void setOrderSource(Integer orderSource) {
        this.orderSource = orderSource;
    }
    public String getThirdOrderId() {
        return thirdOrderId;
    }
    public void setThirdOrderId(String thirdOrderId) {
        this.thirdOrderId = thirdOrderId;
    }
    public Integer getCancelReasonId() {
        return cancelReasonId;
    }
    public void setCancelReasonId(Integer cancelReasonId) {
        this.cancelReasonId = cancelReasonId;
    }
    public String getCancelReason() {
        return cancelReason;
    }
    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }
    public Integer getDistance() {
        return distance;
    }
    public void setDistance(Integer distance) {
        this.distance = distance;
    }
    public Double getPremiumFee() {
        return premiumFee;
    }
    public void setPremiumFee(Double premiumFee) {
        this.premiumFee = premiumFee;
    }
    public String getReceiveCode() {
        return receiveCode;
    }
    public void setReceiveCode(String receiveCode) {
        this.receiveCode = receiveCode;
    }
    public Double getCancelFee() {
        return cancelFee;
    }
    public void setCancelFee(Double cancelFee) {
        this.cancelFee = cancelFee;
    }
    public Double getBmlAmount() {
        return bmlAmount;
    }
    public void setBmlAmount(Double bmlAmount) {
        this.bmlAmount = bmlAmount;
    }
    public Long getPredictDeliveryTime() {
        return predictDeliveryTime;
    }
    public void setPredictDeliveryTime(Long predictDeliveryTime) {
        this.predictDeliveryTime = predictDeliveryTime;
    }
    public Long getPoiMealAssessmentTime() {
        return poiMealAssessmentTime;
    }
    public void setPoiMealAssessmentTime(Long poiMealAssessmentTime) {
        this.poiMealAssessmentTime = poiMealAssessmentTime;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Long getOrderCompletedTime() {
        return orderCompletedTime;
    }
    public void setOrderCompletedTime(Long orderCompletedTime) {
        this.orderCompletedTime = orderCompletedTime;
    }
    public Float getShippingFee() {
        return shippingFee;
    }
    public void setShippingFee(Float shippingFee) {
        this.shippingFee = shippingFee;
    }




    @Override
    public String toString() {
        return "WmoperngQueryLogisticsStatusResponse{" + "result=" + result + "," + "orderId=" + orderId + "," + "logisticsStatus=" + logisticsStatus + "," + "logisticsName=" + logisticsName + "," + "sendTime=" + sendTime + "," + "confirmTime=" + confirmTime + "," + "cancelTime=" + cancelTime + "," + "fetchTime=" + fetchTime + "," + "completedTime=" + completedTime + "," + "dispatcherName=" + dispatcherName + "," + "dispatcherMobile=" + dispatcherMobile + "," + "poiShippingFee=" + poiShippingFee + "," + "shippingTips=" + shippingTips + "," + "tipAmount=" + tipAmount + "," + "deliveryAvailable=" + deliveryAvailable + "," + "fetchPictures=" + fetchPictures + "," + "deliveryPictures=" + deliveryPictures + "," + "orderSource=" + orderSource + "," + "thirdOrderId=" + thirdOrderId + "," + "cancelReasonId=" + cancelReasonId + "," + "cancelReason=" + cancelReason + "," + "distance=" + distance + "," + "premiumFee=" + premiumFee + "," + "receiveCode=" + receiveCode + "," + "cancelFee=" + cancelFee + "," + "bmlAmount=" + bmlAmount + "," + "predictDeliveryTime=" + predictDeliveryTime + "," + "poiMealAssessmentTime=" + poiMealAssessmentTime + "," + "status=" + status + "," + "orderCompletedTime=" + orderCompletedTime + "," + "shippingFee=" + shippingFee + "}";
    }
}
