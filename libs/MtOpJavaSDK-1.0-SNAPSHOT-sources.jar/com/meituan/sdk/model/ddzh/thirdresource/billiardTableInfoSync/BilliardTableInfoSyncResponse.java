package com.meituan.sdk.model.ddzh.thirdresource.billiardTableInfoSync;

import com.google.gson.annotations.SerializedName;

/**
* 球桌数据变更同步
* This file was automatically generated.
*/
public class BilliardTableInfoSyncResponse {
    @SerializedName("success")
    private Boolean success;

    public Boolean getSuccess() {
        return success;
    }
    public void setSuccess(Boolean success) {
        this.success = success;
    }




    @Override
    public String toString() {
        return "BilliardTableInfoSyncResponse{" + "success=" + success + "}";
    }
}
