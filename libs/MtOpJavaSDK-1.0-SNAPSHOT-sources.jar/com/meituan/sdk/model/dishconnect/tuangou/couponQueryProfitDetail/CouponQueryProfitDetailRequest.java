package com.meituan.sdk.model.dishconnect.tuangou.couponQueryProfitDetail;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询券码结算扩展明细
* This file was automatically generated.
*/
@ApiMeta(
    path = "/dishconnect/tuangou/coupon/queryProfitDetail",
    businessId = 79,
    apiVersion = "10045",
    apiName = "coupon_query_profit_detail",
    needAuth = false
)
public class CouponQueryProfitDetailRequest implements MeituanRequest<CouponQueryProfitDetailResponse> {
    /**
    * <p data-diff-id="ct-diff-id-58730f82-6ce7-4fcc-a4a7-5a81cd7c8037"><span style="color: #333">门店在商家收银系统编号</span></p>
    */
    @NotBlank(message = "vendorShopId不能为空")
    @SerializedName("vendorShopId")
    private String vendorShopId;
    /**
    * <p data-diff-id="ct-diff-id-a96d7e63-a401-463a-8974-da70ba2370c9"><span style="color: #333">券码</span></p>
    */
    @NotBlank(message = "couponCode不能为空")
    @SerializedName("couponCode")
    private String couponCode;

    public String getVendorShopId() {
        return vendorShopId;
    }
    public void setVendorShopId(String vendorShopId) {
        this.vendorShopId = vendorShopId;
    }
    public String getCouponCode() {
        return couponCode;
    }
    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }


    @Override
    public MeituanResponse<CouponQueryProfitDetailResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<CouponQueryProfitDetailResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "CouponQueryProfitDetailRequest{" + "vendorShopId=" + vendorShopId + "," + "couponCode=" + couponCode + "}";
    }
}
