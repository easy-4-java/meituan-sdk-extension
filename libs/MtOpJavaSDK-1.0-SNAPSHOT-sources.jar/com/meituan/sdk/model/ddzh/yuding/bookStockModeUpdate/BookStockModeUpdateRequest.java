package com.meituan.sdk.model.ddzh.yuding.bookStockModeUpdate;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 预定库存模式变更同步
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/stock/mode/update",
    businessId = 58,
    apiVersion = "10053",
    apiName = "book_stock_mode_update",
    needAuth = true
)
public class BookStockModeUpdateRequest implements MeituanRequest<BookStockModeUpdateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-1af92afc-cf53-4ff8-b390-31a9f5d9429a">变更后预期模式</p>
    */
    @NotBlank(message = "expectMode不能为空")
    @SerializedName("expectMode")
    private String expectMode;
    /**
    * <p data-diff-id="ct-diff-id-f96b15af-d8fd-426a-9387-74c32cc6ae67">变更前原模式</p>
    */
    @NotBlank(message = "originalMode不能为空")
    @SerializedName("originalMode")
    private String originalMode;
    /**
    * <p data-diff-id="ct-diff-id-e17bff76-f2d8-4f1f-ba5e-d4686d7461f8">业务类型，eg：足疗库存行业-1</p>
    */
    @NotNull(message = "bizType不能为空")
    @SerializedName("bizType")
    private Integer bizType;
    /**
    * <p data-diff-id="ct-diff-id-1bc04d14-32e6-42ff-af19-54df82f175d1">变更时间戳(单位：毫秒)</p>
    */
    @SerializedName("updateTime")
    private Long updateTime;

    public String getExpectMode() {
        return expectMode;
    }
    public void setExpectMode(String expectMode) {
        this.expectMode = expectMode;
    }
    public String getOriginalMode() {
        return originalMode;
    }
    public void setOriginalMode(String originalMode) {
        this.originalMode = originalMode;
    }
    public Integer getBizType() {
        return bizType;
    }
    public void setBizType(Integer bizType) {
        this.bizType = bizType;
    }
    public Long getUpdateTime() {
        return updateTime;
    }
    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }


    @Override
    public MeituanResponse<BookStockModeUpdateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<BookStockModeUpdateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "BookStockModeUpdateRequest{" + "expectMode=" + expectMode + "," + "originalMode=" + originalMode + "," + "bizType=" + bizType + "," + "updateTime=" + updateTime + "}";
    }
}
