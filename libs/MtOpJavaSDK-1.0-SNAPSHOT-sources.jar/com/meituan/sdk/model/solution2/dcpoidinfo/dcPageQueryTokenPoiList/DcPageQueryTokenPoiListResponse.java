package com.meituan.sdk.model.solution2.dcpoidinfo.dcPageQueryTokenPoiList;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 适用门店查询
* This file was automatically generated.
*/
public class DcPageQueryTokenPoiListResponse {
    /**
    * 总数
    */
    @SerializedName("total")
    private Integer total;
    @SerializedName("poiInfoList")
    private List<CustomerPoiInfoTO> poiInfoList;

    public Integer getTotal() {
        return total;
    }
    public void setTotal(Integer total) {
        this.total = total;
    }
    public List<CustomerPoiInfoTO> getPoiInfoList() {
        return poiInfoList;
    }
    public void setPoiInfoList(List<CustomerPoiInfoTO> poiInfoList) {
        this.poiInfoList = poiInfoList;
    }




    @Override
    public String toString() {
        return "DcPageQueryTokenPoiListResponse{" + "total=" + total + "," + "poiInfoList=" + poiInfoList + "}";
    }
}
