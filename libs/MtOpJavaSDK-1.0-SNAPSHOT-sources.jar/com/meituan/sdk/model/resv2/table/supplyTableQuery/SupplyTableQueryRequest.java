package com.meituan.sdk.model.resv2.table.supplyTableQuery;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询桌型桌位
* This file was automatically generated.
*/
@ApiMeta(
    path = "/resv2/table/supply/queryTable",
    businessId = 7,
    apiVersion = "10004",
    apiName = "supply_table_query",
    needAuth = true
)
public class SupplyTableQueryRequest implements MeituanRequest<List<VendorTableDTO>> {



    @Override
    public MeituanResponse<List<VendorTableDTO>> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<List<VendorTableDTO>>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return null;
    }


}
