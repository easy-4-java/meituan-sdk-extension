package com.meituan.sdk.model.ddzhkh.xcxpw.queryPayInfo;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class QueryRefundReq {
    /**
    * <p data-diff-id="ct-diff-id-e65a1eab-89b5-4d64-afa7-278fd0484d50"><em><span style="color: rgba(0, 0, 0, 0.65)">美团订单号，与三方订单号二选一</span></em></p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-d9347d78-43af-4c8b-86e7-bd6b833e7486"><em><span style="color: rgba(0, 0, 0, 0.65)">三方订单号，与美团订单号二选一</span></em></p>
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * <p data-diff-id="ct-diff-id-1ce1d23f-cac8-4fc0-aae5-1f89d7443cf8"><em>美团订单支付id，若传递则使用此id进行精准匹配支付单</em><br></p>
    */
    @SerializedName("orderPaymentId")
    private String orderPaymentId;
    /**
    * <p data-diff-id="ct-diff-id-f29617cf-a4fe-4a23-a15d-ed16c59619e8"><em><span style="color: rgba(0, 0, 0, 0.65)">三方支付Id，若传递则使用此id进行精准匹配支付单</span></em></p>
    */
    @SerializedName("vendorPaymentId")
    private String vendorPaymentId;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public String getOrderPaymentId() {
        return orderPaymentId;
    }
    public void setOrderPaymentId(String orderPaymentId) {
        this.orderPaymentId = orderPaymentId;
    }
    public String getVendorPaymentId() {
        return vendorPaymentId;
    }
    public void setVendorPaymentId(String vendorPaymentId) {
        this.vendorPaymentId = vendorPaymentId;
    }




    @Override
    public String toString() {
        return "QueryRefundReq{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "," + "orderPaymentId=" + orderPaymentId + "," + "vendorPaymentId=" + vendorPaymentId + "}";
    }
}
