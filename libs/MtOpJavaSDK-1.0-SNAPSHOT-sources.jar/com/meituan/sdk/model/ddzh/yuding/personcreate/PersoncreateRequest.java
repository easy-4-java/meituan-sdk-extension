package com.meituan.sdk.model.ddzh.yuding.personcreate;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 创建服务人员
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/person/create",
    businessId = 58,
    apiVersion = "10053",
    apiName = "personcreate",
    needAuth = true
)
public class PersoncreateRequest implements MeituanRequest<PersoncreateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-228fe1fc-a789-44d6-a185-a9a1eb21f26d">修改信息的服务人员id，在美团侧通过接口生成的服务人员id 新建时指定为0</p>
    */
    @NotNull(message = "serviceTechId不能为空")
    @SerializedName("serviceTechId")
    private Long serviceTechId;
    /**
    * <p data-diff-id="ct-diff-id-52464200-d6c3-4fcb-b20d-a82a572954b0">身份证号码，新建时必传</p>
    */
    @NotBlank(message = "idCard不能为空")
    @SerializedName("idCard")
    private String idCard;
    /**
    * <p data-diff-id="ct-diff-id-200f0de7-62b9-4caa-9b3a-ee85e636b858">人员姓名，新建时必传</p>
    */
    @NotBlank(message = "name不能为空")
    @SerializedName("name")
    private String name;
    /**
    * <p data-diff-id="ct-diff-id-100c8e37-0cf2-405e-9eca-643570d61acf">手机号，新建和修改手机号时必传</p>
    */
    @NotBlank(message = "phone不能为空")
    @SerializedName("phone")
    private String phone;

    public Long getServiceTechId() {
        return serviceTechId;
    }
    public void setServiceTechId(Long serviceTechId) {
        this.serviceTechId = serviceTechId;
    }
    public String getIdCard() {
        return idCard;
    }
    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }


    @Override
    public MeituanResponse<PersoncreateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<PersoncreateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "PersoncreateRequest{" + "serviceTechId=" + serviceTechId + "," + "idCard=" + idCard + "," + "name=" + name + "," + "phone=" + phone + "}";
    }
}
