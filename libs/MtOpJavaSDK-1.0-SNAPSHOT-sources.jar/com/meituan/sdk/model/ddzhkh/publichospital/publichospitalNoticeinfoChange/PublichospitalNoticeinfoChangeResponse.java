package com.meituan.sdk.model.ddzhkh.publichospital.publichospitalNoticeinfoChange;

import com.google.gson.annotations.SerializedName;

/**
* 医院、科室变更同步
* This file was automatically generated.
*/
public class PublichospitalNoticeinfoChangeResponse {
    @SerializedName("code")
    private Integer code;
    @SerializedName("msg")
    private String msg;
    /**
    * 结果
    */
    @SerializedName("data")
    private String data;

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "PublichospitalNoticeinfoChangeResponse{" + "code=" + code + "," + "msg=" + msg + "," + "data=" + data + "}";
    }
}
