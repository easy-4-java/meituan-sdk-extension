package com.meituan.sdk.model.wmoperNg.order.wmoperGetAuthCode;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取配送详情页面授权码（非接单）
* This file was automatically generated.
*/
@ApiMeta(
    path = "/wmoper/ng/order/business_auth/code/generate",
    businessId = 16,
    apiVersion = "10089",
    apiName = "wmoper_get_auth_code",
    needAuth = true
)
public class WmoperGetAuthCodeRequest implements MeituanRequest<WmoperGetAuthCodeResponse> {
    /**
    * <p data-diff-id="ct-diff-id-6fa86eb9-f294-4c2c-b302-2de2a211f657">业务类型</p>
    */
    @NotBlank(message = "bizType不能为空")
    @SerializedName("bizType")
    private String bizType;
    /**
    * <p data-diff-id="ct-diff-id-5e2c4f66-06aa-4151-af35-bff882567584">订单Id</p>
    */
    @NotNull(message = "orderId不能为空")
    @SerializedName("orderId")
    private Long orderId;

    public String getBizType() {
        return bizType;
    }
    public void setBizType(String bizType) {
        this.bizType = bizType;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }


    @Override
    public MeituanResponse<WmoperGetAuthCodeResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<WmoperGetAuthCodeResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "WmoperGetAuthCodeRequest{" + "bizType=" + bizType + "," + "orderId=" + orderId + "}";
    }
}
