package com.meituan.sdk.model.pms.message.pushMessage;

import com.google.gson.annotations.SerializedName;

/**
* 向PMS推送消息提醒
* This file was automatically generated.
*/
public class PushMessageResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    /**
    * 推送结果
    */
    @SerializedName("data")
    private Boolean data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public Boolean getData() {
        return data;
    }
    public void setData(Boolean data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "PushMessageResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
