package com.meituan.sdk.model.ddzhkh.dingdan.orderQueryInfo;

import com.google.gson.annotations.SerializedName;

/**
* 次卡扣款计划
* This file was automatically generated.
*/
public class CycleCardDeductionPlan {
    /**
    * 扣款次序，从1开始
    */
    @SerializedName("sequenceNo")
    private Integer sequenceNo;
    /**
    * 对应月份价格，单位：分
    */
    @SerializedName("sellPrice")
    private Long sellPrice;
    /**
    * 对应月份扣款金额（用户实付），单位：分
    */
    @SerializedName("userPayPrice")
    private Long userPayPrice;
    /**
    * 预计扣款时间，毫秒时间戳，sequenceNo=1的那个元素没有。并且订单首次核销后才有
    */
    @SerializedName("estimatedDeductionTime")
    private Long estimatedDeductionTime;
    /**
    * 预计核销时间，毫秒时间戳，sequenceNo=1的那个元素没有。并且订单首次核销后才有
    */
    @SerializedName("estimatedConsumeTime")
    private Long estimatedConsumeTime;

    public Integer getSequenceNo() {
        return sequenceNo;
    }
    public void setSequenceNo(Integer sequenceNo) {
        this.sequenceNo = sequenceNo;
    }
    public Long getSellPrice() {
        return sellPrice;
    }
    public void setSellPrice(Long sellPrice) {
        this.sellPrice = sellPrice;
    }
    public Long getUserPayPrice() {
        return userPayPrice;
    }
    public void setUserPayPrice(Long userPayPrice) {
        this.userPayPrice = userPayPrice;
    }
    public Long getEstimatedDeductionTime() {
        return estimatedDeductionTime;
    }
    public void setEstimatedDeductionTime(Long estimatedDeductionTime) {
        this.estimatedDeductionTime = estimatedDeductionTime;
    }
    public Long getEstimatedConsumeTime() {
        return estimatedConsumeTime;
    }
    public void setEstimatedConsumeTime(Long estimatedConsumeTime) {
        this.estimatedConsumeTime = estimatedConsumeTime;
    }




    @Override
    public String toString() {
        return "CycleCardDeductionPlan{" + "sequenceNo=" + sequenceNo + "," + "sellPrice=" + sellPrice + "," + "userPayPrice=" + userPayPrice + "," + "estimatedDeductionTime=" + estimatedDeductionTime + "," + "estimatedConsumeTime=" + estimatedConsumeTime + "}";
    }
}
