package com.meituan.sdk.model.resv2.rule.supplyRuleSave;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class VendorTimePeriodDTOSSub {
    /**
    * <p data-diff-id="ct-diff-id-4c8187bf-0daf-4a46-946e-cb497614bbbb"><span style="color: rgba(0, 0, 0, 0.65)">餐段</span></p>
    */
    @SerializedName("timePeriodType")
    private Integer timePeriodType;
    /**
    * <p data-diff-id="ct-diff-id-e991fc04-dada-44b8-9122-5ccb0d8b71ba"><span style="color: rgba(0, 0, 0, 0.65)">餐段起始小时 限制：0-23</span></p>
    */
    @SerializedName("startHour")
    private Integer startHour;
    /**
    * <p data-diff-id="ct-diff-id-0f15a059-aecc-492b-9001-ec28b280c332"><span style="color: rgba(0, 0, 0, 0.65)">餐段起始分钟，限制0-59</span></p>
    */
    @SerializedName("startMinute")
    private Integer startMinute;
    /**
    * <p data-diff-id="ct-diff-id-e6be06b5-e6f9-4678-bef9-6bd3c2bfa38a"><span style="color: rgba(0, 0, 0, 0.65)">餐段结束小时 限制：0-23</span></p>
    */
    @SerializedName("endHour")
    private Integer endHour;
    /**
    * <p data-diff-id="ct-diff-id-a37a52d4-812d-4bd6-aebc-614aaf415812"><span style="color: rgba(0, 0, 0, 0.65)">餐段结束分钟，限制0-59</span></p>
    */
    @SerializedName("endMinute")
    private Integer endMinute;

    public Integer getTimePeriodType() {
        return timePeriodType;
    }
    public void setTimePeriodType(Integer timePeriodType) {
        this.timePeriodType = timePeriodType;
    }
    public Integer getStartHour() {
        return startHour;
    }
    public void setStartHour(Integer startHour) {
        this.startHour = startHour;
    }
    public Integer getStartMinute() {
        return startMinute;
    }
    public void setStartMinute(Integer startMinute) {
        this.startMinute = startMinute;
    }
    public Integer getEndHour() {
        return endHour;
    }
    public void setEndHour(Integer endHour) {
        this.endHour = endHour;
    }
    public Integer getEndMinute() {
        return endMinute;
    }
    public void setEndMinute(Integer endMinute) {
        this.endMinute = endMinute;
    }




    @Override
    public String toString() {
        return "VendorTimePeriodDTOSSub{" + "timePeriodType=" + timePeriodType + "," + "startHour=" + startHour + "," + "startMinute=" + startMinute + "," + "endHour=" + endHour + "," + "endMinute=" + endMinute + "}";
    }
}
