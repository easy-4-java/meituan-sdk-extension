package com.meituan.sdk.model.pms.message.sendSms;

import com.google.gson.annotations.SerializedName;

/**
* 发送短信
* This file was automatically generated.
*/
public class SendSmsResponse {
    @SerializedName("msg")
    private String msg;
    @SerializedName("code")
    private Long code;
    /**
    * 是否发送成功
    */
    @SerializedName("data")
    private Boolean data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public Boolean getData() {
        return data;
    }
    public void setData(Boolean data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "SendSmsResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
