package com.meituan.sdk.model.tuangouNg.atomgoods.productBoxUpdate;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 上传餐盒信息
* This file was automatically generated.
*/
@ApiMeta(
    path = "/tuangou/ng/atomgoods/product/box/update",
    businessId = 1,
    apiVersion = "10019",
    apiName = "product_box_update",
    needAuth = true
)
public class ProductBoxUpdateRequest implements MeituanRequest<ProductBoxUpdateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-4a0be2b0-1ee1-4846-bdf6-43f6eca67970">附件信息/加价属性类型，1-总部, 2-门店</p>
    */
    @NotNull(message = "scope不能为空")
    @SerializedName("scope")
    private Integer scope;
    /**
    * <p data-diff-id="ct-diff-id-5dca6a2b-0b03-48f5-b840-53fbb42d8c01">总部code，当scope = 1时必填</p>
    */
    @SerializedName("vendorChainId")
    private String vendorChainId;
    /**
    * <p data-diff-id="ct-diff-id-99323a41-edbe-45bc-a706-667be7e02653">门店code，当scope = 2时必填</p>
    */
    @SerializedName("vendorShopId")
    private String vendorShopId;
    /**
    * <p data-diff-id="ct-diff-id-513d9d8f-9f78-491f-86d3-213a75decec3">餐盒列表</p>
    */
    @NotEmpty(message = "boxList不能为空")
    @SerializedName("boxList")
    private List<PBox> boxList;

    public Integer getScope() {
        return scope;
    }
    public void setScope(Integer scope) {
        this.scope = scope;
    }
    public String getVendorChainId() {
        return vendorChainId;
    }
    public void setVendorChainId(String vendorChainId) {
        this.vendorChainId = vendorChainId;
    }
    public String getVendorShopId() {
        return vendorShopId;
    }
    public void setVendorShopId(String vendorShopId) {
        this.vendorShopId = vendorShopId;
    }
    public List<PBox> getBoxList() {
        return boxList;
    }
    public void setBoxList(List<PBox> boxList) {
        this.boxList = boxList;
    }


    @Override
    public MeituanResponse<ProductBoxUpdateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ProductBoxUpdateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ProductBoxUpdateRequest{" + "scope=" + scope + "," + "vendorChainId=" + vendorChainId + "," + "vendorShopId=" + vendorShopId + "," + "boxList=" + boxList + "}";
    }
}
