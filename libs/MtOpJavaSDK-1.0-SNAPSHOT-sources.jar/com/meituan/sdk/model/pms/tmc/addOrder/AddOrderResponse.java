package com.meituan.sdk.model.pms.tmc.addOrder;

import com.google.gson.annotations.SerializedName;

/**
* 新增预订
* This file was automatically generated.
*/
public class AddOrderResponse {
    /**
    * PMS订单号
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * PMS账套ID
    */
    @SerializedName("billId")
    private Long billId;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public Long getBillId() {
        return billId;
    }
    public void setBillId(Long billId) {
        this.billId = billId;
    }




    @Override
    public String toString() {
        return "AddOrderResponse{" + "orderId=" + orderId + "," + "billId=" + billId + "}";
    }
}
