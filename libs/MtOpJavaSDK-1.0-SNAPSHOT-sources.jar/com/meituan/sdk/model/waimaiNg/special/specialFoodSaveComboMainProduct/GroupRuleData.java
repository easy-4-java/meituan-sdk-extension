package com.meituan.sdk.model.waimaiNg.special.specialFoodSaveComboMainProduct;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-3ab5c561-1cdd-4c04-a3b5-2023e88cb7c8">分组规则，仅对自选分组或加购分组有效。分组类型为自选分组或加购分组，即groupType=1或2时必填，否则非必填</p>
* This file was automatically generated.
*/
public class GroupRuleData {
    /**
    * <p data-diff-id="ct-diff-id-ce099aab-9ed9-4c29-bf42-fce57a108f14">分组下子品可选数量，仅对自选分组有效，N选M中的M值，必须大于0。分组类型为自选分组，即groupType=1时必填，否则非必填</p>
    */
    @SerializedName("minOptionalQuantity")
    private Integer minOptionalQuantity;
    /**
    * <p data-diff-id="ct-diff-id-ae460056-eef3-4fee-bd43-abed46f1d1fd">分组下同一子品是否可以重复选，仅对自选分组或加购分组有效，0：不能重复选，1：可以重复选。加购分组类型下值必须为1；自选分组类型下，若子品可选数量为1，即minOptionalQuantity=1，则值必须为0。分组类型为自选分组或加购分组，即groupType=1或2时必填，否则非必填</p>
    */
    @SerializedName("canBeReSelected")
    private Integer canBeReSelected;

    public Integer getMinOptionalQuantity() {
        return minOptionalQuantity;
    }
    public void setMinOptionalQuantity(Integer minOptionalQuantity) {
        this.minOptionalQuantity = minOptionalQuantity;
    }
    public Integer getCanBeReSelected() {
        return canBeReSelected;
    }
    public void setCanBeReSelected(Integer canBeReSelected) {
        this.canBeReSelected = canBeReSelected;
    }




    @Override
    public String toString() {
        return "GroupRuleData{" + "minOptionalQuantity=" + minOptionalQuantity + "," + "canBeReSelected=" + canBeReSelected + "}";
    }
}
