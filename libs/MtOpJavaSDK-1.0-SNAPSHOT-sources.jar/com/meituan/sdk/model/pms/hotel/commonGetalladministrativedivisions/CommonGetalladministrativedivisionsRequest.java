package com.meituan.sdk.model.pms.hotel.commonGetalladministrativedivisions;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取所有行政区划
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/hotel/common/getalladministrativedivisions",
    businessId = 57,
    apiVersion = "10012",
    apiName = "common_getalladministrativedivisions",
    needAuth = true
)
public class CommonGetalladministrativedivisionsRequest implements MeituanRequest<CommonGetalladministrativedivisionsResponse> {



    @Override
    public MeituanResponse<CommonGetalladministrativedivisionsResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<CommonGetalladministrativedivisionsResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return null;
    }


}
