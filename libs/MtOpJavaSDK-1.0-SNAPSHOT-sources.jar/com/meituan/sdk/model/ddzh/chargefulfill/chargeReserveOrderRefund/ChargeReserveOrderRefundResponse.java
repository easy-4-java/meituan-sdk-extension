package com.meituan.sdk.model.ddzh.chargefulfill.chargeReserveOrderRefund;

import com.google.gson.annotations.SerializedName;

/**
* 充电占位费订单退款
* This file was automatically generated.
*/
public class ChargeReserveOrderRefundResponse {
    /**
    * 退款结果，true-成功，false-失败
    */
    @SerializedName("result")
    private Boolean result;

    public Boolean getResult() {
        return result;
    }
    public void setResult(Boolean result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "ChargeReserveOrderRefundResponse{" + "result=" + result + "}";
    }
}
