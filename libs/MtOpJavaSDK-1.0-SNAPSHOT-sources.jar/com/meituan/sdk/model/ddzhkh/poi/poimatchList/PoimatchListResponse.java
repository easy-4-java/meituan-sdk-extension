package com.meituan.sdk.model.ddzhkh.poi.poimatchList;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 查询POI匹配列表
* This file was automatically generated.
*/
public class PoimatchListResponse {
    @SerializedName("thirdPartyPoiIdList")
    private List<ThirdPartyPoiIdListSub> thirdPartyPoiIdList;

    public List<ThirdPartyPoiIdListSub> getThirdPartyPoiIdList() {
        return thirdPartyPoiIdList;
    }
    public void setThirdPartyPoiIdList(List<ThirdPartyPoiIdListSub> thirdPartyPoiIdList) {
        this.thirdPartyPoiIdList = thirdPartyPoiIdList;
    }




    @Override
    public String toString() {
        return "PoimatchListResponse{" + "thirdPartyPoiIdList=" + thirdPartyPoiIdList + "}";
    }
}
