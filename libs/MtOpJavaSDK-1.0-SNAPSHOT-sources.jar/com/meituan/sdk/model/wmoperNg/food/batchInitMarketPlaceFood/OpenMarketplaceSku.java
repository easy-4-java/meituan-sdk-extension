package com.meituan.sdk.model.wmoperNg.food.batchInitMarketPlaceFood;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-64c7172c-b44b-4e67-a190-be77be49256f"><span style="color: ">sku</span></p>
* This file was automatically generated.
*/
public class OpenMarketplaceSku {
    /**
    * <p data-diff-id="ct-diff-id-a12f2fbd-a012-4245-866d-ef4c139bc1f7"><span style="color: ">sku</span> code码，必须与主站品一致</p>
    */
    @NotBlank(message = "skuId不能为空")
    @SerializedName("skuId")
    private String skuId;
    /**
    * <p data-diff-id="ct-diff-id-1a40d84b-8d41-4370-8fbd-d1a7e633d8eb">sku售卖属性</p>
    */
    @SerializedName("skuAttrs")
    private List<SkuAttr> skuAttrs;
    /**
    * <p data-diff-id="ct-diff-id-9ddbb0a6-d6c0-49c8-b108-357d9dfe3e31">价格模型</p>
    */
    @NotEmpty(message = "priceList不能为空")
    @SerializedName("priceList")
    private List<SkuPrice> priceList;

    public String getSkuId() {
        return skuId;
    }
    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }
    public List<SkuAttr> getSkuAttrs() {
        return skuAttrs;
    }
    public void setSkuAttrs(List<SkuAttr> skuAttrs) {
        this.skuAttrs = skuAttrs;
    }
    public List<SkuPrice> getPriceList() {
        return priceList;
    }
    public void setPriceList(List<SkuPrice> priceList) {
        this.priceList = priceList;
    }




    @Override
    public String toString() {
        return "OpenMarketplaceSku{" + "skuId=" + skuId + "," + "skuAttrs=" + skuAttrs + "," + "priceList=" + priceList + "}";
    }
}
