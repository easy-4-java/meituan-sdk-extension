package com.meituan.sdk.model.pms.tmc.queryOrder;

import com.google.gson.annotations.SerializedName;

/**
* 联系人信息
* This file was automatically generated.
*/
public class LiaisonDTO {
    /**
    * 姓名
    */
    @SerializedName("name")
    private String name;
    /**
    * 手机号
    */
    @SerializedName("mobile")
    private String mobile;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }




    @Override
    public String toString() {
        return "LiaisonDTO{" + "name=" + name + "," + "mobile=" + mobile + "}";
    }
}
