package com.meituan.sdk.model.pms.esports.pcOpLog;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 记录电脑开关机日志
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/esports/pcOpLog",
    businessId = 57,
    apiVersion = "10029",
    apiName = "pc_op_log",
    needAuth = true
)
public class PcOpLogRequest implements MeituanRequest<PcOpLogResponse> {
    /**
    * <p data-diff-id="ct-diff-id-51fd91ab-e25b-439c-95d0-f08bcaff6ec3">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-b7a13f2b-9fbe-4092-88d8-c5d4785cfe5c">设备序列号</p>
    */
    @NotBlank(message = "serialNumber不能为空")
    @SerializedName("serialNumber")
    private String serialNumber;
    /**
    * <p data-diff-id="ct-diff-id-5a5e16f4-da4a-4e65-99fe-a224b8383dff">房间号</p>
    */
    @NotBlank(message = "roomNumber不能为空")
    @SerializedName("roomNumber")
    private String roomNumber;
    /**
    * <p data-diff-id="ct-diff-id-2efdc474-f686-4254-a997-21f393cd9bd1"><span style="color: #333">操作类型：1：开机，0：关机</span></p>
    */
    @NotNull(message = "opType不能为空")
    @SerializedName("opType")
    private Integer opType;
    /**
    * <p data-diff-id="ct-diff-id-29379acc-35b6-46ec-ba78-8bee9dda2c81"><span style="color: #333">操作时间，格式:yyyy-MM-dd HH:mm:ss</span></p>
    */
    @NotBlank(message = "opTime不能为空")
    @SerializedName("opTime")
    private String opTime;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getSerialNumber() {
        return serialNumber;
    }
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }
    public String getRoomNumber() {
        return roomNumber;
    }
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }
    public Integer getOpType() {
        return opType;
    }
    public void setOpType(Integer opType) {
        this.opType = opType;
    }
    public String getOpTime() {
        return opTime;
    }
    public void setOpTime(String opTime) {
        this.opTime = opTime;
    }


    @Override
    public MeituanResponse<PcOpLogResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<PcOpLogResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "PcOpLogRequest{" + "hotelId=" + hotelId + "," + "serialNumber=" + serialNumber + "," + "roomNumber=" + roomNumber + "," + "opType=" + opType + "," + "opTime=" + opTime + "}";
    }
}
