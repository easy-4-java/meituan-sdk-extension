package com.meituan.sdk.model.tuangouNg.smar.batchUpsertProductApplicableRules;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-cc3242f9-cb76-4bc9-a488-75cf46ea1b0c">适用菜品，可能为空</p><ul data-diff-id="ct-diff-id-ede53924-94fd-40b8-bbf3-4f3103f155c9"><li data-list-item-diff-id="ct-list-item-diff-id-8ef88e06-637f-4252-956b-89bdcbee138d"><p data-diff-id="ct-diff-id-a56c5e70-d317-4938-bfb0-3b49b7983845">代金券 useType=2，list为空，---&gt; 全都不可用</p></li><li data-list-item-diff-id="ct-list-item-diff-id-23637323-90bb-4dcc-b1b5-53aa3a8db350"><p data-diff-id="ct-diff-id-2913cb06-d8f8-4645-9f49-8849e672082a">代金券 useType=3, list为空，  ---&gt; 全都可用</p></li><li data-list-item-diff-id="ct-list-item-diff-id-a5c1f94d-ac69-40be-bde3-81442b03944e"><p data-diff-id="ct-diff-id-fc543399-ca5d-4cb3-a413-171b47829b18">productType=2 &amp; useType=1，代金券全部适用可不传</p></li><li data-list-item-diff-id="ct-list-item-diff-id-a2e05443-0405-4acc-9643-0e863cc8e21a"><p data-diff-id="ct-diff-id-c20ba227-eeca-4635-9a7f-8c24659561db">productType=1 &amp; useType=1，套餐全部适用不可不传</p></li></ul>
* This file was automatically generated.
*/
public class PUseItem {
    /**
    * <p data-diff-id="ct-diff-id-3902f014-7619-41da-9060-d4ca92aa2741">productType=1套餐时，itemId=套餐id<br>productType=2代金券时，itemId=实体（套餐、菜品spuId、分类id）</p>
    */
    @NotBlank(message = "itemId不能为空")
    @SerializedName("itemId")
    private String itemId;
    /**
    * <p data-diff-id="ct-diff-id-474f594b-a622-44f8-957d-69214bed3016">二级Id  对应saas侧的 goodsId (spu对应的skuId)</p>
    */
    @SerializedName("subItemId")
    private String subItemId;
    /**
    * <p data-diff-id="ct-diff-id-ba31d534-7127-428d-8aca-b5d1e5d22cb5"><span style="color: rgb(51, 51, 51)">标识类型</span></p><p data-diff-id="ct-diff-id-69e807c7-a3ed-4df8-859e-ff7039374e46"><span style="color: rgb(51, 51, 51)">1-</span><strong><span style="color: rgb(51, 51, 51)">saas套餐</span></strong><span style="color: rgb(51, 51, 51)"><br>2-</span><strong><span style="color: rgb(51, 51, 51)">saas菜品</span></strong><span style="color: rgb(51, 51, 51)"><br>3-</span><strong><span style="color: rgb(51, 51, 51)">saas菜品类目（仅代金券适用规则时使用）</span></strong></p>
    */
    @NotNull(message = "itemType不能为空")
    @SerializedName("itemType")
    private Integer itemType;

    public String getItemId() {
        return itemId;
    }
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }
    public String getSubItemId() {
        return subItemId;
    }
    public void setSubItemId(String subItemId) {
        this.subItemId = subItemId;
    }
    public Integer getItemType() {
        return itemType;
    }
    public void setItemType(Integer itemType) {
        this.itemType = itemType;
    }




    @Override
    public String toString() {
        return "PUseItem{" + "itemId=" + itemId + "," + "subItemId=" + subItemId + "," + "itemType=" + itemType + "}";
    }
}
