package com.meituan.sdk.model.ddzhkh.miniprogram.tradeCreateOrder;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-2e98a4a7-77f3-4982-bd18-db8c306a3f55"><strong><span style="color: rgb(245, 34, 45)">租车行业必传</span></strong></p>
* This file was automatically generated.
*/
public class CarRentalOrderInfoReq {
    /**
    * <p data-diff-id="ct-diff-id-b025fe59-f1e3-4631-b930-30adcb6e4ae1">下单人姓名。<span style="color: rgb(51, 51, 51)">（预约成功需必传）</span></p>
    */
    @SerializedName("personName")
    private String personName;
    /**
    * <p data-diff-id="ct-diff-id-71b9c58c-be34-4801-80c0-ca9554603afe">下单人手机号。<span style="color: #333">（预约成功需必传）</span></p>
    */
    @SerializedName("personMobileNo")
    private String personMobileNo;
    /**
    * <p data-diff-id="ct-diff-id-65bbd705-ddeb-4c1a-9400-397037f1db1c">车牌号。<span style="color: rgb(51, 51, 51)">（预约成功需必传）</span></p>
    */
    @SerializedName("licensePlateNumber")
    private String licensePlateNumber;
    /**
    * <p data-diff-id="ct-diff-id-147b1662-ec11-444b-868a-5ab78dc6fe69">车型。（预约成功需必传）</p>
    */
    @SerializedName("carType")
    private String carType;
    /**
    * <p data-diff-id="ct-diff-id-c3d67758-22ac-487d-863d-b9147cdb4655">车辆配置。（预约成功需必传）</p>
    */
    @SerializedName("carDisposition")
    private String carDisposition;
    /**
    * <p data-diff-id="ct-diff-id-afd4cba1-322a-46b8-8bb9-12bb6c6f497b">租用时长（<span style="color: rgb(51, 51, 51)">单位：时</span>，预约成功需必传）</p>
    */
    @SerializedName("rentalPeriod")
    private Integer rentalPeriod;
    /**
    * <p data-diff-id="ct-diff-id-9a6c0f11-a902-4d78-b194-3dd3cb496c51">租车开始时间。（毫秒时间戳，预约成功需必传）</p>
    */
    @SerializedName("rentalBeginTime")
    private Long rentalBeginTime;
    /**
    * <p data-diff-id="ct-diff-id-f4da5bf0-133c-492f-bbfa-6238fb95acc8">租车结束时间。（毫秒时间戳，预约成功需必传）</p>
    */
    @SerializedName("rentalEndTime")
    private Long rentalEndTime;
    /**
    * <p data-diff-id="ct-diff-id-3cf20aa4-cbbb-43ae-9d97-df6999329e05">验单时间。（毫秒时间戳，已验证需必传）</p>
    */
    @SerializedName("verifyTime")
    private Long verifyTime;
    /**
    * <p data-diff-id="ct-diff-id-43783142-ee1e-4bbc-a561-1db00708f268">完成时间。（毫秒时间戳，已验证需必传）</p>
    */
    @SerializedName("completeTime")
    private Long completeTime;
    /**
    * <p data-diff-id="ct-diff-id-3c7606a5-f07f-4f7a-8a72-1421ddf21175">取消时间（毫秒时间戳，已取消需必传）</p>
    */
    @SerializedName("cancelTime")
    private Long cancelTime;
    /**
    * <p data-diff-id="ct-diff-id-da339c8d-a27a-4220-8f00-5c67940f921b">商户配置的押金金额（分）。 （预约成功需必传）</p>
    */
    @SerializedName("depositAmount")
    private Long depositAmount;
    /**
    * <p data-diff-id="ct-diff-id-34c5345a-4368-48df-9921-46dc7c595ffd">日均保险（分）。 （预约成功需必传）</p>
    */
    @SerializedName("dailyInsuranceAmount")
    private Long dailyInsuranceAmount;
    /**
    * <p data-diff-id="ct-diff-id-2c7f20ba-ba40-45a4-bac3-246f3f1e43e6">日均租金（分）。 （下单需必传）</p>
    */
    @SerializedName("dailyRentalAmount")
    private Long dailyRentalAmount;
    /**
    * <p data-diff-id="ct-diff-id-38094134-de81-4635-86ad-5c5e9f70b2b3">商户订单总价（分）。 （预约成功需必传）</p>
    */
    @SerializedName("vendorTotalAmount")
    private Long vendorTotalAmount;
    /**
    * <p data-diff-id="ct-diff-id-29ccecc3-1d88-46a7-9c5c-5b750bb5dde2">用车人信息。（预约成功需必传）</p>
    */
    @SerializedName("useCarPersonReq")
    private UseCarPersonReq useCarPersonReq;
    /**
    * <p data-diff-id="ct-diff-id-f9fe73ef-e10a-440c-a92c-ebfe6d241fff">取车信息。 （预约成功必传）</p>
    */
    @SerializedName("pickUpCarInfoReq")
    private PackCarInfoReq pickUpCarInfoReq;
    /**
    * <p data-diff-id="ct-diff-id-744496b0-1d97-48d2-98e8-c694c53230f1">还车信息。 （预约成功需必传）</p>
    */
    @SerializedName("returnCarInfoReq")
    private PackCarInfoReq returnCarInfoReq;
    /**
    * <p data-diff-id="ct-diff-id-9eb4b929-9c67-4114-9bc8-b00584898643">费项组成，预约成功、已验证、撤销验证必传</p>
    */
    @SerializedName("feeDetailList")
    private List<FeeDetail> feeDetailList;

    public String getPersonName() {
        return personName;
    }
    public void setPersonName(String personName) {
        this.personName = personName;
    }
    public String getPersonMobileNo() {
        return personMobileNo;
    }
    public void setPersonMobileNo(String personMobileNo) {
        this.personMobileNo = personMobileNo;
    }
    public String getLicensePlateNumber() {
        return licensePlateNumber;
    }
    public void setLicensePlateNumber(String licensePlateNumber) {
        this.licensePlateNumber = licensePlateNumber;
    }
    public String getCarType() {
        return carType;
    }
    public void setCarType(String carType) {
        this.carType = carType;
    }
    public String getCarDisposition() {
        return carDisposition;
    }
    public void setCarDisposition(String carDisposition) {
        this.carDisposition = carDisposition;
    }
    public Integer getRentalPeriod() {
        return rentalPeriod;
    }
    public void setRentalPeriod(Integer rentalPeriod) {
        this.rentalPeriod = rentalPeriod;
    }
    public Long getRentalBeginTime() {
        return rentalBeginTime;
    }
    public void setRentalBeginTime(Long rentalBeginTime) {
        this.rentalBeginTime = rentalBeginTime;
    }
    public Long getRentalEndTime() {
        return rentalEndTime;
    }
    public void setRentalEndTime(Long rentalEndTime) {
        this.rentalEndTime = rentalEndTime;
    }
    public Long getVerifyTime() {
        return verifyTime;
    }
    public void setVerifyTime(Long verifyTime) {
        this.verifyTime = verifyTime;
    }
    public Long getCompleteTime() {
        return completeTime;
    }
    public void setCompleteTime(Long completeTime) {
        this.completeTime = completeTime;
    }
    public Long getCancelTime() {
        return cancelTime;
    }
    public void setCancelTime(Long cancelTime) {
        this.cancelTime = cancelTime;
    }
    public Long getDepositAmount() {
        return depositAmount;
    }
    public void setDepositAmount(Long depositAmount) {
        this.depositAmount = depositAmount;
    }
    public Long getDailyInsuranceAmount() {
        return dailyInsuranceAmount;
    }
    public void setDailyInsuranceAmount(Long dailyInsuranceAmount) {
        this.dailyInsuranceAmount = dailyInsuranceAmount;
    }
    public Long getDailyRentalAmount() {
        return dailyRentalAmount;
    }
    public void setDailyRentalAmount(Long dailyRentalAmount) {
        this.dailyRentalAmount = dailyRentalAmount;
    }
    public Long getVendorTotalAmount() {
        return vendorTotalAmount;
    }
    public void setVendorTotalAmount(Long vendorTotalAmount) {
        this.vendorTotalAmount = vendorTotalAmount;
    }
    public UseCarPersonReq getUseCarPersonReq() {
        return useCarPersonReq;
    }
    public void setUseCarPersonReq(UseCarPersonReq useCarPersonReq) {
        this.useCarPersonReq = useCarPersonReq;
    }
    public PackCarInfoReq getPickUpCarInfoReq() {
        return pickUpCarInfoReq;
    }
    public void setPickUpCarInfoReq(PackCarInfoReq pickUpCarInfoReq) {
        this.pickUpCarInfoReq = pickUpCarInfoReq;
    }
    public PackCarInfoReq getReturnCarInfoReq() {
        return returnCarInfoReq;
    }
    public void setReturnCarInfoReq(PackCarInfoReq returnCarInfoReq) {
        this.returnCarInfoReq = returnCarInfoReq;
    }
    public List<FeeDetail> getFeeDetailList() {
        return feeDetailList;
    }
    public void setFeeDetailList(List<FeeDetail> feeDetailList) {
        this.feeDetailList = feeDetailList;
    }




    @Override
    public String toString() {
        return "CarRentalOrderInfoReq{" + "personName=" + personName + "," + "personMobileNo=" + personMobileNo + "," + "licensePlateNumber=" + licensePlateNumber + "," + "carType=" + carType + "," + "carDisposition=" + carDisposition + "," + "rentalPeriod=" + rentalPeriod + "," + "rentalBeginTime=" + rentalBeginTime + "," + "rentalEndTime=" + rentalEndTime + "," + "verifyTime=" + verifyTime + "," + "completeTime=" + completeTime + "," + "cancelTime=" + cancelTime + "," + "depositAmount=" + depositAmount + "," + "dailyInsuranceAmount=" + dailyInsuranceAmount + "," + "dailyRentalAmount=" + dailyRentalAmount + "," + "vendorTotalAmount=" + vendorTotalAmount + "," + "useCarPersonReq=" + useCarPersonReq + "," + "pickUpCarInfoReq=" + pickUpCarInfoReq + "," + "returnCarInfoReq=" + returnCarInfoReq + "," + "feeDetailList=" + feeDetailList + "}";
    }
}
