package com.meituan.sdk.model.ddzhkh.shangpin.productSearchSupplyDiagnostics;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 商品优化推荐
* This file was automatically generated.
*/
public class ProductSearchSupplyDiagnosticsResponse {
    /**
    * 商品优化推荐信息列表
    */
    @SerializedName("result")
    private List<SearchSupplyDiagnosticsInfo> result;

    public List<SearchSupplyDiagnosticsInfo> getResult() {
        return result;
    }
    public void setResult(List<SearchSupplyDiagnosticsInfo> result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "ProductSearchSupplyDiagnosticsResponse{" + "result=" + result + "}";
    }
}
