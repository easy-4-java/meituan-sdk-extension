package com.meituan.sdk.model.pms.tmc.getPhysicalRoomtypes;

import com.google.gson.annotations.SerializedName;

/**
* 房型列表
* This file was automatically generated.
*/
public class PhysicalRoomTypeDTO {
    /**
    * 房型编码
    */
    @SerializedName("roomTypeId")
    private String roomTypeId;
    /**
    * 房型名称
    */
    @SerializedName("roomTypeName")
    private String roomTypeName;
    /**
    * 房型简称
    */
    @SerializedName("abbreviation")
    private String abbreviation;
    /**
    * 房型描述
    */
    @SerializedName("description")
    private String description;
    /**
    * 是否启用
    */
    @SerializedName("isActive")
    private Boolean isActive;
    /**
    * 房型扩展信息
    */
    @SerializedName("roomTypeExtra")
    private RoomTypeExtraDTO roomTypeExtra;

    public String getRoomTypeId() {
        return roomTypeId;
    }
    public void setRoomTypeId(String roomTypeId) {
        this.roomTypeId = roomTypeId;
    }
    public String getRoomTypeName() {
        return roomTypeName;
    }
    public void setRoomTypeName(String roomTypeName) {
        this.roomTypeName = roomTypeName;
    }
    public String getAbbreviation() {
        return abbreviation;
    }
    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public Boolean getIsActive() {
        return isActive;
    }
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public RoomTypeExtraDTO getRoomTypeExtra() {
        return roomTypeExtra;
    }
    public void setRoomTypeExtra(RoomTypeExtraDTO roomTypeExtra) {
        this.roomTypeExtra = roomTypeExtra;
    }




    @Override
    public String toString() {
        return "PhysicalRoomTypeDTO{" + "roomTypeId=" + roomTypeId + "," + "roomTypeName=" + roomTypeName + "," + "abbreviation=" + abbreviation + "," + "description=" + description + "," + "isActive=" + isActive + "," + "roomTypeExtra=" + roomTypeExtra + "}";
    }
}
