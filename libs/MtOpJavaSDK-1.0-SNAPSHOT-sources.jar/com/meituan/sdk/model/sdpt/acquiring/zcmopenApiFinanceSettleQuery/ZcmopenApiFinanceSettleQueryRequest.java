package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiFinanceSettleQuery;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* [结算]查询结算明细
* This file was automatically generated.
*/
@ApiMeta(
    path = "/sdpt/acquiring/api/finance/settle/query",
    businessId = 52,
    apiVersion = "10122",
    apiName = "zcmopen_api_finance_settle_query",
    needAuth = false
)
public class ZcmopenApiFinanceSettleQueryRequest implements MeituanRequest<ZcmopenApiFinanceSettleQueryResponse> {
    /**
    * <p data-diff-id="ct-diff-id-ddff1df6-2b9e-4d31-8341-77a13da8bf02"><span style="color: #333">交易日期，查询某天的交易结算情况， 格式为yyyyMMDD 目前只支持按天查询</span></p>
    */
    @NotNull(message = "cutDay不能为空")
    @SerializedName("cutDay")
    private Long cutDay;
    /**
    * <p data-diff-id="ct-diff-id-06878207-5907-4bcf-971e-31d51bb1b966"><span style="color: #333">门店id</span></p>
    */
    @NotNull(message = "merchantId不能为空")
    @SerializedName("merchantId")
    private Long merchantId;
    /**
    * <p data-diff-id="ct-diff-id-33c338b7-c6d5-4b2b-8f84-ea9d7bf7ef17"><span style="color: #333">交易单号，是交易接口返回值referno字段的值 详见 订单查询，如果不指定交易单号，按其他条件查询</span></p>
    */
    @SerializedName("tradeNo")
    private String tradeNo;

    public Long getCutDay() {
        return cutDay;
    }
    public void setCutDay(Long cutDay) {
        this.cutDay = cutDay;
    }
    public Long getMerchantId() {
        return merchantId;
    }
    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }
    public String getTradeNo() {
        return tradeNo;
    }
    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }


    @Override
    public MeituanResponse<ZcmopenApiFinanceSettleQueryResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ZcmopenApiFinanceSettleQueryResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ZcmopenApiFinanceSettleQueryRequest{" + "cutDay=" + cutDay + "," + "merchantId=" + merchantId + "," + "tradeNo=" + tradeNo + "}";
    }
}
