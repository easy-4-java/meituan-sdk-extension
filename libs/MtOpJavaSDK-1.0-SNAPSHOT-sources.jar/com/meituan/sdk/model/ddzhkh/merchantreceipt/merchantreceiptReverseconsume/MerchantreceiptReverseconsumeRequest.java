package com.meituan.sdk.model.ddzhkh.merchantreceipt.merchantreceiptReverseconsume;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 商家券撤销验券
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/merchantreceipt/reverseconsume",
    businessId = 59,
    apiVersion = "10028",
    apiName = "merchantreceipt_reverseconsume",
    needAuth = true
)
public class MerchantreceiptReverseconsumeRequest implements MeituanRequest<MerchantreceiptReverseconsumeResponse> {
    /**
    * <p data-diff-id="ct-diff-id-6f286b13-29b4-4dee-a851-1e105e866888"><span style="color: rgba(0, 0, 0, 0.65)">流水号，用于幂等校验</span></p>
    */
    @NotBlank(message = "sequenceId不能为空")
    @SerializedName("sequenceId")
    private String sequenceId;
    /**
    * <p data-diff-id="ct-diff-id-8c0937bb-835b-4fee-bf0a-5879f627beec"><span style="color: rgba(0, 0, 0, 0.65)">订单号</span></p>
    */
    @NotBlank(message = "orderId不能为空")
    @SerializedName("orderId")
    private String orderId;
    /**
    * <p data-diff-id="ct-diff-id-fb668203-3202-479f-a825-bb86c03d5147"><span style="color: rgba(0, 0, 0, 0.65)">撤销核销的门店ID</span></p>
    */
    @NotBlank(message = "opPoiId不能为空")
    @SerializedName("opPoiId")
    private String opPoiId;
    /**
    * <p data-diff-id="ct-diff-id-f41f8d9a-c89e-4230-889e-847878d58099"><span style="color: rgba(0, 0, 0, 0.65)">仅支持一码一用，固定参数 - false</span></p>
    */
    @NotNull(message = "multiUse不能为空")
    @SerializedName("multiUse")
    private Boolean multiUse;
    /**
    * <p data-diff-id="ct-diff-id-d38c795e-5423-4160-8055-dbb5f585568b">待撤销的券码</p>
    */
    @NotBlank(message = "receiptCode不能为空")
    @SerializedName("receiptCode")
    private String receiptCode;
    /**
    * <p data-diff-id="ct-diff-id-944a8a19-2d57-4f6a-a553-c3028ed185d9">撤销后新的券码，撤销后必须重新给一张与原券码不同的券码</p>
    */
    @NotBlank(message = "newReceiptCode不能为空")
    @SerializedName("newReceiptCode")
    private String newReceiptCode;

    public String getSequenceId() {
        return sequenceId;
    }
    public void setSequenceId(String sequenceId) {
        this.sequenceId = sequenceId;
    }
    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public String getOpPoiId() {
        return opPoiId;
    }
    public void setOpPoiId(String opPoiId) {
        this.opPoiId = opPoiId;
    }
    public Boolean getMultiUse() {
        return multiUse;
    }
    public void setMultiUse(Boolean multiUse) {
        this.multiUse = multiUse;
    }
    public String getReceiptCode() {
        return receiptCode;
    }
    public void setReceiptCode(String receiptCode) {
        this.receiptCode = receiptCode;
    }
    public String getNewReceiptCode() {
        return newReceiptCode;
    }
    public void setNewReceiptCode(String newReceiptCode) {
        this.newReceiptCode = newReceiptCode;
    }


    @Override
    public MeituanResponse<MerchantreceiptReverseconsumeResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<MerchantreceiptReverseconsumeResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "MerchantreceiptReverseconsumeRequest{" + "sequenceId=" + sequenceId + "," + "orderId=" + orderId + "," + "opPoiId=" + opPoiId + "," + "multiUse=" + multiUse + "," + "receiptCode=" + receiptCode + "," + "newReceiptCode=" + newReceiptCode + "}";
    }
}
