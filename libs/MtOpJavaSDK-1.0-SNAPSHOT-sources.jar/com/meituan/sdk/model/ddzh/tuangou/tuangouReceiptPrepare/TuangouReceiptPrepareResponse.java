package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptPrepare;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 输码验券校验
* This file was automatically generated.
*/
public class TuangouReceiptPrepareResponse {
    /**
    * 可验证的张数
    */
    @SerializedName("count")
    private Integer count;
    /**
    * 订单ID
    */
    @SerializedName("orderId")
    private String orderId;
    /**
    * 验证券码
    */
    @SerializedName("receiptCode")
    private String receiptCode;
    /**
    * 套餐ID（若验证的券所对应的商品为团购时，该字段必返回），次卡（平台次卡，不是团购次卡）和拼团不返回此参数
    */
    @SerializedName("dealId")
    private Long dealId;
    /**
    * 团购ID，团购id与套餐id是一对多的关系（若验证的券所对应的商品为团购时，该字段必返回），次卡（平台次卡，不是团购次卡）和拼团不返回此参数
    */
    @SerializedName("dealGroupId")
    private Long dealGroupId;
    /**
    * 商品名称
    */
    @SerializedName("dealTitle")
    private String dealTitle;
    /**
    * 商品售卖价格
    */
    @SerializedName("dealPrice")
    private Double dealPrice;
    /**
    * 商品市场价
    */
    @SerializedName("dealMarketPrice")
    private Double dealMarketPrice;
    /**
    * 用户手机号
    */
    @SerializedName("mobile")
    private String mobile;
    /**
    * 业务类型 0:普通团购  203:拼团 205:次卡 217:通兑标品
    */
    @SerializedName("bizType")
    private Integer bizType;
    /**
    * 支付明细(订单维度，如果订单有多张券可以通过订单券码分摊金额查询接口查询)
    */
    @SerializedName("paymentDetail")
    private List<PaymentDetailSub> paymentDetail;
    /**
    * 券过期时间
    */
    @SerializedName("receiptEndDate")
    private Long receiptEndDate;
    /**
    * 是否是团购次卡
    */
    @SerializedName("tgTimesCardFlag")
    private Boolean tgTimesCardFlag;
    /**
    * 团购次卡可用总次数
    */
    @SerializedName("purchaseToConsumeRatio")
    private String purchaseToConsumeRatio;
    /**
    * 团购次卡单次卡价格（单位：分）
    */
    @SerializedName("timesCardUnitPrice")
    private String timesCardUnitPrice;
    /**
    * 补贴金额（平台分摊）
    */
    @SerializedName("platformAmount")
    private String platformAmount;
    /**
    * 补贴金额（商户分摊）
    */
    @SerializedName("merchantAmount")
    private String merchantAmount;
    /**
    * 体检加项信息
    */
    @SerializedName("additionItemInfos")
    private List<RadditionItemInfo> additionItemInfos;
    /**
    * 商品类型 1、泛商品如丽人派样活动商品等（若验证的券所对应的商品非团购时，该字段必返回）
    */
    @SerializedName("productType")
    private Long productType;
    /**
    * 商品ID（若验证的券所对应的商品非团购时，该字段必返回，productItemId含义参考商品管理API）
    */
    @SerializedName("productItemId")
    private Long productItemId;
    /**
    * 三方商品ID（仅限家居、珠宝行业）
    */
    @SerializedName("thirdPartyProductId")
    private String thirdPartyProductId;
    /**
    * Map<Long, List<ReceiptPrepareResult>> JSON格式。多团单维度券信息，如果为null则为单团单,key为productItemId
    */
    @SerializedName("receiptInfoMap")
    private String receiptInfoMap;
    /**
    * 商品类型，0：普通商品，1：支持在线付尾款
    */
    @SerializedName("dealType")
    private Integer dealType;
    /**
    * 下单用户ID
    */
    @SerializedName("opUserId")
    private String opUserId;
    /**
    * 下单用户平台，1-美团，2-点评
    */
    @SerializedName("platform")
    private Integer platform;
    /**
    * 购买时间
    */
    @SerializedName("buyTime")
    private Long buyTime;
    /**
    * 团购券是否在适用时间，在适用时段：1；不在适用时间：2
    */
    @SerializedName("verificationType")
    private Integer verificationType;
    /**
    * 商品份数，预订券码中包含的同类商品数量，一品多态预订场景下券码必传，团购场景不传
    */
    @SerializedName("dealQuantity")
    private Integer dealQuantity;

    public Integer getCount() {
        return count;
    }
    public void setCount(Integer count) {
        this.count = count;
    }
    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public String getReceiptCode() {
        return receiptCode;
    }
    public void setReceiptCode(String receiptCode) {
        this.receiptCode = receiptCode;
    }
    public Long getDealId() {
        return dealId;
    }
    public void setDealId(Long dealId) {
        this.dealId = dealId;
    }
    public Long getDealGroupId() {
        return dealGroupId;
    }
    public void setDealGroupId(Long dealGroupId) {
        this.dealGroupId = dealGroupId;
    }
    public String getDealTitle() {
        return dealTitle;
    }
    public void setDealTitle(String dealTitle) {
        this.dealTitle = dealTitle;
    }
    public Double getDealPrice() {
        return dealPrice;
    }
    public void setDealPrice(Double dealPrice) {
        this.dealPrice = dealPrice;
    }
    public Double getDealMarketPrice() {
        return dealMarketPrice;
    }
    public void setDealMarketPrice(Double dealMarketPrice) {
        this.dealMarketPrice = dealMarketPrice;
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    public Integer getBizType() {
        return bizType;
    }
    public void setBizType(Integer bizType) {
        this.bizType = bizType;
    }
    public List<PaymentDetailSub> getPaymentDetail() {
        return paymentDetail;
    }
    public void setPaymentDetail(List<PaymentDetailSub> paymentDetail) {
        this.paymentDetail = paymentDetail;
    }
    public Long getReceiptEndDate() {
        return receiptEndDate;
    }
    public void setReceiptEndDate(Long receiptEndDate) {
        this.receiptEndDate = receiptEndDate;
    }
    public Boolean getTgTimesCardFlag() {
        return tgTimesCardFlag;
    }
    public void setTgTimesCardFlag(Boolean tgTimesCardFlag) {
        this.tgTimesCardFlag = tgTimesCardFlag;
    }
    public String getPurchaseToConsumeRatio() {
        return purchaseToConsumeRatio;
    }
    public void setPurchaseToConsumeRatio(String purchaseToConsumeRatio) {
        this.purchaseToConsumeRatio = purchaseToConsumeRatio;
    }
    public String getTimesCardUnitPrice() {
        return timesCardUnitPrice;
    }
    public void setTimesCardUnitPrice(String timesCardUnitPrice) {
        this.timesCardUnitPrice = timesCardUnitPrice;
    }
    public String getPlatformAmount() {
        return platformAmount;
    }
    public void setPlatformAmount(String platformAmount) {
        this.platformAmount = platformAmount;
    }
    public String getMerchantAmount() {
        return merchantAmount;
    }
    public void setMerchantAmount(String merchantAmount) {
        this.merchantAmount = merchantAmount;
    }
    public List<RadditionItemInfo> getAdditionItemInfos() {
        return additionItemInfos;
    }
    public void setAdditionItemInfos(List<RadditionItemInfo> additionItemInfos) {
        this.additionItemInfos = additionItemInfos;
    }
    public Long getProductType() {
        return productType;
    }
    public void setProductType(Long productType) {
        this.productType = productType;
    }
    public Long getProductItemId() {
        return productItemId;
    }
    public void setProductItemId(Long productItemId) {
        this.productItemId = productItemId;
    }
    public String getThirdPartyProductId() {
        return thirdPartyProductId;
    }
    public void setThirdPartyProductId(String thirdPartyProductId) {
        this.thirdPartyProductId = thirdPartyProductId;
    }
    public String getReceiptInfoMap() {
        return receiptInfoMap;
    }
    public void setReceiptInfoMap(String receiptInfoMap) {
        this.receiptInfoMap = receiptInfoMap;
    }
    public Integer getDealType() {
        return dealType;
    }
    public void setDealType(Integer dealType) {
        this.dealType = dealType;
    }
    public String getOpUserId() {
        return opUserId;
    }
    public void setOpUserId(String opUserId) {
        this.opUserId = opUserId;
    }
    public Integer getPlatform() {
        return platform;
    }
    public void setPlatform(Integer platform) {
        this.platform = platform;
    }
    public Long getBuyTime() {
        return buyTime;
    }
    public void setBuyTime(Long buyTime) {
        this.buyTime = buyTime;
    }
    public Integer getVerificationType() {
        return verificationType;
    }
    public void setVerificationType(Integer verificationType) {
        this.verificationType = verificationType;
    }
    public Integer getDealQuantity() {
        return dealQuantity;
    }
    public void setDealQuantity(Integer dealQuantity) {
        this.dealQuantity = dealQuantity;
    }




    @Override
    public String toString() {
        return "TuangouReceiptPrepareResponse{" + "count=" + count + "," + "orderId=" + orderId + "," + "receiptCode=" + receiptCode + "," + "dealId=" + dealId + "," + "dealGroupId=" + dealGroupId + "," + "dealTitle=" + dealTitle + "," + "dealPrice=" + dealPrice + "," + "dealMarketPrice=" + dealMarketPrice + "," + "mobile=" + mobile + "," + "bizType=" + bizType + "," + "paymentDetail=" + paymentDetail + "," + "receiptEndDate=" + receiptEndDate + "," + "tgTimesCardFlag=" + tgTimesCardFlag + "," + "purchaseToConsumeRatio=" + purchaseToConsumeRatio + "," + "timesCardUnitPrice=" + timesCardUnitPrice + "," + "platformAmount=" + platformAmount + "," + "merchantAmount=" + merchantAmount + "," + "additionItemInfos=" + additionItemInfos + "," + "productType=" + productType + "," + "productItemId=" + productItemId + "," + "thirdPartyProductId=" + thirdPartyProductId + "," + "receiptInfoMap=" + receiptInfoMap + "," + "dealType=" + dealType + "," + "opUserId=" + opUserId + "," + "platform=" + platform + "," + "buyTime=" + buyTime + "," + "verificationType=" + verificationType + "," + "dealQuantity=" + dealQuantity + "}";
    }
}
