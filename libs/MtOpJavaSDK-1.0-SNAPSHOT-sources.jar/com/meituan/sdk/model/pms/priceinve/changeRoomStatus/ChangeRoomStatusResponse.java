package com.meituan.sdk.model.pms.priceinve.changeRoomStatus;

import com.google.gson.annotations.SerializedName;

/**
* 修改房态
* This file was automatically generated.
*/
public class ChangeRoomStatusResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    /**
    * 修改结果
    */
    @SerializedName("data")
    private Boolean data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public Boolean getData() {
        return data;
    }
    public void setData(Boolean data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "ChangeRoomStatusResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
