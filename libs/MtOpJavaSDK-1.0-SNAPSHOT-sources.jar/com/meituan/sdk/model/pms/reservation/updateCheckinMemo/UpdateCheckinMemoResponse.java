package com.meituan.sdk.model.pms.reservation.updateCheckinMemo;

import com.google.gson.annotations.SerializedName;

/**
* 修改接待单备注
* This file was automatically generated.
*/
public class UpdateCheckinMemoResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    /**
    * 是否修改成功
    */
    @SerializedName("data")
    private Boolean data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public Boolean getData() {
        return data;
    }
    public void setData(Boolean data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "UpdateCheckinMemoResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
