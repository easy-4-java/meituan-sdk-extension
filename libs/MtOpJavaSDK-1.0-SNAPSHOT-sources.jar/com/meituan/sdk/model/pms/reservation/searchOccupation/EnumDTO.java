package com.meituan.sdk.model.pms.reservation.searchOccupation;

import com.google.gson.annotations.SerializedName;

/**
* 入住类型，详见CheckinType枚举
* This file was automatically generated.
*/
public class EnumDTO {
    /**
    * 编码
    */
    @SerializedName("cnName")
    private String cnName;
    /**
    * 描述
    */
    @SerializedName("enName")
    private String enName;

    public String getCnName() {
        return cnName;
    }
    public void setCnName(String cnName) {
        this.cnName = cnName;
    }
    public String getEnName() {
        return enName;
    }
    public void setEnName(String enName) {
        this.enName = enName;
    }




    @Override
    public String toString() {
        return "EnumDTO{" + "cnName=" + cnName + "," + "enName=" + enName + "}";
    }
}
