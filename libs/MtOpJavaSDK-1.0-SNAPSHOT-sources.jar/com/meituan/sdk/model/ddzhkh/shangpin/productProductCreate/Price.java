package com.meituan.sdk.model.ddzhkh.shangpin.productProductCreate;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-258ebc11-e3c3-42f5-b112-2a1104e7f86c"><span style="color: rgb(31, 45, 61)">售卖SKU价格模型</span></p>
* This file was automatically generated.
*/
public class Price {
    /**
    * <p data-diff-id="ct-diff-id-a461d35d-fd79-4580-ba2a-5fbce73d9a0d"><span style="color: rgb(31, 45, 61)">售卖价格，取值范围：0-99999999.99，精确到两位小数，单位：元。如101.01，表示101.01元1分</span><br></p>
    */
    @NotNull(message = "price不能为空")
    @SerializedName("price")
    private Double price;

    public Double getPrice() {
        return price;
    }
    public void setPrice(Double price) {
        this.price = price;
    }




    @Override
    public String toString() {
        return "Price{" + "price=" + price + "}";
    }
}
