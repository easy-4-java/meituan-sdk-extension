package com.meituan.sdk.model.ddzhkh.xcxbj.syncOrder;

import com.google.gson.annotations.SerializedName;

/**
* 订单同步
* This file was automatically generated.
*/
public class SyncOrderResponse {
    /**
    * 系统交互结果
    */
    @SerializedName("extra")
    private ExtraObj extra;
    /**
    * 业务交互结果业务交互结果
    */
    @SerializedName("res")
    private ResObj res;

    public ExtraObj getExtra() {
        return extra;
    }
    public void setExtra(ExtraObj extra) {
        this.extra = extra;
    }
    public ResObj getRes() {
        return res;
    }
    public void setRes(ResObj res) {
        this.res = res;
    }




    @Override
    public String toString() {
        return "SyncOrderResponse{" + "extra=" + extra + "," + "res=" + res + "}";
    }
}
