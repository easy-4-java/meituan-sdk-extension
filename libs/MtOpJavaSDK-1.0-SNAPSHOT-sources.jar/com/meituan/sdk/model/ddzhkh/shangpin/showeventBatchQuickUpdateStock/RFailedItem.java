package com.meituan.sdk.model.ddzhkh.shangpin.showeventBatchQuickUpdateStock;

import com.google.gson.annotations.SerializedName;

/**
* 失败项列表
* This file was automatically generated.
*/
public class RFailedItem {
    /**
    * 三方演出项目ID
    */
    @SerializedName("thirdPartyShowEventId")
    private String thirdPartyShowEventId;
    /**
    * 失败码，500
    */
    @SerializedName("code")
    private Integer code;
    /**
    * 失败原因
    */
    @SerializedName("message")
    private String message;

    public String getThirdPartyShowEventId() {
        return thirdPartyShowEventId;
    }
    public void setThirdPartyShowEventId(String thirdPartyShowEventId) {
        this.thirdPartyShowEventId = thirdPartyShowEventId;
    }
    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }




    @Override
    public String toString() {
        return "RFailedItem{" + "thirdPartyShowEventId=" + thirdPartyShowEventId + "," + "code=" + code + "," + "message=" + message + "}";
    }
}
