package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptBatchconsume;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 验券详情
* This file was automatically generated.
*/
public class ReceiptConsumeResult {
    /**
    * 订单号
    */
    @SerializedName("orderId")
    private String orderId;
    /**
    * 券码
    */
    @SerializedName("receiptCode")
    private String receiptCode;
    /**
    * 套餐ID
    */
    @SerializedName("dealId")
    private Long dealId;
    /**
    * 团购ID
    */
    @SerializedName("dealgroupId")
    private Long dealgroupId;
    /**
    * 商品名称
    */
    @SerializedName("dealTitle")
    private String dealTitle;
    /**
    * 商品类型（仅支持消费码）
    */
    @SerializedName("productType")
    private Long productType;
    /**
    * 商品消费码（仅支持消费码验券）
    */
    @SerializedName("productItemId")
    private Long productItemId;
    /**
    * 商品售卖价格
    */
    @SerializedName("dealPrice")
    private Double dealPrice;
    /**
    * 商品市场价
    */
    @SerializedName("dealMarketPrice")
    private Double dealMarketPrice;
    /**
    * 用户手机号（加密过的）
    */
    @SerializedName("mobile")
    private String mobile;
    /**
    * 业务类型
    */
    @SerializedName("bizType")
    private Integer bizType;
    /**
    * 该券码所在的订单的支付明细，如果一笔订单包含两个券码a、b，在核销a、b券码时返回信息一致，都是该订单的支付明细
    */
    @SerializedName("paymentDetail")
    private List<RpaymentDetail> paymentDetail;
    /**
    * 券过期时间(毫秒数)
    */
    @SerializedName("receiptEndDate")
    private Long receiptEndDate;

    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public String getReceiptCode() {
        return receiptCode;
    }
    public void setReceiptCode(String receiptCode) {
        this.receiptCode = receiptCode;
    }
    public Long getDealId() {
        return dealId;
    }
    public void setDealId(Long dealId) {
        this.dealId = dealId;
    }
    public Long getDealgroupId() {
        return dealgroupId;
    }
    public void setDealgroupId(Long dealgroupId) {
        this.dealgroupId = dealgroupId;
    }
    public String getDealTitle() {
        return dealTitle;
    }
    public void setDealTitle(String dealTitle) {
        this.dealTitle = dealTitle;
    }
    public Long getProductType() {
        return productType;
    }
    public void setProductType(Long productType) {
        this.productType = productType;
    }
    public Long getProductItemId() {
        return productItemId;
    }
    public void setProductItemId(Long productItemId) {
        this.productItemId = productItemId;
    }
    public Double getDealPrice() {
        return dealPrice;
    }
    public void setDealPrice(Double dealPrice) {
        this.dealPrice = dealPrice;
    }
    public Double getDealMarketPrice() {
        return dealMarketPrice;
    }
    public void setDealMarketPrice(Double dealMarketPrice) {
        this.dealMarketPrice = dealMarketPrice;
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    public Integer getBizType() {
        return bizType;
    }
    public void setBizType(Integer bizType) {
        this.bizType = bizType;
    }
    public List<RpaymentDetail> getPaymentDetail() {
        return paymentDetail;
    }
    public void setPaymentDetail(List<RpaymentDetail> paymentDetail) {
        this.paymentDetail = paymentDetail;
    }
    public Long getReceiptEndDate() {
        return receiptEndDate;
    }
    public void setReceiptEndDate(Long receiptEndDate) {
        this.receiptEndDate = receiptEndDate;
    }




    @Override
    public String toString() {
        return "ReceiptConsumeResult{" + "orderId=" + orderId + "," + "receiptCode=" + receiptCode + "," + "dealId=" + dealId + "," + "dealgroupId=" + dealgroupId + "," + "dealTitle=" + dealTitle + "," + "productType=" + productType + "," + "productItemId=" + productItemId + "," + "dealPrice=" + dealPrice + "," + "dealMarketPrice=" + dealMarketPrice + "," + "mobile=" + mobile + "," + "bizType=" + bizType + "," + "paymentDetail=" + paymentDetail + "," + "receiptEndDate=" + receiptEndDate + "}";
    }
}
