package com.meituan.sdk.model.ddzhkh.shangpin.showeventBatchQuickUpdateStock;

import com.google.gson.annotations.SerializedName;

/**
* 成功项列表
* This file was automatically generated.
*/
public class RSuccessItem {
    /**
    * 三方演出项目ID
    */
    @SerializedName("thirdPartyShowEventId")
    private String thirdPartyShowEventId;

    public String getThirdPartyShowEventId() {
        return thirdPartyShowEventId;
    }
    public void setThirdPartyShowEventId(String thirdPartyShowEventId) {
        this.thirdPartyShowEventId = thirdPartyShowEventId;
    }




    @Override
    public String toString() {
        return "RSuccessItem{" + "thirdPartyShowEventId=" + thirdPartyShowEventId + "}";
    }
}
