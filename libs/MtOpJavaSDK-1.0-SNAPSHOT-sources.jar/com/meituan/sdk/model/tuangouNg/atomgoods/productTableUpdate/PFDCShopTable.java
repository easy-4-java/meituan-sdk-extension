package com.meituan.sdk.model.tuangouNg.atomgoods.productTableUpdate;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-98670b69-55c7-43b2-ad82-45b0d174f082">桌台列表</p>
* This file was automatically generated.
*/
public class PFDCShopTable {
    /**
    * <p data-diff-id="ct-diff-id-6df2a52e-8dd6-4920-8aad-fc18e977156e"><em><span style="color: rgba(0, 0, 0, 0.65)">桌台唯一标识，可用id，同一门店下标识唯一，最长100字符</span></em></p>
    */
    @NotBlank(message = "tableCode不能为空")
    @SerializedName("tableCode")
    private String tableCode;
    /**
    * <p data-diff-id="ct-diff-id-7f81be01-9765-412d-af02-cad5a992ea15"><em><span style="color: rgba(0, 0, 0, 0.65)">桌台名称+编码</span></em></p>
    */
    @NotBlank(message = "tableName不能为空")
    @SerializedName("tableName")
    private String tableName;
    /**
    * <p data-diff-id="ct-diff-id-8d2d4898-daa7-4417-885c-c29fd62b8290">最小人数，不填默认为1</p>
    */
    @SerializedName("minPerson")
    private Long minPerson;
    /**
    * <p data-diff-id="ct-diff-id-81b09f0d-6c73-4d1f-9402-e0daf723df7a">最大人数</p>
    */
    @NotNull(message = "maxPerson不能为空")
    @SerializedName("maxPerson")
    private Long maxPerson;
    /**
    * <p data-diff-id="ct-diff-id-597650e3-2997-4cc8-9afb-414d52ed8544">桌台类型。1-堂食，2-非堂食</p>
    */
    @NotNull(message = "tableUseType不能为空")
    @SerializedName("tableUseType")
    private Integer tableUseType;
    /**
    * <p data-diff-id="ct-diff-id-334e26f8-eddf-471c-99fc-2fb8e006de5b">所在区域，1-大厅，2-包间，3-室外，4-其他</p>
    */
    @NotNull(message = "areaType不能为空")
    @SerializedName("areaType")
    private Integer areaType;
    /**
    * <p data-diff-id="ct-diff-id-a17ea59e-ceab-4040-acba-2a4347a02150">areaType=4时可自定义名称</p>
    */
    @NotBlank(message = "areaName不能为空")
    @SerializedName("areaName")
    private String areaName;
    /**
    * <p data-diff-id="ct-diff-id-f08a6f8a-72ca-4446-8bb8-e9e2d9988891">区域id</p>
    */
    @NotBlank(message = "areaId不能为空")
    @SerializedName("areaId")
    private String areaId;
    /**
    * <p data-diff-id="ct-diff-id-c1cc1e97-a6b0-425f-bbd0-078360155359">变更类型（1新增，2删除，3更新）</p><p data-diff-id="ct-diff-id-0000688f-3e5a-41d3-9ed3-c13402078443"><strong>变更类型为删除时，仅填tableCode即可</strong></p>
    */
    @NotNull(message = "changeType不能为空")
    @SerializedName("changeType")
    private Integer changeType;
    /**
    * <p data-diff-id="ct-diff-id-e502be64-1c28-4ef4-abde-af426ee842b2">二维码标识列表，列表最大</p><p data-diff-id="ct-diff-id-51e56d37-e883-4214-9f21-f09c0cf4af18">5000，字符最长100字符</p><p data-diff-id="ct-diff-id-a6bc3449-294f-4f56-9068-1bd9931798a0"><strong><span style="color: rgb(255, 74, 71)">二维码标识要唯一。</span></strong></p>
    */
    @SerializedName("qrCodeList")
    private List<String> qrCodeList;
    /**
    * <p data-diff-id="ct-diff-id-835461be-0e0b-42dd-b6ad-8bae9cae5ad2"><span style="color: rgb(6, 125, 23)">桌台所在包间信息</span></p>
    */
    @SerializedName("roomInfo")
    private PFDCRoom roomInfo;

    public String getTableCode() {
        return tableCode;
    }
    public void setTableCode(String tableCode) {
        this.tableCode = tableCode;
    }
    public String getTableName() {
        return tableName;
    }
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    public Long getMinPerson() {
        return minPerson;
    }
    public void setMinPerson(Long minPerson) {
        this.minPerson = minPerson;
    }
    public Long getMaxPerson() {
        return maxPerson;
    }
    public void setMaxPerson(Long maxPerson) {
        this.maxPerson = maxPerson;
    }
    public Integer getTableUseType() {
        return tableUseType;
    }
    public void setTableUseType(Integer tableUseType) {
        this.tableUseType = tableUseType;
    }
    public Integer getAreaType() {
        return areaType;
    }
    public void setAreaType(Integer areaType) {
        this.areaType = areaType;
    }
    public String getAreaName() {
        return areaName;
    }
    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }
    public String getAreaId() {
        return areaId;
    }
    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }
    public Integer getChangeType() {
        return changeType;
    }
    public void setChangeType(Integer changeType) {
        this.changeType = changeType;
    }
    public List<String> getQrCodeList() {
        return qrCodeList;
    }
    public void setQrCodeList(List<String> qrCodeList) {
        this.qrCodeList = qrCodeList;
    }
    public PFDCRoom getRoomInfo() {
        return roomInfo;
    }
    public void setRoomInfo(PFDCRoom roomInfo) {
        this.roomInfo = roomInfo;
    }




    @Override
    public String toString() {
        return "PFDCShopTable{" + "tableCode=" + tableCode + "," + "tableName=" + tableName + "," + "minPerson=" + minPerson + "," + "maxPerson=" + maxPerson + "," + "tableUseType=" + tableUseType + "," + "areaType=" + areaType + "," + "areaName=" + areaName + "," + "areaId=" + areaId + "," + "changeType=" + changeType + "," + "qrCodeList=" + qrCodeList + "," + "roomInfo=" + roomInfo + "}";
    }
}
