package com.meituan.sdk.model.ddzh.cafebook.cybercafeBookResultSync;

import com.google.gson.annotations.SerializedName;

/**
* 网吧订座结果同步
* This file was automatically generated.
*/
public class CybercafeBookResultSyncResponse {
    /**
    * 同步结果，true-成功，false-失败
    */
    @SerializedName("result")
    private Boolean result;

    public Boolean getResult() {
        return result;
    }
    public void setResult(Boolean result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "CybercafeBookResultSyncResponse{" + "result=" + result + "}";
    }
}
