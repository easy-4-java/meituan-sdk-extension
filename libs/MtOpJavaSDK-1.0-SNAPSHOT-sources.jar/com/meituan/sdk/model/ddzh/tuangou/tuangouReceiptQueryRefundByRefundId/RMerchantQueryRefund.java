package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptQueryRefundByRefundId;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class RMerchantQueryRefund {
    /**
    * 是否可退
    */
    @SerializedName("canRefund")
    private Boolean canRefund;
    /**
    * 可退数量
    */
    @SerializedName("maxRefundQuantity")
    private Integer maxRefundQuantity;
    /**
    * 可退券列表
    */
    @SerializedName("receiptList")
    private List<PreRefundReceiptResult> receiptList;
    /**
    * 退款金额组成
    */
    @SerializedName("refundAmountItemList")
    private List<RefundAmountItemResult> refundAmountItemList;
    /**
    * 是否支持部分退 true-是，false-否
    */
    @SerializedName("canPartRefund")
    private Boolean canPartRefund;
    /**
    * 最大可退金额，单位：分
    */
    @SerializedName("maxRefundAmount")
    private Long maxRefundAmount;

    public Boolean getCanRefund() {
        return canRefund;
    }
    public void setCanRefund(Boolean canRefund) {
        this.canRefund = canRefund;
    }
    public Integer getMaxRefundQuantity() {
        return maxRefundQuantity;
    }
    public void setMaxRefundQuantity(Integer maxRefundQuantity) {
        this.maxRefundQuantity = maxRefundQuantity;
    }
    public List<PreRefundReceiptResult> getReceiptList() {
        return receiptList;
    }
    public void setReceiptList(List<PreRefundReceiptResult> receiptList) {
        this.receiptList = receiptList;
    }
    public List<RefundAmountItemResult> getRefundAmountItemList() {
        return refundAmountItemList;
    }
    public void setRefundAmountItemList(List<RefundAmountItemResult> refundAmountItemList) {
        this.refundAmountItemList = refundAmountItemList;
    }
    public Boolean getCanPartRefund() {
        return canPartRefund;
    }
    public void setCanPartRefund(Boolean canPartRefund) {
        this.canPartRefund = canPartRefund;
    }
    public Long getMaxRefundAmount() {
        return maxRefundAmount;
    }
    public void setMaxRefundAmount(Long maxRefundAmount) {
        this.maxRefundAmount = maxRefundAmount;
    }




    @Override
    public String toString() {
        return "RMerchantQueryRefund{" + "canRefund=" + canRefund + "," + "maxRefundQuantity=" + maxRefundQuantity + "," + "receiptList=" + receiptList + "," + "refundAmountItemList=" + refundAmountItemList + "," + "canPartRefund=" + canPartRefund + "," + "maxRefundAmount=" + maxRefundAmount + "}";
    }
}
