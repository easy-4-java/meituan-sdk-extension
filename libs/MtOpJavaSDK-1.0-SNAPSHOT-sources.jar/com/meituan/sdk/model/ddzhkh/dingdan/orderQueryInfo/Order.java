package com.meituan.sdk.model.ddzhkh.dingdan.orderQueryInfo;

import com.google.gson.annotations.SerializedName;

/**
* 订单信息
* This file was automatically generated.
*/
public class Order {
    /**
    * 统一订单Id
    */
    @SerializedName("unifiedOrderId")
    private String unifiedOrderId;
    /**
    * 订单Id，用户订单详情页实际看到的订单Id
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * 商品快照结构化信息
    */
    @SerializedName("productSnapshotContentStruct")
    private String productSnapshotContentStruct;
    /**
    * 周次次卡信息
    */
    @SerializedName("cycleCardInfo")
    private CycleCardInfo cycleCardInfo;
    /**
    * 订单状态，1-初始状态，处于下单流程中，2-创建成功，订单创建成功，等待用户支付，3-订单取消，订单超时未支付，4-订单终止，订单发券失败，支付金额会退款给用户，5-订单完成，订单发券成功
    */
    @SerializedName("status")
    private Integer status;
    /**
    * 订单创建时间(仅预订支持)
    */
    @SerializedName("addTime")
    private Long addTime;
    /**
    * 订单支付成功时间戳
    */
    @SerializedName("paySuccessTime")
    private Long paySuccessTime;
    /**
    * 订单总金额(仅预订支持)
    */
    @SerializedName("amount")
    private String amount;
    /**
    * 订单实付金额(仅预订支持)
    */
    @SerializedName("paidAmount")
    private String paidAmount;
    /**
    * 订单支付优惠金额(仅团购)
    */
    @SerializedName("payDiscountAmount")
    private String payDiscountAmount;
    /**
    * 商户分摊补贴金额(仅团购)
    */
    @SerializedName("merchantAmount")
    private String merchantAmount;
    /**
    * 平台分摊补贴金额(仅团购)
    */
    @SerializedName("platformAmount")
    private String platformAmount;
    /**
    * 下单美团门店id(混淆后)(仅预订支持)
    */
    @SerializedName("opPoiId")
    private String opPoiId;
    /**
    * 订单渠道，eg:mt/dp(仅预订支持)
    */
    @SerializedName("orderChannel")
    private String orderChannel;
    /**
    * 订单业务类型，206-预订
    */
    @SerializedName("bizType")
    private Integer bizType;
    /**
    * 商品类型(仅预订支持)
    */
    @SerializedName("spuType")
    private String spuType;
    /**
    * 预订开始时间(仅预订支持)
    */
    @SerializedName("bookStartTime")
    private String bookStartTime;
    /**
    * 预订结束时间(仅预订支持)
    */
    @SerializedName("bookEndTime")
    private String bookEndTime;
    /**
    * 预订订单使用；是否为后订订单
    */
    @SerializedName("bookAfterGroup")
    private Boolean bookAfterGroup;

    public String getUnifiedOrderId() {
        return unifiedOrderId;
    }
    public void setUnifiedOrderId(String unifiedOrderId) {
        this.unifiedOrderId = unifiedOrderId;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getProductSnapshotContentStruct() {
        return productSnapshotContentStruct;
    }
    public void setProductSnapshotContentStruct(String productSnapshotContentStruct) {
        this.productSnapshotContentStruct = productSnapshotContentStruct;
    }
    public CycleCardInfo getCycleCardInfo() {
        return cycleCardInfo;
    }
    public void setCycleCardInfo(CycleCardInfo cycleCardInfo) {
        this.cycleCardInfo = cycleCardInfo;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Long getAddTime() {
        return addTime;
    }
    public void setAddTime(Long addTime) {
        this.addTime = addTime;
    }
    public Long getPaySuccessTime() {
        return paySuccessTime;
    }
    public void setPaySuccessTime(Long paySuccessTime) {
        this.paySuccessTime = paySuccessTime;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public String getPaidAmount() {
        return paidAmount;
    }
    public void setPaidAmount(String paidAmount) {
        this.paidAmount = paidAmount;
    }
    public String getPayDiscountAmount() {
        return payDiscountAmount;
    }
    public void setPayDiscountAmount(String payDiscountAmount) {
        this.payDiscountAmount = payDiscountAmount;
    }
    public String getMerchantAmount() {
        return merchantAmount;
    }
    public void setMerchantAmount(String merchantAmount) {
        this.merchantAmount = merchantAmount;
    }
    public String getPlatformAmount() {
        return platformAmount;
    }
    public void setPlatformAmount(String platformAmount) {
        this.platformAmount = platformAmount;
    }
    public String getOpPoiId() {
        return opPoiId;
    }
    public void setOpPoiId(String opPoiId) {
        this.opPoiId = opPoiId;
    }
    public String getOrderChannel() {
        return orderChannel;
    }
    public void setOrderChannel(String orderChannel) {
        this.orderChannel = orderChannel;
    }
    public Integer getBizType() {
        return bizType;
    }
    public void setBizType(Integer bizType) {
        this.bizType = bizType;
    }
    public String getSpuType() {
        return spuType;
    }
    public void setSpuType(String spuType) {
        this.spuType = spuType;
    }
    public String getBookStartTime() {
        return bookStartTime;
    }
    public void setBookStartTime(String bookStartTime) {
        this.bookStartTime = bookStartTime;
    }
    public String getBookEndTime() {
        return bookEndTime;
    }
    public void setBookEndTime(String bookEndTime) {
        this.bookEndTime = bookEndTime;
    }
    public Boolean getBookAfterGroup() {
        return bookAfterGroup;
    }
    public void setBookAfterGroup(Boolean bookAfterGroup) {
        this.bookAfterGroup = bookAfterGroup;
    }




    @Override
    public String toString() {
        return "Order{" + "unifiedOrderId=" + unifiedOrderId + "," + "orderId=" + orderId + "," + "productSnapshotContentStruct=" + productSnapshotContentStruct + "," + "cycleCardInfo=" + cycleCardInfo + "," + "status=" + status + "," + "addTime=" + addTime + "," + "paySuccessTime=" + paySuccessTime + "," + "amount=" + amount + "," + "paidAmount=" + paidAmount + "," + "payDiscountAmount=" + payDiscountAmount + "," + "merchantAmount=" + merchantAmount + "," + "platformAmount=" + platformAmount + "," + "opPoiId=" + opPoiId + "," + "orderChannel=" + orderChannel + "," + "bizType=" + bizType + "," + "spuType=" + spuType + "," + "bookStartTime=" + bookStartTime + "," + "bookEndTime=" + bookEndTime + "," + "bookAfterGroup=" + bookAfterGroup + "}";
    }
}
