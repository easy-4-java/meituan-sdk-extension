package com.meituan.sdk.model.dishconnect.settle.queryByPage;

import com.google.gson.annotations.SerializedName;

/**
* 券营销活动详情，可选字段（如需使用，请联系美团侧运营进行单独配置，默认不透出，仅供商家需要神会员详细营销金额情况使用）  注意：如需该字段，请求参数中增加settleType。  settleType：  0：团购美团码核销结算  1：团购美团码发券结算  2：买单结算  4：秒提/啡快/在线点结算
* This file was automatically generated.
*/
public class PromotionDetail {
    /**
    * 活动类型
    */
    @SerializedName("promotionType")
    private String promotionType;
    /**
    * 活动名称
    */
    @SerializedName("promotionName")
    private String promotionName;
    /**
    * 促销开始时间 格式: yyyy/MM/dd
    */
    @SerializedName("startDate")
    private String startDate;
    /**
    * 促销结束时间 格式: yyyy/MM/dd
    */
    @SerializedName("endDate")
    private String endDate;
    /**
    * 促销状态
    */
    @SerializedName("promotionStatus")
    private String promotionStatus;
    /**
    * 商促结算类型，余额抵扣/随单抵扣
    */
    @SerializedName("settleType")
    private String settleType;
    /**
    * 促销费总额
    */
    @SerializedName("amount")
    private String amount;
    /**
    * 商家承担促销费-随单抵扣
    */
    @SerializedName("merchantAmountWithOrder")
    private String merchantAmountWithOrder;
    /**
    * 商家承担促销费-营销账户余额抵扣
    */
    @SerializedName("merchantAmountByBalance")
    private String merchantAmountByBalance;
    /**
    * 美团承担促销费
    */
    @SerializedName("platformAmount")
    private String platformAmount;
    /**
    * 备注
    */
    @SerializedName("remark")
    private String remark;

    public String getPromotionType() {
        return promotionType;
    }
    public void setPromotionType(String promotionType) {
        this.promotionType = promotionType;
    }
    public String getPromotionName() {
        return promotionName;
    }
    public void setPromotionName(String promotionName) {
        this.promotionName = promotionName;
    }
    public String getStartDate() {
        return startDate;
    }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    public String getEndDate() {
        return endDate;
    }
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    public String getPromotionStatus() {
        return promotionStatus;
    }
    public void setPromotionStatus(String promotionStatus) {
        this.promotionStatus = promotionStatus;
    }
    public String getSettleType() {
        return settleType;
    }
    public void setSettleType(String settleType) {
        this.settleType = settleType;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public String getMerchantAmountWithOrder() {
        return merchantAmountWithOrder;
    }
    public void setMerchantAmountWithOrder(String merchantAmountWithOrder) {
        this.merchantAmountWithOrder = merchantAmountWithOrder;
    }
    public String getMerchantAmountByBalance() {
        return merchantAmountByBalance;
    }
    public void setMerchantAmountByBalance(String merchantAmountByBalance) {
        this.merchantAmountByBalance = merchantAmountByBalance;
    }
    public String getPlatformAmount() {
        return platformAmount;
    }
    public void setPlatformAmount(String platformAmount) {
        this.platformAmount = platformAmount;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }




    @Override
    public String toString() {
        return "PromotionDetail{" + "promotionType=" + promotionType + "," + "promotionName=" + promotionName + "," + "startDate=" + startDate + "," + "endDate=" + endDate + "," + "promotionStatus=" + promotionStatus + "," + "settleType=" + settleType + "," + "amount=" + amount + "," + "merchantAmountWithOrder=" + merchantAmountWithOrder + "," + "merchantAmountByBalance=" + merchantAmountByBalance + "," + "platformAmount=" + platformAmount + "," + "remark=" + remark + "}";
    }
}
