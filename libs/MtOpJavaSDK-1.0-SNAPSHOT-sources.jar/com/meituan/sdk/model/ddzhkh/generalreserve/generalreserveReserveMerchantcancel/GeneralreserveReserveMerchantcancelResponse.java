package com.meituan.sdk.model.ddzhkh.generalreserve.generalreserveReserveMerchantcancel;

import com.google.gson.annotations.SerializedName;

/**
* 商家取消
* This file was automatically generated.
*/
public class GeneralreserveReserveMerchantcancelResponse {
    @SerializedName("result")
    private Boolean result;

    public Boolean getResult() {
        return result;
    }
    public void setResult(Boolean result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "GeneralreserveReserveMerchantcancelResponse{" + "result=" + result + "}";
    }
}
