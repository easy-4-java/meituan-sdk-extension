package com.meituan.sdk.model.waimaiNg.dish.batchDelSpu;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 批量删除商品
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/dish/food/batchDelSpu",
    businessId = 2,
    apiVersion = "10123",
    apiName = "batch_del_spu",
    needAuth = true
)
public class BatchDelSpuRequest implements MeituanRequest<String> {
    /**
    * <p data-diff-id="ct-diff-id-d123b7bd-2a14-4333-bf9d-29a25a58d6af">场域id，有则删除场域商品，不填则删除外卖主站商品</p>
    */
    @SerializedName("marketplaceId")
    private String marketplaceId;
    /**
    * <p data-diff-id="ct-diff-id-a0961cf2-3c22-48bf-8ddd-e72f46bdf4b0"><span style="color: rgba(0, 0, 0, 0.65)">spu code码，多个使用逗号拼接，需要跟外卖主站品的appFoodCode保持一致。</span></p>
    */
    @NotBlank(message = "appFoodCodes不能为空")
    @SerializedName("appFoodCodes")
    private String appFoodCodes;

    public String getMarketplaceId() {
        return marketplaceId;
    }
    public void setMarketplaceId(String marketplaceId) {
        this.marketplaceId = marketplaceId;
    }
    public String getAppFoodCodes() {
        return appFoodCodes;
    }
    public void setAppFoodCodes(String appFoodCodes) {
        this.appFoodCodes = appFoodCodes;
    }


    @Override
    public MeituanResponse<String> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<String>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "BatchDelSpuRequest{" + "marketplaceId=" + marketplaceId + "," + "appFoodCodes=" + appFoodCodes + "}";
    }
}
