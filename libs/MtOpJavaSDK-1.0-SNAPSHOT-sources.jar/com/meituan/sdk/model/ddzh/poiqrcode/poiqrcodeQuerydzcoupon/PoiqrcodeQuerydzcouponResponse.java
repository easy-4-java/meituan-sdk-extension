package com.meituan.sdk.model.ddzh.poiqrcode.poiqrcodeQuerydzcoupon;

import com.google.gson.annotations.SerializedName;

/**
* 获取门店优惠码
* This file was automatically generated.
*/
public class PoiqrcodeQuerydzcouponResponse {
    /**
    * 优惠码图片地址
    */
    @SerializedName("imageUrl")
    private String imageUrl;

    public String getImageUrl() {
        return imageUrl;
    }
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }




    @Override
    public String toString() {
        return "PoiqrcodeQuerydzcouponResponse{" + "imageUrl=" + imageUrl + "}";
    }
}
