package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiCommonBankAll;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* [基础]查询银行信息
* This file was automatically generated.
*/
public class ZcmopenApiCommonBankAllResponse {
    @SerializedName("data")
    private List<DataSub> data;

    public List<DataSub> getData() {
        return data;
    }
    public void setData(List<DataSub> data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "ZcmopenApiCommonBankAllResponse{" + "data=" + data + "}";
    }
}
