package com.meituan.sdk.model.ddzhkh.miniprogram.tradeQueryOrder;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-ea7b65a4-0f83-421f-8189-d3edd4743332">订单查询具体参数</p>
* This file was automatically generated.
*/
public class QueryOrderReq {
    /**
    * <p data-diff-id="ct-diff-id-4b8445c5-8ed5-41f5-aa03-cce0b1dfcb48">美团订单号，与三方订单号二选一</p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-19d60a87-9afa-4f6e-8198-8bcfa06c35d1">三方订单号，与美团订单号二选一</p>
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }




    @Override
    public String toString() {
        return "QueryOrderReq{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "}";
    }
}
