package com.meituan.sdk.model.mlive.streams.reportLiveMaterialV2;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 提交直播物料，集采场景
* This file was automatically generated.
*/
@ApiMeta(
    path = "/mlive/streams/reportMaterial/v2",
    businessId = 50,
    apiVersion = "10016",
    apiName = "report_live_material_v2",
    needAuth = false
)
public class ReportLiveMaterialV2Request implements MeituanRequest<Boolean> {
    /**
    * <p data-diff-id="ct-diff-id-4be1b55d-2931-41b2-a7f1-078aff38bdb6"><span style="color: #333">直播物料</span></p>
    */
    @SerializedName("liveMaterial")
    private LiveMaterial liveMaterial;
    /**
    * <p data-diff-id="ct-diff-id-6678fef0-591f-4c98-8c00-2a1c8e24d256"><span style="color: #333">直播id</span></p>
    */
    @SerializedName("liveId")
    private Long liveId;
    /**
    * <p data-diff-id="ct-diff-id-1bea8cc6-b133-4633-9937-c873c7c3e94a">主播id</p>
    */
    @SerializedName("anchorId")
    private Long anchorId;

    public LiveMaterial getLiveMaterial() {
        return liveMaterial;
    }
    public void setLiveMaterial(LiveMaterial liveMaterial) {
        this.liveMaterial = liveMaterial;
    }
    public Long getLiveId() {
        return liveId;
    }
    public void setLiveId(Long liveId) {
        this.liveId = liveId;
    }
    public Long getAnchorId() {
        return anchorId;
    }
    public void setAnchorId(Long anchorId) {
        this.anchorId = anchorId;
    }


    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ReportLiveMaterialV2Request{" + "liveMaterial=" + liveMaterial + "," + "liveId=" + liveId + "," + "anchorId=" + anchorId + "}";
    }
}
