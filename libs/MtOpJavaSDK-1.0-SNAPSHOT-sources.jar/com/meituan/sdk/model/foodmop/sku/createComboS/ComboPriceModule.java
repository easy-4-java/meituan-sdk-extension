package com.meituan.sdk.model.foodmop.sku.createComboS;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-9aaa1299-e7f4-4699-8066-bf51a078ef7b"><span style="color: rgb(102, 102, 102)">套餐价格模块，包含基础价格、加价规则、分摊规则 基础价格和加价规则 如果需要更新必须同时传（如果只有固定分组可以不传加价规则） 基础价格和加价规则、分摊规则不能都为空 新建套餐时，都需要传</span></p>
* This file was automatically generated.
*/
public class ComboPriceModule {
    /**
    * <p data-diff-id="ct-diff-id-5c1dfd72-6eb3-4a91-8372-f9b1f28e2012"><span style="color: rgb(102, 102, 102)">基础价格</span></p>
    */
    @SerializedName("basicPrice")
    private Long basicPrice;
    /**
    * <p data-diff-id="ct-diff-id-db17967b-5321-42b2-a44d-b0969bfc7efd"><span style="color: rgb(102, 102, 102)">加价规则</span></p>
    */
    @SerializedName("addPriceRule")
    private AddPriceRule addPriceRule;
    /**
    * <p data-diff-id="ct-diff-id-667d3cf3-50f1-4e1a-8b79-3c19de7c38b8"><span style="color: rgb(102, 102, 102)">分摊规则</span></p>
    */
    @SerializedName("sharePriceRule")
    private SharePriceRule sharePriceRule;

    public Long getBasicPrice() {
        return basicPrice;
    }
    public void setBasicPrice(Long basicPrice) {
        this.basicPrice = basicPrice;
    }
    public AddPriceRule getAddPriceRule() {
        return addPriceRule;
    }
    public void setAddPriceRule(AddPriceRule addPriceRule) {
        this.addPriceRule = addPriceRule;
    }
    public SharePriceRule getSharePriceRule() {
        return sharePriceRule;
    }
    public void setSharePriceRule(SharePriceRule sharePriceRule) {
        this.sharePriceRule = sharePriceRule;
    }




    @Override
    public String toString() {
        return "ComboPriceModule{" + "basicPrice=" + basicPrice + "," + "addPriceRule=" + addPriceRule + "," + "sharePriceRule=" + sharePriceRule + "}";
    }
}
