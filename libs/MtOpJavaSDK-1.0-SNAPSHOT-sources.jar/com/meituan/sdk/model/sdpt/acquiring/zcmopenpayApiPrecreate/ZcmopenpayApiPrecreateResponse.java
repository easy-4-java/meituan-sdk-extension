package com.meituan.sdk.model.sdpt.acquiring.zcmopenpayApiPrecreate;

import com.google.gson.annotations.SerializedName;

/**
* 美团收单[扫码支付]扫码支付接口
* This file was automatically generated.
*/
public class ZcmopenpayApiPrecreateResponse {
    /**
    * SUCCESS： 请求成功；FAIL：请求失败 请重试
    */
    @SerializedName("status")
    private String status;
    /**
    * 错误编码 （status 为失败的时候有
    */
    @SerializedName("errCode")
    private String errCode;
    /**
    * 错误消息描述（status 为失败的时候有）
    */
    @SerializedName("errMsg")
    private String errMsg;
    /**
    * 子错误码（status 为失败的时候有）
    */
    @SerializedName("subCode")
    private String subCode;
    /**
    * 子错误码的描述（status 为失败的时候有）
    */
    @SerializedName("subMsg")
    private String subMsg;
    /**
    * 随机数（status为成功的时候有）
    */
    @SerializedName("random")
    private String random;
    /**
    * 	 签名（status为成功的时候有）
    */
    @SerializedName("sign")
    private String sign;
    /**
    * 接入方订单号
    */
    @SerializedName("outTradeNo")
    private String outTradeNo;
    /**
    * NATIVE支付方式返回的动态二维码
    */
    @SerializedName("qrCode")
    private String qrCode;
    /**
    * 支付宝JSAPI支付方式返回，支付宝H5调起支付宝支付所需参数
    */
    @SerializedName("transactionId")
    private String transactionId;
    /**
    * 微信JSAPI支付方式返回，微信H5调起微信支付所需参数
    */
    @SerializedName("prepayId")
    private String prepayId;
    /**
    * 微信JSAPI支付方式返回，微信H5调起微信支付所需参数
    */
    @SerializedName("appId")
    private String appId;
    /**
    * 微信JSAPI支付方式返回，微信H5调起微信支付所需参数
    */
    @SerializedName("timeStamp")
    private String timeStamp;
    /**
    * 微信JSAPI支付方式返回，微信H5调起微信支付所需参数
    */
    @SerializedName("nonceStr")
    private String nonceStr;
    /**
    * 微信JSAPI支付方式返回，微信H5调起微信支付所需参数
    */
    @SerializedName("signType")
    private String signType;
    /**
    * 微信JSAPI支付方式返回，微信H5调起微信支付所需参数
    */
    @SerializedName("paySign")
    private String paySign;
    /**
    * 预收款订单token，调起美团钱包使用
    */
    @SerializedName("payToken")
    private String payToken;
    /**
    * 预收款订单号，调起美团钱包使用
    */
    @SerializedName("tradeNo")
    private String tradeNo;

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getErrCode() {
        return errCode;
    }
    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }
    public String getErrMsg() {
        return errMsg;
    }
    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
    public String getSubCode() {
        return subCode;
    }
    public void setSubCode(String subCode) {
        this.subCode = subCode;
    }
    public String getSubMsg() {
        return subMsg;
    }
    public void setSubMsg(String subMsg) {
        this.subMsg = subMsg;
    }
    public String getRandom() {
        return random;
    }
    public void setRandom(String random) {
        this.random = random;
    }
    public String getSign() {
        return sign;
    }
    public void setSign(String sign) {
        this.sign = sign;
    }
    public String getOutTradeNo() {
        return outTradeNo;
    }
    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }
    public String getQrCode() {
        return qrCode;
    }
    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }
    public String getTransactionId() {
        return transactionId;
    }
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
    public String getPrepayId() {
        return prepayId;
    }
    public void setPrepayId(String prepayId) {
        this.prepayId = prepayId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getTimeStamp() {
        return timeStamp;
    }
    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }
    public String getNonceStr() {
        return nonceStr;
    }
    public void setNonceStr(String nonceStr) {
        this.nonceStr = nonceStr;
    }
    public String getSignType() {
        return signType;
    }
    public void setSignType(String signType) {
        this.signType = signType;
    }
    public String getPaySign() {
        return paySign;
    }
    public void setPaySign(String paySign) {
        this.paySign = paySign;
    }
    public String getPayToken() {
        return payToken;
    }
    public void setPayToken(String payToken) {
        this.payToken = payToken;
    }
    public String getTradeNo() {
        return tradeNo;
    }
    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }




    @Override
    public String toString() {
        return "ZcmopenpayApiPrecreateResponse{" + "status=" + status + "," + "errCode=" + errCode + "," + "errMsg=" + errMsg + "," + "subCode=" + subCode + "," + "subMsg=" + subMsg + "," + "random=" + random + "," + "sign=" + sign + "," + "outTradeNo=" + outTradeNo + "," + "qrCode=" + qrCode + "," + "transactionId=" + transactionId + "," + "prepayId=" + prepayId + "," + "appId=" + appId + "," + "timeStamp=" + timeStamp + "," + "nonceStr=" + nonceStr + "," + "signType=" + signType + "," + "paySign=" + paySign + "," + "payToken=" + payToken + "," + "tradeNo=" + tradeNo + "}";
    }
}
