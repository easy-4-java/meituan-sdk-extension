package com.meituan.sdk.model.ddzhkh.miniprogram.tradeQueryOrder;

import com.google.gson.annotations.SerializedName;

/**
* 退款信息列表
* This file was automatically generated.
*/
public class RefundInfo {
    /**
    * 美团退款单号
    */
    @SerializedName("refundId")
    private String refundId;
    /**
    * 商户退款单号
    */
    @SerializedName("vendorRefundId")
    private String vendorRefundId;
    /**
    * 美团订单号
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * 状态，SUCCESS：退款成功 PROCESSING：退款已受理
    */
    @SerializedName("refundStatus")
    private String refundStatus;
    /**
    * 退款原因
    */
    @SerializedName("reason")
    private String reason;
    /**
    * 退款成功时间，时间戳，精度毫秒 *退款成功状态时存在
    */
    @SerializedName("successTime")
    private Long successTime;
    /**
    * 退款申请时间，时间戳，精度毫秒
    */
    @SerializedName("createTime")
    private Long createTime;
    /**
    * 外部传入的自定义数据
    */
    @SerializedName("refundExt")
    private String refundExt;
    /**
    * 退给用户实付金额，单位：分
    */
    @SerializedName("totalRefundAmount")
    private Long totalRefundAmount;

    public String getRefundId() {
        return refundId;
    }
    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }
    public String getVendorRefundId() {
        return vendorRefundId;
    }
    public void setVendorRefundId(String vendorRefundId) {
        this.vendorRefundId = vendorRefundId;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getRefundStatus() {
        return refundStatus;
    }
    public void setRefundStatus(String refundStatus) {
        this.refundStatus = refundStatus;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }
    public Long getSuccessTime() {
        return successTime;
    }
    public void setSuccessTime(Long successTime) {
        this.successTime = successTime;
    }
    public Long getCreateTime() {
        return createTime;
    }
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
    public String getRefundExt() {
        return refundExt;
    }
    public void setRefundExt(String refundExt) {
        this.refundExt = refundExt;
    }
    public Long getTotalRefundAmount() {
        return totalRefundAmount;
    }
    public void setTotalRefundAmount(Long totalRefundAmount) {
        this.totalRefundAmount = totalRefundAmount;
    }




    @Override
    public String toString() {
        return "RefundInfo{" + "refundId=" + refundId + "," + "vendorRefundId=" + vendorRefundId + "," + "orderId=" + orderId + "," + "refundStatus=" + refundStatus + "," + "reason=" + reason + "," + "successTime=" + successTime + "," + "createTime=" + createTime + "," + "refundExt=" + refundExt + "," + "totalRefundAmount=" + totalRefundAmount + "}";
    }
}
