package com.meituan.sdk.model.ddzhkh.xcxzc.createRelationOrder;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* 
* This file was automatically generated.
*/
public class BaseProductReq {
    /**
    * <p data-diff-id="ct-diff-id-72e7e12d-0373-4652-ac4c-51bf436991c8">商品ID</p>
    */
    @NotNull(message = "productId不能为空")
    @SerializedName("productId")
    private Long productId;
    /**
    * <p data-diff-id="ct-diff-id-fef6d9bb-3246-4dee-93b7-1fc734b5a6b6">sku id</p>
    */
    @NotBlank(message = "skuId不能为空")
    @SerializedName("skuId")
    private String skuId;
    /**
    * <p data-diff-id="ct-diff-id-d4ac89b9-ab57-454c-bcdd-29575dd91cc6">售卖总价，单位分（含附加项费用）</p>
    */
    @NotNull(message = "totalAmount不能为空")
    @SerializedName("totalAmount")
    private Long totalAmount;
    /**
    * <p data-diff-id="ct-diff-id-ace7e6cf-9234-4ea6-9977-83e7ef5f23d0">用户选择的下单数量</p>
    */
    @NotNull(message = "quantity不能为空")
    @SerializedName("quantity")
    private Integer quantity;
    /**
    * <p data-diff-id="ct-diff-id-6397f604-79ab-4000-97f5-9281a44668c1">商品扩展字段；长度限制2048</p>
    */
    @SerializedName("productExt")
    private String productExt;
    /**
    * <p data-diff-id="ct-diff-id-a8e7d8ce-6abb-43d7-9e7c-494e1d7d9608">商品名称</p>
    */
    @NotBlank(message = "productName不能为空")
    @SerializedName("productName")
    private String productName;

    public Long getProductId() {
        return productId;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }
    public String getSkuId() {
        return skuId;
    }
    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }
    public Long getTotalAmount() {
        return totalAmount;
    }
    public void setTotalAmount(Long totalAmount) {
        this.totalAmount = totalAmount;
    }
    public Integer getQuantity() {
        return quantity;
    }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
    public String getProductExt() {
        return productExt;
    }
    public void setProductExt(String productExt) {
        this.productExt = productExt;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }




    @Override
    public String toString() {
        return "BaseProductReq{" + "productId=" + productId + "," + "skuId=" + skuId + "," + "totalAmount=" + totalAmount + "," + "quantity=" + quantity + "," + "productExt=" + productExt + "," + "productName=" + productName + "}";
    }
}
