package com.meituan.sdk.model.mendianzhilian.test.search;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询门店信息
* This file was automatically generated.
*/
@ApiMeta(
    path = "/mendianzhilian/test/map/poi/search",
    businessId = 71,
    apiVersion = "10024",
    apiName = "search",
    needAuth = false
)
public class SearchRequest implements MeituanRequest<SearchResponse> {
    /**
    * <p data-diff-id="ct-diff-id-840348cd-004c-4c8d-bff5-616852d7257d">开发者ID</p>
    */
    @NotBlank(message = "developerId不能为空")
    @SerializedName("developerId")
    private String developerId;
    /**
    * <p data-diff-id="ct-diff-id-cd18a56d-6179-4b55-83da-208aa6393950">外部品牌erp门店编码</p>
    */
    @NotBlank(message = "poiId不能为空")
    @SerializedName("poiId")
    private String poiId;

    public String getDeveloperId() {
        return developerId;
    }
    public void setDeveloperId(String developerId) {
        this.developerId = developerId;
    }
    public String getPoiId() {
        return poiId;
    }
    public void setPoiId(String poiId) {
        this.poiId = poiId;
    }


    @Override
    public MeituanResponse<SearchResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<SearchResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "SearchRequest{" + "developerId=" + developerId + "," + "poiId=" + poiId + "}";
    }
}
