package com.meituan.sdk.model.pms.reservation.queryUngeneratedRoomRent;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 查询接待单是否生成过房费
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/reservation/queryUnGeneratedRoomRent",
    businessId = 57,
    apiVersion = "10050",
    apiName = "query_ungenerated_room_rent",
    needAuth = true
)
public class QueryUngeneratedRoomRentRequest implements MeituanRequest<QueryUngeneratedRoomRentResponse> {
    /**
    * <p data-diff-id="ct-diff-id-966e1a69-59bc-4d31-9ecb-a5dcb21501f6">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-44653351-69d3-405c-88fe-8558eac7151c">接待单ID</p>
    */
    @NotEmpty(message = "checkinIds不能为空")
    @SerializedName("checkinIds")
    private List<Long> checkinIds;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public List<Long> getCheckinIds() {
        return checkinIds;
    }
    public void setCheckinIds(List<Long> checkinIds) {
        this.checkinIds = checkinIds;
    }


    @Override
    public MeituanResponse<QueryUngeneratedRoomRentResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<QueryUngeneratedRoomRentResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "QueryUngeneratedRoomRentRequest{" + "hotelId=" + hotelId + "," + "checkinIds=" + checkinIds + "}";
    }
}
