package com.meituan.sdk.model.mlive.streams.getPushUrlWithMaterial;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-f23ed4f2-123c-4453-9be0-077fe2200824">商品讲解预设的问题&amp;回答</p><p data-diff-id="ct-diff-id-3f6ca442-29d5-4489-bcf9-f1f70734509f">generateType=2时，可不传；其它情况，必传</p>
* This file was automatically generated.
*/
public class QuestionsSub {
    /**
    * <p data-diff-id="ct-diff-id-4e0b02ca-de76-4e2e-9a24-d5c0f4b80a09">商品问题</p><p data-diff-id="ct-diff-id-1a321791-2e4a-4441-aa98-fc73c6cd0484">questions非空时，必传</p>
    */
    @SerializedName("question")
    private String question;
    /**
    * <p data-diff-id="ct-diff-id-887f0709-8f1e-4b7d-bf6a-39cf0fcd6dfe">商品回答</p><p data-diff-id="ct-diff-id-fd90764a-ce0e-4442-b3ee-681a47babfa3">questions非空时，必传</p>
    */
    @SerializedName("answer")
    private String answer;

    public String getQuestion() {
        return question;
    }
    public void setQuestion(String question) {
        this.question = question;
    }
    public String getAnswer() {
        return answer;
    }
    public void setAnswer(String answer) {
        this.answer = answer;
    }




    @Override
    public String toString() {
        return "QuestionsSub{" + "question=" + question + "," + "answer=" + answer + "}";
    }
}
