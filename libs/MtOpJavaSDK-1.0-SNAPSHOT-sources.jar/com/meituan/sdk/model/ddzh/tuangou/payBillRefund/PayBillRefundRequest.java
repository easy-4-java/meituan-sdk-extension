package com.meituan.sdk.model.ddzh.tuangou.payBillRefund;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 买单订单退款
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/tuangou/paybill/refund",
    businessId = 58,
    apiVersion = "10102",
    apiName = "pay_bill_refund",
    needAuth = true
)
public class PayBillRefundRequest implements MeituanRequest<PayBillRefundResponse> {
    /**
    * <p data-diff-id="ct-diff-id-ade58fb5-e4c2-48cf-8f03-e3704493633e">买单订单号</p>
    */
    @NotBlank(message = "orderId不能为空")
    @SerializedName("orderId")
    private String orderId;

    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }


    @Override
    public MeituanResponse<PayBillRefundResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<PayBillRefundResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "PayBillRefundRequest{" + "orderId=" + orderId + "}";
    }
}
