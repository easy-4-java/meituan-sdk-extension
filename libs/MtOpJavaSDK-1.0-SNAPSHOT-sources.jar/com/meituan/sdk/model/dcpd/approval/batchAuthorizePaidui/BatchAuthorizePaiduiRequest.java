package com.meituan.sdk.model.dcpd.approval.batchAuthorizePaidui;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 批量门店授权接口-到餐排队
* This file was automatically generated.
*/
@ApiMeta(
    path = "/dcpd/approval/batchAuthorize",
    businessId = 49,
    apiVersion = "10000",
    apiName = "batch_authorize_paidui",
    needAuth = false
)
public class BatchAuthorizePaiduiRequest implements MeituanRequest<String> {
    /**
    * <p data-diff-id="ct-diff-id-dc1691f9-df8f-4b6f-b7b0-df8602585eeb"><em><span style="color: rgba(0, 0, 0, 0.65)">门店ID列表。门店在开店宝上展示的门店id。</span></em></p>
    */
    @NotEmpty(message = "shopIds不能为空")
    @SerializedName("shopIds")
    private List<Long> shopIds;
    /**
    * <p data-diff-id="ct-diff-id-80c57618-b5a6-4a01-9dae-951a1d38c0ef"><em><span style="color: rgba(0, 0, 0, 0.65)">授权范围（逗号隔开），例如：</span></em></p>
    */
    @NotBlank(message = "scope不能为空")
    @SerializedName("scope")
    private String scope;
    /**
    * <p data-diff-id="ct-diff-id-370e9c7f-ecec-442b-b206-422235d5edd6"><em><span style="color: rgba(0, 0, 0, 0.65)">门店类型；标识shopIds类型；1:美团门店ID，2:点评门店ID</span></em></p>
    */
    @NotNull(message = "shopType不能为空")
    @SerializedName("shopType")
    private Long shopType;
    /**
    * <p data-diff-id="ct-diff-id-9b4fdd8b-3bcd-4ba3-a736-5196d39c596e"><em><span style="color: rgba(0, 0, 0, 0.65)">商家账号。</span><span style="color: rgb(0, 0, 0)">商家打开开店宝时，通过账号密码方式登录的账号。注意，不是手机号。</span></em></p>
    */
    @NotBlank(message = "bizAccLogin不能为空")
    @SerializedName("bizAccLogin")
    private String bizAccLogin;

    public List<Long> getShopIds() {
        return shopIds;
    }
    public void setShopIds(List<Long> shopIds) {
        this.shopIds = shopIds;
    }
    public String getScope() {
        return scope;
    }
    public void setScope(String scope) {
        this.scope = scope;
    }
    public Long getShopType() {
        return shopType;
    }
    public void setShopType(Long shopType) {
        this.shopType = shopType;
    }
    public String getBizAccLogin() {
        return bizAccLogin;
    }
    public void setBizAccLogin(String bizAccLogin) {
        this.bizAccLogin = bizAccLogin;
    }


    @Override
    public MeituanResponse<String> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<String>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "BatchAuthorizePaiduiRequest{" + "shopIds=" + shopIds + "," + "scope=" + scope + "," + "shopType=" + shopType + "," + "bizAccLogin=" + bizAccLogin + "}";
    }
}
