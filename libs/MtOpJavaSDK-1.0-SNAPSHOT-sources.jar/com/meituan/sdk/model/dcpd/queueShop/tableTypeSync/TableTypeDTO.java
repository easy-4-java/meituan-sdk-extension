package com.meituan.sdk.model.dcpd.queueShop.tableTypeSync;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-4b0370a4-5acb-48fd-bfdb-7cde800856d1">桌型列表</p>
* This file was automatically generated.
*/
public class TableTypeDTO {
    /**
    * <p data-diff-id="ct-diff-id-36565416-d868-452e-a732-6727c4bb7d1b">桌型id，新增时无需填写</p>
    */
    @SerializedName("tableTypeId")
    private Integer tableTypeId;
    /**
    * <p data-diff-id="ct-diff-id-d9bb1023-34df-4b62-a8af-3e7ba79d5587">桌型名称</p>
    */
    @SerializedName("tableTypeName")
    private String tableTypeName;
    /**
    * <p data-diff-id="ct-diff-id-3fc044e3-9b4d-49df-93cf-9bf1590de017">桌型名称</p>
    */
    @SerializedName("displayName")
    private String displayName;
    /**
    * <p data-diff-id="ct-diff-id-9684bced-9014-472d-886c-da893a22077d">最小人数</p>
    */
    @SerializedName("minCapacity")
    private Integer minCapacity;
    /**
    * <p data-diff-id="ct-diff-id-3f07dde0-805f-4ebe-8a24-1949c8201a87">最大人数</p>
    */
    @SerializedName("maxCapacity")
    private Integer maxCapacity;
    /**
    * <p data-diff-id="ct-diff-id-0132b7d6-2ea5-484e-ab08-4da7ad149f6f">桌型前缀</p>
    */
    @SerializedName("numPrefix")
    private String numPrefix;
    /**
    * <p data-diff-id="ct-diff-id-8ec8642c-e2f0-43ab-8356-ca18f26ecac6">操作类型：1新增，2修改，3删除</p>
    */
    @SerializedName("operateType")
    private Integer operateType;

    public Integer getTableTypeId() {
        return tableTypeId;
    }
    public void setTableTypeId(Integer tableTypeId) {
        this.tableTypeId = tableTypeId;
    }
    public String getTableTypeName() {
        return tableTypeName;
    }
    public void setTableTypeName(String tableTypeName) {
        this.tableTypeName = tableTypeName;
    }
    public String getDisplayName() {
        return displayName;
    }
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    public Integer getMinCapacity() {
        return minCapacity;
    }
    public void setMinCapacity(Integer minCapacity) {
        this.minCapacity = minCapacity;
    }
    public Integer getMaxCapacity() {
        return maxCapacity;
    }
    public void setMaxCapacity(Integer maxCapacity) {
        this.maxCapacity = maxCapacity;
    }
    public String getNumPrefix() {
        return numPrefix;
    }
    public void setNumPrefix(String numPrefix) {
        this.numPrefix = numPrefix;
    }
    public Integer getOperateType() {
        return operateType;
    }
    public void setOperateType(Integer operateType) {
        this.operateType = operateType;
    }




    @Override
    public String toString() {
        return "TableTypeDTO{" + "tableTypeId=" + tableTypeId + "," + "tableTypeName=" + tableTypeName + "," + "displayName=" + displayName + "," + "minCapacity=" + minCapacity + "," + "maxCapacity=" + maxCapacity + "," + "numPrefix=" + numPrefix + "," + "operateType=" + operateType + "}";
    }
}
