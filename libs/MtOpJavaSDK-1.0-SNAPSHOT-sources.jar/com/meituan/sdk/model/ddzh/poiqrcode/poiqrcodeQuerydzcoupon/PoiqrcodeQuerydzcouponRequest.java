package com.meituan.sdk.model.ddzh.poiqrcode.poiqrcodeQuerydzcoupon;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取门店优惠码
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/poiqrcode/querydzcoupon",
    businessId = 58,
    apiVersion = "10000",
    apiName = "poiqrcode_querydzcoupon",
    needAuth = true
)
public class PoiqrcodeQuerydzcouponRequest implements MeituanRequest<PoiqrcodeQuerydzcouponResponse> {



    @Override
    public MeituanResponse<PoiqrcodeQuerydzcouponResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<PoiqrcodeQuerydzcouponResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return null;
    }


}
