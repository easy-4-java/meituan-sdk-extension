package com.meituan.sdk.model.pms.hotel.getEbPoiInfo;

import com.google.gson.annotations.SerializedName;

/**
* 获取酒店绑定美团EBPOI信息
* This file was automatically generated.
*/
public class GetEbPoiInfoResponse {
    /**
    * 酒店绑定美团酒店供应商ID
    */
    @SerializedName("partnerId")
    private Long partnerId;
    /**
    * 酒店绑定美团酒店POI ID
    */
    @SerializedName("poiId")
    private Long poiId;
    /**
    * 酒店绑定美团酒店POI名称
    */
    @SerializedName("poiName")
    private String poiName;

    public Long getPartnerId() {
        return partnerId;
    }
    public void setPartnerId(Long partnerId) {
        this.partnerId = partnerId;
    }
    public Long getPoiId() {
        return poiId;
    }
    public void setPoiId(Long poiId) {
        this.poiId = poiId;
    }
    public String getPoiName() {
        return poiName;
    }
    public void setPoiName(String poiName) {
        this.poiName = poiName;
    }




    @Override
    public String toString() {
        return "GetEbPoiInfoResponse{" + "partnerId=" + partnerId + "," + "poiId=" + poiId + "," + "poiName=" + poiName + "}";
    }
}
