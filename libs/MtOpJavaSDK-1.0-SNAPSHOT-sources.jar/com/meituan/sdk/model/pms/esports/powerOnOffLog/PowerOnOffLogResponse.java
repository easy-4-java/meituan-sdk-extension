package com.meituan.sdk.model.pms.esports.powerOnOffLog;

import com.google.gson.annotations.SerializedName;

/**
* 客人上下机日志同步
* This file was automatically generated.
*/
public class PowerOnOffLogResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    /**
    * 是否同步成功
    */
    @SerializedName("data")
    private Boolean data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public Boolean getData() {
        return data;
    }
    public void setData(Boolean data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "PowerOnOffLogResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
