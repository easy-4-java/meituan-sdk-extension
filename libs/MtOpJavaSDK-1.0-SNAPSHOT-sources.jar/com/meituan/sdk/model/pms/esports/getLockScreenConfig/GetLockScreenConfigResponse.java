package com.meituan.sdk.model.pms.esports.getLockScreenConfig;

import com.google.gson.annotations.SerializedName;

/**
* 获取门店锁屏配置
* This file was automatically generated.
*/
public class GetLockScreenConfigResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    @SerializedName("data")
    private EsportsLockScreenConfigDTO data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public EsportsLockScreenConfigDTO getData() {
        return data;
    }
    public void setData(EsportsLockScreenConfigDTO data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "GetLockScreenConfigResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
