package com.meituan.sdk.model.pms.hotel.getCityList;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取城市列表
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/hotel/getCityList",
    businessId = 57,
    apiVersion = "10015",
    apiName = "get_city_list",
    needAuth = true
)
public class GetCityListRequest implements MeituanRequest<GetCityListResponse> {



    @Override
    public MeituanResponse<GetCityListResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<GetCityListResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return null;
    }


}
