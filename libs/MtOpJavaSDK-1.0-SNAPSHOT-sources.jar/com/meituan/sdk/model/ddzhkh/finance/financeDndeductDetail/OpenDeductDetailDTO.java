package com.meituan.sdk.model.ddzhkh.finance.financeDndeductDetail;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class OpenDeductDetailDTO {
    /**
    * 交易凭证（订单号/券码）
    */
    @SerializedName("voucherNo")
    private String voucherNo;
    /**
    * 订单内容
    */
    @SerializedName("orderContent")
    private String orderContent;
    /**
    * 调整时间
    */
    @SerializedName("deductTime")
    private Long deductTime;
    /**
    * 商品ID
    */
    @SerializedName("skuId")
    private String skuId;
    /**
    * 商品描述
    */
    @SerializedName("skuDesc")
    private String skuDesc;
    /**
    * 消费门店
    */
    @SerializedName("shopName")
    private String shopName;
    /**
    * 调整金额
    */
    @SerializedName("deductAmount")
    private String deductAmount;
    /**
    * 备注
    */
    @SerializedName("memo")
    private String memo;
    /**
    * 是否总店
    */
    @SerializedName("generalShop")
    private Boolean generalShop;
    /**
    * 消费门店
    */
    @SerializedName("opPoiId")
    private String opPoiId;

    public String getVoucherNo() {
        return voucherNo;
    }
    public void setVoucherNo(String voucherNo) {
        this.voucherNo = voucherNo;
    }
    public String getOrderContent() {
        return orderContent;
    }
    public void setOrderContent(String orderContent) {
        this.orderContent = orderContent;
    }
    public Long getDeductTime() {
        return deductTime;
    }
    public void setDeductTime(Long deductTime) {
        this.deductTime = deductTime;
    }
    public String getSkuId() {
        return skuId;
    }
    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }
    public String getSkuDesc() {
        return skuDesc;
    }
    public void setSkuDesc(String skuDesc) {
        this.skuDesc = skuDesc;
    }
    public String getShopName() {
        return shopName;
    }
    public void setShopName(String shopName) {
        this.shopName = shopName;
    }
    public String getDeductAmount() {
        return deductAmount;
    }
    public void setDeductAmount(String deductAmount) {
        this.deductAmount = deductAmount;
    }
    public String getMemo() {
        return memo;
    }
    public void setMemo(String memo) {
        this.memo = memo;
    }
    public Boolean getGeneralShop() {
        return generalShop;
    }
    public void setGeneralShop(Boolean generalShop) {
        this.generalShop = generalShop;
    }
    public String getOpPoiId() {
        return opPoiId;
    }
    public void setOpPoiId(String opPoiId) {
        this.opPoiId = opPoiId;
    }




    @Override
    public String toString() {
        return "OpenDeductDetailDTO{" + "voucherNo=" + voucherNo + "," + "orderContent=" + orderContent + "," + "deductTime=" + deductTime + "," + "skuId=" + skuId + "," + "skuDesc=" + skuDesc + "," + "shopName=" + shopName + "," + "deductAmount=" + deductAmount + "," + "memo=" + memo + "," + "generalShop=" + generalShop + "," + "opPoiId=" + opPoiId + "}";
    }
}
