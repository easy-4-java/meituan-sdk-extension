package com.meituan.sdk.model.waimaiNg.diancan.diancanShopconfigQuery;

import com.google.gson.annotations.SerializedName;

/**
* 门店详细配置
* This file was automatically generated.
*/
public class VendorShopConfigDTO {
    /**
    * 服务配置
    */
    @SerializedName("serviceConfig")
    private VendorServiceConfigDTO serviceConfig;
    /**
    * 业务配置
    */
    @SerializedName("bizConfig")
    private VendorBizConfigDTO bizConfig;

    public VendorServiceConfigDTO getServiceConfig() {
        return serviceConfig;
    }
    public void setServiceConfig(VendorServiceConfigDTO serviceConfig) {
        this.serviceConfig = serviceConfig;
    }
    public VendorBizConfigDTO getBizConfig() {
        return bizConfig;
    }
    public void setBizConfig(VendorBizConfigDTO bizConfig) {
        this.bizConfig = bizConfig;
    }




    @Override
    public String toString() {
        return "VendorShopConfigDTO{" + "serviceConfig=" + serviceConfig + "," + "bizConfig=" + bizConfig + "}";
    }
}
