package com.meituan.sdk.model.wmoperNg.food.foodBatchGet;

import com.google.gson.annotations.SerializedName;

/**
* 售卖属性 spuAttr与skuAttr中的属性数量相同且属性内容相同（mode=2)
* This file was automatically generated.
*/
public class SkuAttr {
    /**
    * sku唯一标识
    */
    @SerializedName("sku_id")
    private String skuId;
    /**
    * 属性编号；例：温度(1)，口味(2)等
    */
    @SerializedName("no")
    private Integer no;
    /**
    * 属性名称 example="冷热" name长度不能大于10
    */
    @SerializedName("name")
    private String name;
    /**
    * 属性值, example="冷" value长度不能大于10
    */
    @SerializedName("value")
    private String value;

    public String getSkuId() {
        return skuId;
    }
    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }
    public Integer getNo() {
        return no;
    }
    public void setNo(Integer no) {
        this.no = no;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }




    @Override
    public String toString() {
        return "SkuAttr{" + "skuId=" + skuId + "," + "no=" + no + "," + "name=" + name + "," + "value=" + value + "}";
    }
}
