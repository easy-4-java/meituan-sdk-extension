package com.meituan.sdk.model.ddzh.yuding.pricelistSubmit;

import java.util.List;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-5619c2a0-2105-49ac-addb-f571809cbf72">商品时段时间信息</p>
* This file was automatically generated.
*/
public class PeriodDay {
    /**
    * <p data-diff-id="ct-diff-id-dd2bdd95-f083-44d5-a8aa-6e63303b0699">日期类型，循环日期或特殊日期</p><p data-diff-id="ct-diff-id-8db9d645-d6ba-40be-8b95-6524684b8b35">1 - 循环日期</p><p data-diff-id="ct-diff-id-f4ce44cc-cf8d-449f-bcef-e42898a6c3d0">2 - 特殊日期</p>
    */
    @SerializedName("dayType")
    private Integer dayType;
    /**
    * <p data-diff-id="ct-diff-id-81f2255b-2227-48e7-b1ee-7a5bde5a024a">周几：</p><p data-diff-id="ct-diff-id-32ad1972-b2f2-4404-b1e8-1c0bb36e2fb4">1-周一</p><p data-diff-id="ct-diff-id-f89c5512-8b0b-428c-9e7f-a4a5fd76d28f">2-周二</p><p data-diff-id="ct-diff-id-881d2ff4-63b8-4602-ac12-60b1b46edf2c">3-周三</p><p data-diff-id="ct-diff-id-499ce785-edc1-4cd3-bd0f-18e450f840f2">4-周四</p><p data-diff-id="ct-diff-id-51975230-3c3e-4229-9ab8-9bc3c173c588">5-周五</p><p data-diff-id="ct-diff-id-5ffa0f91-9c00-43f7-900b-d2aaa01a601e">6-周六</p><p data-diff-id="ct-diff-id-9aed70f7-385e-4527-8b50-f1b1cc387a91">7-周日</p>
    */
    @SerializedName("dayOfWeek")
    private Integer dayOfWeek;
    /**
    * <p data-diff-id="ct-diff-id-c1450d9e-5b6b-41b7-9cf2-65abfc7a938b">特殊日期开始日期，yyyy-MM-dd格式</p>
    */
    @SerializedName("specialStartDate")
    private String specialStartDate;
    /**
    * <p data-diff-id="ct-diff-id-e6ff7b2b-b394-4a5e-a36d-c19f4f6a4033">特殊日期结束日期，yyyy-MM-dd格式</p>
    */
    @SerializedName("specialEndDate")
    private String specialEndDate;
    /**
    * <p data-diff-id="ct-diff-id-a89bd86f-940a-4450-9f0f-9f6e89a716d3">商品时段信息</p>
    */
    @NotEmpty(message = "periodTimes不能为空")
    @SerializedName("periodTimes")
    private List<PeriodTime> periodTimes;

    public Integer getDayType() {
        return dayType;
    }
    public void setDayType(Integer dayType) {
        this.dayType = dayType;
    }
    public Integer getDayOfWeek() {
        return dayOfWeek;
    }
    public void setDayOfWeek(Integer dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }
    public String getSpecialStartDate() {
        return specialStartDate;
    }
    public void setSpecialStartDate(String specialStartDate) {
        this.specialStartDate = specialStartDate;
    }
    public String getSpecialEndDate() {
        return specialEndDate;
    }
    public void setSpecialEndDate(String specialEndDate) {
        this.specialEndDate = specialEndDate;
    }
    public List<PeriodTime> getPeriodTimes() {
        return periodTimes;
    }
    public void setPeriodTimes(List<PeriodTime> periodTimes) {
        this.periodTimes = periodTimes;
    }




    @Override
    public String toString() {
        return "PeriodDay{" + "dayType=" + dayType + "," + "dayOfWeek=" + dayOfWeek + "," + "specialStartDate=" + specialStartDate + "," + "specialEndDate=" + specialEndDate + "," + "periodTimes=" + periodTimes + "}";
    }
}
