package com.meituan.sdk.model.ddzhkh.xcxwy.createOrder;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* 
* This file was automatically generated.
*/
public class VendorInfoReq {
    /**
    * <p data-diff-id="ct-diff-id-df325506-be98-462d-8808-c53c1ab8d202">三方商户订单号，每次调用下单均要变更</p>
    */
    @NotBlank(message = "vendorOrderId不能为空")
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * <p data-diff-id="ct-diff-id-ef713b65-91c5-4453-afe0-dacb3329c925">用户在三方商户侧的下单时间，毫秒时间戳</p>
    */
    @NotNull(message = "vendorOrderTime不能为空")
    @SerializedName("vendorOrderTime")
    private Long vendorOrderTime;
    /**
    * <p data-diff-id="ct-diff-id-e53ee907-29f7-485b-a4d5-3ad391b19cbb">商户支付Id</p>
    */
    @NotBlank(message = "vendorPaymentId不能为空")
    @SerializedName("vendorPaymentId")
    private String vendorPaymentId;

    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public Long getVendorOrderTime() {
        return vendorOrderTime;
    }
    public void setVendorOrderTime(Long vendorOrderTime) {
        this.vendorOrderTime = vendorOrderTime;
    }
    public String getVendorPaymentId() {
        return vendorPaymentId;
    }
    public void setVendorPaymentId(String vendorPaymentId) {
        this.vendorPaymentId = vendorPaymentId;
    }




    @Override
    public String toString() {
        return "VendorInfoReq{" + "vendorOrderId=" + vendorOrderId + "," + "vendorOrderTime=" + vendorOrderTime + "," + "vendorPaymentId=" + vendorPaymentId + "}";
    }
}
