package com.meituan.sdk.model.ddzhkh.xcx3csmzl.refundOrder;

import com.google.gson.annotations.SerializedName;

/**
* 业务交互结果业务交互结果
* This file was automatically generated.
*/
public class ResObj {
    @SerializedName("code")
    private Integer code;
    @SerializedName("msg")
    private String msg;
    /**
    * 生单请求结果
    */
    @SerializedName("data")
    private PrepayRes data;

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public PrepayRes getData() {
        return data;
    }
    public void setData(PrepayRes data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "ResObj{" + "code=" + code + "," + "msg=" + msg + "," + "data=" + data + "}";
    }
}
