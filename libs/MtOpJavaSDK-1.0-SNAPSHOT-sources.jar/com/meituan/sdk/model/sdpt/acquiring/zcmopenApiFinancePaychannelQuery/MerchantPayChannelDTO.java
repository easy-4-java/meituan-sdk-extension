package com.meituan.sdk.model.sdpt.acquiring.zcmopenApiFinancePaychannelQuery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 商户支付通道信息
* This file was automatically generated.
*/
public class MerchantPayChannelDTO {
    /**
    * 支付通道类型,1-微信；2-支付宝；3-美团；4-银联卡；10-讯联
    */
    @SerializedName("payChannelType")
    private Integer payChannelType;
    /**
    * 商户外部商户号信息
    */
    @SerializedName("outMerchantDTOs")
    private List<OutMerchantDTO> outMerchantDTOs;

    public Integer getPayChannelType() {
        return payChannelType;
    }
    public void setPayChannelType(Integer payChannelType) {
        this.payChannelType = payChannelType;
    }
    public List<OutMerchantDTO> getOutMerchantDTOs() {
        return outMerchantDTOs;
    }
    public void setOutMerchantDTOs(List<OutMerchantDTO> outMerchantDTOs) {
        this.outMerchantDTOs = outMerchantDTOs;
    }




    @Override
    public String toString() {
        return "MerchantPayChannelDTO{" + "payChannelType=" + payChannelType + "," + "outMerchantDTOs=" + outMerchantDTOs + "}";
    }
}
