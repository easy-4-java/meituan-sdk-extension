package com.meituan.sdk.model.foodmop.order.diancannewOrderQueryOrderDownloadUrl;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 品牌查询美团日全量订单下载地址
* This file was automatically generated.
*/
public class DiancannewOrderQueryOrderDownloadUrlResponse {
    /**
    * yyyy-MM-dd 的格式，具体的日期，和入参的date相对应
    */
    @SerializedName("date")
    private String date;
    /**
    * 品牌侧订单ID文件下载链接，x天内下载有效
    */
    @SerializedName("fileUrl")
    private List<String> fileUrl;
    /**
    * 扩展字段
    */
    @SerializedName("resExt")
    private Map resExt;

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public List<String> getFileUrl() {
        return fileUrl;
    }
    public void setFileUrl(List<String> fileUrl) {
        this.fileUrl = fileUrl;
    }
    public Map getResExt() {
        return resExt;
    }
    public void setResExt(Map resExt) {
        this.resExt = resExt;
    }




    @Override
    public String toString() {
        return "DiancannewOrderQueryOrderDownloadUrlResponse{" + "date=" + date + "," + "fileUrl=" + fileUrl + "," + "resExt=" + resExt + "}";
    }
}
