package com.meituan.sdk.model.design.image.imageEnhanceNew;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 图像增强美化
* This file was automatically generated.
*/
@ApiMeta(
    path = "/design/image/image_enhance_new",
    businessId = 24,
    apiVersion = "10031",
    apiName = "image_enhance_new",
    needAuth = false
)
public class ImageEnhanceNewRequest implements MeituanRequest<ImageEnhanceNewResponse> {
    /**
    * <p data-diff-id="ct-diff-id-85c14fd0-1618-4649-bb72-e8f417c61884"><font style="font-size:14px;line-height:22px" data-size="14"><span style="color: rgba(0, 0, 0, 0.65)">图片格式：JPG(JPEG)，PNG 图片像素尺寸：最小48*48像素，最大4096*4096像素 图片文件大小：最大 10MB</span></font></p>
    */
    @NotBlank(message = "imageUrl不能为空")
    @SerializedName("image_url")
    private String imageUrl;

    public String getImageUrl() {
        return imageUrl;
    }
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }


    @Override
    public MeituanResponse<ImageEnhanceNewResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ImageEnhanceNewResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ImageEnhanceNewRequest{" + "imageUrl=" + imageUrl + "}";
    }
}
