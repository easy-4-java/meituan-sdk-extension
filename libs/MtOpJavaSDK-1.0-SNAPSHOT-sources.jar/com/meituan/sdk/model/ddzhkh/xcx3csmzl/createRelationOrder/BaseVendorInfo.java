package com.meituan.sdk.model.ddzhkh.xcx3csmzl.createRelationOrder;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-1d431775-70aa-4d7c-8a18-b3e7fddd0c20"><span style="color: rgba(0, 0, 0, 0.65)">三方商户订单信息</span></p>
* This file was automatically generated.
*/
public class BaseVendorInfo {
    /**
    * <p data-diff-id="ct-diff-id-e6f43e32-6661-41bb-9e71-f971231a6a16">三方商户订单号，每次调用下单均要变更</p>
    */
    @NotBlank(message = "vendorOrderId不能为空")
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * <p data-diff-id="ct-diff-id-324b3482-fbb5-427f-b670-f4f8fb007124">用户在三方商户侧的下单时间，毫秒时间戳</p>
    */
    @SerializedName("vendorOrderTime")
    private Long vendorOrderTime;
    /**
    * <p data-diff-id="ct-diff-id-65b2402e-2175-4023-a99a-4b15e7289eff">商户支付Id</p>
    */
    @NotBlank(message = "vendorPaymentId不能为空")
    @SerializedName("vendorPaymentId")
    private String vendorPaymentId;
    /**
    * <p data-diff-id="ct-diff-id-f74096c3-1dad-4488-b82d-7e6ce98d303e">三方透传自定义支付参数，支付结果通知三方时回传；长度限制2048</p>
    */
    @SerializedName("vendorPayInfo")
    private String vendorPayInfo;

    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public Long getVendorOrderTime() {
        return vendorOrderTime;
    }
    public void setVendorOrderTime(Long vendorOrderTime) {
        this.vendorOrderTime = vendorOrderTime;
    }
    public String getVendorPaymentId() {
        return vendorPaymentId;
    }
    public void setVendorPaymentId(String vendorPaymentId) {
        this.vendorPaymentId = vendorPaymentId;
    }
    public String getVendorPayInfo() {
        return vendorPayInfo;
    }
    public void setVendorPayInfo(String vendorPayInfo) {
        this.vendorPayInfo = vendorPayInfo;
    }




    @Override
    public String toString() {
        return "BaseVendorInfo{" + "vendorOrderId=" + vendorOrderId + "," + "vendorOrderTime=" + vendorOrderTime + "," + "vendorPaymentId=" + vendorPaymentId + "," + "vendorPayInfo=" + vendorPayInfo + "}";
    }
}
