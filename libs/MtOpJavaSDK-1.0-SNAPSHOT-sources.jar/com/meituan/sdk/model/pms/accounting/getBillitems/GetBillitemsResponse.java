package com.meituan.sdk.model.pms.accounting.getBillitems;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 获取账务明细
* This file was automatically generated.
*/
public class GetBillitemsResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    @SerializedName("data")
    private List<BillItemDTO> data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public List<BillItemDTO> getData() {
        return data;
    }
    public void setData(List<BillItemDTO> data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "GetBillitemsResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
