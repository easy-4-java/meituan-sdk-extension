package com.meituan.sdk.model.ddzh.yuding.bookUnreserveAddprice;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-a4009952-cc4f-4314-a73b-cde5c960c431">加价信息列表</p>
* This file was automatically generated.
*/
public class BalancePaymentDetailsDTO {
    /**
    * <p data-diff-id="ct-diff-id-d980f70e-0a7b-4b7a-9050-cfab85831de3">尾款明细项ID</p>
    */
    @NotNull(message = "id不能为空")
    @SerializedName("id")
    private Integer id;
    /**
    * <p data-diff-id="ct-diff-id-e9ca65a5-0014-46bc-a6e1-ee0f69745e0f">尾款明细项金额，单位：分。</p>
    */
    @NotNull(message = "unitPrice不能为空")
    @SerializedName("unitPrice")
    private Integer unitPrice;
    /**
    * <p data-diff-id="ct-diff-id-6c863521-086b-4083-8c24-cafa46544dde">数量</p>
    */
    @NotNull(message = "size不能为空")
    @SerializedName("size")
    private Integer size;
    /**
    * <p data-diff-id="ct-diff-id-2af922d0-ee3d-4b66-b0af-d3f0bc4bac41">是否上门费，1：是；2：否。</p>
    */
    @NotNull(message = "type不能为空")
    @SerializedName("type")
    private Integer type;

    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getUnitPrice() {
        return unitPrice;
    }
    public void setUnitPrice(Integer unitPrice) {
        this.unitPrice = unitPrice;
    }
    public Integer getSize() {
        return size;
    }
    public void setSize(Integer size) {
        this.size = size;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }




    @Override
    public String toString() {
        return "BalancePaymentDetailsDTO{" + "id=" + id + "," + "unitPrice=" + unitPrice + "," + "size=" + size + "," + "type=" + type + "}";
    }
}
