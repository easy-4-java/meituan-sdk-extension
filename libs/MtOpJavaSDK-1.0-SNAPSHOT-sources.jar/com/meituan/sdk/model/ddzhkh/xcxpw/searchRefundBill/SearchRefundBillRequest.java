package com.meituan.sdk.model.ddzhkh.xcxpw.searchRefundBill;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询退款账单
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/xcxpw/search_refund_bill",
    businessId = 59,
    apiVersion = "10027",
    apiName = "search_refund_bill",
    needAuth = true
)
public class SearchRefundBillRequest implements MeituanRequest<SearchRefundBillResponse> {
    @NotBlank(message = "generalBizData不能为空")
    @SerializedName("generalBizData")
    private String generalBizData;
    @NotNull(message = "searchBillReq不能为空")
    @SerializedName("searchBillReq")
    private QueryRefundReq searchBillReq;

    public String getGeneralBizData() {
        return generalBizData;
    }
    public void setGeneralBizData(String generalBizData) {
        this.generalBizData = generalBizData;
    }
    public QueryRefundReq getSearchBillReq() {
        return searchBillReq;
    }
    public void setSearchBillReq(QueryRefundReq searchBillReq) {
        this.searchBillReq = searchBillReq;
    }


    @Override
    public MeituanResponse<SearchRefundBillResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<SearchRefundBillResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "SearchRefundBillRequest{" + "generalBizData=" + generalBizData + "," + "searchBillReq=" + searchBillReq + "}";
    }
}
