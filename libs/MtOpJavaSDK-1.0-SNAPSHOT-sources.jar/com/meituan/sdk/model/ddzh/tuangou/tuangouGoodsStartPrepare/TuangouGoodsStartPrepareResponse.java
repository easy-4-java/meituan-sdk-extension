package com.meituan.sdk.model.ddzh.tuangou.tuangouGoodsStartPrepare;

import com.google.gson.annotations.SerializedName;

/**
* 团购商家开始备货
* This file was automatically generated.
*/
public class TuangouGoodsStartPrepareResponse {
    /**
    * true-成功，false失败
    */
    @SerializedName("result")
    private Boolean result;

    public Boolean getResult() {
        return result;
    }
    public void setResult(Boolean result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "TuangouGoodsStartPrepareResponse{" + "result=" + result + "}";
    }
}
