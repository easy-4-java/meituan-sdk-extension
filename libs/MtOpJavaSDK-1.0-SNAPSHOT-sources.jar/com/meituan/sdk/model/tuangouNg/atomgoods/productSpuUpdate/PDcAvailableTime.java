package com.meituan.sdk.model.tuangouNg.atomgoods.productSpuUpdate;

import java.util.List;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-f0b0042d-6e43-425d-ba5a-0ace26bbf75d">售卖时间，如果不写则代表没有限制</p>
* This file was automatically generated.
*/
public class PDcAvailableTime {
    /**
    * <p data-diff-id="ct-diff-id-d3d3a87b-e871-4996-aa64-31f6e2d247ff">周几</p>
    */
    @NotNull(message = "dayOfWeek不能为空")
    @SerializedName("dayOfWeek")
    private Integer dayOfWeek;
    /**
    * <p data-diff-id="ct-diff-id-3e675d74-dbbd-46c8-becc-41d7baa51005">可售卖时间范围，不能重叠</p><p data-diff-id="ct-diff-id-8996add5-7e6a-48d2-9cc1-616b77dccc83">(代表一天内的，如果是跨天请用两个PDcTimeRange对象)</p>
    */
    @NotEmpty(message = "range不能为空")
    @SerializedName("range")
    private List<PDcTimeRange> range;

    public Integer getDayOfWeek() {
        return dayOfWeek;
    }
    public void setDayOfWeek(Integer dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }
    public List<PDcTimeRange> getRange() {
        return range;
    }
    public void setRange(List<PDcTimeRange> range) {
        this.range = range;
    }




    @Override
    public String toString() {
        return "PDcAvailableTime{" + "dayOfWeek=" + dayOfWeek + "," + "range=" + range + "}";
    }
}
