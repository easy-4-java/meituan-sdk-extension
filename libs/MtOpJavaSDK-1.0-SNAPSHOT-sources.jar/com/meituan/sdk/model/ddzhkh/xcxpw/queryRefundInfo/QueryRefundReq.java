package com.meituan.sdk.model.ddzhkh.xcxpw.queryRefundInfo;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class QueryRefundReq {
    /**
    * <p data-diff-id="ct-diff-id-e65a1eab-89b5-4d64-afa7-278fd0484d50"><em><span style="color: rgba(0, 0, 0, 0.65)">美团订单号，与三方订单号二选一</span></em></p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-d9347d78-43af-4c8b-86e7-bd6b833e7486"><em><span style="color: rgba(0, 0, 0, 0.65)">三方订单号，与美团订单号二选一</span></em></p>
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * <p data-diff-id="ct-diff-id-098b5b23-31ab-41ad-a5e2-1dda6716799a">商户退款号</p>
    */
    @SerializedName("vendorRefundId")
    private String vendorRefundId;
    /**
    * <p data-diff-id="ct-diff-id-ad532f15-5d94-45b6-b2e0-91fb3077541d">美团退款单号</p>
    */
    @SerializedName("refundId")
    private String refundId;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public String getVendorRefundId() {
        return vendorRefundId;
    }
    public void setVendorRefundId(String vendorRefundId) {
        this.vendorRefundId = vendorRefundId;
    }
    public String getRefundId() {
        return refundId;
    }
    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }




    @Override
    public String toString() {
        return "QueryRefundReq{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "," + "vendorRefundId=" + vendorRefundId + "," + "refundId=" + refundId + "}";
    }
}
