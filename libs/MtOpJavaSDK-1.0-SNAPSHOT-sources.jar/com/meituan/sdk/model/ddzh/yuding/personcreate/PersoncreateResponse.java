package com.meituan.sdk.model.ddzh.yuding.personcreate;

import com.google.gson.annotations.SerializedName;

/**
* 创建服务人员
* This file was automatically generated.
*/
public class PersoncreateResponse {
    /**
    * 服务人员名称
    */
    @SerializedName("name")
    private String name;
    /**
    * 服务人员id
    */
    @SerializedName("serviceTechId")
    private Long serviceTechId;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Long getServiceTechId() {
        return serviceTechId;
    }
    public void setServiceTechId(Long serviceTechId) {
        this.serviceTechId = serviceTechId;
    }




    @Override
    public String toString() {
        return "PersoncreateResponse{" + "name=" + name + "," + "serviceTechId=" + serviceTechId + "}";
    }
}
