package com.meituan.sdk.model.resv2.table.tableDiningTimeUpdateNew;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-9e133e66-01e1-425a-81e8-945b673a3674"><span style="color: ">该维度的餐段配置信息</span></p>
* This file was automatically generated.
*/
public class PMealPeriodConfig {
    @SerializedName("regularPeriods")
    private List<PDayGroup> regularPeriods;
    @SerializedName("specialPeriods")
    private List<PSpecialTimeRange> specialPeriods;

    public List<PDayGroup> getRegularPeriods() {
        return regularPeriods;
    }
    public void setRegularPeriods(List<PDayGroup> regularPeriods) {
        this.regularPeriods = regularPeriods;
    }
    public List<PSpecialTimeRange> getSpecialPeriods() {
        return specialPeriods;
    }
    public void setSpecialPeriods(List<PSpecialTimeRange> specialPeriods) {
        this.specialPeriods = specialPeriods;
    }




    @Override
    public String toString() {
        return "PMealPeriodConfig{" + "regularPeriods=" + regularPeriods + "," + "specialPeriods=" + specialPeriods + "}";
    }
}
