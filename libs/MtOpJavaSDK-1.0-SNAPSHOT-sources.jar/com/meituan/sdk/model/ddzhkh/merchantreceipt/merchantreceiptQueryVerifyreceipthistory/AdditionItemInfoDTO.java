package com.meituan.sdk.model.ddzhkh.merchantreceipt.merchantreceiptQueryVerifyreceipthistory;

import com.google.gson.annotations.SerializedName;

/**
* 加项信息
* This file was automatically generated.
*/
public class AdditionItemInfoDTO {
    /**
    * 服务名
    */
    @SerializedName("serviceTitle")
    private String serviceTitle;
    /**
    * 调价规则当前金额(当前金额，单位：元)
    */
    @SerializedName("adjustedAmount")
    private String adjustedAmount;
    /**
    * 加项商品id
    */
    @SerializedName("productId")
    private String productId;
    /**
    * 三方加项商品id
    */
    @SerializedName("addItemThirdPartyId")
    private String addItemThirdPartyId;

    public String getServiceTitle() {
        return serviceTitle;
    }
    public void setServiceTitle(String serviceTitle) {
        this.serviceTitle = serviceTitle;
    }
    public String getAdjustedAmount() {
        return adjustedAmount;
    }
    public void setAdjustedAmount(String adjustedAmount) {
        this.adjustedAmount = adjustedAmount;
    }
    public String getProductId() {
        return productId;
    }
    public void setProductId(String productId) {
        this.productId = productId;
    }
    public String getAddItemThirdPartyId() {
        return addItemThirdPartyId;
    }
    public void setAddItemThirdPartyId(String addItemThirdPartyId) {
        this.addItemThirdPartyId = addItemThirdPartyId;
    }




    @Override
    public String toString() {
        return "AdditionItemInfoDTO{" + "serviceTitle=" + serviceTitle + "," + "adjustedAmount=" + adjustedAmount + "," + "productId=" + productId + "," + "addItemThirdPartyId=" + addItemThirdPartyId + "}";
    }
}
