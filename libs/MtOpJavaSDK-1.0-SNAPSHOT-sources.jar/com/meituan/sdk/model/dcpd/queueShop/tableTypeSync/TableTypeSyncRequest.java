package com.meituan.sdk.model.dcpd.queueShop.tableTypeSync;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 同步全量桌型
* This file was automatically generated.
*/
@ApiMeta(
    path = "/dcpd/queue/shop/config/tableType/sync",
    businessId = 49,
    apiVersion = "10000",
    apiName = "table_type_sync",
    needAuth = true
)
public class TableTypeSyncRequest implements MeituanRequest<Boolean> {
    /**
    * <p data-diff-id="ct-diff-id-fa400b1f-b075-4078-a599-eb3a81143617">操作时间，单位毫秒</p>
    */
    @SerializedName("operateTime")
    private Long operateTime;
    /**
    * <p data-diff-id="ct-diff-id-4b0370a4-5acb-48fd-bfdb-7cde800856d1">桌型列表</p>
    */
    @SerializedName("tableTypeList")
    private List<TableTypeDTO> tableTypeList;

    public Long getOperateTime() {
        return operateTime;
    }
    public void setOperateTime(Long operateTime) {
        this.operateTime = operateTime;
    }
    public List<TableTypeDTO> getTableTypeList() {
        return tableTypeList;
    }
    public void setTableTypeList(List<TableTypeDTO> tableTypeList) {
        this.tableTypeList = tableTypeList;
    }


    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TableTypeSyncRequest{" + "operateTime=" + operateTime + "," + "tableTypeList=" + tableTypeList + "}";
    }
}
