package com.meituan.sdk.model.ddzh.yuding.updateorderfulfillinfo;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 更新订单履约信息
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/updateorderfulfillinfo",
    businessId = 58,
    apiVersion = "10053",
    apiName = "updateorderfulfillinfo",
    needAuth = true
)
public class UpdateorderfulfillinfoRequest implements MeituanRequest<UpdateorderfulfillinfoResponse> {
    /**
    * <p data-diff-id="ct-diff-id-3d84d5aa-3307-465f-8e3e-fe209bcc0fc7"><span style="color: rgb(31, 45, 61)">订单id &nbsp; &nbsp;&nbsp;</span></p>
    */
    @NotBlank(message = "orderId不能为空")
    @SerializedName("orderId")
    private String orderId;
    /**
    * <p data-diff-id="ct-diff-id-d77e0341-dc2b-4a2b-aa58-90ed4649ca42"><span style="color: rgb(31, 45, 61)">扩展信息 &nbsp; &nbsp; &nbsp; &nbsp;</span></p>
    */
    @NotBlank(message = "attrKeyValue不能为空")
    @SerializedName("attrKeyValue")
    private String attrKeyValue;
    /**
    * <p data-diff-id="ct-diff-id-7c7acd5f-2548-4cab-a00d-616f0acd092a">生活服务行业新增字段，其他行业不传。交易类型，枚举值：1-预订，2-团单（团购后预约），商家根据此属性字段识别交易类型，预订业务该字段非必传，团购后预约业务必传&nbsp;</p>
    */
    @SerializedName("type")
    private Integer type;
    /**
    * <p data-diff-id="ct-diff-id-96bda3fb-218e-4ec1-bb03-58a6ac682d2c"><span style="color: rgb(31, 45, 61)">履约状态：</span><br><span style="color: rgb(31, 45, 61)">已分配（通用）：40001&nbsp;</span><br><span style="color: rgb(31, 45, 61)">已取件（洗衣）：40101&nbsp;</span><br><span style="color: rgb(31, 45, 61)">已到达（通用）：40002 &nbsp;</span><br><span style="color: rgb(31, 45, 61)">清洗中（洗衣）：41101 &nbsp;</span><br><span style="color: rgb(31, 45, 61)">返回中（洗衣）：41102 &nbsp;</span><br><span style="color: rgb(31, 45, 61)">履约完成（通用）：41001 &nbsp;</span></p>
    */
    @NotNull(message = "orderFulfillStatus不能为空")
    @SerializedName("orderFulfillStatus")
    private Integer orderFulfillStatus;

    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public String getAttrKeyValue() {
        return attrKeyValue;
    }
    public void setAttrKeyValue(String attrKeyValue) {
        this.attrKeyValue = attrKeyValue;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getOrderFulfillStatus() {
        return orderFulfillStatus;
    }
    public void setOrderFulfillStatus(Integer orderFulfillStatus) {
        this.orderFulfillStatus = orderFulfillStatus;
    }


    @Override
    public MeituanResponse<UpdateorderfulfillinfoResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<UpdateorderfulfillinfoResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "UpdateorderfulfillinfoRequest{" + "orderId=" + orderId + "," + "attrKeyValue=" + attrKeyValue + "," + "type=" + type + "," + "orderFulfillStatus=" + orderFulfillStatus + "}";
    }
}
