package com.meituan.sdk.model.waimaiNg.order.queryZbCancelDeliveryReason;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取订单可以取消跑腿的原因
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/order/queryZbCancelDeliveryReason",
    businessId = 2,
    apiVersion = "10154",
    apiName = "query_zb_cancel_delivery_reason",
    needAuth = true
)
public class QueryZbCancelDeliveryReasonRequest implements MeituanRequest<QueryZbCancelDeliveryReasonResponse> {
    /**
    * <p><span style="color: rgba(0, 0, 0, 0.87)"><font style="font-size:14px;line-height:22px" data-size="14">订单号</font></span></p>
    */
    @SerializedName("orderId")
    private String orderId;
    /**
    * <p data-diff-id="ct-diff-id-39d19cef-cc99-430d-8ebf-bc47ca7ff787">订单来源 0 无来源 1 美团 2 饿了么 3 百度 4 其他 5京东到家 6 青云自建订单 7歪马微商城，升级到支持非美团订单接口协议后必填</p>
    */
    @SerializedName("orderSource")
    private Integer orderSource;
    /**
    * <p data-diff-id="ct-diff-id-548a9ca2-148c-4d64-9754-05c9142fe625">三方订单号，必填</p>
    */
    @SerializedName("thirdOrderId")
    private String thirdOrderId;
    /**
    * <p data-diff-id="ct-diff-id-0abb4548-7146-4752-947b-6fc2e9168b7d">门店授权token</p>
    */
    @SerializedName("psAuthorizeToken")
    private String psAuthorizeToken;

    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public Integer getOrderSource() {
        return orderSource;
    }
    public void setOrderSource(Integer orderSource) {
        this.orderSource = orderSource;
    }
    public String getThirdOrderId() {
        return thirdOrderId;
    }
    public void setThirdOrderId(String thirdOrderId) {
        this.thirdOrderId = thirdOrderId;
    }
    public String getPsAuthorizeToken() {
        return psAuthorizeToken;
    }
    public void setPsAuthorizeToken(String psAuthorizeToken) {
        this.psAuthorizeToken = psAuthorizeToken;
    }


    @Override
    public MeituanResponse<QueryZbCancelDeliveryReasonResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<QueryZbCancelDeliveryReasonResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "QueryZbCancelDeliveryReasonRequest{" + "orderId=" + orderId + "," + "orderSource=" + orderSource + "," + "thirdOrderId=" + thirdOrderId + "," + "psAuthorizeToken=" + psAuthorizeToken + "}";
    }
}
