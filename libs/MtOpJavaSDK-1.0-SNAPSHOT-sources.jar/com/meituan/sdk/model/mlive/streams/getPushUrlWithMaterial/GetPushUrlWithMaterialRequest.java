package com.meituan.sdk.model.mlive.streams.getPushUrlWithMaterial;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 用直播物料获取推流地址
* This file was automatically generated.
*/
@ApiMeta(
    path = "/mlive/streams/getPushUrlWithLiveMaterial",
    businessId = 50,
    apiVersion = "10010",
    apiName = "get_push_url_with_material",
    needAuth = true
)
public class GetPushUrlWithMaterialRequest implements MeituanRequest<List<LiveStreamDTO>> {
    /**
    * <p data-diff-id="ct-diff-id-a817bbbf-1a80-4a1e-98fa-d8ad22fae6e3"><span style="color: ">必传，直播推流相关参数</span></p>
    */
    @SerializedName("streamParam")
    private StreamParam streamParam;
    /**
    * <p data-diff-id="ct-diff-id-7da322cf-bbd4-4d75-9414-861baf9c0d09">直播物料。</p><p data-diff-id="ct-diff-id-3ac2f8bb-b6e1-456f-bf3d-032cfefc7e20">同一个liveid首次必传，重复获取推流地址时，非必传</p>
    */
    @SerializedName("liveMateria")
    private LiveMateria liveMateria;
    /**
    * <p data-diff-id="ct-diff-id-931e85f7-2a5d-4a08-863b-ebedb5343ad1"><span style="color: ">必传，直播id</span></p>
    */
    @SerializedName("liveId")
    private Long liveId;

    public StreamParam getStreamParam() {
        return streamParam;
    }
    public void setStreamParam(StreamParam streamParam) {
        this.streamParam = streamParam;
    }
    public LiveMateria getLiveMateria() {
        return liveMateria;
    }
    public void setLiveMateria(LiveMateria liveMateria) {
        this.liveMateria = liveMateria;
    }
    public Long getLiveId() {
        return liveId;
    }
    public void setLiveId(Long liveId) {
        this.liveId = liveId;
    }


    @Override
    public MeituanResponse<List<LiveStreamDTO>> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<List<LiveStreamDTO>>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GetPushUrlWithMaterialRequest{" + "streamParam=" + streamParam + "," + "liveMateria=" + liveMateria + "," + "liveId=" + liveId + "}";
    }
}
