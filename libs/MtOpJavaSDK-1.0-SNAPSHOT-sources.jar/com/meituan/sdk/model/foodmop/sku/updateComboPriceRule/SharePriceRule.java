package com.meituan.sdk.model.foodmop.sku.updateComboPriceRule;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-456e446d-fdb8-43c8-b950-d026997f2e96"><span style="color: rgb(102, 102, 102)">分摊规则</span></p>
* This file was automatically generated.
*/
public class SharePriceRule {
    /**
    * <p data-diff-id="ct-diff-id-c908a04b-6314-44c1-9a16-909abec8aa9a"><span style="color: rgb(102, 102, 102)">分摊规则： 2001 - 根据商品原价分摊，无需content</span></p>
    */
    @NotNull(message = "type不能为空")
    @SerializedName("type")
    private Integer type;
    /**
    * <p data-diff-id="ct-diff-id-c5e464fd-510d-446c-a677-ac6257776c0e"><span style="color: rgb(102, 102, 102)">规则内容</span></p>
    */
    @NotBlank(message = "value不能为空")
    @SerializedName("value")
    private String value;

    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }




    @Override
    public String toString() {
        return "SharePriceRule{" + "type=" + type + "," + "value=" + value + "}";
    }
}
