package com.meituan.sdk.model.pms.data.queryJy08;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* JY08报表接口
* This file was automatically generated.
*/
public class QueryJy08Response {
    @SerializedName("summaryDetailList")
    private List<TJYSummaryDTO> summaryDetailList;
    @SerializedName("customerCategoryList")
    private List<TJYDimensionDTO> customerCategoryList;
    @SerializedName("checkinTypeList")
    private List<TJYDimensionDTO> checkinTypeList;
    @SerializedName("orderSourceList")
    private List<TJYDimensionDTO> orderSourceList;
    @SerializedName("roomTypeList")
    private List<TJYDimensionDTO> roomTypeList;
    @SerializedName("channelList")
    private List<TJYDimensionDTO> channelList;

    public List<TJYSummaryDTO> getSummaryDetailList() {
        return summaryDetailList;
    }
    public void setSummaryDetailList(List<TJYSummaryDTO> summaryDetailList) {
        this.summaryDetailList = summaryDetailList;
    }
    public List<TJYDimensionDTO> getCustomerCategoryList() {
        return customerCategoryList;
    }
    public void setCustomerCategoryList(List<TJYDimensionDTO> customerCategoryList) {
        this.customerCategoryList = customerCategoryList;
    }
    public List<TJYDimensionDTO> getCheckinTypeList() {
        return checkinTypeList;
    }
    public void setCheckinTypeList(List<TJYDimensionDTO> checkinTypeList) {
        this.checkinTypeList = checkinTypeList;
    }
    public List<TJYDimensionDTO> getOrderSourceList() {
        return orderSourceList;
    }
    public void setOrderSourceList(List<TJYDimensionDTO> orderSourceList) {
        this.orderSourceList = orderSourceList;
    }
    public List<TJYDimensionDTO> getRoomTypeList() {
        return roomTypeList;
    }
    public void setRoomTypeList(List<TJYDimensionDTO> roomTypeList) {
        this.roomTypeList = roomTypeList;
    }
    public List<TJYDimensionDTO> getChannelList() {
        return channelList;
    }
    public void setChannelList(List<TJYDimensionDTO> channelList) {
        this.channelList = channelList;
    }




    @Override
    public String toString() {
        return "QueryJy08Response{" + "summaryDetailList=" + summaryDetailList + "," + "customerCategoryList=" + customerCategoryList + "," + "checkinTypeList=" + checkinTypeList + "," + "orderSourceList=" + orderSourceList + "," + "roomTypeList=" + roomTypeList + "," + "channelList=" + channelList + "}";
    }
}
