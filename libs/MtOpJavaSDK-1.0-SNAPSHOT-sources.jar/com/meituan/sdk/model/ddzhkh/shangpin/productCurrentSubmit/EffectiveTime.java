package com.meituan.sdk.model.ddzhkh.shangpin.productCurrentSubmit;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-4742d4d0-5760-4c8b-ae66-11fe678d9618"><span style="color: ">有效时间</span></p>
* This file was automatically generated.
*/
public class EffectiveTime {
    /**
    * <p data-diff-id="ct-diff-id-a1b335b6-6ab7-4c43-a96d-54a2ccbc43b2">有效开始时间，yyyy-MM-dd（<span style="color: rgb(245, 34, 45)">effectiveTimeType为0 时必填</span>）</p>
    */
    @SerializedName("effectiveStartTime")
    private String effectiveStartTime;
    /**
    * <p data-diff-id="ct-diff-id-1410ee1d-2398-483e-b6d3-bcb3247dd234">有效时间类型，0-固定effectiveStartTime~effectiveEndTime内有效 1-下单后effectiveDays天内有效</p>
    */
    @NotNull(message = "effectiveTimeType不能为空")
    @SerializedName("effectiveTimeType")
    private Integer effectiveTimeType;
    /**
    * <p data-diff-id="ct-diff-id-2270957c-4a6c-410d-b433-e978dc467f07"><span style="color: ">有效天数</span></p>
    */
    @SerializedName("effectiveDays")
    private Integer effectiveDays;
    /**
    * <p data-diff-id="ct-diff-id-b63cc720-9cbb-44b0-b5f9-feeb2082e02d">有效结束时间，yyyy-MM-dd，（<span style="color: rgb(245, 34, 45)">effectiveTimeType为0 时必填</span>）</p>
    */
    @SerializedName("effectiveEndTime")
    private String effectiveEndTime;

    public String getEffectiveStartTime() {
        return effectiveStartTime;
    }
    public void setEffectiveStartTime(String effectiveStartTime) {
        this.effectiveStartTime = effectiveStartTime;
    }
    public Integer getEffectiveTimeType() {
        return effectiveTimeType;
    }
    public void setEffectiveTimeType(Integer effectiveTimeType) {
        this.effectiveTimeType = effectiveTimeType;
    }
    public Integer getEffectiveDays() {
        return effectiveDays;
    }
    public void setEffectiveDays(Integer effectiveDays) {
        this.effectiveDays = effectiveDays;
    }
    public String getEffectiveEndTime() {
        return effectiveEndTime;
    }
    public void setEffectiveEndTime(String effectiveEndTime) {
        this.effectiveEndTime = effectiveEndTime;
    }




    @Override
    public String toString() {
        return "EffectiveTime{" + "effectiveStartTime=" + effectiveStartTime + "," + "effectiveTimeType=" + effectiveTimeType + "," + "effectiveDays=" + effectiveDays + "," + "effectiveEndTime=" + effectiveEndTime + "}";
    }
}
