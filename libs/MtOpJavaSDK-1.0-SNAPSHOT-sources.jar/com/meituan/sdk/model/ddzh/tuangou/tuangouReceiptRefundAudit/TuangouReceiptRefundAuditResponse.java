package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptRefundAudit;

import com.google.gson.annotations.SerializedName;

/**
* 团购退款审核
* This file was automatically generated.
*/
public class TuangouReceiptRefundAuditResponse {
    @SerializedName("result")
    private RMerchantRefundAudit result;

    public RMerchantRefundAudit getResult() {
        return result;
    }
    public void setResult(RMerchantRefundAudit result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "TuangouReceiptRefundAuditResponse{" + "result=" + result + "}";
    }
}
