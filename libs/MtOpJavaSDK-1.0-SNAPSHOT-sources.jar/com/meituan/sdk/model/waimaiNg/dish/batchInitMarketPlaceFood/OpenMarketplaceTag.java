package com.meituan.sdk.model.waimaiNg.dish.batchInitMarketPlaceFood;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-e05b0b24-440c-41ce-bbc1-e5348545eb5c">菜品分类</p>
* This file was automatically generated.
*/
public class OpenMarketplaceTag {
    /**
    * <p data-diff-id="ct-diff-id-02bb6cd4-d281-4318-8fa8-888fe6964e95"><span style="color: ">分类名称</span></p>
    */
    @NotBlank(message = "tagName不能为空")
    @SerializedName("tagName")
    private String tagName;
    /**
    * <p data-diff-id="ct-diff-id-45766103-783e-4126-8d41-0d3048faa81f">tag类型（本次需求只能传 0）</p><p data-diff-id="ct-diff-id-45f9e25b-bfc7-474d-a5db-f4235615e8a1">0.跟随必选分类下单 1.必选分类 2.可单独下单</p>
    */
    @NotBlank(message = "type不能为空")
    @SerializedName("type")
    private String type;
    /**
    * <p data-diff-id="ct-diff-id-4a027821-fe94-47ab-933a-89fb08640e46">售卖场景</p><p data-diff-id="ct-diff-id-e1bafd07-7e6c-472c-ae5e-b73088af0354">0.默认使用主站分组 1.创建场域分组（二期支持）</p>
    */
    @NotNull(message = "sellSceneType不能为空")
    @SerializedName("sellSceneType")
    private Integer sellSceneType;

    public String getTagName() {
        return tagName;
    }
    public void setTagName(String tagName) {
        this.tagName = tagName;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public Integer getSellSceneType() {
        return sellSceneType;
    }
    public void setSellSceneType(Integer sellSceneType) {
        this.sellSceneType = sellSceneType;
    }




    @Override
    public String toString() {
        return "OpenMarketplaceTag{" + "tagName=" + tagName + "," + "type=" + type + "," + "sellSceneType=" + sellSceneType + "}";
    }
}
