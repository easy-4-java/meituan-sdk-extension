package com.meituan.sdk.model.resv2.table.tablestatusUpdate;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 预订更新桌台使用状态(最新)
* This file was automatically generated.
*/
@ApiMeta(
    path = "/resv2/table/status/upload",
    businessId = 7,
    apiVersion = "10024",
    apiName = "tablestatus_update",
    needAuth = true
)
public class TablestatusUpdateRequest implements MeituanRequest<TablestatusUpdateResponse> {
    /**
    * <p data-diff-id="ct-diff-id-8f11ee3b-6a04-40f5-ab60-ad1c8f0576df"><span style="color: ">桌台列表</span></p>
    */
    @NotEmpty(message = "tableStatusList不能为空")
    @SerializedName("tableStatusList")
    private List<PFdcTableStatus> tableStatusList;

    public List<PFdcTableStatus> getTableStatusList() {
        return tableStatusList;
    }
    public void setTableStatusList(List<PFdcTableStatus> tableStatusList) {
        this.tableStatusList = tableStatusList;
    }


    @Override
    public MeituanResponse<TablestatusUpdateResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<TablestatusUpdateResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TablestatusUpdateRequest{" + "tableStatusList=" + tableStatusList + "}";
    }
}
