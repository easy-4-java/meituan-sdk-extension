package com.meituan.sdk.model.waimaiNg.dish.dishQueryListByEpoiid;

import com.google.gson.annotations.SerializedName;

/**
* 小料信息
* This file was automatically generated.
*/
public class OpenTopping {
    /**
    * 小料名称
    */
    @SerializedName("name")
    private String name;
    /**
    * 小料code
    */
    @SerializedName("toppingCode")
    private String toppingCode;
    /**
    * 小料偏移id
    */
    @SerializedName("mtToppingId")
    private Long mtToppingId;
    /**
    * 价格，最多两位小数
    */
    @SerializedName("price")
    private String price;
    /**
    * 最大库存
    */
    @SerializedName("maxStock")
    private Integer maxStock;
    /**
    * 当前库存  -1代表无限库存
    */
    @SerializedName("stock")
    private Integer stock;
    /**
    * 是否自动补足  该字段只能填写0、1，默认为0   0-不开启，1-开启
    */
    @SerializedName("autoRefresh")
    private Integer autoRefresh;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getToppingCode() {
        return toppingCode;
    }
    public void setToppingCode(String toppingCode) {
        this.toppingCode = toppingCode;
    }
    public Long getMtToppingId() {
        return mtToppingId;
    }
    public void setMtToppingId(Long mtToppingId) {
        this.mtToppingId = mtToppingId;
    }
    public String getPrice() {
        return price;
    }
    public void setPrice(String price) {
        this.price = price;
    }
    public Integer getMaxStock() {
        return maxStock;
    }
    public void setMaxStock(Integer maxStock) {
        this.maxStock = maxStock;
    }
    public Integer getStock() {
        return stock;
    }
    public void setStock(Integer stock) {
        this.stock = stock;
    }
    public Integer getAutoRefresh() {
        return autoRefresh;
    }
    public void setAutoRefresh(Integer autoRefresh) {
        this.autoRefresh = autoRefresh;
    }




    @Override
    public String toString() {
        return "OpenTopping{" + "name=" + name + "," + "toppingCode=" + toppingCode + "," + "mtToppingId=" + mtToppingId + "," + "price=" + price + "," + "maxStock=" + maxStock + "," + "stock=" + stock + "," + "autoRefresh=" + autoRefresh + "}";
    }
}
