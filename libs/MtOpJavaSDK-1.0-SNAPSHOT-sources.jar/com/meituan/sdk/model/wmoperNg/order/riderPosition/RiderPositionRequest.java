package com.meituan.sdk.model.wmoperNg.order.riderPosition;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 自配订单同步配送信息
* This file was automatically generated.
*/
@ApiMeta(
    path = "/wmoper/ng/order/riderPosition",
    businessId = 16,
    apiVersion = "10095",
    apiName = "rider_position",
    needAuth = true
)
public class RiderPositionRequest implements MeituanRequest<String> {
    /**
    * <p>订单号</p>
    */
    @NotNull(message = "orderId不能为空")
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p>第三方配送商物流单号，字段不为空时长度必须小于32位</p>
    */
    @SerializedName("thirdCarrierId")
    private String thirdCarrierId;
    /**
    * <p><span style="color: rgba(0, 0, 0, 0.87)"><font style="font-size:14px;line-height:22px" data-size="14">code 说明 0 配送单发往配送 10 配送单已确认 15 骑手已到店 20 骑手已取餐 40 骑手已送达 100 配送单已取消</font></span></p>
    */
    @NotNull(message = "logisticsStatus不能为空")
    @SerializedName("logisticsStatus")
    private Integer logisticsStatus;
    /**
    * <p><span style="color: rgba(0, 0, 0, 0.87)"><font style="font-size:14px;line-height:22px" data-size="14">配送人名称</font></span></p>
    */
    @NotBlank(message = "courierName不能为空")
    @SerializedName("courierName")
    private String courierName;
    /**
    * <p><span style="color: rgb(88, 90, 110)"><font style="font-size:14px;line-height:22px" data-size="14">配送员联系电话。 格式为纯数字，仅支持11位手机号、固定电话、400电话、用“#”“_”“,”拼接分机号的电话</font></span></p>
    */
    @NotBlank(message = "courierPhone不能为空")
    @SerializedName("courierPhone")
    private String courierPhone;
    /**
    * <p data-diff-id="ct-diff-id-faf551c1-f421-40bc-a418-2a4fb6409970"><span style="color: #333">第三方配送方式（配送code：配送方）</span></p><p data-diff-id="ct-diff-id-05e3c6b1-2fde-4fd9-b1e0-6f684a615279"><span style="color: #333">10001：顺丰同城<br>10002：达达<br>10003：闪送<br>10004：蜂鸟<br>10005：UU跑腿<br>10006：快跑者<br>10007：极客快送<br>10008：点我达<br>10009：同达<br>10010：生活半径<br>10011：邻趣<br>10012：趣送<br>10013：快服务<br>10014：菜鸟新配盟<br>10015：商家自建配送<br>10016：风先生<br>10017：其他<br>10018：美团配送<br>10019：来答配送<br>10020：好急跑腿<br>10021：送个东西<br>10022：靠谱送<br>10023：快男跑腿<br>10024：曹操跑腿<br>10025：爱跑腿<br>10026：裹小递<br>10027：抖送<br>10028：行优达<br>10029：新闪送<br>10031：帮啦<br>10033：大有配送<br>10035：哪都达<br>10038：开始送<br>10040：懒猪快送<br>10041：上海食派士商贸发展有限公司<br>10042：快狗打车<br>10043：超跑同城<br>10044：365跑腿网<br>10045：骑帮闪送<br>10046：一步同城<br>10047：跑腿联盟<br>10048：悟空快跑<br>10049：送小闲<br>10050：曹操送<br>10051：货拉拉企业版<br>10052：大圣急送<br>10053：趣来达<br>10054：梁跑跑<br>10055：蜂骑快送<br>10056：滴滴货运<br>10057：中里办<br>10058：云小跑<br>10059：小U急送<br>10060：腿腿骑行配送<br>10061：校内专送<br>10062：闪跑侠<br>10063：校园外卖购<br>10064：同城懒人<br>10065：快达<br>10067：单满多<br>10068：逸猫快送<br>10069：快驼<br>10070：微顶跑腿<br>10071：荣宸快送<br>10072：金骑配送<br>10073：代帮跑腿<br>10074：来啦跑腿<br>10075：小羚配送<br>10076：必宿校园<br>10077：荣帮<br>10078：同用跑腿<br>10079：迅达配送<br>10080：兰陵跑腿<br>10081：麻利跑腿<br>10082：温代配送<br>10083：响送全成<br>10111：DD骑士<br>10084：乐外卖<br>10085：闪急送<br>10086：黑骑配送<br>10087：神兵跑腿<br>10089：丰和同城<br>10090：超风速送<br>10091：上铺闪电侠<br>10092：呼拉跑腿<br>10093：微刷快点<br>10094：云快卖<br>10113：八戒跑腿<br>10095：思雨同城急送<br>10114：滴滴快送<br>10096：25度<br>10115：秒先锋<br>10097：信速达<br>10098：送道<br>10099：东海速送<br>10117：叮当同城配送<br>10100：送大侠<br>10101：轻云送<br>10102：送佳<br>10103：四海达<br>10118：大帝同城<br>10119：一点即达<br>10120：星途配送<br>10104：达先蜂<br>10105：快马跑腿<br>10106：百业达人汇<br>10107：0851跑腿<br>10121：交点配送<br>10108：珠海递时代<br>10123：邦邦马<br>10124：一点宿达<br>10125：兔哆邦<br>10126：涛诚快送<br>10127：C单小队<br>10128：坚裹帮<br>10129：送来达<br>10130：美团汽车送<br>10131：及跑跑<br>10132：速送<br>10133：稳达在线<br>10134：大风配送<br>10135：翔豪同城配送<br>10136：闪泉跑腿<br>10137：镖统<br>10138：跑跑快送<br>10139：星橙送<br>10140：呼呼代跑<br>10141：冲冲冲超级送<br>10142：鲁邮同城<br>10143：圣骑配送<br>10144：FD配送<br>10145：长鹿跑腿<br>10146：聚城达<br>10147：来云台<br>10148：达斯罕跑腿<br>10149：洪洪送<br>10150：货拉拉</span></p><p data-diff-id="ct-diff-id-3cfa5909-dade-4e0b-8155-0109502d37fb"><span style="color: #333">10151：先锋配送</span></p><p data-diff-id="ct-diff-id-b01f511a-2c03-46a0-809f-5434116035fe"><span style="color: #333">10152：图鲲即配</span></p><p data-diff-id="ct-diff-id-e99368b6-5d2e-4d6d-b07a-8e3ecb2542b9"><span style="color: #333">10153：腿腿快送</span></p><p data-diff-id="ct-diff-id-24c38f74-829b-483a-830a-a50499aeebed"><span style="color: #333">10154：TT跑腿</span></p><p data-diff-id="ct-diff-id-3837c55f-5b07-4b2c-890b-c127588681cf"><span style="color: #333">10155：极速跑腿</span></p><p data-diff-id="ct-diff-id-ff7c9156-37e2-4394-b833-0f74f9d789ad"><span style="color: #333">10156：零晨配送</span></p><p data-diff-id="ct-diff-id-f4ce920c-b977-46d8-bc92-99b3a30724d0"><span style="color: #333">10157：吉送配送</span></p><p data-diff-id="ct-diff-id-9a5cf811-18e2-4293-89a8-af12bdb370fd"><span style="color: #333">10158：哈啰送货</span></p><p data-diff-id="ct-diff-id-28adf578-6434-4ebb-a591-90cd4db28dbc"><span style="color: #333">10159：飞鸟即配</span></p><p data-diff-id="ct-diff-id-5ab33923-09f3-4cd3-9c3f-a5edbbceae55"><span style="color: #333">10160：小优急送</span></p><p data-diff-id="ct-diff-id-d4e1456e-91c5-48ae-b9af-ee0834496fee"><span style="color: #333">10161：普惠快送</span></p><p data-diff-id="ct-diff-id-9f44cc13-a678-4237-96ef-a667719f8d63"><span style="color: #333">10162：运立宝同城</span></p><p data-diff-id="ct-diff-id-f85f8b81-8985-4413-b67e-7a9feaecc426"><span style="color: #333">10163：骑送侠</span></p><p data-diff-id="ct-diff-id-b7f86d2e-290e-4f0d-9664-e97b30097371"><span style="color: #333">10164：影悦网络</span></p><p data-diff-id="ct-diff-id-77297a41-8bf3-4d8d-a706-f28d6c06e955"><span style="color: #333">10165：众邦跑腿</span></p><p data-diff-id="ct-diff-id-3f1fe591-6665-47e3-bb95-df2dbdea9769"><span style="color: #333">10166：快送汇</span></p><p data-diff-id="ct-diff-id-0790654c-4fab-4c01-8a62-7fcc159b3749"><span style="color: #333">10167：秒秒达</span></p><p data-diff-id="ct-diff-id-c060cba4-cd2d-4c65-bcbe-26ecd5e66a40"><span style="color: #333">10168：速闪蜂</span></p><p data-diff-id="ct-diff-id-25ff3a5e-31cf-47f6-912d-782fd8b5b437"><span style="color: #333">10169：羊村便利宝</span></p><p data-diff-id="ct-diff-id-8901ada3-017c-47df-85a6-00737ea73868"><span style="color: #333">10170：骑顺达</span></p><p data-diff-id="ct-diff-id-cd3df88e-49fd-405e-83cb-de3ed0f5caa1"><span style="color: #333">10171：惠顺达跑腿</span></p><p data-diff-id="ct-diff-id-38837599-2d00-4831-8a8b-b46a5a9ec194"><span style="color: #333">10172：依心跑腿</span></p><p data-diff-id="ct-diff-id-7bb5a73d-5e68-488d-9718-bcd641b3e7c0"><span style="color: #333">10173：新邦同城</span></p><p data-diff-id="ct-diff-id-dff09f7f-d8de-4a8e-ac5e-d3b5a5fdb75a"><span style="color: #333">10174：嘎嘎快</span></p><p data-diff-id="ct-diff-id-de4ac04f-c363-48eb-8cbc-2cda53b73041"><span style="color: #333">10175：同城运力</span></p><p data-diff-id="ct-diff-id-0878bd03-3a81-41b5-a68c-119f2f32fc77"><span style="color: #333">10176：青春飞骑</span></p><p data-diff-id="ct-diff-id-5718d44a-4e1f-4706-a3c2-b27ad643f31c"><span style="color: #333">10177：异路同城</span></p><p data-diff-id="ct-diff-id-82016db9-8c5e-4a14-ba0f-634638a97752"><span style="color: #333">10178：鹿诚生活</span></p><p data-diff-id="ct-diff-id-b003a620-786a-453a-8b67-8c55298a3ece"><span style="color: #333">10179：闪现秒送</span></p><p data-diff-id="ct-diff-id-8066a6f9-9861-46fa-adc7-0d1794563029"><span style="color: #333">10180：飞鸟速达</span></p><p data-diff-id="ct-diff-id-76924334-872a-4ccc-91e0-bb0e29e8fe79"><span style="color: #333">10181:美饿达</span></p><p data-diff-id="ct-diff-id-bd7299df-d457-4060-a34c-bb59a372904c"><span style="color: #333">10182:省点送</span></p><p data-diff-id="ct-diff-id-07cf52df-56e3-4c5f-8f19-2d8a4e97c9f9"><span style="color: #333">10183:蕉互急速达</span></p><p data-diff-id="ct-diff-id-d03072a4-599b-4860-a649-c9ef969df660"><span style="color: #333">10184:一城飞客</span></p><p data-diff-id="ct-diff-id-249e9c89-d6ca-4f35-a085-3b2115366cc8"><span style="color: #333">10185:小邮快跑</span></p><p data-diff-id="ct-diff-id-3a5e7a23-d158-491f-bbed-390c5e42929e"><span style="color: #333">10186:跑腿快车</span></p><p data-diff-id="ct-diff-id-0135b854-f510-40de-85d4-6ed11bb1e415"><span style="color: #333">10187:韩跑跑</span></p><p data-diff-id="ct-diff-id-5d786650-b736-49f4-998d-e63f0bf24e37"><span style="color: #333">10188:莞聚跑腿</span></p><p data-diff-id="ct-diff-id-279e380b-e77c-478e-b848-ed99df3eebc4"><span style="color: #333">10189:裹裹科技</span></p><p data-diff-id="ct-diff-id-9c4c8ae4-403d-4a64-9fdb-6ba41b914de9"><span style="color: #333">10190:安克弗跑腿</span></p><p data-diff-id="ct-diff-id-f3caae7d-c8cc-4c74-a44d-c9941b880cce"><span style="color: #333">10191:酷跑跑腿</span></p><p data-diff-id="ct-diff-id-d48fdf99-e163-4eb3-8fd3-fd4254ce3dc6"><span style="color: #333">10192:千里马跑腿</span></p><p data-diff-id="ct-diff-id-55606772-4576-4623-9e34-6a9da1df554f"><span style="color: #333">10193:燕城速达</span></p><p data-diff-id="ct-diff-id-10f06dc0-2b8b-4b86-ab40-678831d7f8a7"><span style="color: #333">10194:水站宝</span></p><p data-diff-id="ct-diff-id-6384a738-bac7-48d9-8105-ab74e5cc8abb"><span style="color: #333">10195:火速帮</span></p><p data-diff-id="ct-diff-id-5344fd67-b912-4262-8b10-cb282f65c943"><span style="color: #333">10196:捷顺配送</span></p><p data-diff-id="ct-diff-id-ea6cba49-f6cd-418e-8552-dddb7ae02d13"><span style="color: #333">10197:辉会急送</span></p><p data-diff-id="ct-diff-id-bd98d4ca-9246-41f2-8e22-accdbf5b47d0"><span style="color: #333">10198:方元同城</span></p><p data-diff-id="ct-diff-id-bb2827d7-f816-4f2e-b44d-e07a9898d2f0"><span style="color: #333">10199:小嗨跑腿</span></p><p data-diff-id="ct-diff-id-858a0946-f2e5-45b5-8d42-a990b2668157"><span style="color: #333">10200:灵风速递</span></p><p data-diff-id="ct-diff-id-b8bfa435-652d-4f2f-be1f-f04043f15a5c"><span style="color: #333">10201:巨商u客</span></p><p data-diff-id="ct-diff-id-c5c32e82-a011-4582-a4d2-29df00d18376"><span style="color: #333">10202:次方达</span></p><p data-diff-id="ct-diff-id-2bda60c9-47c8-420f-95cf-519463c2e7fd"><span style="color: #333">10203:豪客骑士</span></p><p data-diff-id="ct-diff-id-30a0b3dd-9c8d-411e-b3ee-c84489e15356"><span style="color: #333">10204:龙哥畅跑</span></p><p data-diff-id="ct-diff-id-2d562d93-bd43-4efa-8df6-821fe7b05102"><span style="color: #333">10205:圣百配送</span></p><p data-diff-id="ct-diff-id-dc90ed4d-4593-450f-9e71-750740ded10c"><span style="color: #333">10206:飒飒来</span></p><p data-diff-id="ct-diff-id-cd631087-a463-45dd-81a7-6222fd3a8442"><span style="color: #333">10207:百物物流</span></p><p data-diff-id="ct-diff-id-658c0ede-b51c-4091-9bd1-fc24d7c6dcbd"><span style="color: #333">10208:便民跑腿</span></p><p data-diff-id="ct-diff-id-9b07915c-a165-4109-906b-8460ad8729b6"><span style="color: #333">10209:准点配送</span></p><p data-diff-id="ct-diff-id-c9312df5-0487-42fa-8965-27a014813e59"><span style="color: #333">10210:邮政同城急送平台</span></p><p data-diff-id="ct-diff-id-6eac747b-ab93-464a-85a3-350371c501fc"><span style="color: #333">10211:英德配送</span></p><p data-diff-id="ct-diff-id-d0c8ba0f-2fe2-43f1-9e23-b39e3e3ce34f"><span style="color: #333">10212:指动跑腿</span></p><p data-diff-id="ct-diff-id-e64d8e6f-546a-4650-ba6e-54a3635095a9"><span style="color: #333">10213:送美邻</span></p><p data-diff-id="ct-diff-id-092c2876-290a-4c9c-8949-63ae566eaf8b"><span style="color: #333">10214:华盛配送</span></p><p data-diff-id="ct-diff-id-5f461454-080c-4a12-aab3-8b4426560049"><span style="color: #333">10215:快到</span></p><p data-diff-id="ct-diff-id-76f2d6fa-906e-495a-bd67-920147e5c842"><span style="color: #333">10216:小马快跑</span></p><p data-diff-id="ct-diff-id-26e0c79c-17dd-443d-bfd2-60df1f6e2bf8"><span style="color: #333">10217:呼兰闪送帮</span></p><p data-diff-id="ct-diff-id-74820156-d690-44f8-bf03-f2a49824202f"><span style="color: #333">10218:便利专送</span></p><p data-diff-id="ct-diff-id-05ba14d5-7562-4410-af5f-541e64900e1b"><span style="color: #333">10219:微订</span></p><p data-diff-id="ct-diff-id-6e030763-2956-4d34-a236-022c6722ff7f"><span style="color: #333">10220:闪达送</span></p><p data-diff-id="ct-diff-id-c83fe81d-62c6-490d-9d2c-b2955d65e815"><span style="color: #333">10221:琦天急送</span></p><p data-diff-id="ct-diff-id-53ccc331-d45f-477e-9350-f4b4dc5668e7"><span style="color: #333">10222:驰惠达</span></p><p data-diff-id="ct-diff-id-7530c19f-fc32-46fd-a93a-16548b363709"><span style="color: #333">10223:速帮跑腿</span></p><p data-diff-id="ct-diff-id-363aedad-3e2c-47b8-9624-004b8a6a8e08"><span style="color: #333">10224:奕得送</span></p><p data-diff-id="ct-diff-id-4e7b0670-ae63-4a52-9e55-f2c338ad7038"><span style="color: #333">10225:三条腿快送</span></p><p data-diff-id="ct-diff-id-19fcc37b-d09f-44f3-aa7e-edd95591981e"><span style="color: #333">10226:酷鸟快送</span></p><p data-diff-id="ct-diff-id-867ff927-0fb5-42a5-94a3-ed09e90f2296"><span style="color: #333">10227:桂速达</span></p><p data-diff-id="ct-diff-id-5590b37c-f5f2-41ca-b334-117b8b94c8ec"><span style="color: #333">10228:快点点专送</span></p><p data-diff-id="ct-diff-id-ec5a489f-e0ee-4f0c-baab-367740380983"><span style="color: #333">10229:拼必达</span></p>
    */
    @NotNull(message = "thirdLogisticsId不能为空")
    @SerializedName("thirdLogisticsId")
    private Integer thirdLogisticsId;
    /**
    * <p><span style="color: rgba(0, 0, 0, 0.87)"><font style="font-size:14px;line-height:22px" data-size="14">骑手当前的纬度</font></span></p>
    */
    @NotBlank(message = "latitude不能为空")
    @SerializedName("latitude")
    private String latitude;
    /**
    * <p><span style="color: rgba(0, 0, 0, 0.87)"><font style="font-size:14px;line-height:22px" data-size="14">骑手当前的经度</font></span></p>
    */
    @NotBlank(message = "longitude不能为空")
    @SerializedName("longitude")
    private String longitude;
    /**
    * <p>骑手信息采集时间戳</p>
    */
    @NotNull(message = "backFlowTime不能为空")
    @SerializedName("backFlowTime")
    private Integer backFlowTime;
    /**
    * <p><span style="color: "><font style="font-size:14px;line-height:22px" data-size="14">配送员电话类型。0是真实号，1是隐私号</font></span></p>
    */
    @SerializedName("courierPhoneType")
    private Integer courierPhoneType;
    /**
    * <p data-diff-id="ct-diff-id-35129403-91a1-4ac2-8ac5-a953d03ffd1d"><span style="color: ">履约订单是否允许修改配送信息。选填，不填默认为否；传1为「是」，传0为「否」</span></p>
    */
    @SerializedName("IsSupportUpdateRecipientInfo")
    private Boolean isSupportUpdateRecipientInfo;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getThirdCarrierId() {
        return thirdCarrierId;
    }
    public void setThirdCarrierId(String thirdCarrierId) {
        this.thirdCarrierId = thirdCarrierId;
    }
    public Integer getLogisticsStatus() {
        return logisticsStatus;
    }
    public void setLogisticsStatus(Integer logisticsStatus) {
        this.logisticsStatus = logisticsStatus;
    }
    public String getCourierName() {
        return courierName;
    }
    public void setCourierName(String courierName) {
        this.courierName = courierName;
    }
    public String getCourierPhone() {
        return courierPhone;
    }
    public void setCourierPhone(String courierPhone) {
        this.courierPhone = courierPhone;
    }
    public Integer getThirdLogisticsId() {
        return thirdLogisticsId;
    }
    public void setThirdLogisticsId(Integer thirdLogisticsId) {
        this.thirdLogisticsId = thirdLogisticsId;
    }
    public String getLatitude() {
        return latitude;
    }
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
    public String getLongitude() {
        return longitude;
    }
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
    public Integer getBackFlowTime() {
        return backFlowTime;
    }
    public void setBackFlowTime(Integer backFlowTime) {
        this.backFlowTime = backFlowTime;
    }
    public Integer getCourierPhoneType() {
        return courierPhoneType;
    }
    public void setCourierPhoneType(Integer courierPhoneType) {
        this.courierPhoneType = courierPhoneType;
    }
    public Boolean getIsSupportUpdateRecipientInfo() {
        return isSupportUpdateRecipientInfo;
    }
    public void setIsSupportUpdateRecipientInfo(Boolean isSupportUpdateRecipientInfo) {
        this.isSupportUpdateRecipientInfo = isSupportUpdateRecipientInfo;
    }


    @Override
    public MeituanResponse<String> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<String>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "RiderPositionRequest{" + "orderId=" + orderId + "," + "thirdCarrierId=" + thirdCarrierId + "," + "logisticsStatus=" + logisticsStatus + "," + "courierName=" + courierName + "," + "courierPhone=" + courierPhone + "," + "thirdLogisticsId=" + thirdLogisticsId + "," + "latitude=" + latitude + "," + "longitude=" + longitude + "," + "backFlowTime=" + backFlowTime + "," + "courierPhoneType=" + courierPhoneType + "," + "isSupportUpdateRecipientInfo=" + isSupportUpdateRecipientInfo + "}";
    }
}
