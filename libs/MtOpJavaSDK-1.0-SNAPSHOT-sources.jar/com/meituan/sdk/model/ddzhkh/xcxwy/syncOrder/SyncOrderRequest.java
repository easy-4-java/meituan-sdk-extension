package com.meituan.sdk.model.ddzhkh.xcxwy.syncOrder;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 订单同步
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/xcxwy/sync_status",
    businessId = 59,
    apiVersion = "10003",
    apiName = "sync_order",
    needAuth = true
)
public class SyncOrderRequest implements MeituanRequest<SyncOrderResponse> {
    @NotBlank(message = "generalBizData不能为空")
    @SerializedName("generalBizData")
    private String generalBizData;
    @NotNull(message = "orderDataChangeReq不能为空")
    @SerializedName("orderDataChangeReq")
    private OrderDataChangeReq orderDataChangeReq;

    public String getGeneralBizData() {
        return generalBizData;
    }
    public void setGeneralBizData(String generalBizData) {
        this.generalBizData = generalBizData;
    }
    public OrderDataChangeReq getOrderDataChangeReq() {
        return orderDataChangeReq;
    }
    public void setOrderDataChangeReq(OrderDataChangeReq orderDataChangeReq) {
        this.orderDataChangeReq = orderDataChangeReq;
    }


    @Override
    public MeituanResponse<SyncOrderResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<SyncOrderResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "SyncOrderRequest{" + "generalBizData=" + generalBizData + "," + "orderDataChangeReq=" + orderDataChangeReq + "}";
    }
}
