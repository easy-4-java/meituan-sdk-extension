package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptBatchconsume;

import com.google.gson.annotations.SerializedName;

/**
* 该券码所在的订单的支付明细，如果一笔订单包含两个券码a、b，在核销a、b券码时返回信息一致，都是该订单的支付明细
* This file was automatically generated.
*/
public class RpaymentDetail {
    /**
    * 支付详情id
    */
    @SerializedName("paymentDetailId")
    private String paymentDetailId;
    /**
    * 支付金额
    */
    @SerializedName("amount")
    private String amount;
    /**
    * 金额类型，类型说明：     2：抵用券       5：积分      6：立减       8：商户抵用券      10：C端美团支付      12：优惠代码      15：美团立减      17：商家立减      18：美团商家立减      21：次卡      22：打折卡      23：B端美团支付      24：全渠道会员券      25：pos支付      26：线下认款平台。其中，8，17，18，22，24 表示商家优惠
    */
    @SerializedName("amountType")
    private Integer amountType;

    public String getPaymentDetailId() {
        return paymentDetailId;
    }
    public void setPaymentDetailId(String paymentDetailId) {
        this.paymentDetailId = paymentDetailId;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public Integer getAmountType() {
        return amountType;
    }
    public void setAmountType(Integer amountType) {
        this.amountType = amountType;
    }




    @Override
    public String toString() {
        return "RpaymentDetail{" + "paymentDetailId=" + paymentDetailId + "," + "amount=" + amount + "," + "amountType=" + amountType + "}";
    }
}
