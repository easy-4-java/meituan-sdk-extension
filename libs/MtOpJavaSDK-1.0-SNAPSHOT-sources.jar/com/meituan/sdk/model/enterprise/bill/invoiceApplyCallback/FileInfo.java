package com.meituan.sdk.model.enterprise.bill.invoiceApplyCallback;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class FileInfo {
    /**
    * <p data-diff-id="ct-diff-id-c1b63105-20ad-4ebb-8328-f4ebd5b291ca">文件类型</p>
    */
    @NotBlank(message = "fileType不能为空")
    @SerializedName("fileType")
    private String fileType;
    /**
    * <p data-diff-id="ct-diff-id-e0d3594f-ac92-4353-adba-2f2974b3ab8b">下载地址</p>
    */
    @NotBlank(message = "fileUrl不能为空")
    @SerializedName("fileUrl")
    private String fileUrl;
    /**
    * <p data-diff-id="ct-diff-id-c9b2ed51-e639-4337-8a90-811ca46a1b03">备注</p>
    */
    @SerializedName("remark")
    private String remark;

    public String getFileType() {
        return fileType;
    }
    public void setFileType(String fileType) {
        this.fileType = fileType;
    }
    public String getFileUrl() {
        return fileUrl;
    }
    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }




    @Override
    public String toString() {
        return "FileInfo{" + "fileType=" + fileType + "," + "fileUrl=" + fileUrl + "," + "remark=" + remark + "}";
    }
}
