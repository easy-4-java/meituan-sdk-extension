package com.meituan.sdk.model.foodmop.shop.shoporproductUnboundQuery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 查询秒提未开通的门店/未映射门店的团单
* This file was automatically generated.
*/
public class ShoporproductUnboundQueryResponse {
    /**
    * 分页上下文
    */
    @SerializedName("pageContext")
    private DataMap pageContext;
    @SerializedName("items")
    private List<Object> items;

    public DataMap getPageContext() {
        return pageContext;
    }
    public void setPageContext(DataMap pageContext) {
        this.pageContext = pageContext;
    }
    public List<Object> getItems() {
        return items;
    }
    public void setItems(List<Object> items) {
        this.items = items;
    }




    @Override
    public String toString() {
        return "ShoporproductUnboundQueryResponse{" + "pageContext=" + pageContext + "," + "items=" + items + "}";
    }
}
