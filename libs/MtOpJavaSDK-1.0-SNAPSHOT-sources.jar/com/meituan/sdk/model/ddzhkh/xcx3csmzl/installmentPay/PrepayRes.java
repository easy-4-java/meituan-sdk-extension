package com.meituan.sdk.model.ddzhkh.xcx3csmzl.installmentPay;

import com.google.gson.annotations.SerializedName;

/**
* 生单请求结果
* This file was automatically generated.
*/
public class PrepayRes {
    /**
    * 支付token
    */
    @SerializedName("payToken")
    private String payToken;
    /**
    * 平台订单支付模型Id
    */
    @SerializedName("orderPaymentId")
    private String orderPaymentId;
    /**
    * 支付流水号
    */
    @SerializedName("tradeNo")
    private String tradeNo;

    public String getPayToken() {
        return payToken;
    }
    public void setPayToken(String payToken) {
        this.payToken = payToken;
    }
    public String getOrderPaymentId() {
        return orderPaymentId;
    }
    public void setOrderPaymentId(String orderPaymentId) {
        this.orderPaymentId = orderPaymentId;
    }
    public String getTradeNo() {
        return tradeNo;
    }
    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }




    @Override
    public String toString() {
        return "PrepayRes{" + "payToken=" + payToken + "," + "orderPaymentId=" + orderPaymentId + "," + "tradeNo=" + tradeNo + "}";
    }
}
