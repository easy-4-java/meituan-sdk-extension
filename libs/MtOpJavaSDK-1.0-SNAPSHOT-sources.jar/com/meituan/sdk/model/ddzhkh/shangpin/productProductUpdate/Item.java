package com.meituan.sdk.model.ddzhkh.shangpin.productProductUpdate;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-22c957b4-e848-4154-9599-21989c8aab37"><span style="color: rgb(31, 45, 61)">售卖SKU列表</span></p>
* This file was automatically generated.
*/
public class Item {
    /**
    * <p data-diff-id="ct-diff-id-47146bb0-1ee5-4989-ad22-2db855b7775e"><span style="color: rgb(31, 45, 61)">售卖SKU名称，长度限制&lt;=30</span></p>
    */
    @NotBlank(message = "itemName不能为空")
    @SerializedName("itemName")
    private String itemName;
    /**
    * <p data-diff-id="ct-diff-id-258ebc11-e3c3-42f5-b112-2a1104e7f86c"><span style="color: rgb(31, 45, 61)">售卖SKU价格模型</span></p>
    */
    @NotNull(message = "itemPrice不能为空")
    @SerializedName("itemPrice")
    private Price itemPrice;
    /**
    * <p data-diff-id="ct-diff-id-52e1dd8f-0080-4f12-8b33-cf66a240f7ce"><span style="color: rgb(31, 45, 61)">售卖SKU价格类型，0-一口价</span></p>
    */
    @NotNull(message = "priceType不能为空")
    @SerializedName("priceType")
    private Integer priceType;
    /**
    * <p data-diff-id="ct-diff-id-97b95fa0-da95-447c-bdbc-6048bfe5250e"><span style="color: rgb(31, 45, 61)">售卖SKU市场价格（原价），取值范围：0-99999999.99，精确到两位小数，单位：元。如101.01，表示101.01元1分</span></p>
    */
    @NotNull(message = "marketPrice不能为空")
    @SerializedName("marketPrice")
    private Double marketPrice;
    /**
    * <p data-diff-id="ct-diff-id-6400fa27-e824-4dcf-9095-95b9848c15a0"><span style="color: rgb(31, 45, 61)">三方售卖SKUID，长度64</span></p>
    */
    @NotBlank(message = "appItemId不能为空")
    @SerializedName("appItemId")
    private String appItemId;
    /**
    * <p data-diff-id="ct-diff-id-5c6abd04-2868-4aa5-bb9f-3f2a615e49c3"><span style="color: rgb(31, 45, 61)">售卖SKU属性，类型Map&lt;Long,List&lt;String&gt;&gt;</span></p>
    */
    @NotBlank(message = "attributes不能为空")
    @SerializedName("attributes")
    private String attributes;
    /**
    * <p data-diff-id="ct-diff-id-0f4661e0-cfe4-4f5e-99ae-56067994d59d"><span style="color: rgb(31, 45, 61)">售卖SKU库存类型，用来区分场景，1-三方，</span><br><span style="color: rgb(31, 45, 61)">注：在化妆品商品中，该字段无意义，写1即可</span></p>
    */
    @NotNull(message = "stockScene不能为空")
    @SerializedName("stockScene")
    private Integer stockScene;
    /**
    * <p data-diff-id="ct-diff-id-abd11254-5997-4436-b47c-c441786206f7"><span style="color: rgb(31, 45, 61)">售卖SKU ID，编辑场景传入则修改已有售卖SKU</span></p>
    */
    @SerializedName("itemId")
    private Long itemId;

    public String getItemName() {
        return itemName;
    }
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }
    public Price getItemPrice() {
        return itemPrice;
    }
    public void setItemPrice(Price itemPrice) {
        this.itemPrice = itemPrice;
    }
    public Integer getPriceType() {
        return priceType;
    }
    public void setPriceType(Integer priceType) {
        this.priceType = priceType;
    }
    public Double getMarketPrice() {
        return marketPrice;
    }
    public void setMarketPrice(Double marketPrice) {
        this.marketPrice = marketPrice;
    }
    public String getAppItemId() {
        return appItemId;
    }
    public void setAppItemId(String appItemId) {
        this.appItemId = appItemId;
    }
    public String getAttributes() {
        return attributes;
    }
    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }
    public Integer getStockScene() {
        return stockScene;
    }
    public void setStockScene(Integer stockScene) {
        this.stockScene = stockScene;
    }
    public Long getItemId() {
        return itemId;
    }
    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }




    @Override
    public String toString() {
        return "Item{" + "itemName=" + itemName + "," + "itemPrice=" + itemPrice + "," + "priceType=" + priceType + "," + "marketPrice=" + marketPrice + "," + "appItemId=" + appItemId + "," + "attributes=" + attributes + "," + "stockScene=" + stockScene + "," + "itemId=" + itemId + "}";
    }
}
