package com.meituan.sdk.model.resv2.rule.supplyRuleSave;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class VendorSpecialRuleDTO {
    @SerializedName("vendorSpecialBookableRuleDTOS")
    private List<VendorSpecialBookableRuleDTO> vendorSpecialBookableRuleDTOS;
    /**
    * <p data-diff-id="ct-diff-id-2a24cccb-89df-4000-b561-2afcc33db984"><span style="color: rgba(0, 0, 0, 0.65)">特殊不可订规则</span></p>
    */
    @SerializedName("vendorSpecialUnbookableRuleDTOS")
    private List<VendorSpecialUnbookableRuleDTO> vendorSpecialUnbookableRuleDTOS;

    public List<VendorSpecialBookableRuleDTO> getVendorSpecialBookableRuleDTOS() {
        return vendorSpecialBookableRuleDTOS;
    }
    public void setVendorSpecialBookableRuleDTOS(List<VendorSpecialBookableRuleDTO> vendorSpecialBookableRuleDTOS) {
        this.vendorSpecialBookableRuleDTOS = vendorSpecialBookableRuleDTOS;
    }
    public List<VendorSpecialUnbookableRuleDTO> getVendorSpecialUnbookableRuleDTOS() {
        return vendorSpecialUnbookableRuleDTOS;
    }
    public void setVendorSpecialUnbookableRuleDTOS(List<VendorSpecialUnbookableRuleDTO> vendorSpecialUnbookableRuleDTOS) {
        this.vendorSpecialUnbookableRuleDTOS = vendorSpecialUnbookableRuleDTOS;
    }




    @Override
    public String toString() {
        return "VendorSpecialRuleDTO{" + "vendorSpecialBookableRuleDTOS=" + vendorSpecialBookableRuleDTOS + "," + "vendorSpecialUnbookableRuleDTOS=" + vendorSpecialUnbookableRuleDTOS + "}";
    }
}
