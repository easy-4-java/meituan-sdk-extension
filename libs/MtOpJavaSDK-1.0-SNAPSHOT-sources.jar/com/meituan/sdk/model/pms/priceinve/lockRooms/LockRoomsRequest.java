package com.meituan.sdk.model.pms.priceinve.lockRooms;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 锁房
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/priceinve/lockRooms",
    businessId = 57,
    apiVersion = "10011",
    apiName = "lock_rooms",
    needAuth = true
)
public class LockRoomsRequest implements MeituanRequest<LockRoomsResponse> {
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-431be8de-d3f1-4969-8d6b-4e491ddea53e">房间号列表</p>
    */
    @NotEmpty(message = "roomNumbers不能为空")
    @SerializedName("roomNumbers")
    private List<String> roomNumbers;
    /**
    * <p data-diff-id="ct-diff-id-82d32bcd-38aa-42b2-a490-feaf2ac0a8c6">锁房原因</p>
    */
    @NotBlank(message = "reason不能为空")
    @SerializedName("reason")
    private String reason;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public List<String> getRoomNumbers() {
        return roomNumbers;
    }
    public void setRoomNumbers(List<String> roomNumbers) {
        this.roomNumbers = roomNumbers;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }


    @Override
    public MeituanResponse<LockRoomsResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<LockRoomsResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "LockRoomsRequest{" + "hotelId=" + hotelId + "," + "roomNumbers=" + roomNumbers + "," + "reason=" + reason + "}";
    }
}
