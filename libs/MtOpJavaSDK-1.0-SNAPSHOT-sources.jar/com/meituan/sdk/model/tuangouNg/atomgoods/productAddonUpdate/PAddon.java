package com.meituan.sdk.model.tuangouNg.atomgoods.productAddonUpdate;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-51177ebf-cb8a-4f0e-a74d-f1d8ab22b6f2">加价属性、菜品附加信息</p>
* This file was automatically generated.
*/
public class PAddon {
    /**
    * <p data-diff-id="ct-diff-id-634e92b3-7f8e-4c00-9054-a6b07614906e">三方附加信息/加价属性Id</p>
    */
    @NotBlank(message = "addOnId不能为空")
    @SerializedName("addOnId")
    private String addOnId;
    /**
    * <p data-diff-id="ct-diff-id-e41aad99-1318-40ed-8c70-9a5753a3f794">附加信息/加价属性名称</p>
    */
    @NotBlank(message = "addOnName不能为空")
    @SerializedName("addOnName")
    private String addOnName;
    /**
    * <p data-diff-id="ct-diff-id-5de5beff-2171-4e6f-90b5-c109e0dce613">附加信息/加价属性描述</p>
    */
    @SerializedName("addOnDesc")
    private String addOnDesc;
    /**
    * <p data-diff-id="ct-diff-id-33134ec8-0106-4a44-b400-84456c19e15d">计价类型，1-固定计价，2-按称量计价，默认为1</p>
    */
    @SerializedName("valuateType")
    private Integer valuateType;
    /**
    * <p data-diff-id="ct-diff-id-05e0b7b1-8cef-4d9a-bb7b-68321f8e45ec">价格，单位是分，不可以为负，默认为0</p>
    */
    @SerializedName("price")
    private Long price;
    /**
    * <p data-diff-id="ct-diff-id-1e00d334-9764-45bf-85eb-83e1479d25a0">加价属性状态</p>
    */
    @NotNull(message = "status不能为空")
    @SerializedName("status")
    private Integer status;
    /**
    * <p data-diff-id="ct-diff-id-2dc15c2f-496c-4191-b856-4a22462e89ab">排序, 必须从1开始，且不重复</p>
    */
    @SerializedName("sort")
    private Integer sort;
    /**
    * <p data-diff-id="ct-diff-id-fd53c00a-4343-4be1-8067-e7a4d84f230b">上传菜品加价属性时不传，spu更新时需传</p>
    */
    @SerializedName("addOnGroupId")
    private String addOnGroupId;
    /**
    * <p data-diff-id="ct-diff-id-924830ce-3297-44c4-b611-3b57c1c1e0d7"><span style="color: #333">0-总部下发，1-门店自建（如果是门店菜，必传）</span></p>
    */
    @SerializedName("publishType")
    private Integer publishType;
    /**
    * <p data-diff-id="ct-diff-id-5218a953-3a02-4b3b-9bfa-803ffe58ff7b"><span style="color: #333">关联的总部菜加价属性id（如果门店菜是总部下发，必传）</span></p>
    */
    @SerializedName("chainAddOnId")
    private String chainAddOnId;
    /**
    * <p data-diff-id="ct-diff-id-41c5905b-a9ce-49a4-a305-66a99973e1ca"><span style="color: #333">总部code（如果门店菜是总部下发，必传）</span></p>
    */
    @SerializedName("vendorChainId")
    private String vendorChainId;
    /**
    * <p data-diff-id="ct-diff-id-3ddd3aa8-1b3e-4597-a067-eeb2dd1ef9b3">其他价格</p>
    */
    @SerializedName("extraPriceList")
    private List<PSubjectExtraPrice> extraPriceList;

    public String getAddOnId() {
        return addOnId;
    }
    public void setAddOnId(String addOnId) {
        this.addOnId = addOnId;
    }
    public String getAddOnName() {
        return addOnName;
    }
    public void setAddOnName(String addOnName) {
        this.addOnName = addOnName;
    }
    public String getAddOnDesc() {
        return addOnDesc;
    }
    public void setAddOnDesc(String addOnDesc) {
        this.addOnDesc = addOnDesc;
    }
    public Integer getValuateType() {
        return valuateType;
    }
    public void setValuateType(Integer valuateType) {
        this.valuateType = valuateType;
    }
    public Long getPrice() {
        return price;
    }
    public void setPrice(Long price) {
        this.price = price;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public String getAddOnGroupId() {
        return addOnGroupId;
    }
    public void setAddOnGroupId(String addOnGroupId) {
        this.addOnGroupId = addOnGroupId;
    }
    public Integer getPublishType() {
        return publishType;
    }
    public void setPublishType(Integer publishType) {
        this.publishType = publishType;
    }
    public String getChainAddOnId() {
        return chainAddOnId;
    }
    public void setChainAddOnId(String chainAddOnId) {
        this.chainAddOnId = chainAddOnId;
    }
    public String getVendorChainId() {
        return vendorChainId;
    }
    public void setVendorChainId(String vendorChainId) {
        this.vendorChainId = vendorChainId;
    }
    public List<PSubjectExtraPrice> getExtraPriceList() {
        return extraPriceList;
    }
    public void setExtraPriceList(List<PSubjectExtraPrice> extraPriceList) {
        this.extraPriceList = extraPriceList;
    }




    @Override
    public String toString() {
        return "PAddon{" + "addOnId=" + addOnId + "," + "addOnName=" + addOnName + "," + "addOnDesc=" + addOnDesc + "," + "valuateType=" + valuateType + "," + "price=" + price + "," + "status=" + status + "," + "sort=" + sort + "," + "addOnGroupId=" + addOnGroupId + "," + "publishType=" + publishType + "," + "chainAddOnId=" + chainAddOnId + "," + "vendorChainId=" + vendorChainId + "," + "extraPriceList=" + extraPriceList + "}";
    }
}
