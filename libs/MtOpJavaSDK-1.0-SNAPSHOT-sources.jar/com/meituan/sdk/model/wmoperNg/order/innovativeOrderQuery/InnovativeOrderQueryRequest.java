package com.meituan.sdk.model.wmoperNg.order.innovativeOrderQuery;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 食光机-查询订单详情
* This file was automatically generated.
*/
@ApiMeta(
    path = "/wmoper/ng/order/innovative/getInnovativeOrderDetail",
    businessId = 16,
    apiVersion = "10056",
    apiName = "innovative_order_query",
    needAuth = true
)
public class InnovativeOrderQueryRequest implements MeituanRequest<InnovativeOrderQueryResponse> {
    @SerializedName("orderDate")
    private String orderDate;
    @SerializedName("bizType")
    private String bizType;
    @SerializedName("pageNumber")
    private Integer pageNumber;

    public String getOrderDate() {
        return orderDate;
    }
    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }
    public String getBizType() {
        return bizType;
    }
    public void setBizType(String bizType) {
        this.bizType = bizType;
    }
    public Integer getPageNumber() {
        return pageNumber;
    }
    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }


    @Override
    public MeituanResponse<InnovativeOrderQueryResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<InnovativeOrderQueryResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "InnovativeOrderQueryRequest{" + "orderDate=" + orderDate + "," + "bizType=" + bizType + "," + "pageNumber=" + pageNumber + "}";
    }
}
