package com.meituan.sdk.model.ddzhkh.xcxwy.submitFileTransfer;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class ExtraObj {
    @SerializedName("errorCode")
    private String errorCode;
    @SerializedName("errorMsg")
    private String errorMsg;

    public String getErrorCode() {
        return errorCode;
    }
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
    public String getErrorMsg() {
        return errorMsg;
    }
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }




    @Override
    public String toString() {
        return "ExtraObj{" + "errorCode=" + errorCode + "," + "errorMsg=" + errorMsg + "}";
    }
}
