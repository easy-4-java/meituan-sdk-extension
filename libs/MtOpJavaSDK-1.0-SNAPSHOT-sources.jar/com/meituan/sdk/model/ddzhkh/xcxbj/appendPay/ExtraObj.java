package com.meituan.sdk.model.ddzhkh.xcxbj.appendPay;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class ExtraObj {
    /**
    * 系统交互码
    */
    @SerializedName("errorCode")
    private Integer errorCode;
    /**
    * 系统交互码msg
    */
    @SerializedName("errorMsg")
    private String errorMsg;
    /**
    * 美团traceId
    */
    @SerializedName("traceId")
    private String traceId;

    public Integer getErrorCode() {
        return errorCode;
    }
    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }
    public String getErrorMsg() {
        return errorMsg;
    }
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
    public String getTraceId() {
        return traceId;
    }
    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }




    @Override
    public String toString() {
        return "ExtraObj{" + "errorCode=" + errorCode + "," + "errorMsg=" + errorMsg + "," + "traceId=" + traceId + "}";
    }
}
