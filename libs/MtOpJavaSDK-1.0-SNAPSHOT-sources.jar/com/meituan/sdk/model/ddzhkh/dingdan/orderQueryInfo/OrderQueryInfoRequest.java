package com.meituan.sdk.model.ddzhkh.dingdan.orderQueryInfo;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 订单及券码状态查询
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/dingdan/query/info",
    businessId = 59,
    apiVersion = "10043",
    apiName = "order_query_info",
    needAuth = true
)
public class OrderQueryInfoRequest implements MeituanRequest<OrderQueryInfoResponse> {
    /**
    * <p data-diff-id="ct-diff-id-40cecbeb-a5e1-438f-8d4f-2575cd13c52a"><span style="color: rgb(31, 45, 61)">订单ID（用户订单详情页实际看到的订单号）</span><br><span style="color: rgb(31, 45, 61)">orderId 与 unifiedOrderId 必须二选一，同时传参时以unifiedOrderId 为准，以 orderId 查询订单信息</span><span style="color: rgb(255, 74, 71)">不支持持非团购</span><span style="color: rgb(31, 45, 61)">业务</span></p>
    */
    @SerializedName("orderId")
    private String orderId;
    /**
    * <p data-diff-id="ct-diff-id-8bcd8e58-a005-4893-ac94-76876adc6682"><span style="color: ">需要查询的信息，1-订单，2-券码，3-退款申请单，5-商品快照信息，6-订单下单金额明细快照，</span><span style="color: #333">7-职人信息</span></p>
    */
    @NotEmpty(message = "type不能为空")
    @SerializedName("type")
    private List<Integer> type;
    /**
    * <p data-diff-id="ct-diff-id-55c2ef96-423c-407e-aea3-f3fda553c5f7"><span style="color: rgb(31, 45, 61)">统一订单ID（对外透出的订单号）</span></p><p style="text-align: start;" data-diff-id="ct-diff-id-246e226d-dcb9-4538-ab80-a48b23381a1b">orderId 与 unifiedOrderId 必须二选一，同时传参时以unifiedOrderId 为准，以 unifiedOrderId 查询订单信息<span style="color: rgb(255, 74, 71)">支持非团购</span>业务</p>
    */
    @SerializedName("unifiedOrderId")
    private String unifiedOrderId;

    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public List<Integer> getType() {
        return type;
    }
    public void setType(List<Integer> type) {
        this.type = type;
    }
    public String getUnifiedOrderId() {
        return unifiedOrderId;
    }
    public void setUnifiedOrderId(String unifiedOrderId) {
        this.unifiedOrderId = unifiedOrderId;
    }


    @Override
    public MeituanResponse<OrderQueryInfoResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<OrderQueryInfoResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "OrderQueryInfoRequest{" + "orderId=" + orderId + "," + "type=" + type + "," + "unifiedOrderId=" + unifiedOrderId + "}";
    }
}
