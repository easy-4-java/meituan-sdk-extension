package com.meituan.sdk.model.rhone.mtp.productLevelPriceNoticeV2;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-d4b72c72-1ad5-4975-866b-68e5d0a553b4"><span style="color: ">场次信息</span></p>
* This file was automatically generated.
*/
public class LevelInfoListSub {
    /**
    * <p data-diff-id="ct-diff-id-1eb97802-5337-4361-ae2d-e98feb9c7834"><span style="color: ">层级名称信息，如：”上午场“、”贵宾席“</span></p>
    */
    @SerializedName("levelName")
    private String levelName;
    /**
    * <p data-diff-id="ct-diff-id-71739254-7f77-4d1c-af4a-d29d4de6a324"><span style="color: ">层级序号，最多支持3层：1-第一层；2-第二层；3-第三层</span></p>
    */
    @SerializedName("levelNo")
    private Integer levelNo;

    public String getLevelName() {
        return levelName;
    }
    public void setLevelName(String levelName) {
        this.levelName = levelName;
    }
    public Integer getLevelNo() {
        return levelNo;
    }
    public void setLevelNo(Integer levelNo) {
        this.levelNo = levelNo;
    }




    @Override
    public String toString() {
        return "LevelInfoListSub{" + "levelName=" + levelName + "," + "levelNo=" + levelNo + "}";
    }
}
