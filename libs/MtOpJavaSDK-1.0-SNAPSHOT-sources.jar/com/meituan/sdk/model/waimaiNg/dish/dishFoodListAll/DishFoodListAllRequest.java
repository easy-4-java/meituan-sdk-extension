package com.meituan.sdk.model.waimaiNg.dish.dishFoodListAll;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询门店菜品列表（包括门店的套餐商品和普通商品）
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/dish/food/listAll",
    businessId = 2,
    apiVersion = "10132",
    apiName = "dish_food_list_all",
    needAuth = true
)
public class DishFoodListAllRequest implements MeituanRequest<List<FoodInfo>> {
    /**
    * <p><span style="color: rgba(0, 0, 0, 0.65)"><font style="font-size:14px;line-height:22px" data-size="14">分页查询偏移量</font></span></p>
    */
    @NotNull(message = "offset不能为空")
    @SerializedName("offset")
    private Integer offset;
    /**
    * <p><span style="color: rgba(0, 0, 0, 0.65)"><font style="font-size:14px;line-height:22px" data-size="14">分页查询每页查询的数量,须小于200</font></span></p>
    */
    @NotNull(message = "limit不能为空")
    @SerializedName("limit")
    private Integer limit;
    /**
    * <p data-diff-id="ct-diff-id-a660573c-7ee1-4b2c-92ce-e80a94566910">是否查询小料组信息及defaultSelect</p><p data-diff-id="ct-diff-id-afa40980-6edd-4709-89ea-1f76c9011458">默认为false</p>
    */
    @SerializedName("needTopping")
    private Boolean needTopping;
    /**
    * <p data-diff-id="ct-diff-id-8dba112c-d1f0-4cf8-a17b-44ca95863c4f">场域id，有则查询场域商品， 不填则返回外卖主站商品</p>
    */
    @SerializedName("marketplaceId")
    private String marketplaceId;

    public Integer getOffset() {
        return offset;
    }
    public void setOffset(Integer offset) {
        this.offset = offset;
    }
    public Integer getLimit() {
        return limit;
    }
    public void setLimit(Integer limit) {
        this.limit = limit;
    }
    public Boolean getNeedTopping() {
        return needTopping;
    }
    public void setNeedTopping(Boolean needTopping) {
        this.needTopping = needTopping;
    }
    public String getMarketplaceId() {
        return marketplaceId;
    }
    public void setMarketplaceId(String marketplaceId) {
        this.marketplaceId = marketplaceId;
    }


    @Override
    public MeituanResponse<List<FoodInfo>> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<List<FoodInfo>>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "DishFoodListAllRequest{" + "offset=" + offset + "," + "limit=" + limit + "," + "needTopping=" + needTopping + "," + "marketplaceId=" + marketplaceId + "}";
    }
}
