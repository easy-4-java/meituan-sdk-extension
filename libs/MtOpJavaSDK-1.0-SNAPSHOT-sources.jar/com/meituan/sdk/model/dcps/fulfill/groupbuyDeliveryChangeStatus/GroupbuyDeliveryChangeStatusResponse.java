package com.meituan.sdk.model.dcps.fulfill.groupbuyDeliveryChangeStatus;

import com.google.gson.annotations.SerializedName;

/**
* 1.1.12配送信息回调
* This file was automatically generated.
*/
public class GroupbuyDeliveryChangeStatusResponse {
    /**
    * 预约单id
    */
    @SerializedName("bookingOrderId")
    private String bookingOrderId;
    /**
    * 本接口返回空
    */
    @SerializedName("opKey")
    private String opKey;

    public String getBookingOrderId() {
        return bookingOrderId;
    }
    public void setBookingOrderId(String bookingOrderId) {
        this.bookingOrderId = bookingOrderId;
    }
    public String getOpKey() {
        return opKey;
    }
    public void setOpKey(String opKey) {
        this.opKey = opKey;
    }




    @Override
    public String toString() {
        return "GroupbuyDeliveryChangeStatusResponse{" + "bookingOrderId=" + bookingOrderId + "," + "opKey=" + opKey + "}";
    }
}
