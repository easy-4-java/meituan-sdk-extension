package com.meituan.sdk.model.ddzh.yuding.isvconsume;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 用户到店核销
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/isvconsume",
    businessId = 58,
    apiVersion = "10057",
    apiName = "isvconsume",
    needAuth = true
)
public class IsvconsumeRequest implements MeituanRequest<IsvconsumeResponse> {
    /**
    * <p data-diff-id="ct-diff-id-fd6c1de3-afa3-428c-b5c4-3f6aa4737d2e"><span style="color: rgb(31, 45, 61)">订单id</span></p>
    */
    @NotBlank(message = "orderId不能为空")
    @SerializedName("orderId")
    private String orderId;
    /**
    * <p data-diff-id="ct-diff-id-15aa09e7-0907-4ed9-ad06-c4646834577c"><span style="color: rgba(0, 0, 0, 0.65)">订单实际开始时间，格式为yyyy-MM-dd HH:mm，如2025-12-12 12:01，时间精确到分钟；若门店支持续时能力，则此字段必传；</span></p>
    */
    @SerializedName("startTime")
    private String startTime;
    /**
    * <p data-diff-id="ct-diff-id-51a085ae-7e7c-4456-a13c-20a570c9c5de"><span style="color: rgba(0, 0, 0, 0.65)">订单预计结束时间，格式为yyyy-MM-dd HH:mm，如2025-12-12 16:01，时间精确到分钟；若门店支持续时能力，则此字段必传</span></p>
    */
    @SerializedName("endTime")
    private String endTime;

    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public String getStartTime() {
        return startTime;
    }
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    public String getEndTime() {
        return endTime;
    }
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }


    @Override
    public MeituanResponse<IsvconsumeResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<IsvconsumeResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "IsvconsumeRequest{" + "orderId=" + orderId + "," + "startTime=" + startTime + "," + "endTime=" + endTime + "}";
    }
}
