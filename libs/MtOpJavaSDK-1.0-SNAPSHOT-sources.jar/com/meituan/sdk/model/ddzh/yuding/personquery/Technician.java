package com.meituan.sdk.model.ddzh.yuding.personquery;

import com.google.gson.annotations.SerializedName;

/**
* 人员信息列表 注：类型为对象类型，详见扩展参数technicians
* This file was automatically generated.
*/
public class Technician {
    /**
    * 服务人员id
    */
    @SerializedName("serviceTechId")
    private Long serviceTechId;
    /**
    * 人员姓名
    */
    @SerializedName("name")
    private String name;
    /**
    * 身份证
    */
    @SerializedName("idCard")
    private String idCard;
    /**
    * 手机号
    */
    @SerializedName("phone")
    private String phone;

    public Long getServiceTechId() {
        return serviceTechId;
    }
    public void setServiceTechId(Long serviceTechId) {
        this.serviceTechId = serviceTechId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getIdCard() {
        return idCard;
    }
    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }




    @Override
    public String toString() {
        return "Technician{" + "serviceTechId=" + serviceTechId + "," + "name=" + name + "," + "idCard=" + idCard + "," + "phone=" + phone + "}";
    }
}
