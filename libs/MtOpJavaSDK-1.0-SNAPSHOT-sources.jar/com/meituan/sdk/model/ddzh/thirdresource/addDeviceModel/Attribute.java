package com.meituan.sdk.model.ddzh.thirdresource.addDeviceModel;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-043b94a5-9fd9-4d5d-b5b1-9f0ef9e0f918">扩展信息列表</p>
* This file was automatically generated.
*/
public class Attribute {
    /**
    * <p data-diff-id="ct-diff-id-2e5fea4d-8550-4145-8b8f-02998f14b806"><span style="color: #333">信息名</span></p>
    */
    @NotBlank(message = "key不能为空")
    @SerializedName("key")
    private String key;
    /**
    * <p data-diff-id="ct-diff-id-703682b1-2d50-44bb-9e1c-2bb232f67ecd">信息值，如果valueType=1，按"aa,bb,cc"的形式传递</p>
    */
    @NotBlank(message = "value不能为空")
    @SerializedName("value")
    private String value;
    /**
    * <p data-diff-id="ct-diff-id-0d1ae30e-cce3-4d8a-8b4f-1bb2896666e7"><span style="color: rgba(0, 0, 0, 0.65)">信息值形式：0-枚举，单选、1-枚举，多选、2-自定义输入</span></p>
    */
    @NotBlank(message = "valueType不能为空")
    @SerializedName("valueType")
    private String valueType;

    public String getKey() {
        return key;
    }
    public void setKey(String key) {
        this.key = key;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public String getValueType() {
        return valueType;
    }
    public void setValueType(String valueType) {
        this.valueType = valueType;
    }




    @Override
    public String toString() {
        return "Attribute{" + "key=" + key + "," + "value=" + value + "," + "valueType=" + valueType + "}";
    }
}
