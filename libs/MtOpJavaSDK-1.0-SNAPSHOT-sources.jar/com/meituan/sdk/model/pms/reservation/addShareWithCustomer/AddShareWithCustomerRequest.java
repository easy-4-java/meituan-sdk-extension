package com.meituan.sdk.model.pms.reservation.addShareWithCustomer;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 添加同住
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/reservation/addShareWithCustomer",
    businessId = 57,
    apiVersion = "10029",
    apiName = "add_share_with_customer",
    needAuth = true
)
public class AddShareWithCustomerRequest implements MeituanRequest<AddShareWithCustomerResponse> {
    /**
    * <p data-diff-id="ct-diff-id-cdc39a84-0fd0-430b-b931-edac916ab600">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-65db43b3-2fc7-4407-a202-5994ff94375d">接待单ID</p>
    */
    @NotNull(message = "checkinId不能为空")
    @SerializedName("checkinId")
    private Long checkinId;
    /**
    * <p data-diff-id="ct-diff-id-3f71545b-7c72-4d7f-a972-33447a31f900">入住客人信息</p>
    */
    @SerializedName("customer")
    private Customer customer;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public Long getCheckinId() {
        return checkinId;
    }
    public void setCheckinId(Long checkinId) {
        this.checkinId = checkinId;
    }
    public Customer getCustomer() {
        return customer;
    }
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }


    @Override
    public MeituanResponse<AddShareWithCustomerResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<AddShareWithCustomerResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "AddShareWithCustomerRequest{" + "hotelId=" + hotelId + "," + "checkinId=" + checkinId + "," + "customer=" + customer + "}";
    }
}
