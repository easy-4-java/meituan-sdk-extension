package com.meituan.sdk.model.ddzhkh.shangpin.productProductUpdateProductStock;

import java.util.List;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-af487841-a5b1-47ae-a644-c1b7cc057b9b"><span style="color: rgb(31, 45, 61)">售卖SKU列表， 注：类型为对象类型，详见扩展参数item_stocks &nbsp; &nbsp;</span></p>
* This file was automatically generated.
*/
public class ItemStock {
    /**
    * <p data-diff-id="ct-diff-id-c6203b48-f657-4e9c-90a0-f1e82333f46e"><span style="color: rgb(31, 45, 61)">售卖SKU ID&nbsp;</span></p>
    */
    @NotNull(message = "itemId不能为空")
    @SerializedName("itemId")
    private Long itemId;
    /**
    * <p data-diff-id="ct-diff-id-f528ea48-95ac-48d3-b53c-cf0903643963"><span style="color: rgb(31, 45, 61)">SKU商品库存 &nbsp;&nbsp;</span></p>
    */
    @SerializedName("stock")
    private Integer stock;
    /**
    * <p data-diff-id="ct-diff-id-cb24b5ba-189b-4666-b065-249c9eb13bc1"><span style="color: rgb(31, 45, 61)">SKU分门店库存更新数组（和 stock 有且只有一个） 注：类型为对象类型，详见扩展参数shop_stocks &nbsp;&nbsp;</span></p>
    */
    @SerializedName("shopStocks")
    private List<ShopStock> shopStocks;

    public Long getItemId() {
        return itemId;
    }
    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }
    public Integer getStock() {
        return stock;
    }
    public void setStock(Integer stock) {
        this.stock = stock;
    }
    public List<ShopStock> getShopStocks() {
        return shopStocks;
    }
    public void setShopStocks(List<ShopStock> shopStocks) {
        this.shopStocks = shopStocks;
    }




    @Override
    public String toString() {
        return "ItemStock{" + "itemId=" + itemId + "," + "stock=" + stock + "," + "shopStocks=" + shopStocks + "}";
    }
}
