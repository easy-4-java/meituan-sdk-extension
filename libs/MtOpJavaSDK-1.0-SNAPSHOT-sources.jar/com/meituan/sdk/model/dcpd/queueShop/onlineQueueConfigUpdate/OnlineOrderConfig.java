package com.meituan.sdk.model.dcpd.queueShop.onlineQueueConfigUpdate;

import java.util.List;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-ccfdbf3a-d5de-45b8-b0a2-be940d06770d">在线排队设置</p>
* This file was automatically generated.
*/
public class OnlineOrderConfig {
    /**
    * <p data-diff-id="ct-diff-id-67d54cae-5cb1-46c7-834c-0b61327c8802">是否支持线上取号</p>
    */
    @NotNull(message = "supportOnlineGetOrder不能为空")
    @SerializedName("supportOnlineGetOrder")
    private Boolean supportOnlineGetOrder;
    /**
    * <p data-diff-id="ct-diff-id-dd0e0ac5-7fa0-49ca-933d-c810a4601073">是否进行线上取号限制</p>
    */
    @NotNull(message = "numberLimitSwitch不能为空")
    @SerializedName("numberLimitSwitch")
    private Boolean numberLimitSwitch;
    /**
    * <p data-diff-id="ct-diff-id-819c223a-75c5-4df3-99b7-805d8d5db296">取号限制的方式，0-不限制，1-分时段全桌型限量，2-按天全桌型限量，3-分时段分桌型限量，4-按天分桌型限量</p>
    */
    @NotNull(message = "limitType不能为空")
    @SerializedName("limitType")
    private Integer limitType;
    /**
    * <p data-diff-id="ct-diff-id-afc3d4da-3e28-4024-b086-7e39025a8d2b">取号数量限制明细</p>
    */
    @SerializedName("numberLimitDetails")
    private List<NumberLimitDetail> numberLimitDetails;

    public Boolean getSupportOnlineGetOrder() {
        return supportOnlineGetOrder;
    }
    public void setSupportOnlineGetOrder(Boolean supportOnlineGetOrder) {
        this.supportOnlineGetOrder = supportOnlineGetOrder;
    }
    public Boolean getNumberLimitSwitch() {
        return numberLimitSwitch;
    }
    public void setNumberLimitSwitch(Boolean numberLimitSwitch) {
        this.numberLimitSwitch = numberLimitSwitch;
    }
    public Integer getLimitType() {
        return limitType;
    }
    public void setLimitType(Integer limitType) {
        this.limitType = limitType;
    }
    public List<NumberLimitDetail> getNumberLimitDetails() {
        return numberLimitDetails;
    }
    public void setNumberLimitDetails(List<NumberLimitDetail> numberLimitDetails) {
        this.numberLimitDetails = numberLimitDetails;
    }




    @Override
    public String toString() {
        return "OnlineOrderConfig{" + "supportOnlineGetOrder=" + supportOnlineGetOrder + "," + "numberLimitSwitch=" + numberLimitSwitch + "," + "limitType=" + limitType + "," + "numberLimitDetails=" + numberLimitDetails + "}";
    }
}
