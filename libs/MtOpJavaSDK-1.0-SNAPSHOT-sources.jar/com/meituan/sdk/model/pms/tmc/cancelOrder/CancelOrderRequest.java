package com.meituan.sdk.model.pms.tmc.cancelOrder;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 取消订单
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/tmc/cancelOrder",
    businessId = 57,
    apiVersion = "10028",
    apiName = "cancel_order",
    needAuth = true
)
public class CancelOrderRequest implements MeituanRequest<Boolean> {
    /**
    * <p data-diff-id="ct-diff-id-8af2251a-9a84-4026-af48-e5172faa34e3">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-0151edc4-487b-414f-9d3f-61c1795aa443">渠道订单号</p>
    */
    @NotBlank(message = "channelOrderSn不能为空")
    @SerializedName("channelOrderSn")
    private String channelOrderSn;
    /**
    * <p data-diff-id="ct-diff-id-05ad8511-6074-41df-881b-eb669a0d681e">PMS订单号</p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-ef7eb2e9-ca5b-43d4-9bf8-07f046edd3e9">取消原因</p>
    */
    @NotBlank(message = "memo不能为空")
    @SerializedName("memo")
    private String memo;
    /**
    * <p data-diff-id="ct-diff-id-b1c6a219-198f-42d5-b8e1-99a2c74e57fc">渠道，海外渠道时必传，仅支持单渠道，参考值分别为: Agoda、Booking、Expedia</p>
    */
    @SerializedName("channel")
    private String channel;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getChannelOrderSn() {
        return channelOrderSn;
    }
    public void setChannelOrderSn(String channelOrderSn) {
        this.channelOrderSn = channelOrderSn;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getMemo() {
        return memo;
    }
    public void setMemo(String memo) {
        this.memo = memo;
    }
    public String getChannel() {
        return channel;
    }
    public void setChannel(String channel) {
        this.channel = channel;
    }


    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "CancelOrderRequest{" + "hotelId=" + hotelId + "," + "channelOrderSn=" + channelOrderSn + "," + "orderId=" + orderId + "," + "memo=" + memo + "," + "channel=" + channel + "}";
    }
}
