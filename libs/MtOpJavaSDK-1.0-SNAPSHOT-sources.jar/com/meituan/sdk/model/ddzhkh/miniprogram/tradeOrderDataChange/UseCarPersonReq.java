package com.meituan.sdk.model.ddzhkh.miniprogram.tradeOrderDataChange;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-6b016b20-e768-4fc4-ab7c-17b3c0f8ced2">用车人信息，预约成功必传</p>
* This file was automatically generated.
*/
public class UseCarPersonReq {
    /**
    * <p data-diff-id="ct-diff-id-c8122acc-b9b6-49e0-b2ec-667910f5e5ac">用车人姓名</p>
    */
    @SerializedName("personName")
    private String personName;
    /**
    * <p data-diff-id="ct-diff-id-ad52e46f-115f-4cfc-b4b5-5293999b5ff0">用车人手机号</p>
    */
    @SerializedName("mobileNo")
    private String mobileNo;
    /**
    * <p data-diff-id="ct-diff-id-245e7dad-2ec3-4bc0-89bd-cd42f5a55cdc">用车人证件类型：</p><p data-diff-id="ct-diff-id-cb877582-fa68-4da9-b638-9676a3d1fd76">1-身份证</p><p data-diff-id="ct-diff-id-a2f73ab9-7e39-4d78-99e1-a52ad53e8bf3">2-护照</p><p data-diff-id="ct-diff-id-34b9d02a-5a46-4f12-8caa-db606baaee35">3-台胞证</p><p data-diff-id="ct-diff-id-0cdb4ed5-50ec-4c18-b6a9-38caf291b601">4-港澳居民来往内地通行证</p><p data-diff-id="ct-diff-id-6381ac98-9870-4c50-bcf6-ddf956bb587b">5-港澳台居住证</p><p data-diff-id="ct-diff-id-387448ef-bebb-4efc-9731-ab7bd3e5da3d">6-外国人永久居留身份证</p>
    */
    @SerializedName("certificateType")
    private Integer certificateType;
    /**
    * <p data-diff-id="ct-diff-id-bf518723-de67-4346-a197-9981eceac47e">用车人证件号码</p>
    */
    @SerializedName("certificateNo")
    private String certificateNo;

    public String getPersonName() {
        return personName;
    }
    public void setPersonName(String personName) {
        this.personName = personName;
    }
    public String getMobileNo() {
        return mobileNo;
    }
    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }
    public Integer getCertificateType() {
        return certificateType;
    }
    public void setCertificateType(Integer certificateType) {
        this.certificateType = certificateType;
    }
    public String getCertificateNo() {
        return certificateNo;
    }
    public void setCertificateNo(String certificateNo) {
        this.certificateNo = certificateNo;
    }




    @Override
    public String toString() {
        return "UseCarPersonReq{" + "personName=" + personName + "," + "mobileNo=" + mobileNo + "," + "certificateType=" + certificateType + "," + "certificateNo=" + certificateNo + "}";
    }
}
