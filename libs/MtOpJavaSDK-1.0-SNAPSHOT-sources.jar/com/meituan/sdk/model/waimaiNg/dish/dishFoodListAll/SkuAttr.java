package com.meituan.sdk.model.waimaiNg.dish.dishFoodListAll;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* 售卖属性。spuAttr与skuAttr中的属性数量相同且属性内容相同（mode=2)
* This file was automatically generated.
*/
public class SkuAttr {
    /**
    * 属性名称。example="冷热"，name长度不能大于10
    */
    @NotBlank(message = "name不能为空")
    @SerializedName("name")
    private String name;
    /**
    * 属性编号。例：温度(1)，口味(2)等
    */
    @NotNull(message = "no不能为空")
    @SerializedName("no")
    private Long no;
    /**
    * sku唯一标识
    */
    @NotBlank(message = "skuId不能为空")
    @SerializedName("skuId")
    private String skuId;
    /**
    * 属性值。example="冷"，value长度不能大于10
    */
    @NotBlank(message = "value不能为空")
    @SerializedName("value")
    private String value;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Long getNo() {
        return no;
    }
    public void setNo(Long no) {
        this.no = no;
    }
    public String getSkuId() {
        return skuId;
    }
    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }




    @Override
    public String toString() {
        return "SkuAttr{" + "name=" + name + "," + "no=" + no + "," + "skuId=" + skuId + "," + "value=" + value + "}";
    }
}
