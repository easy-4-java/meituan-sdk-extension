package com.meituan.sdk.model.ddzh.ugc.ugcQuerystar;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 查询门店星级和单项分
* This file was automatically generated.
*/
public class UgcQuerystarResponse {
    /**
    * 点评平台和美团平台一致，50代表5星
    */
    @SerializedName("shopStar")
    private Integer shopStar;
    /**
    * 单项分,部分类目为空
    */
    @SerializedName("subScore")
    private List<SubScore> subScore;
    /**
    * 门店星级
    */
    @SerializedName("fiveScore")
    private String fiveScore;

    public Integer getShopStar() {
        return shopStar;
    }
    public void setShopStar(Integer shopStar) {
        this.shopStar = shopStar;
    }
    public List<SubScore> getSubScore() {
        return subScore;
    }
    public void setSubScore(List<SubScore> subScore) {
        this.subScore = subScore;
    }
    public String getFiveScore() {
        return fiveScore;
    }
    public void setFiveScore(String fiveScore) {
        this.fiveScore = fiveScore;
    }




    @Override
    public String toString() {
        return "UgcQuerystarResponse{" + "shopStar=" + shopStar + "," + "subScore=" + subScore + "," + "fiveScore=" + fiveScore + "}";
    }
}
