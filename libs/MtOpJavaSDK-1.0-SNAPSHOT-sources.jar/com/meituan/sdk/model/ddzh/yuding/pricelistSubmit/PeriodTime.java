package com.meituan.sdk.model.ddzh.yuding.pricelistSubmit;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-a89bd86f-940a-4450-9f0f-9f6e89a716d3">商品时段信息</p>
* This file was automatically generated.
*/
public class PeriodTime {
    /**
    * <p data-diff-id="ct-diff-id-44a2aa9d-bb06-4653-ac8a-581b1381cd5b">开始时间</p>
    */
    @NotBlank(message = "beginTime不能为空")
    @SerializedName("beginTime")
    private String beginTime;
    /**
    * <p data-diff-id="ct-diff-id-48f54475-40c6-42ec-98d1-641e72b6051f">结束时间</p>
    */
    @NotBlank(message = "endTime不能为空")
    @SerializedName("endTime")
    private String endTime;
    /**
    * <p data-diff-id="ct-diff-id-a178b366-5ecb-4cbd-8ef2-f7404274f1c2">结束时间是否跨天：</p><p data-diff-id="ct-diff-id-a05d19c7-4857-4a11-938b-9758031b6229">0 - 结束时间不跨天</p><p data-diff-id="ct-diff-id-720c1b2e-6ac4-40a1-8f34-6652518993d4">1 - 结束时间跨天</p>
    */
    @NotNull(message = "endTimeNextDay不能为空")
    @SerializedName("endTimeNextDay")
    private Integer endTimeNextDay;
    /**
    * <p data-diff-id="ct-diff-id-24940edb-d16c-4c52-8c86-d41711fc61cb">时间类型，目前美团支持进场模式和包段模式两种</p><p data-diff-id="ct-diff-id-1c356eca-8d8a-4282-9c22-c37a3db0361c">1 - 包段模式</p><p data-diff-id="ct-diff-id-1586ce3c-3b43-4e07-9ca9-a20408e39aad">2 - 进场模式</p>
    */
    @NotNull(message = "timeSelectType不能为空")
    @SerializedName("timeSelectType")
    private Integer timeSelectType;

    public String getBeginTime() {
        return beginTime;
    }
    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime;
    }
    public String getEndTime() {
        return endTime;
    }
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    public Integer getEndTimeNextDay() {
        return endTimeNextDay;
    }
    public void setEndTimeNextDay(Integer endTimeNextDay) {
        this.endTimeNextDay = endTimeNextDay;
    }
    public Integer getTimeSelectType() {
        return timeSelectType;
    }
    public void setTimeSelectType(Integer timeSelectType) {
        this.timeSelectType = timeSelectType;
    }




    @Override
    public String toString() {
        return "PeriodTime{" + "beginTime=" + beginTime + "," + "endTime=" + endTime + "," + "endTimeNextDay=" + endTimeNextDay + "," + "timeSelectType=" + timeSelectType + "}";
    }
}
