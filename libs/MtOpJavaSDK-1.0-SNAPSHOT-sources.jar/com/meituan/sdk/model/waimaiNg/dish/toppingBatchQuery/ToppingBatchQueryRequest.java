package com.meituan.sdk.model.waimaiNg.dish.toppingBatchQuery;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 查询小料信息接口（根据小料code查询）
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/dish/topping/batchQuery",
    businessId = 2,
    apiVersion = "10113",
    apiName = "topping_batch_query",
    needAuth = true
)
public class ToppingBatchQueryRequest implements MeituanRequest<List<OpenTopping>> {
    /**
    * <p data-diff-id="ct-diff-id-b26e5db3-caa5-4321-a615-e3674951f390">查询小料的toppingCode</p>
    */
    @NotEmpty(message = "toppingCodes不能为空")
    @SerializedName("toppingCodes")
    private List<String> toppingCodes;

    public List<String> getToppingCodes() {
        return toppingCodes;
    }
    public void setToppingCodes(List<String> toppingCodes) {
        this.toppingCodes = toppingCodes;
    }


    @Override
    public MeituanResponse<List<OpenTopping>> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<List<OpenTopping>>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ToppingBatchQueryRequest{" + "toppingCodes=" + toppingCodes + "}";
    }
}
