package com.meituan.sdk.model.waimaiNg.order.batchQuerySmsSendResult;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 查询短信发送结果
* This file was automatically generated.
*/
public class BatchQuerySmsSendResultResponse {
    /**
    * 查询成功数据，短信发送用户的结果，包括短信发送成功和失败两种场景，通过具体字段区分
    */
    @SerializedName("success_list")
    private List<Success> successList;
    /**
    * 查询失败数据，比如消息id异常或权限异常场景，不包括短信发送失败数据
    */
    @SerializedName("error_list")
    private List<Error> errorList;
    /**
    * 1-全部操作成功，如需获取具体成功信息可以查看success_list或者success_map字段；2-部分成功，成功的数据存储在success_list或者success_map字段，失败的数据存在error_list字段中；3-全部操作失败，失败的数据存在error_list字段中；4-请求失败，一般为签名或限流问题，关注error_list字段中的具体描述即可
    */
    @SerializedName("code")
    private Integer code;
    /**
    * 操作错误时的描述信息
    */
    @SerializedName("msg")
    private String msg;

    public List<Success> getSuccessList() {
        return successList;
    }
    public void setSuccessList(List<Success> successList) {
        this.successList = successList;
    }
    public List<Error> getErrorList() {
        return errorList;
    }
    public void setErrorList(List<Error> errorList) {
        this.errorList = errorList;
    }
    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }




    @Override
    public String toString() {
        return "BatchQuerySmsSendResultResponse{" + "successList=" + successList + "," + "errorList=" + errorList + "," + "code=" + code + "," + "msg=" + msg + "}";
    }
}
