package com.meituan.sdk.model.pms.accounting.completeGuaranteeItem;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 完成预授权
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/accounting/completeGuaranteeItem",
    businessId = 57,
    apiVersion = "10012",
    apiName = "complete_guarantee_item",
    needAuth = true
)
public class CompleteGuaranteeItemRequest implements MeituanRequest<CompleteGuaranteeItemResponse> {
    /**
    * <p data-diff-id="ct-diff-id-e8f8083c-1cdb-472c-9425-a4acd35f9205">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-a8dc56e7-d395-43dd-9812-0735ec9e7274"><span style="color: rgba(0, 0, 0, 0.65)">预授权ID</span></p>
    */
    @NotNull(message = "guaranteeItemId不能为空")
    @SerializedName("guaranteeItemId")
    private Long guaranteeItemId;
    /**
    * <p data-diff-id="ct-diff-id-61f16733-b79e-429e-9a6f-9efc8311e3ee">需要预授权完成金额</p>
    */
    @NotBlank(message = "usedAmount不能为空")
    @SerializedName("usedAmount")
    private String usedAmount;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public Long getGuaranteeItemId() {
        return guaranteeItemId;
    }
    public void setGuaranteeItemId(Long guaranteeItemId) {
        this.guaranteeItemId = guaranteeItemId;
    }
    public String getUsedAmount() {
        return usedAmount;
    }
    public void setUsedAmount(String usedAmount) {
        this.usedAmount = usedAmount;
    }


    @Override
    public MeituanResponse<CompleteGuaranteeItemResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<CompleteGuaranteeItemResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "CompleteGuaranteeItemRequest{" + "hotelId=" + hotelId + "," + "guaranteeItemId=" + guaranteeItemId + "," + "usedAmount=" + usedAmount + "}";
    }
}
