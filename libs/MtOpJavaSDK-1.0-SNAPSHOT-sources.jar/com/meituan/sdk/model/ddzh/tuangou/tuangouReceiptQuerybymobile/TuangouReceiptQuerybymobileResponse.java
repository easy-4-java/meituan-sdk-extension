package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptQuerybymobile;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 手机号查询可用团购券
* This file was automatically generated.
*/
public class TuangouReceiptQuerybymobileResponse {
    @SerializedName("result")
    private List<UserReceiptDTO> result;

    public List<UserReceiptDTO> getResult() {
        return result;
    }
    public void setResult(List<UserReceiptDTO> result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "TuangouReceiptQuerybymobileResponse{" + "result=" + result + "}";
    }
}
