package com.meituan.sdk.model.ddzh.tuangou.tuangouReceiptBatchReverseconsume;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 批量撤销验券
* This file was automatically generated.
*/
public class TuangouReceiptBatchReverseconsumeResponse {
    @SerializedName("result")
    private List<ReceiptConsumeResult> result;

    public List<ReceiptConsumeResult> getResult() {
        return result;
    }
    public void setResult(List<ReceiptConsumeResult> result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "TuangouReceiptBatchReverseconsumeResponse{" + "result=" + result + "}";
    }
}
