package com.meituan.sdk.model.ddzhkh.shangpin.productUnitedQueryProduct;

import com.google.gson.annotations.SerializedName;

/**
* sku信息列表
* This file was automatically generated.
*/
public class OpenSkuDTO {
    /**
    * skuId
    */
    @SerializedName("skuId")
    private Long skuId;
    /**
    * sku名称
    */
    @SerializedName("skuName")
    private String skuName;
    /**
    * 三方skuId
    */
    @SerializedName("thirdPartySkuId")
    private String thirdPartySkuId;
    /**
    * 售卖价
    */
    @SerializedName("sellPrice")
    private String sellPrice;
    /**
    * 原价
    */
    @SerializedName("marketPrice")
    private String marketPrice;
    /**
    * 库存类型，0-代表不限制库存 1-代表限制
    */
    @SerializedName("stockType")
    private Integer stockType;
    /**
    * 库存总量
    */
    @SerializedName("totalStock")
    private Integer totalStock;
    /**
    * 扩展信息，通常是非必填的或非全行业通用的字段
    */
    @SerializedName("ext")
    private Map ext;

    public Long getSkuId() {
        return skuId;
    }
    public void setSkuId(Long skuId) {
        this.skuId = skuId;
    }
    public String getSkuName() {
        return skuName;
    }
    public void setSkuName(String skuName) {
        this.skuName = skuName;
    }
    public String getThirdPartySkuId() {
        return thirdPartySkuId;
    }
    public void setThirdPartySkuId(String thirdPartySkuId) {
        this.thirdPartySkuId = thirdPartySkuId;
    }
    public String getSellPrice() {
        return sellPrice;
    }
    public void setSellPrice(String sellPrice) {
        this.sellPrice = sellPrice;
    }
    public String getMarketPrice() {
        return marketPrice;
    }
    public void setMarketPrice(String marketPrice) {
        this.marketPrice = marketPrice;
    }
    public Integer getStockType() {
        return stockType;
    }
    public void setStockType(Integer stockType) {
        this.stockType = stockType;
    }
    public Integer getTotalStock() {
        return totalStock;
    }
    public void setTotalStock(Integer totalStock) {
        this.totalStock = totalStock;
    }
    public Map getExt() {
        return ext;
    }
    public void setExt(Map ext) {
        this.ext = ext;
    }




    @Override
    public String toString() {
        return "OpenSkuDTO{" + "skuId=" + skuId + "," + "skuName=" + skuName + "," + "thirdPartySkuId=" + thirdPartySkuId + "," + "sellPrice=" + sellPrice + "," + "marketPrice=" + marketPrice + "," + "stockType=" + stockType + "," + "totalStock=" + totalStock + "," + "ext=" + ext + "}";
    }
}
