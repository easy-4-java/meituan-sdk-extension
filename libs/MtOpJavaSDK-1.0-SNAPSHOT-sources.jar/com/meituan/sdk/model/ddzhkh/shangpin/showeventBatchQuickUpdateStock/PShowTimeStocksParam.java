package com.meituan.sdk.model.ddzhkh.shangpin.showeventBatchQuickUpdateStock;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-5a5c92b0-51e3-4b50-bb86-792ee56ee93b"><span style="color: rgba(0, 0, 0, 0.65)">场次信息</span></p>
* This file was automatically generated.
*/
public class PShowTimeStocksParam {
    /**
    * <p data-diff-id="ct-diff-id-59afc509-a5b5-4efa-b24c-24faf20f461f"><em><span style="color: rgba(0, 0, 0, 0.65)">演出场次ID</span></em></p>
    */
    @NotBlank(message = "thirdPartyShowtimeId不能为空")
    @SerializedName("thirdPartyShowtimeId")
    private String thirdPartyShowtimeId;
    /**
    * <p data-diff-id="ct-diff-id-83dfc1e5-40c6-411e-992b-7ed2cc34f3fb"><span style="color: rgba(0, 0, 0, 0.65)">票档信息</span></p>
    */
    @NotEmpty(message = "ticketGrade不能为空")
    @SerializedName("ticketGrade")
    private List<PTicketStockParam> ticketGrade;

    public String getThirdPartyShowtimeId() {
        return thirdPartyShowtimeId;
    }
    public void setThirdPartyShowtimeId(String thirdPartyShowtimeId) {
        this.thirdPartyShowtimeId = thirdPartyShowtimeId;
    }
    public List<PTicketStockParam> getTicketGrade() {
        return ticketGrade;
    }
    public void setTicketGrade(List<PTicketStockParam> ticketGrade) {
        this.ticketGrade = ticketGrade;
    }




    @Override
    public String toString() {
        return "PShowTimeStocksParam{" + "thirdPartyShowtimeId=" + thirdPartyShowtimeId + "," + "ticketGrade=" + ticketGrade + "}";
    }
}
