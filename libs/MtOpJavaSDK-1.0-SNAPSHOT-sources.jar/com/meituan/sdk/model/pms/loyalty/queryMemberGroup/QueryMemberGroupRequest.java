package com.meituan.sdk.model.pms.loyalty.queryMemberGroup;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询会员群体
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/loyalty/queryGroupPeoples",
    businessId = 57,
    apiVersion = "10012",
    apiName = "query_member_group",
    needAuth = true
)
public class QueryMemberGroupRequest implements MeituanRequest<QueryMemberGroupResponse> {
    /**
    * <p data-diff-id="ct-diff-id-869a7ef3-31e8-4ea9-8197-45a580a72bb4">分组id</p>
    */
    @NotNull(message = "groupId不能为空")
    @SerializedName("groupId")
    private Long groupId;
    /**
    * <p data-diff-id="ct-diff-id-ea9ff362-e521-4d66-bbbb-9dd853a6fd4a">当前页</p>
    */
    @NotNull(message = "currentPageNum不能为空")
    @SerializedName("currentPageNum")
    private Integer currentPageNum;
    /**
    * <p data-diff-id="ct-diff-id-d2e85ec7-2616-4974-a7a2-418ffdff31f1">每页大小</p>
    */
    @NotNull(message = "pageSize不能为空")
    @SerializedName("pageSize")
    private Integer pageSize;

    public Long getGroupId() {
        return groupId;
    }
    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }
    public Integer getCurrentPageNum() {
        return currentPageNum;
    }
    public void setCurrentPageNum(Integer currentPageNum) {
        this.currentPageNum = currentPageNum;
    }
    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }


    @Override
    public MeituanResponse<QueryMemberGroupResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<QueryMemberGroupResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "QueryMemberGroupRequest{" + "groupId=" + groupId + "," + "currentPageNum=" + currentPageNum + "," + "pageSize=" + pageSize + "}";
    }
}
