package com.meituan.sdk.model.ddzhkh.shangpin.productShopproductsGet;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 产品信息列表
* This file was automatically generated.
*/
public class ShopProductTO {
    /**
    * 状态，0-无效，1-上架，2-下架
    */
    @SerializedName("status")
    private Integer status;
    /**
    * 产品ID
    */
    @SerializedName("productId")
    private Long productId;
    /**
    * 产品名称
    */
    @SerializedName("productName")
    private String productName;
    /**
    * 三方产品id
    */
    @SerializedName("appProductId")
    private String appProductId;
    /**
    * 流程状态，10-编辑中，12-已提交，20-审核中，22-审核通过，24-审核驳回，30-已发布
    */
    @SerializedName("flowStatus")
    private Integer flowStatus;
    /**
    * 项目信息列表
    */
    @SerializedName("shopProductItems")
    private List<ShopProductItem> shopProductItems;

    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Long getProductId() {
        return productId;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public String getAppProductId() {
        return appProductId;
    }
    public void setAppProductId(String appProductId) {
        this.appProductId = appProductId;
    }
    public Integer getFlowStatus() {
        return flowStatus;
    }
    public void setFlowStatus(Integer flowStatus) {
        this.flowStatus = flowStatus;
    }
    public List<ShopProductItem> getShopProductItems() {
        return shopProductItems;
    }
    public void setShopProductItems(List<ShopProductItem> shopProductItems) {
        this.shopProductItems = shopProductItems;
    }




    @Override
    public String toString() {
        return "ShopProductTO{" + "status=" + status + "," + "productId=" + productId + "," + "productName=" + productName + "," + "appProductId=" + appProductId + "," + "flowStatus=" + flowStatus + "," + "shopProductItems=" + shopProductItems + "}";
    }
}
