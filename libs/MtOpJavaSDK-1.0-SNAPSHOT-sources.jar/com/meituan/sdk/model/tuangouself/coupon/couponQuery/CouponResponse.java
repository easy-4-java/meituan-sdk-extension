package com.meituan.sdk.model.tuangouself.coupon.couponQuery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class CouponResponse {
    /**
    * 项目ID
    */
    @SerializedName("dealId")
    private Integer dealId;
    /**
    * 项目名称
    */
    @SerializedName("dealTitle")
    private String dealTitle;
    /**
    * 项目类型，0套餐，1代金券
    */
    @SerializedName("dealType")
    private Integer dealType;
    /**
    * 券码
    */
    @SerializedName("code")
    private String code;
    /**
    * 券有效期开始时间，单位秒
    */
    @SerializedName("couponStartTime")
    private Long couponStartTime;
    /**
    * 券有效期结束时间，单位秒
    */
    @SerializedName("couponEndTime")
    private Long couponEndTime;
    /**
    * 券对应的订单id
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * 项目的市场价，用于展示
    */
    @SerializedName("buyPrice")
    private String buyPrice;
    /**
    * 下单时团购券售卖价格
    */
    @SerializedName("salePrice")
    private String salePrice;
    /**
    * 商家实际收款金额
    */
    @SerializedName("settlePrice")
    private String settlePrice;
    /**
    * 券码购买平台（0美团、1点评）
    */
    @SerializedName("platform")
    private Integer platform;
    /**
    * 券使用规则
    */
    @SerializedName("useRule")
    private UserRule useRule;
    /**
    * deal对应的菜品信息
    */
    @SerializedName("menuInfo")
    private List<DealMenu> menuInfo;
    /**
    * 是否可用
    */
    @SerializedName("canUse")
    private Boolean canUse;
    /**
    * 非使用时间是否可以验券。true:是；false:否
    */
    @SerializedName("canUseAnyTime")
    private Boolean canUseAnyTime;
    /**
    * 不可用原因
    */
    @SerializedName("unavailableReason")
    private String unavailableReason;
    /**
    * 开店宝上单商家录入的项目名称，仅套餐券使用
    */
    @SerializedName("rawTitle")
    private String rawTitle;
    /**
    * 第三方商品ID(三方上单填入）。
    */
    @SerializedName("thirdProductId")
    private String thirdProductId;
    /**
    * 开店宝商品列表标题。
    */
    @SerializedName("platformTitle")
    private String platformTitle;
    /**
    * C端场景中提单页、支付结果页、查看券码和订单页面的项目标题以及开店宝核销后展示的标题。C端场景包括美团App，点评App，美团小程序。
    */
    @SerializedName("shortAttrTitle")
    private String shortAttrTitle;
    /**
    * 预充值商家促
    */
    @SerializedName("bizCostByAccount")
    private String bizCostByAccount;
    /**
    * 随单扣商家促
    */
    @SerializedName("bizCost")
    private String bizCost;
    /**
    * 阶梯次卡信息
    */
    @SerializedName("steppedTimeCard")
    private SteppedTimeCardPriceYuanDTO steppedTimeCard;
    /**
    * 次卡类型，0:不是次卡，1:普通次卡，2:阶梯次卡
    */
    @SerializedName("timeCardType")
    private Integer timeCardType;
    /**
    * 项目ID
    */
    @SerializedName("longDealId")
    private Long longDealId;

    public Integer getDealId() {
        return dealId;
    }
    public void setDealId(Integer dealId) {
        this.dealId = dealId;
    }
    public String getDealTitle() {
        return dealTitle;
    }
    public void setDealTitle(String dealTitle) {
        this.dealTitle = dealTitle;
    }
    public Integer getDealType() {
        return dealType;
    }
    public void setDealType(Integer dealType) {
        this.dealType = dealType;
    }
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public Long getCouponStartTime() {
        return couponStartTime;
    }
    public void setCouponStartTime(Long couponStartTime) {
        this.couponStartTime = couponStartTime;
    }
    public Long getCouponEndTime() {
        return couponEndTime;
    }
    public void setCouponEndTime(Long couponEndTime) {
        this.couponEndTime = couponEndTime;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getBuyPrice() {
        return buyPrice;
    }
    public void setBuyPrice(String buyPrice) {
        this.buyPrice = buyPrice;
    }
    public String getSalePrice() {
        return salePrice;
    }
    public void setSalePrice(String salePrice) {
        this.salePrice = salePrice;
    }
    public String getSettlePrice() {
        return settlePrice;
    }
    public void setSettlePrice(String settlePrice) {
        this.settlePrice = settlePrice;
    }
    public Integer getPlatform() {
        return platform;
    }
    public void setPlatform(Integer platform) {
        this.platform = platform;
    }
    public UserRule getUseRule() {
        return useRule;
    }
    public void setUseRule(UserRule useRule) {
        this.useRule = useRule;
    }
    public List<DealMenu> getMenuInfo() {
        return menuInfo;
    }
    public void setMenuInfo(List<DealMenu> menuInfo) {
        this.menuInfo = menuInfo;
    }
    public Boolean getCanUse() {
        return canUse;
    }
    public void setCanUse(Boolean canUse) {
        this.canUse = canUse;
    }
    public Boolean getCanUseAnyTime() {
        return canUseAnyTime;
    }
    public void setCanUseAnyTime(Boolean canUseAnyTime) {
        this.canUseAnyTime = canUseAnyTime;
    }
    public String getUnavailableReason() {
        return unavailableReason;
    }
    public void setUnavailableReason(String unavailableReason) {
        this.unavailableReason = unavailableReason;
    }
    public String getRawTitle() {
        return rawTitle;
    }
    public void setRawTitle(String rawTitle) {
        this.rawTitle = rawTitle;
    }
    public String getThirdProductId() {
        return thirdProductId;
    }
    public void setThirdProductId(String thirdProductId) {
        this.thirdProductId = thirdProductId;
    }
    public String getPlatformTitle() {
        return platformTitle;
    }
    public void setPlatformTitle(String platformTitle) {
        this.platformTitle = platformTitle;
    }
    public String getShortAttrTitle() {
        return shortAttrTitle;
    }
    public void setShortAttrTitle(String shortAttrTitle) {
        this.shortAttrTitle = shortAttrTitle;
    }
    public String getBizCostByAccount() {
        return bizCostByAccount;
    }
    public void setBizCostByAccount(String bizCostByAccount) {
        this.bizCostByAccount = bizCostByAccount;
    }
    public String getBizCost() {
        return bizCost;
    }
    public void setBizCost(String bizCost) {
        this.bizCost = bizCost;
    }
    public SteppedTimeCardPriceYuanDTO getSteppedTimeCard() {
        return steppedTimeCard;
    }
    public void setSteppedTimeCard(SteppedTimeCardPriceYuanDTO steppedTimeCard) {
        this.steppedTimeCard = steppedTimeCard;
    }
    public Integer getTimeCardType() {
        return timeCardType;
    }
    public void setTimeCardType(Integer timeCardType) {
        this.timeCardType = timeCardType;
    }
    public Long getLongDealId() {
        return longDealId;
    }
    public void setLongDealId(Long longDealId) {
        this.longDealId = longDealId;
    }




    @Override
    public String toString() {
        return "CouponResponse{" + "dealId=" + dealId + "," + "dealTitle=" + dealTitle + "," + "dealType=" + dealType + "," + "code=" + code + "," + "couponStartTime=" + couponStartTime + "," + "couponEndTime=" + couponEndTime + "," + "orderId=" + orderId + "," + "buyPrice=" + buyPrice + "," + "salePrice=" + salePrice + "," + "settlePrice=" + settlePrice + "," + "platform=" + platform + "," + "useRule=" + useRule + "," + "menuInfo=" + menuInfo + "," + "canUse=" + canUse + "," + "canUseAnyTime=" + canUseAnyTime + "," + "unavailableReason=" + unavailableReason + "," + "rawTitle=" + rawTitle + "," + "thirdProductId=" + thirdProductId + "," + "platformTitle=" + platformTitle + "," + "shortAttrTitle=" + shortAttrTitle + "," + "bizCostByAccount=" + bizCostByAccount + "," + "bizCost=" + bizCost + "," + "steppedTimeCard=" + steppedTimeCard + "," + "timeCardType=" + timeCardType + "," + "longDealId=" + longDealId + "}";
    }
}
