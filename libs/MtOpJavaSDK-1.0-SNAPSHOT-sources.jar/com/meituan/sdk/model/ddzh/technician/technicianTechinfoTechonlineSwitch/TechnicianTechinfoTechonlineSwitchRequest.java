package com.meituan.sdk.model.ddzh.technician.technicianTechinfoTechonlineSwitch;

import com.meituan.sdk.annotations.ApiMeta;
import java.lang.Void;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* （三嫂）手艺人上下线
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/technician/techOnline/switch",
    businessId = 58,
    apiVersion = "10002",
    apiName = "technician_techinfo_techonline_switch",
    needAuth = true
)
public class TechnicianTechinfoTechonlineSwitchRequest implements MeituanRequest<Void> {
    /**
    * <p data-diff-id="ct-diff-id-9eb9a198-71a2-4ac0-84d9-96f462d0dc87">数据源来源，熊猫固定传1</p>
    */
    @NotNull(message = "sourceType不能为空")
    @SerializedName("sourceType")
    private Integer sourceType;
    /**
    * <p data-diff-id="ct-diff-id-08a3e7d8-c3c3-4987-846a-79261ac027a4">熊猫系统的手艺人id</p>
    */
    @NotNull(message = "sourceTechId不能为空")
    @SerializedName("sourceTechId")
    private Long sourceTechId;
    /**
    * <p data-diff-id="ct-diff-id-bf2a26e9-988a-4c08-8ff4-aca168f01708">状态 1-在线 2-下线</p>
    */
    @NotNull(message = "switchOnline不能为空")
    @SerializedName("switchOnline")
    private Integer switchOnline;

    public Integer getSourceType() {
        return sourceType;
    }
    public void setSourceType(Integer sourceType) {
        this.sourceType = sourceType;
    }
    public Long getSourceTechId() {
        return sourceTechId;
    }
    public void setSourceTechId(Long sourceTechId) {
        this.sourceTechId = sourceTechId;
    }
    public Integer getSwitchOnline() {
        return switchOnline;
    }
    public void setSwitchOnline(Integer switchOnline) {
        this.switchOnline = switchOnline;
    }


    @Override
    public MeituanResponse<Void> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Void>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TechnicianTechinfoTechonlineSwitchRequest{" + "sourceType=" + sourceType + "," + "sourceTechId=" + sourceTechId + "," + "switchOnline=" + switchOnline + "}";
    }
}
