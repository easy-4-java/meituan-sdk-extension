package com.meituan.sdk.model.pms.accounting.addGuaranteeItem;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 新增预授权
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/accounting/addGuaranteeItem",
    businessId = 57,
    apiVersion = "10015",
    apiName = "add_guarantee_item",
    needAuth = true
)
public class AddGuaranteeItemRequest implements MeituanRequest<AddGuaranteeItemResponse> {
    /**
    * <p data-diff-id="ct-diff-id-198febaf-43d0-4cf4-b062-5ae9bc1aacaa">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-2afa2a18-5e63-4b4c-a8fb-d07a17f5d2ce">账套ID</p>
    */
    @NotNull(message = "billId不能为空")
    @SerializedName("billId")
    private Long billId;
    /**
    * <p data-diff-id="ct-diff-id-bec83daa-584d-428c-9164-9b555f5e7d71"><span style="color: #333">预授权类型，ONLINEPAY：在线支付扫码授权，POS_ALIPAY：POS支付宝授权，POS_WECHAT：POS微信授权，BANKCARD：POS银行卡授权</span></p>
    */
    @NotBlank(message = "guaranteeType不能为空")
    @SerializedName("guaranteeType")
    private String guaranteeType;
    /**
    * <p data-diff-id="ct-diff-id-8cc6c777-f05b-4146-9e19-a785077fcd40">金额</p>
    */
    @NotBlank(message = "guaranteeAmount不能为空")
    @SerializedName("guaranteeAmount")
    private String guaranteeAmount;
    /**
    * <p data-diff-id="ct-diff-id-eda95673-110c-474a-b251-c21d427bf84a">在线支付信息，当guaranteeType为<span style="color: rgb(51, 51, 51)">ONLINEPAY时不能为空</span></p>
    */
    @SerializedName("onlinePaymentInfo")
    private OnlinePaymentInfo onlinePaymentInfo;
    /**
    * <p data-diff-id="ct-diff-id-ee3412bd-a023-4391-b866-094b7a452aff">备注</p>
    */
    @SerializedName("memo")
    private String memo;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public Long getBillId() {
        return billId;
    }
    public void setBillId(Long billId) {
        this.billId = billId;
    }
    public String getGuaranteeType() {
        return guaranteeType;
    }
    public void setGuaranteeType(String guaranteeType) {
        this.guaranteeType = guaranteeType;
    }
    public String getGuaranteeAmount() {
        return guaranteeAmount;
    }
    public void setGuaranteeAmount(String guaranteeAmount) {
        this.guaranteeAmount = guaranteeAmount;
    }
    public OnlinePaymentInfo getOnlinePaymentInfo() {
        return onlinePaymentInfo;
    }
    public void setOnlinePaymentInfo(OnlinePaymentInfo onlinePaymentInfo) {
        this.onlinePaymentInfo = onlinePaymentInfo;
    }
    public String getMemo() {
        return memo;
    }
    public void setMemo(String memo) {
        this.memo = memo;
    }


    @Override
    public MeituanResponse<AddGuaranteeItemResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<AddGuaranteeItemResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "AddGuaranteeItemRequest{" + "hotelId=" + hotelId + "," + "billId=" + billId + "," + "guaranteeType=" + guaranteeType + "," + "guaranteeAmount=" + guaranteeAmount + "," + "onlinePaymentInfo=" + onlinePaymentInfo + "," + "memo=" + memo + "}";
    }
}
