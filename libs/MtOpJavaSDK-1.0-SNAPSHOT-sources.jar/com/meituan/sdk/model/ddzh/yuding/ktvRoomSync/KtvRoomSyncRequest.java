package com.meituan.sdk.model.ddzh.yuding.ktvRoomSync;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* ktv三方房型数据同步
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/yuding/ktv/room/sync",
    businessId = 58,
    apiVersion = "10053",
    apiName = "ktv_room_sync",
    needAuth = true
)
public class KtvRoomSyncRequest implements MeituanRequest<KtvRoomSyncResponse> {
    @NotEmpty(message = "roomList不能为空")
    @SerializedName("roomList")
    private List<KtvRoomDTO> roomList;

    public List<KtvRoomDTO> getRoomList() {
        return roomList;
    }
    public void setRoomList(List<KtvRoomDTO> roomList) {
        this.roomList = roomList;
    }


    @Override
    public MeituanResponse<KtvRoomSyncResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<KtvRoomSyncResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "KtvRoomSyncRequest{" + "roomList=" + roomList + "}";
    }
}
