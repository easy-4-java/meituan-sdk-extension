package com.meituan.sdk.model.ddzhkh.xcxwy.createOrder;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class ExtraObj {
    /**
    * 系统交互码
    */
    @SerializedName("errorMsg")
    private String errorMsg;
    /**
    * 系统交互msg
    */
    @SerializedName("errorCode")
    private Integer errorCode;
    @SerializedName("traceId")
    private String traceId;

    public String getErrorMsg() {
        return errorMsg;
    }
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
    public Integer getErrorCode() {
        return errorCode;
    }
    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }
    public String getTraceId() {
        return traceId;
    }
    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }




    @Override
    public String toString() {
        return "ExtraObj{" + "errorMsg=" + errorMsg + "," + "errorCode=" + errorCode + "," + "traceId=" + traceId + "}";
    }
}
