package com.meituan.sdk.model.tuangouNg.atomgoods.productAddonUpdate;


/**
* 创建或更新菜品加价属性信息
* This file was automatically generated.
*/
public class ProductAddonUpdateResponse {





}
