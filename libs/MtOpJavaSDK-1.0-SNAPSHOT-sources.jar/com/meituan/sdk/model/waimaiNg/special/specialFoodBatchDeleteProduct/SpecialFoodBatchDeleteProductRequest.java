package com.meituan.sdk.model.waimaiNg.special.specialFoodBatchDeleteProduct;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 单门店下批量删除商品(拼好饭)
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/special/phf/product/batchDeleteSpu",
    businessId = 2,
    apiVersion = "10007",
    apiName = "special_food_batch_delete_product",
    needAuth = true
)
public class SpecialFoodBatchDeleteProductRequest implements MeituanRequest<SpecialFoodBatchDeleteProductResponse> {
    /**
    * 待删除的菜品id（多个，以逗号隔开，最多100个），支持删除普通商品、套餐子商品、套餐主商品。单次仅允许删除普通商品、套餐子商品、套餐主商品中的一种
    */
    @NotBlank(message = "appFoodCodes不能为空")
    @SerializedName("app_food_codes")
    private String appFoodCodes;

    public String getAppFoodCodes() {
        return appFoodCodes;
    }
    public void setAppFoodCodes(String appFoodCodes) {
        this.appFoodCodes = appFoodCodes;
    }


    @Override
    public MeituanResponse<SpecialFoodBatchDeleteProductResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<SpecialFoodBatchDeleteProductResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "SpecialFoodBatchDeleteProductRequest{" + "appFoodCodes=" + appFoodCodes + "}";
    }
}
