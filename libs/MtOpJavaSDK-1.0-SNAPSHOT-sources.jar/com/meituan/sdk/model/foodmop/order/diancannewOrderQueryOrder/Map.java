package com.meituan.sdk.model.foodmop.order.diancannewOrderQueryOrder;


/**
* <p data-diff-id="ct-diff-id-2a52149e-b608-4c88-a2e2-25c07a54945b"><span style="color: ">扩展字段 Map&lt;String,String&gt;</span></p>
* This file was automatically generated.
*/
public class Map {





}
