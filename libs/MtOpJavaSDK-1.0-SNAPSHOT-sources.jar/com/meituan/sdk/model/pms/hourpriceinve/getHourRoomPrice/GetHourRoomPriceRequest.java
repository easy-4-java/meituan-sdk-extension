package com.meituan.sdk.model.pms.hourpriceinve.getHourRoomPrice;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 获取钟点房价格
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/hourpriceinve/getHourRoomPrice",
    businessId = 57,
    apiVersion = "10003",
    apiName = "get_hour_room_price",
    needAuth = true
)
public class GetHourRoomPriceRequest implements MeituanRequest<GetHourRoomPriceResponse> {
    /**
    * <p data-diff-id="ct-diff-id-d0225ff8-178d-472e-b700-a69fe4e64478">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-690dfaa5-9fac-41a8-a8fb-292c45450514">渠道：门店-Hotel、美团-MeiTuanEBK、携程<em>-</em>TRIP、抖音-DOUYIN、飞猪-FLIGGY、微信-WECHAT</p>
    */
    @NotBlank(message = "channel不能为空")
    @SerializedName("channel")
    private String channel;
    /**
    * <p data-diff-id="ct-diff-id-40f459eb-c331-4bf7-a591-ad8e1aaeddac"><span style="color: #333">房型编号列表</span></p>
    */
    @SerializedName("roomTypeList")
    private List<String> roomTypeList;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getChannel() {
        return channel;
    }
    public void setChannel(String channel) {
        this.channel = channel;
    }
    public List<String> getRoomTypeList() {
        return roomTypeList;
    }
    public void setRoomTypeList(List<String> roomTypeList) {
        this.roomTypeList = roomTypeList;
    }


    @Override
    public MeituanResponse<GetHourRoomPriceResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<GetHourRoomPriceResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GetHourRoomPriceRequest{" + "hotelId=" + hotelId + "," + "channel=" + channel + "," + "roomTypeList=" + roomTypeList + "}";
    }
}
