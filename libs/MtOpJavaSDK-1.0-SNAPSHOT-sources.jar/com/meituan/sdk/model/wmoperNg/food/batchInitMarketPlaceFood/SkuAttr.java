package com.meituan.sdk.model.wmoperNg.food.batchInitMarketPlaceFood;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-1a40d84b-8d41-4370-8fbd-d1a7e633d8eb">sku售卖属性</p>
* This file was automatically generated.
*/
public class SkuAttr {
    /**
    * <p data-diff-id="ct-diff-id-037b4e48-30c6-4bb0-aaa3-644c071bdf40">属性名称</p>
    */
    @NotBlank(message = "name不能为空")
    @SerializedName("name")
    private String name;
    /**
    * <p data-diff-id="ct-diff-id-c0a883f3-74cb-4f47-abc8-6f92b8beae1e">属性值</p>
    */
    @NotBlank(message = "value不能为空")
    @SerializedName("value")
    private String value;
    /**
    * <p data-diff-id="ct-diff-id-b5241ab0-2156-4b8d-a7dd-e737bf483d0a">属性编号</p>
    */
    @SerializedName("no")
    private Integer no;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public Integer getNo() {
        return no;
    }
    public void setNo(Integer no) {
        this.no = no;
    }




    @Override
    public String toString() {
        return "SkuAttr{" + "name=" + name + "," + "value=" + value + "," + "no=" + no + "}";
    }
}
