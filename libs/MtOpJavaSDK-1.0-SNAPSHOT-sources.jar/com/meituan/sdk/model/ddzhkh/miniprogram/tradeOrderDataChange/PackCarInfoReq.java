package com.meituan.sdk.model.ddzhkh.miniprogram.tradeOrderDataChange;

import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-8e3ef55d-b181-4781-aada-c18f3b518436">取车信息，预约成功必传</p>
* This file was automatically generated.
*/
public class PackCarInfoReq {
    /**
    * <p data-diff-id="ct-diff-id-8b8f6259-067a-438d-a3d1-48287633fbd2">网点名称</p>
    */
    @SerializedName("shopName")
    private String shopName;
    /**
    * <p data-diff-id="ct-diff-id-474e3d3d-2e67-40cc-8354-f1761915c676">取还车城市</p>
    */
    @SerializedName("city")
    private String city;
    /**
    * <p data-diff-id="ct-diff-id-2e2c1943-d6ad-4bf9-9d7a-0dceb581fa75">取还车地址</p>
    */
    @SerializedName("address")
    private String address;
    /**
    * <p data-diff-id="ct-diff-id-0f2b7752-ff4c-480d-8ba8-ee89c8166b40">取/还车时间，毫秒时间戳</p>
    */
    @SerializedName("packTime")
    private String packTime;
    /**
    * <p data-diff-id="ct-diff-id-df3fedfd-8881-4f09-8339-62eaa6089b2c">实际取/还车时间，毫秒时间戳</p>
    */
    @SerializedName("realPackTime")
    private Long realPackTime;
    /**
    * <p data-diff-id="ct-diff-id-36d4a07c-4211-4bc2-b900-6e4b84e5ccf3">取车地址经度，格式坐标(百度)</p>
    */
    @SerializedName("longitude")
    private String longitude;
    /**
    * <p data-diff-id="ct-diff-id-954b3eb0-4281-4cc1-b1b7-061356658ec6">取车地址纬度，格式坐标(百度)</p>
    */
    @SerializedName("latitude")
    private String latitude;
    /**
    * <p data-diff-id="ct-diff-id-ec5cf9b0-456e-4fc5-90b5-b8d0b79ab346">营业时间，格式：HH:mm:ss - HH:mm:ss</p>
    */
    @SerializedName("businessHours")
    private String businessHours;
    /**
    * <p data-diff-id="ct-diff-id-1590c42d-49f8-47d7-a38b-0844714c6818">取还车类型：1 自行去门店；2 接送至门店；3 上门去取车</p>
    */
    @SerializedName("carFulfillType")
    private Integer carFulfillType;
    /**
    * <p data-diff-id="ct-diff-id-2cb72f41-9260-4d73-be8d-67b593450e6d">取还车油/电量</p>
    */
    @SerializedName("residualEnergy")
    private String residualEnergy;

    public String getShopName() {
        return shopName;
    }
    public void setShopName(String shopName) {
        this.shopName = shopName;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getPackTime() {
        return packTime;
    }
    public void setPackTime(String packTime) {
        this.packTime = packTime;
    }
    public Long getRealPackTime() {
        return realPackTime;
    }
    public void setRealPackTime(Long realPackTime) {
        this.realPackTime = realPackTime;
    }
    public String getLongitude() {
        return longitude;
    }
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
    public String getLatitude() {
        return latitude;
    }
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
    public String getBusinessHours() {
        return businessHours;
    }
    public void setBusinessHours(String businessHours) {
        this.businessHours = businessHours;
    }
    public Integer getCarFulfillType() {
        return carFulfillType;
    }
    public void setCarFulfillType(Integer carFulfillType) {
        this.carFulfillType = carFulfillType;
    }
    public String getResidualEnergy() {
        return residualEnergy;
    }
    public void setResidualEnergy(String residualEnergy) {
        this.residualEnergy = residualEnergy;
    }




    @Override
    public String toString() {
        return "PackCarInfoReq{" + "shopName=" + shopName + "," + "city=" + city + "," + "address=" + address + "," + "packTime=" + packTime + "," + "realPackTime=" + realPackTime + "," + "longitude=" + longitude + "," + "latitude=" + latitude + "," + "businessHours=" + businessHours + "," + "carFulfillType=" + carFulfillType + "," + "residualEnergy=" + residualEnergy + "}";
    }
}
