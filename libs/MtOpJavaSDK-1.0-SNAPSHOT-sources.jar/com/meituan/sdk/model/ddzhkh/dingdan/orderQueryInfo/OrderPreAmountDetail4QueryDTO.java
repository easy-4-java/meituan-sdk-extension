package com.meituan.sdk.model.ddzhkh.dingdan.orderQueryInfo;

import com.google.gson.annotations.SerializedName;

/**
* 订单下单金额明细快照
* This file was automatically generated.
*/
public class OrderPreAmountDetail4QueryDTO {
    /**
    * 支付批次
    */
    @SerializedName("payBatchNo")
    private Integer payBatchNo;
    /**
    * 支付类型，同同接口字段receiptList.amountShareList.amountType
    */
    @SerializedName("amountType")
    private Integer amountType;
    /**
    * 支付金额，单位：分
    */
    @SerializedName("amount")
    private Long amount;

    public Integer getPayBatchNo() {
        return payBatchNo;
    }
    public void setPayBatchNo(Integer payBatchNo) {
        this.payBatchNo = payBatchNo;
    }
    public Integer getAmountType() {
        return amountType;
    }
    public void setAmountType(Integer amountType) {
        this.amountType = amountType;
    }
    public Long getAmount() {
        return amount;
    }
    public void setAmount(Long amount) {
        this.amount = amount;
    }




    @Override
    public String toString() {
        return "OrderPreAmountDetail4QueryDTO{" + "payBatchNo=" + payBatchNo + "," + "amountType=" + amountType + "," + "amount=" + amount + "}";
    }
}
