package com.meituan.sdk.model.ddzh.print.printOrderInfoSync;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class ExpressInfo {
    /**
    * <p data-diff-id="ct-diff-id-c5d423e3-6981-4f19-8948-3f3633a8c568">快递公司编码，取值来自<a class="ct-link" href="https://developer.meituan.com/docs/biz/biz_ddzh_2fe0c221-214e-4bd9-83d6-a58f129664fd" data-auto_update="0">快递公司编码</a>的code</p>
    */
    @NotBlank(message = "expressCode不能为空")
    @SerializedName("expressCode")
    private String expressCode;
    /**
    * <p data-diff-id="ct-diff-id-da8f61b0-1649-4f2a-beb8-c214d8664620">快递单号</p>
    */
    @NotBlank(message = "expressNumber不能为空")
    @SerializedName("expressNumber")
    private String expressNumber;

    public String getExpressCode() {
        return expressCode;
    }
    public void setExpressCode(String expressCode) {
        this.expressCode = expressCode;
    }
    public String getExpressNumber() {
        return expressNumber;
    }
    public void setExpressNumber(String expressNumber) {
        this.expressNumber = expressNumber;
    }




    @Override
    public String toString() {
        return "ExpressInfo{" + "expressCode=" + expressCode + "," + "expressNumber=" + expressNumber + "}";
    }
}
