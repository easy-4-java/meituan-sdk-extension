package com.meituan.sdk.model.ddzhkh.generalreserve.generalreserveReserveFee;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class ResvSubjectMap {
    /**
    * <p data-diff-id="ct-diff-id-e60d1500-5866-4534-bbd6-ed8a595cc3ba"><span style="color: rgb(31, 45, 61)">门店ID。</span><span style="color: rgba(0, 0, 0, 0.87)">该字段是混淆字段，实际值类型为混淆后的字符串类型。</span></p>
    */
    @NotBlank(message = "opPoiId不能为空")
    @SerializedName("opPoiId")
    private String opPoiId;
    /**
    * <p data-diff-id="ct-diff-id-913bc5f6-f93e-43e5-9f5f-712695e121da"><span style="color: ">项目类型（1.团购 2.自定义 3.标品，目前接入的业务方只传团购即可</span></p>
    */
    @SerializedName("projectType")
    private Integer projectType;

    public String getOpPoiId() {
        return opPoiId;
    }
    public void setOpPoiId(String opPoiId) {
        this.opPoiId = opPoiId;
    }
    public Integer getProjectType() {
        return projectType;
    }
    public void setProjectType(Integer projectType) {
        this.projectType = projectType;
    }




    @Override
    public String toString() {
        return "ResvSubjectMap{" + "opPoiId=" + opPoiId + "," + "projectType=" + projectType + "}";
    }
}
