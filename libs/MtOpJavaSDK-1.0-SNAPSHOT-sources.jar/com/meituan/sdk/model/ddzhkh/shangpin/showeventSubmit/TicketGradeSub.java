package com.meituan.sdk.model.ddzhkh.shangpin.showeventSubmit;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* 
* This file was automatically generated.
*/
public class TicketGradeSub {
    @NotBlank(message = "thirdPartyTicketGradeId不能为空")
    @SerializedName("thirdPartyTicketGradeId")
    private String thirdPartyTicketGradeId;
    /**
    * <p data-diff-id="ct-diff-id-a4645e98-e469-48db-b5ca-707cc579d1fa">票价名称</p>
    */
    @NotBlank(message = "name不能为空")
    @SerializedName("name")
    private String name;
    /**
    * <p data-diff-id="ct-diff-id-67be0bcb-b07f-4e6a-8ca8-1e6a6b265537">票面价</p>
    */
    @NotBlank(message = "marketPrice不能为空")
    @SerializedName("marketPrice")
    private String marketPrice;
    /**
    * <p data-diff-id="ct-diff-id-c39a23fc-6f83-4fe3-80bb-94b055f62280">实际销售价</p>
    */
    @NotBlank(message = "sellPrice不能为空")
    @SerializedName("sellPrice")
    private String sellPrice;
    /**
    * <p data-diff-id="ct-diff-id-705ceed9-d716-43cc-a82d-04393879c8fe">票价说明</p>
    */
    @SerializedName("comment")
    private String comment;
    /**
    * <p data-diff-id="ct-diff-id-5bd23a9f-961a-47c8-bc1f-cfacb37b5b4c">类别，1：基础票，2：固定套票，3:自由套票</p>
    */
    @SerializedName("category")
    private Integer category;
    /**
    * <p data-diff-id="ct-diff-id-a4fc0809-5f3f-4ab1-9c30-6b213131c65f">是否启用，1：启用；0：未启用</p>
    */
    @NotNull(message = "enabled不能为空")
    @SerializedName("enabled")
    private Integer enabled;
    /**
    * <p data-diff-id="ct-diff-id-e4fcc602-5e89-40c6-95c7-487966596bbb">是否停售, 1:可售，2:停售</p>
    */
    @NotNull(message = "soldOutState不能为空")
    @SerializedName("soldOutState")
    private Integer soldOutState;
    /**
    * <p data-diff-id="ct-diff-id-58e218d6-4ad2-47a8-a34f-945d11ecd0eb">库存数量</p>
    */
    @NotNull(message = "stock不能为空")
    @SerializedName("stock")
    private Long stock;
    @SerializedName("ticketPack")
    private List<TicketPackSub> ticketPack;
    /**
    * <p data-diff-id="ct-diff-id-f2d1a27c-99fa-4cf2-8ede-2e6a98481d20">营销标签</p>
    */
    @SerializedName("marketingLabels")
    private List<String> marketingLabels;
    /**
    * <p data-diff-id="ct-diff-id-efd4a596-2e7e-44d2-be20-adfc590a105f">KV格式，参考示例</p><p data-diff-id="ct-diff-id-4db13643-dbc8-4272-ac5f-d1f17bce04df"></p>
    */
    @SerializedName("ext")
    private Map ext;

    public String getThirdPartyTicketGradeId() {
        return thirdPartyTicketGradeId;
    }
    public void setThirdPartyTicketGradeId(String thirdPartyTicketGradeId) {
        this.thirdPartyTicketGradeId = thirdPartyTicketGradeId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getMarketPrice() {
        return marketPrice;
    }
    public void setMarketPrice(String marketPrice) {
        this.marketPrice = marketPrice;
    }
    public String getSellPrice() {
        return sellPrice;
    }
    public void setSellPrice(String sellPrice) {
        this.sellPrice = sellPrice;
    }
    public String getComment() {
        return comment;
    }
    public void setComment(String comment) {
        this.comment = comment;
    }
    public Integer getCategory() {
        return category;
    }
    public void setCategory(Integer category) {
        this.category = category;
    }
    public Integer getEnabled() {
        return enabled;
    }
    public void setEnabled(Integer enabled) {
        this.enabled = enabled;
    }
    public Integer getSoldOutState() {
        return soldOutState;
    }
    public void setSoldOutState(Integer soldOutState) {
        this.soldOutState = soldOutState;
    }
    public Long getStock() {
        return stock;
    }
    public void setStock(Long stock) {
        this.stock = stock;
    }
    public List<TicketPackSub> getTicketPack() {
        return ticketPack;
    }
    public void setTicketPack(List<TicketPackSub> ticketPack) {
        this.ticketPack = ticketPack;
    }
    public List<String> getMarketingLabels() {
        return marketingLabels;
    }
    public void setMarketingLabels(List<String> marketingLabels) {
        this.marketingLabels = marketingLabels;
    }
    public Map getExt() {
        return ext;
    }
    public void setExt(Map ext) {
        this.ext = ext;
    }




    @Override
    public String toString() {
        return "TicketGradeSub{" + "thirdPartyTicketGradeId=" + thirdPartyTicketGradeId + "," + "name=" + name + "," + "marketPrice=" + marketPrice + "," + "sellPrice=" + sellPrice + "," + "comment=" + comment + "," + "category=" + category + "," + "enabled=" + enabled + "," + "soldOutState=" + soldOutState + "," + "stock=" + stock + "," + "ticketPack=" + ticketPack + "," + "marketingLabels=" + marketingLabels + "," + "ext=" + ext + "}";
    }
}
