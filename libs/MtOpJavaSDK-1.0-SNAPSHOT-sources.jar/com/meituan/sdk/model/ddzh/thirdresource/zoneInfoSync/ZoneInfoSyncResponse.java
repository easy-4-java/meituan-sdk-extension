package com.meituan.sdk.model.ddzh.thirdresource.zoneInfoSync;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 座区信息同步
* This file was automatically generated.
*/
public class ZoneInfoSyncResponse {
    /**
    * true-同步成功，false-同步失败
    */
    @SerializedName("result")
    private Boolean result;
    /**
    * 失败明细列表
    */
    @SerializedName("failDetails")
    private List<FailDetailInfo> failDetails;

    public Boolean getResult() {
        return result;
    }
    public void setResult(Boolean result) {
        this.result = result;
    }
    public List<FailDetailInfo> getFailDetails() {
        return failDetails;
    }
    public void setFailDetails(List<FailDetailInfo> failDetails) {
        this.failDetails = failDetails;
    }




    @Override
    public String toString() {
        return "ZoneInfoSyncResponse{" + "result=" + result + "," + "failDetails=" + failDetails + "}";
    }
}
