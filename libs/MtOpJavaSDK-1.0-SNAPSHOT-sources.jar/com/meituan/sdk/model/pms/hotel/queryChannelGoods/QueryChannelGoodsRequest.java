package com.meituan.sdk.model.pms.hotel.queryChannelGoods;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询渠道产品
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/hotel/queryChannelRoomTypes",
    businessId = 57,
    apiVersion = "10035",
    apiName = "query_channel_goods",
    needAuth = true
)
public class QueryChannelGoodsRequest implements MeituanRequest<List<ChannelRoomTypeDTO>> {
    /**
    * 酒店ID
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * 渠道编码，如 TRIP/MeituanEBK/DOUYIN/FLIGGY 或门店渠道标识
    */
    @NotBlank(message = "channelKey不能为空")
    @SerializedName("channelKey")
    private String channelKey;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getChannelKey() {
        return channelKey;
    }
    public void setChannelKey(String channelKey) {
        this.channelKey = channelKey;
    }


    @Override
    public MeituanResponse<List<ChannelRoomTypeDTO>> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<List<ChannelRoomTypeDTO>>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "QueryChannelGoodsRequest{" + "hotelId=" + hotelId + "," + "channelKey=" + channelKey + "}";
    }
}
