package com.meituan.sdk.model.ddzh.registration.registrationDepartmentAddEdit;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 医院挂号-新增&更新科室
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/registration/department/addOrEdit",
    businessId = 58,
    apiVersion = "10004",
    apiName = "registration_department_add_edit",
    needAuth = true
)
public class RegistrationDepartmentAddEditRequest implements MeituanRequest<RegistrationDepartmentAddEditResponse> {
    /**
    * <p data-diff-id="ct-diff-id-8e3d3991-920f-420c-9c28-81b636e6f3de">科室信息</p>
    */
    @NotNull(message = "departmentManage不能为空")
    @SerializedName("departmentManage")
    private AddOrEditDepartmentManageDTO departmentManage;
    /**
    * <p data-diff-id="ct-diff-id-ea6d23cb-4c8f-4c75-af67-bfd98ea92885">1：新增 2：更新</p>
    */
    @NotNull(message = "operationType不能为空")
    @SerializedName("operationType")
    private Integer operationType;

    public AddOrEditDepartmentManageDTO getDepartmentManage() {
        return departmentManage;
    }
    public void setDepartmentManage(AddOrEditDepartmentManageDTO departmentManage) {
        this.departmentManage = departmentManage;
    }
    public Integer getOperationType() {
        return operationType;
    }
    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }


    @Override
    public MeituanResponse<RegistrationDepartmentAddEditResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<RegistrationDepartmentAddEditResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "RegistrationDepartmentAddEditRequest{" + "departmentManage=" + departmentManage + "," + "operationType=" + operationType + "}";
    }
}
