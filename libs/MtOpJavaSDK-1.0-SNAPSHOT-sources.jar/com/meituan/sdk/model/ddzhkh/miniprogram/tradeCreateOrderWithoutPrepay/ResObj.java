package com.meituan.sdk.model.ddzhkh.miniprogram.tradeCreateOrderWithoutPrepay;

import com.google.gson.annotations.SerializedName;

/**
* 业务交互结果
* This file was automatically generated.
*/
public class ResObj {
    @SerializedName("code")
    private Integer code;
    @SerializedName("msg")
    private String msg;
    /**
    * 生单请求结果
    */
    @SerializedName("orderCreateRes")
    private OrderCreateRes orderCreateRes;

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public OrderCreateRes getOrderCreateRes() {
        return orderCreateRes;
    }
    public void setOrderCreateRes(OrderCreateRes orderCreateRes) {
        this.orderCreateRes = orderCreateRes;
    }




    @Override
    public String toString() {
        return "ResObj{" + "code=" + code + "," + "msg=" + msg + "," + "orderCreateRes=" + orderCreateRes + "}";
    }
}
