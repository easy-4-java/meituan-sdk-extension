package com.meituan.sdk.model.ddzhkh.merchantreceipt.merchantreceiptSendCallback;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-477c8470-9e99-45b1-ab84-c25b3051ff13">券码信息列表(发券成功时必填)</p>
* This file was automatically generated.
*/
public class ReceiptInfoResult {
    /**
    * <p data-diff-id="ct-diff-id-7603886b-7319-4458-a74d-b2df1975d183">三方券码</p>
    */
    @NotBlank(message = "receiptCode不能为空")
    @SerializedName("receiptCode")
    private String receiptCode;
    /**
    * <p data-diff-id="ct-diff-id-04b2f824-7466-480d-a705-6d1601843845">商家二维码链接</p>
    */
    @SerializedName("receiptCodePic")
    private String receiptCodePic;

    public String getReceiptCode() {
        return receiptCode;
    }
    public void setReceiptCode(String receiptCode) {
        this.receiptCode = receiptCode;
    }
    public String getReceiptCodePic() {
        return receiptCodePic;
    }
    public void setReceiptCodePic(String receiptCodePic) {
        this.receiptCodePic = receiptCodePic;
    }




    @Override
    public String toString() {
        return "ReceiptInfoResult{" + "receiptCode=" + receiptCode + "," + "receiptCodePic=" + receiptCodePic + "}";
    }
}
