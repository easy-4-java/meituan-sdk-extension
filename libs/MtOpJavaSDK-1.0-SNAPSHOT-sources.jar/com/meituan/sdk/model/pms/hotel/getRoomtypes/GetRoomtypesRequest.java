package com.meituan.sdk.model.pms.hotel.getRoomtypes;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询酒店房型信息
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/hotel/getRoomTypes",
    businessId = 57,
    apiVersion = "10030",
    apiName = "get_roomtypes",
    needAuth = true
)
public class GetRoomtypesRequest implements MeituanRequest<GetRoomtypesResponse> {
    /**
    * <p data-diff-id="ct-diff-id-b4570e2f-4d1f-4b28-9070-c48bd5238fb4">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-4ae0eba8-cc9f-4c6f-81cd-9c32bce62d8c">房型编号</p>
    */
    @SerializedName("roomTypeId")
    private String roomTypeId;
    /**
    * <p data-diff-id="ct-diff-id-d0bb95c0-4631-4b90-bc75-577d1abb8991">是否包含渠道房型</p>
    */
    @SerializedName("includeChannelRoomType")
    private Boolean includeChannelRoomType;
    /**
    * <p data-diff-id="ct-diff-id-4e36eb33-65e2-4b5f-bf84-062b32e11b89">渠道：美团-MeiTuanEBK，携程-TRIP，微信-WECHAT，飞猪-FLIGGY，抖音-DOUYIN</p>
    */
    @SerializedName("channel")
    private String channel;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getRoomTypeId() {
        return roomTypeId;
    }
    public void setRoomTypeId(String roomTypeId) {
        this.roomTypeId = roomTypeId;
    }
    public Boolean getIncludeChannelRoomType() {
        return includeChannelRoomType;
    }
    public void setIncludeChannelRoomType(Boolean includeChannelRoomType) {
        this.includeChannelRoomType = includeChannelRoomType;
    }
    public String getChannel() {
        return channel;
    }
    public void setChannel(String channel) {
        this.channel = channel;
    }


    @Override
    public MeituanResponse<GetRoomtypesResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<GetRoomtypesResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GetRoomtypesRequest{" + "hotelId=" + hotelId + "," + "roomTypeId=" + roomTypeId + "," + "includeChannelRoomType=" + includeChannelRoomType + "," + "channel=" + channel + "}";
    }
}
