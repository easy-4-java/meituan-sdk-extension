package com.meituan.sdk.model.ddzhkh.shangpin.dealgroupBatchRelateRooms;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;
import javax.validation.constraints.NotEmpty;

/**
* 批量推送团购关联包型包间
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/shangpin/dealgroup/relate/rooms",
    businessId = 59,
    apiVersion = "10174",
    apiName = "dealgroup_batch_relate_rooms",
    needAuth = true
)
public class DealgroupBatchRelateRoomsRequest implements MeituanRequest<DealgroupBatchRelateRoomsResponse> {
    /**
    * <p data-diff-id="ct-diff-id-ecb95ea4-77d1-461c-97dd-12f267b2ee1a">团购ID</p>
    */
    @NotNull(message = "dealGroupId不能为空")
    @SerializedName("dealGroupId")
    private Long dealGroupId;
    @NotEmpty(message = "roomRelateInfoList不能为空")
    @SerializedName("roomRelateInfoList")
    private List<PRoomRelateInfo> roomRelateInfoList;

    public Long getDealGroupId() {
        return dealGroupId;
    }
    public void setDealGroupId(Long dealGroupId) {
        this.dealGroupId = dealGroupId;
    }
    public List<PRoomRelateInfo> getRoomRelateInfoList() {
        return roomRelateInfoList;
    }
    public void setRoomRelateInfoList(List<PRoomRelateInfo> roomRelateInfoList) {
        this.roomRelateInfoList = roomRelateInfoList;
    }


    @Override
    public MeituanResponse<DealgroupBatchRelateRoomsResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<DealgroupBatchRelateRoomsResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "DealgroupBatchRelateRoomsRequest{" + "dealGroupId=" + dealGroupId + "," + "roomRelateInfoList=" + roomRelateInfoList + "}";
    }
}
