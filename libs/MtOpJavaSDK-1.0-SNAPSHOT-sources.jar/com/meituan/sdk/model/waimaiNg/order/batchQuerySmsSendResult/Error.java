package com.meituan.sdk.model.waimaiNg.order.batchQuerySmsSendResult;

import com.google.gson.annotations.SerializedName;

/**
* 查询失败数据，比如消息id异常或权限异常场景，不包括短信发送失败数据
* This file was automatically generated.
*/
public class Error {
    /**
    * 查询失败原因code，9201-查询短信失败，无权限或消息不存在
    */
    @SerializedName("code")
    private Integer code;
    /**
    * 查询失败原因描述
    */
    @SerializedName("msg")
    private String msg;

    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }




    @Override
    public String toString() {
        return "Error{" + "code=" + code + "," + "msg=" + msg + "}";
    }
}
