package com.meituan.sdk.model.ddzh.thirdresource.billiardTableInfoSync;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-07460535-e876-4677-bede-226fa6b1cce0">门店球桌信息列表</p>
* This file was automatically generated.
*/
public class PoiBallTableInfoDTO {
    /**
    * <p data-diff-id="ct-diff-id-25b0526c-c0b4-4a34-928e-3213757f6c00">美团门店id（混淆）</p>
    */
    @NotBlank(message = "mtPoiId不能为空")
    @SerializedName("mtPoiId")
    private String mtPoiId;
    /**
    * <p data-diff-id="ct-diff-id-ef173e7b-5d64-4610-bb5c-928de6b41a23">当前门店球桌总数</p>
    */
    @NotNull(message = "totalBallTableNum不能为空")
    @SerializedName("totalBallTableNum")
    private Integer totalBallTableNum;
    /**
    * <p data-diff-id="ct-diff-id-b7f47cb3-562a-4651-b3c5-656169238e6f">当前门店可用球桌数</p>
    */
    @NotNull(message = "availableBallTableNum不能为空")
    @SerializedName("availableBallTableNum")
    private Integer availableBallTableNum;

    public String getMtPoiId() {
        return mtPoiId;
    }
    public void setMtPoiId(String mtPoiId) {
        this.mtPoiId = mtPoiId;
    }
    public Integer getTotalBallTableNum() {
        return totalBallTableNum;
    }
    public void setTotalBallTableNum(Integer totalBallTableNum) {
        this.totalBallTableNum = totalBallTableNum;
    }
    public Integer getAvailableBallTableNum() {
        return availableBallTableNum;
    }
    public void setAvailableBallTableNum(Integer availableBallTableNum) {
        this.availableBallTableNum = availableBallTableNum;
    }




    @Override
    public String toString() {
        return "PoiBallTableInfoDTO{" + "mtPoiId=" + mtPoiId + "," + "totalBallTableNum=" + totalBallTableNum + "," + "availableBallTableNum=" + availableBallTableNum + "}";
    }
}
