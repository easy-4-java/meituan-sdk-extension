package com.meituan.sdk.model.ddzhkh.miniprogram.tradeAppendPaySubmit;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 追加支付
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/miniprogram/trade/append_pay_submit",
    businessId = 59,
    apiVersion = "10013",
    apiName = "trade_append_pay_submit",
    needAuth = true
)
public class TradeAppendPaySubmitRequest implements MeituanRequest<TradeAppendPaySubmitResponse> {
    @NotBlank(message = "generalBizData不能为空")
    @SerializedName("generalBizData")
    private String generalBizData;
    /**
    * <p data-diff-id="ct-diff-id-374d32ee-97d1-469a-829d-271c1cf5d65b">追加支付请求参数</p>
    */
    @NotNull(message = "appendPaySubmitReq不能为空")
    @SerializedName("appendPaySubmitReq")
    private AppendPaySubmitReq appendPaySubmitReq;

    public String getGeneralBizData() {
        return generalBizData;
    }
    public void setGeneralBizData(String generalBizData) {
        this.generalBizData = generalBizData;
    }
    public AppendPaySubmitReq getAppendPaySubmitReq() {
        return appendPaySubmitReq;
    }
    public void setAppendPaySubmitReq(AppendPaySubmitReq appendPaySubmitReq) {
        this.appendPaySubmitReq = appendPaySubmitReq;
    }


    @Override
    public MeituanResponse<TradeAppendPaySubmitResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<TradeAppendPaySubmitResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "TradeAppendPaySubmitRequest{" + "generalBizData=" + generalBizData + "," + "appendPaySubmitReq=" + appendPaySubmitReq + "}";
    }
}
