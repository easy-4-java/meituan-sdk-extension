package com.meituan.sdk.model.ddzhkh.clubactivity.clubactivityClubInfoSync;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 俱乐部信息同步接口
* This file was automatically generated.
*/
public class ClubactivityClubInfoSyncResponse {
    /**
    * 俱乐部同步结果
    */
    @SerializedName("syncResults")
    private List<ThirdPartySyncClubSingleResultDTO> syncResults;

    public List<ThirdPartySyncClubSingleResultDTO> getSyncResults() {
        return syncResults;
    }
    public void setSyncResults(List<ThirdPartySyncClubSingleResultDTO> syncResults) {
        this.syncResults = syncResults;
    }




    @Override
    public String toString() {
        return "ClubactivityClubInfoSyncResponse{" + "syncResults=" + syncResults + "}";
    }
}
