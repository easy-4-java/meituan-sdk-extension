package com.meituan.sdk.model.pms.hotel.searchHotels;

import com.google.gson.annotations.SerializedName;

/**
* 酒店详情
* This file was automatically generated.
*/
public class SearchHotelsResult {
    /**
    * 酒店ID
    */
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * 酒店编号
    */
    @SerializedName("hotelSn")
    private String hotelSn;
    /**
    * 酒店名称
    */
    @SerializedName("hotelName")
    private String hotelName;
    /**
    * 品牌
    */
    @SerializedName("brand")
    private String brand;
    /**
    * 地址
    */
    @SerializedName("address")
    private String address;
    /**
    * 电话
    */
    @SerializedName("phone")
    private String phone;
    /**
    * 传真
    */
    @SerializedName("fax")
    private String fax;
    /**
    * 酒店介绍
    */
    @SerializedName("description")
    private String description;
    /**
    * 城市编码
    */
    @SerializedName("cityId")
    private String cityId;
    /**
    * 行政区编码
    */
    @SerializedName("districtId")
    private String districtId;
    /**
    * 酒店类型，详见HotelType字典
    */
    @SerializedName("hotelType")
    private EnumDTO hotelType;
    /**
    * 酒店状态，详见HotelStatus字典
    */
    @SerializedName("hotelStatus")
    private EnumDTO hotelStatus;
    /**
    * 经度
    */
    @SerializedName("longitude")
    private String longitude;
    /**
    * 纬度
    */
    @SerializedName("latitude")
    private String latitude;
    /**
    * 装修日期
    */
    @SerializedName("decorationDate")
    private String decorationDate;
    /**
    * 开业时间
    */
    @SerializedName("openingDate")
    private String openingDate;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getHotelSn() {
        return hotelSn;
    }
    public void setHotelSn(String hotelSn) {
        this.hotelSn = hotelSn;
    }
    public String getHotelName() {
        return hotelName;
    }
    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }
    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getFax() {
        return fax;
    }
    public void setFax(String fax) {
        this.fax = fax;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getCityId() {
        return cityId;
    }
    public void setCityId(String cityId) {
        this.cityId = cityId;
    }
    public String getDistrictId() {
        return districtId;
    }
    public void setDistrictId(String districtId) {
        this.districtId = districtId;
    }
    public EnumDTO getHotelType() {
        return hotelType;
    }
    public void setHotelType(EnumDTO hotelType) {
        this.hotelType = hotelType;
    }
    public EnumDTO getHotelStatus() {
        return hotelStatus;
    }
    public void setHotelStatus(EnumDTO hotelStatus) {
        this.hotelStatus = hotelStatus;
    }
    public String getLongitude() {
        return longitude;
    }
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
    public String getLatitude() {
        return latitude;
    }
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
    public String getDecorationDate() {
        return decorationDate;
    }
    public void setDecorationDate(String decorationDate) {
        this.decorationDate = decorationDate;
    }
    public String getOpeningDate() {
        return openingDate;
    }
    public void setOpeningDate(String openingDate) {
        this.openingDate = openingDate;
    }




    @Override
    public String toString() {
        return "SearchHotelsResult{" + "hotelId=" + hotelId + "," + "hotelSn=" + hotelSn + "," + "hotelName=" + hotelName + "," + "brand=" + brand + "," + "address=" + address + "," + "phone=" + phone + "," + "fax=" + fax + "," + "description=" + description + "," + "cityId=" + cityId + "," + "districtId=" + districtId + "," + "hotelType=" + hotelType + "," + "hotelStatus=" + hotelStatus + "," + "longitude=" + longitude + "," + "latitude=" + latitude + "," + "decorationDate=" + decorationDate + "," + "openingDate=" + openingDate + "}";
    }
}
