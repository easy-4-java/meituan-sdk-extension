package com.meituan.sdk.model.ddzhkh.shangpin.productUnitedQueryProduct;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询通用商品
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/shangpin/united/query/product",
    businessId = 59,
    apiVersion = "10203",
    apiName = "product_united_query_product",
    needAuth = true
)
public class ProductUnitedQueryProductRequest implements MeituanRequest<ProductUnitedQueryProductResponse> {
    /**
    * <p data-diff-id="ct-diff-id-4c21afef-c714-45ee-84a2-91ebc6c27270">商品ID</p><p data-diff-id="ct-diff-id-e578e12a-590d-497c-aecb-cfbee9168b2b"><br></p>
    */
    @NotNull(message = "productId不能为空")
    @SerializedName("productId")
    private Long productId;
    /**
    * <p data-diff-id="ct-diff-id-86b2a26d-7119-4fb5-b000-688a9231c68e">交易类型 （3：团购）</p><p data-diff-id="ct-diff-id-b815edd8-787e-4b26-b2ad-1ce3057b59ac"><br></p>
    */
    @NotNull(message = "tradeType不能为空")
    @SerializedName("tradeType")
    private Integer tradeType;

    public Long getProductId() {
        return productId;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }
    public Integer getTradeType() {
        return tradeType;
    }
    public void setTradeType(Integer tradeType) {
        this.tradeType = tradeType;
    }


    @Override
    public MeituanResponse<ProductUnitedQueryProductResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ProductUnitedQueryProductResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ProductUnitedQueryProductRequest{" + "productId=" + productId + "," + "tradeType=" + tradeType + "}";
    }
}
