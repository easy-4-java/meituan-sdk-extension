package com.meituan.sdk.model.ddzhkh.generalreserve.generalreserveReserveMerchantfullfill;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 商家履约
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/generalreserve/reserve/merchantfullfill",
    businessId = 59,
    apiVersion = "10004",
    apiName = "generalreserve_reserve_merchantfullfill",
    needAuth = true
)
public class GeneralreserveReserveMerchantfullfillRequest implements MeituanRequest<GeneralreserveReserveMerchantfullfillResponse> {
    /**
    * <p data-diff-id="ct-diff-id-fbd06b82-156f-4a3a-9dfa-580507eba683"><span style="color: rgb(31, 45, 61)">订单ID</span></p>
    */
    @NotNull(message = "leadsId不能为空")
    @SerializedName("leadsId")
    private Long leadsId;
    /**
    * <p data-diff-id="ct-diff-id-e9712f55-4c92-49c0-9e1c-bec23a0dc14c"><span style="color: rgb(51, 51, 51)">美团门店id</span></p><p data-diff-id="ct-diff-id-e02165e4-09e1-4b65-ab1d-7bd95bf8182a"><span style="color: rgba(0, 0, 0, 0.87)">该字段是混淆字段，实际值类型为混淆后的字符串类型</span></p>
    */
    @NotBlank(message = "opPoiId不能为空")
    @SerializedName("opPoiId")
    private String opPoiId;
    /**
    * <p data-diff-id="ct-diff-id-badf7b17-b49e-4490-b502-7e5b3bb1066c"><span style="color: rgb(31, 45, 61)">履约状态&nbsp; 100：已到店</span></p>
    */
    @SerializedName("fulfillStatus")
    private Integer fulfillStatus;
    /**
    * <p data-diff-id="ct-diff-id-7220087e-35b8-4947-a037-ecef5bf82129"><span style="color: rgb(31, 45, 61)">履约状态类型 1.到店状态</span></p>
    */
    @SerializedName("fulfillStatusType")
    private Integer fulfillStatusType;
    /**
    * <p data-diff-id="ct-diff-id-8ffa509a-0f5d-4d70-bc18-b4e329a9edb3"><span style="color: rgb(31, 45, 61)">履约信息</span></p>
    */
    @SerializedName("fulfillInfo")
    private String fulfillInfo;
    /**
    * <p data-diff-id="ct-diff-id-3e0017d7-3473-42ff-94af-aed02f0516c1"><span style="color: rgb(31, 45, 61)">附加信息</span></p>
    */
    @SerializedName("extraMap")
    private String extraMap;

    public Long getLeadsId() {
        return leadsId;
    }
    public void setLeadsId(Long leadsId) {
        this.leadsId = leadsId;
    }
    public String getOpPoiId() {
        return opPoiId;
    }
    public void setOpPoiId(String opPoiId) {
        this.opPoiId = opPoiId;
    }
    public Integer getFulfillStatus() {
        return fulfillStatus;
    }
    public void setFulfillStatus(Integer fulfillStatus) {
        this.fulfillStatus = fulfillStatus;
    }
    public Integer getFulfillStatusType() {
        return fulfillStatusType;
    }
    public void setFulfillStatusType(Integer fulfillStatusType) {
        this.fulfillStatusType = fulfillStatusType;
    }
    public String getFulfillInfo() {
        return fulfillInfo;
    }
    public void setFulfillInfo(String fulfillInfo) {
        this.fulfillInfo = fulfillInfo;
    }
    public String getExtraMap() {
        return extraMap;
    }
    public void setExtraMap(String extraMap) {
        this.extraMap = extraMap;
    }


    @Override
    public MeituanResponse<GeneralreserveReserveMerchantfullfillResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<GeneralreserveReserveMerchantfullfillResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "GeneralreserveReserveMerchantfullfillRequest{" + "leadsId=" + leadsId + "," + "opPoiId=" + opPoiId + "," + "fulfillStatus=" + fulfillStatus + "," + "fulfillStatusType=" + fulfillStatusType + "," + "fulfillInfo=" + fulfillInfo + "," + "extraMap=" + extraMap + "}";
    }
}
