package com.meituan.sdk.model.solution2.dcpoidinfo.dcPageQueryTokenPoiList;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 适用门店查询
* This file was automatically generated.
*/
@ApiMeta(
    path = "/solution2/dcpoidinfo/pageQueryPoiList",
    businessId = 86,
    apiVersion = "10002",
    apiName = "dc_page_query_token_poi_list",
    needAuth = true
)
public class DcPageQueryTokenPoiListRequest implements MeituanRequest<DcPageQueryTokenPoiListResponse> {
    /**
    * <p data-diff-id="ct-diff-id-d223852f-8c63-4935-a7d1-b364d6efeeaf">-</p>
    */
    @NotNull(message = "limit不能为空")
    @SerializedName("limit")
    private Integer limit;
    /**
    * <p data-diff-id="ct-diff-id-ba3cb921-6fd5-416f-9301-3659375d91f9">-</p>
    */
    @NotNull(message = "offset不能为空")
    @SerializedName("offset")
    private Integer offset;

    public Integer getLimit() {
        return limit;
    }
    public void setLimit(Integer limit) {
        this.limit = limit;
    }
    public Integer getOffset() {
        return offset;
    }
    public void setOffset(Integer offset) {
        this.offset = offset;
    }


    @Override
    public MeituanResponse<DcPageQueryTokenPoiListResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<DcPageQueryTokenPoiListResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "DcPageQueryTokenPoiListRequest{" + "limit=" + limit + "," + "offset=" + offset + "}";
    }
}
