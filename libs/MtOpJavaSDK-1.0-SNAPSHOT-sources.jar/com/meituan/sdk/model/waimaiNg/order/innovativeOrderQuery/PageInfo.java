package com.meituan.sdk.model.waimaiNg.order.innovativeOrderQuery;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class PageInfo {
    @SerializedName("currentPageNo")
    private Long currentPageNo;
    @SerializedName("totalPageCount")
    private Long totalPageCount;

    public Long getCurrentPageNo() {
        return currentPageNo;
    }
    public void setCurrentPageNo(Long currentPageNo) {
        this.currentPageNo = currentPageNo;
    }
    public Long getTotalPageCount() {
        return totalPageCount;
    }
    public void setTotalPageCount(Long totalPageCount) {
        this.totalPageCount = totalPageCount;
    }




    @Override
    public String toString() {
        return "PageInfo{" + "currentPageNo=" + currentPageNo + "," + "totalPageCount=" + totalPageCount + "}";
    }
}
