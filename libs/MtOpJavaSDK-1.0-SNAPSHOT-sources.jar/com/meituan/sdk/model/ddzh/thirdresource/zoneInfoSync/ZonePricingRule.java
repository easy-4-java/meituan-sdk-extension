package com.meituan.sdk.model.ddzh.thirdresource.zoneInfoSync;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-21435086-e163-4f21-8406-420033499dfb">对应座区计费规则</p>
* This file was automatically generated.
*/
public class ZonePricingRule {
    /**
    * <p data-diff-id="ct-diff-id-b1de39c5-b7b5-4c03-b37e-beacd51d59e4">会员等级</p>
    */
    @NotNull(message = "level不能为空")
    @SerializedName("level")
    private Integer level;
    /**
    * <p data-diff-id="ct-diff-id-56112d5e-c5c2-42eb-bd2e-318dc68fa6f7">会员等级时价标准，单位：分/小时</p>
    */
    @NotNull(message = "pricePerHour不能为空")
    @SerializedName("pricePerHour")
    private Long pricePerHour;

    public Integer getLevel() {
        return level;
    }
    public void setLevel(Integer level) {
        this.level = level;
    }
    public Long getPricePerHour() {
        return pricePerHour;
    }
    public void setPricePerHour(Long pricePerHour) {
        this.pricePerHour = pricePerHour;
    }




    @Override
    public String toString() {
        return "ZonePricingRule{" + "level=" + level + "," + "pricePerHour=" + pricePerHour + "}";
    }
}
