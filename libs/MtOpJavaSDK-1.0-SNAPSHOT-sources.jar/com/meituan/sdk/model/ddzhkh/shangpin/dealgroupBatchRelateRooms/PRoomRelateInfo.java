package com.meituan.sdk.model.ddzhkh.shangpin.dealgroupBatchRelateRooms;

import java.util.List;
import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* 
* This file was automatically generated.
*/
public class PRoomRelateInfo {
    /**
    * <p data-diff-id="ct-diff-id-ac531943-c0fc-4ebf-b244-f8d4bdcfcc34">门店ID</p>
    */
    @NotBlank(message = "opPoiId不能为空")
    @SerializedName("opPoiId")
    private String opPoiId;
    @NotEmpty(message = "roomInfoList不能为空")
    @SerializedName("roomInfoList")
    private List<PRoomInfo> roomInfoList;

    public String getOpPoiId() {
        return opPoiId;
    }
    public void setOpPoiId(String opPoiId) {
        this.opPoiId = opPoiId;
    }
    public List<PRoomInfo> getRoomInfoList() {
        return roomInfoList;
    }
    public void setRoomInfoList(List<PRoomInfo> roomInfoList) {
        this.roomInfoList = roomInfoList;
    }




    @Override
    public String toString() {
        return "PRoomRelateInfo{" + "opPoiId=" + opPoiId + "," + "roomInfoList=" + roomInfoList + "}";
    }
}
