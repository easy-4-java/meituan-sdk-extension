package com.meituan.sdk.model.rhone.mtp.orderConsumeNotice;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 订单消费通知
* This file was automatically generated.
*/
@ApiMeta(
    path = "/rhone/mtp/api/order/consume/notice",
    businessId = 66,
    apiVersion = "10022",
    apiName = "order_consume_notice",
    needAuth = false
)
public class OrderConsumeNoticeRequest implements MeituanRequest<OrderConsumeNoticeResponse> {
    /**
    * <p data-diff-id="ct-diff-id-5092d5ab-57e8-447e-bb22-d1f9b05de305"><span style="color: ">合作方ID</span></p>
    */
    @SerializedName("partnerId")
    private Integer partnerId;
    /**
    * <p data-diff-id="ct-diff-id-11843d01-eac2-4f67-8b4e-bdbacc99cfaa"><span style="color: ">订单消费通知内容</span></p>
    */
    @SerializedName("body")
    private Body body;

    public Integer getPartnerId() {
        return partnerId;
    }
    public void setPartnerId(Integer partnerId) {
        this.partnerId = partnerId;
    }
    public Body getBody() {
        return body;
    }
    public void setBody(Body body) {
        this.body = body;
    }


    @Override
    public MeituanResponse<OrderConsumeNoticeResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<OrderConsumeNoticeResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "OrderConsumeNoticeRequest{" + "partnerId=" + partnerId + "," + "body=" + body + "}";
    }
}
