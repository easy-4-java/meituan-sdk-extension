package com.meituan.sdk.model.ddzh.yuding.personunbind;

import com.google.gson.annotations.SerializedName;

/**
* 解绑服务人员与门店关系
* This file was automatically generated.
*/
public class PersonunbindResponse {
    /**
    * 服务人员id
    */
    @SerializedName("serviceTechId")
    private Long serviceTechId;

    public Long getServiceTechId() {
        return serviceTechId;
    }
    public void setServiceTechId(Long serviceTechId) {
        this.serviceTechId = serviceTechId;
    }




    @Override
    public String toString() {
        return "PersonunbindResponse{" + "serviceTechId=" + serviceTechId + "}";
    }
}
