package com.meituan.sdk.model.ddzhkh.xcxhjhs.syncAri;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 黄金回收同步价格
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/xcxhjhs/sync_ari",
    businessId = 59,
    apiVersion = "10002",
    apiName = "sync_ari",
    needAuth = true
)
public class SyncAriRequest implements MeituanRequest<SyncAriResponse> {
    @NotBlank(message = "generalBizData不能为空")
    @SerializedName("generalBizData")
    private String generalBizData;
    @NotNull(message = "goldRecycleSyncAriReq不能为空")
    @SerializedName("goldRecycleSyncAriReq")
    private BaseRecycleSyncARIReq goldRecycleSyncAriReq;

    public String getGeneralBizData() {
        return generalBizData;
    }
    public void setGeneralBizData(String generalBizData) {
        this.generalBizData = generalBizData;
    }
    public BaseRecycleSyncARIReq getGoldRecycleSyncAriReq() {
        return goldRecycleSyncAriReq;
    }
    public void setGoldRecycleSyncAriReq(BaseRecycleSyncARIReq goldRecycleSyncAriReq) {
        this.goldRecycleSyncAriReq = goldRecycleSyncAriReq;
    }


    @Override
    public MeituanResponse<SyncAriResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<SyncAriResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "SyncAriRequest{" + "generalBizData=" + generalBizData + "," + "goldRecycleSyncAriReq=" + goldRecycleSyncAriReq + "}";
    }
}
