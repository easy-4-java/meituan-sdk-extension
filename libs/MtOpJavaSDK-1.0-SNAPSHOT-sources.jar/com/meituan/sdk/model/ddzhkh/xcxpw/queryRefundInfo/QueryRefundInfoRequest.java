package com.meituan.sdk.model.ddzhkh.xcxpw.queryRefundInfo;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询退款结果
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/xcxpw/query_refund_info",
    businessId = 59,
    apiVersion = "10025",
    apiName = "query_refund_info",
    needAuth = true
)
public class QueryRefundInfoRequest implements MeituanRequest<QueryRefundInfoResponse> {
    @NotBlank(message = "generalBizData不能为空")
    @SerializedName("generalBizData")
    private String generalBizData;
    @NotNull(message = "queryRefundInfoReq不能为空")
    @SerializedName("queryRefundInfoReq")
    private QueryRefundReq queryRefundInfoReq;

    public String getGeneralBizData() {
        return generalBizData;
    }
    public void setGeneralBizData(String generalBizData) {
        this.generalBizData = generalBizData;
    }
    public QueryRefundReq getQueryRefundInfoReq() {
        return queryRefundInfoReq;
    }
    public void setQueryRefundInfoReq(QueryRefundReq queryRefundInfoReq) {
        this.queryRefundInfoReq = queryRefundInfoReq;
    }


    @Override
    public MeituanResponse<QueryRefundInfoResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<QueryRefundInfoResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "QueryRefundInfoRequest{" + "generalBizData=" + generalBizData + "," + "queryRefundInfoReq=" + queryRefundInfoReq + "}";
    }
}
