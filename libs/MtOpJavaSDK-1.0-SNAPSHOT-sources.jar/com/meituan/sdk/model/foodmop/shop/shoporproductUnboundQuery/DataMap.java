package com.meituan.sdk.model.foodmop.shop.shoporproductUnboundQuery;

import com.google.gson.annotations.SerializedName;

/**
* 分页上下文
* This file was automatically generated.
*/
public class DataMap {
    /**
    * 入参queryType=1时的分页结束标记，值为false时表示还有下一页
    */
    @SerializedName("isScrollDone")
    private Boolean isScrollDone;
    /**
    * 游标id,入参queryType=3时分页参数
    */
    @SerializedName("scrollId")
    private Long scrollId;

    public Boolean getIsScrollDone() {
        return isScrollDone;
    }
    public void setIsScrollDone(Boolean isScrollDone) {
        this.isScrollDone = isScrollDone;
    }
    public Long getScrollId() {
        return scrollId;
    }
    public void setScrollId(Long scrollId) {
        this.scrollId = scrollId;
    }




    @Override
    public String toString() {
        return "DataMap{" + "isScrollDone=" + isScrollDone + "," + "scrollId=" + scrollId + "}";
    }
}
