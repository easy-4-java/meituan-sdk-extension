package com.meituan.sdk.model.waimaiNg.diancan.diancanOrderQuery;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 到店在线核销订单信息查询
* This file was automatically generated.
*/
@ApiMeta(
    path = "/waimai/ng/diancan/order/query",
    businessId = 2,
    apiVersion = "10010",
    apiName = "diancan_order_query",
    needAuth = true
)
public class DiancanOrderQueryRequest implements MeituanRequest<DiancanOrderQueryResponse> {
    /**
    * <p data-diff-id="ct-diff-id-5cdb22be-ba80-4a81-8d69-74ed27dc2a00"><font style="font-size:14px;line-height:22px" data-size="14">订单id，外卖</font><span style="color: ">orderIdView</span></p>
    */
    @NotNull(message = "orderId不能为空")
    @SerializedName("orderId")
    private Long orderId;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }


    @Override
    public MeituanResponse<DiancanOrderQueryResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<DiancanOrderQueryResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "DiancanOrderQueryRequest{" + "orderId=" + orderId + "}";
    }
}
