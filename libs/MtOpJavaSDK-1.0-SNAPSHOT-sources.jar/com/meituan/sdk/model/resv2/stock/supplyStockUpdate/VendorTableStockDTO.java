package com.meituan.sdk.model.resv2.stock.supplyStockUpdate;

import java.util.List;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotEmpty;

/**
* <p data-diff-id="ct-diff-id-8a107fcc-4823-472d-bce9-87b57bb8701d">库存变更实体</p>
* This file was automatically generated.
*/
public class VendorTableStockDTO {
    /**
    * <p data-diff-id="ct-diff-id-4d606043-dc5a-4991-9cf6-17d1fa10e25c">0-大厅 1-包间 3-特殊桌型</p>
    */
    @SerializedName("tableType")
    private Integer tableType;
    /**
    * <p data-diff-id="ct-diff-id-a1d6be37-0c5a-418a-abff-15ddd08485a3">桌型名称 tableType=3(特殊桌型)时，此字段必填</p>
    */
    @SerializedName("tableName")
    private String tableName;
    /**
    * <p data-diff-id="ct-diff-id-7a462fb9-9aa8-41a7-a753-2e42f18ed9ae">美团桌型id，推荐该字段必传，或者 「tableType、tableName」两个字段必传</p>
    */
    @SerializedName("tableTypeId")
    private Long tableTypeId;
    /**
    * <p data-diff-id="ct-diff-id-abf9504d-bef4-4fff-a89c-7dd9c53f7a03">桌位库存实体</p>
    */
    @NotEmpty(message = "vendorTableGroupStockList不能为空")
    @SerializedName("vendorTableGroupStockList")
    private List<VendorTableGroupStockDTO> vendorTableGroupStockList;

    public Integer getTableType() {
        return tableType;
    }
    public void setTableType(Integer tableType) {
        this.tableType = tableType;
    }
    public String getTableName() {
        return tableName;
    }
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    public Long getTableTypeId() {
        return tableTypeId;
    }
    public void setTableTypeId(Long tableTypeId) {
        this.tableTypeId = tableTypeId;
    }
    public List<VendorTableGroupStockDTO> getVendorTableGroupStockList() {
        return vendorTableGroupStockList;
    }
    public void setVendorTableGroupStockList(List<VendorTableGroupStockDTO> vendorTableGroupStockList) {
        this.vendorTableGroupStockList = vendorTableGroupStockList;
    }




    @Override
    public String toString() {
        return "VendorTableStockDTO{" + "tableType=" + tableType + "," + "tableName=" + tableName + "," + "tableTypeId=" + tableTypeId + "," + "vendorTableGroupStockList=" + vendorTableGroupStockList + "}";
    }
}
