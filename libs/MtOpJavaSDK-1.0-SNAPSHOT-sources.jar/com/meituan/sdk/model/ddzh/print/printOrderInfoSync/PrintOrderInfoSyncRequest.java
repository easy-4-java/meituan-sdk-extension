package com.meituan.sdk.model.ddzh.print.printOrderInfoSync;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 文印订单信息及状态同步
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzh/print/orderinfo/sync",
    businessId = 58,
    apiVersion = "10003",
    apiName = "print_order_info_sync",
    needAuth = false
)
public class PrintOrderInfoSyncRequest implements MeituanRequest<PrintOrderInfoSyncResponse> {
    /**
    * <p data-diff-id="ct-diff-id-ae981eff-7de7-4539-8a8e-f32d61fca09d">美团订单号</p>
    */
    @NotBlank(message = "orderId不能为空")
    @SerializedName("orderId")
    private String orderId;
    /**
    * <p data-diff-id="ct-diff-id-21b1c8dd-e602-4fdb-8221-9cbf1a9d19e6">订单履约状态，6102 打印中 -&gt; 6103 打印完成 -&gt; 6104 已分配快递(需要携带快递信息)</p>
    */
    @NotNull(message = "status不能为空")
    @SerializedName("status")
    private Integer status;
    @SerializedName("expressInfo")
    private ExpressInfo expressInfo;

    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public ExpressInfo getExpressInfo() {
        return expressInfo;
    }
    public void setExpressInfo(ExpressInfo expressInfo) {
        this.expressInfo = expressInfo;
    }


    @Override
    public MeituanResponse<PrintOrderInfoSyncResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<PrintOrderInfoSyncResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "PrintOrderInfoSyncRequest{" + "orderId=" + orderId + "," + "status=" + status + "," + "expressInfo=" + expressInfo + "}";
    }
}
