package com.meituan.sdk.model.wmoperNg.food.toppingGroupList;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询小料组接口(分页)
* This file was automatically generated.
*/
@ApiMeta(
    path = "/wmoper/ng/food/toppingGroup/list",
    businessId = 16,
    apiVersion = "10047",
    apiName = "topping_group_list",
    needAuth = true
)
public class ToppingGroupListRequest implements MeituanRequest<List<OpenToppingGroup>> {
    /**
    * <p data-diff-id="ct-diff-id-86ccd572-e4c2-4e86-9315-e8ea201f2bee">需要查询的小料分页大小，最大200</p>
    */
    @NotNull(message = "pageSize不能为空")
    @SerializedName("pageSize")
    private Integer pageSize;
    /**
    * <p data-diff-id="ct-diff-id-31f49c9d-bc8f-4216-90c9-c00c2ebcb855">页码， 从1开始</p>
    */
    @NotNull(message = "pageNo不能为空")
    @SerializedName("pageNo")
    private Integer pageNo;

    public Integer getPageSize() {
        return pageSize;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
    public Integer getPageNo() {
        return pageNo;
    }
    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }


    @Override
    public MeituanResponse<List<OpenToppingGroup>> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<List<OpenToppingGroup>>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ToppingGroupListRequest{" + "pageSize=" + pageSize + "," + "pageNo=" + pageNo + "}";
    }
}
