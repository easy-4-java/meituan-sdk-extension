package com.meituan.sdk.model.ddzhkh.auth.queryPoiMapping;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class PoiInfoTO {
    /**
    * 美团门店id
    */
    @SerializedName("poiId")
    private Long poiId;
    /**
    * 门店混淆id
    */
    @SerializedName("opPoiId")
    private String opPoiId;
    /**
    * 错误信息
    */
    @SerializedName("errMsg")
    private String errMsg;

    public Long getPoiId() {
        return poiId;
    }
    public void setPoiId(Long poiId) {
        this.poiId = poiId;
    }
    public String getOpPoiId() {
        return opPoiId;
    }
    public void setOpPoiId(String opPoiId) {
        this.opPoiId = opPoiId;
    }
    public String getErrMsg() {
        return errMsg;
    }
    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }




    @Override
    public String toString() {
        return "PoiInfoTO{" + "poiId=" + poiId + "," + "opPoiId=" + opPoiId + "," + "errMsg=" + errMsg + "}";
    }
}
