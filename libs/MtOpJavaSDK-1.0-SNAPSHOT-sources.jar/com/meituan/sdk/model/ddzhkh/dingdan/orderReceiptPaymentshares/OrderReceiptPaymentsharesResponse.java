package com.meituan.sdk.model.ddzhkh.dingdan.orderReceiptPaymentshares;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 订单券码分摊金额查询
* This file was automatically generated.
*/
public class OrderReceiptPaymentsharesResponse {
    @SerializedName("result")
    private List<Result> result;

    public List<Result> getResult() {
        return result;
    }
    public void setResult(List<Result> result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "OrderReceiptPaymentsharesResponse{" + "result=" + result + "}";
    }
}
