package com.meituan.sdk.model.waimaiNg.dish.toppingGroupList;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class OpenToppingGroup {
    /**
    * 小料组名称
    */
    @SerializedName("groupName")
    private String groupName;
    /**
    * 小料组编码
    */
    @SerializedName("toppingGroupCode")
    private String toppingGroupCode;
    /**
    * 小料组偏移id
    */
    @SerializedName("mtToppingGroupId")
    private Long mtToppingGroupId;
    /**
    * 是否可重复选  该字段只能填写0， 1  0 不重复  1重复
    */
    @SerializedName("repeatSelect")
    private Integer repeatSelect;
    /**
    * 最大可选数量
    */
    @SerializedName("maxSelect")
    private Integer maxSelect;
    /**
    * 是否可多选，  该字段只能填写0， 1  0不可多选  1可多选
    */
    @SerializedName("multiSelect")
    private Integer multiSelect;
    /**
    * 关联小料
    */
    @SerializedName("toppings")
    private List<OpenRelTopping> toppings;
    /**
    * 关联商品
    */
    @SerializedName("spuToppingGroupRel")
    private List<OpenSpuToppingRel> spuToppingGroupRel;
    /**
    * 最小购买数量
    */
    @SerializedName("minSelect")
    private Integer minSelect;
    /**
    * 是否必选，只能填0、1，0非必选，1必选
    */
    @SerializedName("mandatory")
    private Integer mandatory;

    public String getGroupName() {
        return groupName;
    }
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
    public String getToppingGroupCode() {
        return toppingGroupCode;
    }
    public void setToppingGroupCode(String toppingGroupCode) {
        this.toppingGroupCode = toppingGroupCode;
    }
    public Long getMtToppingGroupId() {
        return mtToppingGroupId;
    }
    public void setMtToppingGroupId(Long mtToppingGroupId) {
        this.mtToppingGroupId = mtToppingGroupId;
    }
    public Integer getRepeatSelect() {
        return repeatSelect;
    }
    public void setRepeatSelect(Integer repeatSelect) {
        this.repeatSelect = repeatSelect;
    }
    public Integer getMaxSelect() {
        return maxSelect;
    }
    public void setMaxSelect(Integer maxSelect) {
        this.maxSelect = maxSelect;
    }
    public Integer getMultiSelect() {
        return multiSelect;
    }
    public void setMultiSelect(Integer multiSelect) {
        this.multiSelect = multiSelect;
    }
    public List<OpenRelTopping> getToppings() {
        return toppings;
    }
    public void setToppings(List<OpenRelTopping> toppings) {
        this.toppings = toppings;
    }
    public List<OpenSpuToppingRel> getSpuToppingGroupRel() {
        return spuToppingGroupRel;
    }
    public void setSpuToppingGroupRel(List<OpenSpuToppingRel> spuToppingGroupRel) {
        this.spuToppingGroupRel = spuToppingGroupRel;
    }
    public Integer getMinSelect() {
        return minSelect;
    }
    public void setMinSelect(Integer minSelect) {
        this.minSelect = minSelect;
    }
    public Integer getMandatory() {
        return mandatory;
    }
    public void setMandatory(Integer mandatory) {
        this.mandatory = mandatory;
    }




    @Override
    public String toString() {
        return "OpenToppingGroup{" + "groupName=" + groupName + "," + "toppingGroupCode=" + toppingGroupCode + "," + "mtToppingGroupId=" + mtToppingGroupId + "," + "repeatSelect=" + repeatSelect + "," + "maxSelect=" + maxSelect + "," + "multiSelect=" + multiSelect + "," + "toppings=" + toppings + "," + "spuToppingGroupRel=" + spuToppingGroupRel + "," + "minSelect=" + minSelect + "," + "mandatory=" + mandatory + "}";
    }
}
