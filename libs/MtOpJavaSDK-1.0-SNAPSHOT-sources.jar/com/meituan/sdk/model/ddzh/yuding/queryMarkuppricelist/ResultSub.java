package com.meituan.sdk.model.ddzh.yuding.queryMarkuppricelist;

import com.google.gson.annotations.SerializedName;

/**
* 
* This file was automatically generated.
*/
public class ResultSub {
    /**
    * 加价项目ID
    */
    @SerializedName("id")
    private Long id;
    /**
    * 名称
    */
    @SerializedName("name")
    private String name;
    /**
    * 购买单位
    */
    @SerializedName("unit")
    private String unit;
    /**
    * 加价金额，单位：分
    */
    @SerializedName("unitPrice")
    private Long unitPrice;
    /**
    * 加价描述信息
    */
    @SerializedName("description")
    private String description;
    /**
    * 最大购买量
    */
    @SerializedName("maxSize")
    private Long maxSize;
    /**
    * 是否支持动态改价，如复杂疏通差价，夜间加价费等不支持修改
    */
    @SerializedName("canChangePrice")
    private Boolean canChangePrice;
    /**
    * 单价文本
    */
    @SerializedName("unitPriceText")
    private String unitPriceText;
    /**
    * 单位堆叠文本
    */
    @SerializedName("countDesc")
    private String countDesc;
    /**
    * 支付时提示文案
    */
    @SerializedName("payText")
    private String payText;
    /**
    * 加价物类型。1：普通加价，2：复杂疏通加价，3：严重堵塞加价
    */
    @SerializedName("itemType")
    private Long itemType;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getUnit() {
        return unit;
    }
    public void setUnit(String unit) {
        this.unit = unit;
    }
    public Long getUnitPrice() {
        return unitPrice;
    }
    public void setUnitPrice(Long unitPrice) {
        this.unitPrice = unitPrice;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public Long getMaxSize() {
        return maxSize;
    }
    public void setMaxSize(Long maxSize) {
        this.maxSize = maxSize;
    }
    public Boolean getCanChangePrice() {
        return canChangePrice;
    }
    public void setCanChangePrice(Boolean canChangePrice) {
        this.canChangePrice = canChangePrice;
    }
    public String getUnitPriceText() {
        return unitPriceText;
    }
    public void setUnitPriceText(String unitPriceText) {
        this.unitPriceText = unitPriceText;
    }
    public String getCountDesc() {
        return countDesc;
    }
    public void setCountDesc(String countDesc) {
        this.countDesc = countDesc;
    }
    public String getPayText() {
        return payText;
    }
    public void setPayText(String payText) {
        this.payText = payText;
    }
    public Long getItemType() {
        return itemType;
    }
    public void setItemType(Long itemType) {
        this.itemType = itemType;
    }




    @Override
    public String toString() {
        return "ResultSub{" + "id=" + id + "," + "name=" + name + "," + "unit=" + unit + "," + "unitPrice=" + unitPrice + "," + "description=" + description + "," + "maxSize=" + maxSize + "," + "canChangePrice=" + canChangePrice + "," + "unitPriceText=" + unitPriceText + "," + "countDesc=" + countDesc + "," + "payText=" + payText + "," + "itemType=" + itemType + "}";
    }
}
