package com.meituan.sdk.model.dishconnect.tuangou.couponBatchConsume;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-e0d80147-1ca0-462f-b376-bc70a24e7b01"><span style="color: #333">该笔订单里的菜品</span></p>
* This file was automatically generated.
*/
public class POrderSku {
    /**
    * <p data-diff-id="ct-diff-id-4df15604-f9e2-43e5-bea3-e200f0e7ff9b"><span style="color: #333">商家系统的菜品skuId</span></p>
    */
    @NotBlank(message = "vendorSkuId不能为空")
    @SerializedName("vendorSkuId")
    private String vendorSkuId;
    /**
    * <p data-diff-id="ct-diff-id-bf5b45ba-720b-45b4-8ab2-a963fe4f9a3a"><span style="color: #333">商家系统的菜品名称</span></p>
    */
    @NotBlank(message = "vendorSkuName不能为空")
    @SerializedName("vendorSkuName")
    private String vendorSkuName;
    /**
    * <p data-diff-id="ct-diff-id-78441a84-b1a4-47c5-899a-f07e111104f7"><span style="color: #333">菜品单位（如个，瓶等）</span></p>
    */
    @SerializedName("unit")
    private String unit;
    /**
    * <p data-diff-id="ct-diff-id-e5d5b4d9-1311-4e26-9aea-cd17f8a8aef7"><span style="color: #333">菜品单价</span></p>
    */
    @NotBlank(message = "unitPrice不能为空")
    @SerializedName("unitPrice")
    private String unitPrice;
    /**
    * <p data-diff-id="ct-diff-id-f5ed3995-a061-47ab-8894-677a88c66415"><span style="color: #333">菜品数量</span></p>
    */
    @NotNull(message = "count不能为空")
    @SerializedName("count")
    private Integer count;

    public String getVendorSkuId() {
        return vendorSkuId;
    }
    public void setVendorSkuId(String vendorSkuId) {
        this.vendorSkuId = vendorSkuId;
    }
    public String getVendorSkuName() {
        return vendorSkuName;
    }
    public void setVendorSkuName(String vendorSkuName) {
        this.vendorSkuName = vendorSkuName;
    }
    public String getUnit() {
        return unit;
    }
    public void setUnit(String unit) {
        this.unit = unit;
    }
    public String getUnitPrice() {
        return unitPrice;
    }
    public void setUnitPrice(String unitPrice) {
        this.unitPrice = unitPrice;
    }
    public Integer getCount() {
        return count;
    }
    public void setCount(Integer count) {
        this.count = count;
    }




    @Override
    public String toString() {
        return "POrderSku{" + "vendorSkuId=" + vendorSkuId + "," + "vendorSkuName=" + vendorSkuName + "," + "unit=" + unit + "," + "unitPrice=" + unitPrice + "," + "count=" + count + "}";
    }
}
