package com.meituan.sdk.model.resv2.rule.supplyRuleQuery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 桌型可预订餐段的配置
* This file was automatically generated.
*/
public class VendorTimeRuleDTO {
    /**
    * 星期
    */
    @SerializedName("weeDayList")
    private List<Integer> weeDayList;
    /**
    * 规则时间信息
    */
    @SerializedName("vendorTimePeriodDTOList")
    private List<VendorTimePeriodDTO> vendorTimePeriodDTOList;
    /**
    * 提前可订规则
    */
    @SerializedName("vendorAdvanceRuleDTO")
    private VendorAdvanceRuleDTO vendorAdvanceRuleDTO;

    public List<Integer> getWeeDayList() {
        return weeDayList;
    }
    public void setWeeDayList(List<Integer> weeDayList) {
        this.weeDayList = weeDayList;
    }
    public List<VendorTimePeriodDTO> getVendorTimePeriodDTOList() {
        return vendorTimePeriodDTOList;
    }
    public void setVendorTimePeriodDTOList(List<VendorTimePeriodDTO> vendorTimePeriodDTOList) {
        this.vendorTimePeriodDTOList = vendorTimePeriodDTOList;
    }
    public VendorAdvanceRuleDTO getVendorAdvanceRuleDTO() {
        return vendorAdvanceRuleDTO;
    }
    public void setVendorAdvanceRuleDTO(VendorAdvanceRuleDTO vendorAdvanceRuleDTO) {
        this.vendorAdvanceRuleDTO = vendorAdvanceRuleDTO;
    }




    @Override
    public String toString() {
        return "VendorTimeRuleDTO{" + "weeDayList=" + weeDayList + "," + "vendorTimePeriodDTOList=" + vendorTimePeriodDTOList + "," + "vendorAdvanceRuleDTO=" + vendorAdvanceRuleDTO + "}";
    }
}
