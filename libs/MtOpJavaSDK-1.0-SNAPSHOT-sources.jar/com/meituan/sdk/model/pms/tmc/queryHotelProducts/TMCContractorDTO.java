package com.meituan.sdk.model.pms.tmc.queryHotelProducts;

import com.google.gson.annotations.SerializedName;

/**
* 协议公司
* This file was automatically generated.
*/
public class TMCContractorDTO {
    /**
    * 协议公司id
    */
    @SerializedName("contractorId")
    private String contractorId;
    /**
    * 协议公司编码
    */
    @SerializedName("contractorAgreementCode")
    private String contractorAgreementCode;
    /**
    * 协议公司名称
    */
    @SerializedName("contractorName")
    private String contractorName;

    public String getContractorId() {
        return contractorId;
    }
    public void setContractorId(String contractorId) {
        this.contractorId = contractorId;
    }
    public String getContractorAgreementCode() {
        return contractorAgreementCode;
    }
    public void setContractorAgreementCode(String contractorAgreementCode) {
        this.contractorAgreementCode = contractorAgreementCode;
    }
    public String getContractorName() {
        return contractorName;
    }
    public void setContractorName(String contractorName) {
        this.contractorName = contractorName;
    }




    @Override
    public String toString() {
        return "TMCContractorDTO{" + "contractorId=" + contractorId + "," + "contractorAgreementCode=" + contractorAgreementCode + "," + "contractorName=" + contractorName + "}";
    }
}
