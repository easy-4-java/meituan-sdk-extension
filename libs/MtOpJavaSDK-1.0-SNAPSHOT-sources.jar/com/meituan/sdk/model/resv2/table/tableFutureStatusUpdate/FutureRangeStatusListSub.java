package com.meituan.sdk.model.resv2.table.tableFutureStatusUpdate;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-b6041d39-6406-45ad-8ca2-f5506094c9cb"><span style="color: ">桌台未来状态。初始化时，需同步全量占用状态，未传的默认空闲</span></p>
* This file was automatically generated.
*/
public class FutureRangeStatusListSub {
    /**
    * <p data-diff-id="ct-diff-id-931bb046-98c9-4474-8889-0cfbc86d0876"><span style="color: ">开始时间,秒级时间戳</span></p>
    */
    @NotNull(message = "startTime不能为空")
    @SerializedName("startTime")
    private Long startTime;
    /**
    * <p data-diff-id="ct-diff-id-7a90baa3-5c50-4d81-b746-1d049450b755"><span style="color: ">结束时间,秒级时间戳</span></p>
    */
    @NotNull(message = "endTime不能为空")
    @SerializedName("endTime")
    private Long endTime;
    /**
    * <p data-diff-id="ct-diff-id-52957a26-9b0f-476b-b321-1142c2b45375"><span style="color: ">桌台使用状态 1(空闲), 2(占用)</span></p>
    */
    @NotNull(message = "status不能为空")
    @SerializedName("status")
    private Long status;

    public Long getStartTime() {
        return startTime;
    }
    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }
    public Long getEndTime() {
        return endTime;
    }
    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }
    public Long getStatus() {
        return status;
    }
    public void setStatus(Long status) {
        this.status = status;
    }




    @Override
    public String toString() {
        return "FutureRangeStatusListSub{" + "startTime=" + startTime + "," + "endTime=" + endTime + "," + "status=" + status + "}";
    }
}
