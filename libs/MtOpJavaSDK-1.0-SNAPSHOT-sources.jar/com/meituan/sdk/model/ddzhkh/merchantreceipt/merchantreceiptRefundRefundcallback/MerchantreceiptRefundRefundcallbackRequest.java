package com.meituan.sdk.model.ddzhkh.merchantreceipt.merchantreceiptRefundRefundcallback;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 商家券退券回调
* This file was automatically generated.
*/
@ApiMeta(
    path = "/ddzhkh/merchantreceipt/refund/refundcallback",
    businessId = 59,
    apiVersion = "10023",
    apiName = "merchantreceipt_refund_refundcallback",
    needAuth = true
)
public class MerchantreceiptRefundRefundcallbackRequest implements MeituanRequest<MerchantreceiptRefundRefundcallbackResponse> {
    /**
    * <p data-diff-id="ct-diff-id-405e9d63-bfb5-443b-bcd6-9bc1fbe8577a">订单ID</p>
    */
    @NotBlank(message = "orderId不能为空")
    @SerializedName("orderId")
    private String orderId;
    /**
    * <p data-diff-id="ct-diff-id-a7ac5a60-8f6e-407c-9c27-f9151ee26ee3"><del><span style="color: rgba(0, 0, 0, 0.65)">券码，逗号分割</span></del><em><span style="color: rgba(0, 0, 0, 0.65)">（已废弃，不影响存量三方使用）</span></em></p>
    */
    @SerializedName("serialNumberList")
    private String serialNumberList;
    /**
    * <p data-diff-id="ct-diff-id-236bdc9a-f3f0-46fa-9b9f-e7cc210f693f">退款id</p><p data-diff-id="ct-diff-id-84e6211e-c823-4e3c-a71f-678d58e88abd"><br></p>
    */
    @NotNull(message = "refundId不能为空")
    @SerializedName("refundId")
    private Long refundId;
    /**
    * <p data-diff-id="ct-diff-id-7279ec4a-124b-4f04-8011-62ef73a29a88"><br><span style="color: ">退券结果</span></p>
    */
    @NotBlank(message = "code不能为空")
    @SerializedName("code")
    private String code;
    /**
    * <p data-diff-id="ct-diff-id-42386ff1-cfd0-4d68-9a34-034feb5108d7">券码集合</p>
    */
    @SerializedName("serialNumbers")
    private List<String> serialNumbers;

    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public String getSerialNumberList() {
        return serialNumberList;
    }
    public void setSerialNumberList(String serialNumberList) {
        this.serialNumberList = serialNumberList;
    }
    public Long getRefundId() {
        return refundId;
    }
    public void setRefundId(Long refundId) {
        this.refundId = refundId;
    }
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public List<String> getSerialNumbers() {
        return serialNumbers;
    }
    public void setSerialNumbers(List<String> serialNumbers) {
        this.serialNumbers = serialNumbers;
    }


    @Override
    public MeituanResponse<MerchantreceiptRefundRefundcallbackResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<MerchantreceiptRefundRefundcallbackResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "MerchantreceiptRefundRefundcallbackRequest{" + "orderId=" + orderId + "," + "serialNumberList=" + serialNumberList + "," + "refundId=" + refundId + "," + "code=" + code + "," + "serialNumbers=" + serialNumbers + "}";
    }
}
