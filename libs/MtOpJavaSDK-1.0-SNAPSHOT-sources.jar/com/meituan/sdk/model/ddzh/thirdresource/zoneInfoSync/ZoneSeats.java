package com.meituan.sdk.model.ddzh.thirdresource.zoneInfoSync;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-1aea79ca-c1d1-4c09-af72-3447045259db">座区内座位列表</p>
* This file was automatically generated.
*/
public class ZoneSeats {
    /**
    * <p data-diff-id="ct-diff-id-b2deeabc-f774-454b-8eab-b8b0d5e3ef66">座位号，座位唯一标识，如果已对接过设备同步应与设备接口中thirdPartyDeviceItemId保持一致</p>
    */
    @NotBlank(message = "seatId不能为空")
    @SerializedName("seatId")
    private String seatId;
    /**
    * <p data-diff-id="ct-diff-id-25f5a2db-1317-4674-af1a-aecd1c834f13"><em><span style="color: rgba(0, 0, 0, 0.65)">三方设备号，如果已对接过设备同步，此字段必传</span></em></p>
    */
    @SerializedName("thirdPartyDeviceItemId")
    private String thirdPartyDeviceItemId;
    /**
    * <p data-diff-id="ct-diff-id-193fcdca-0d5a-403c-9a6c-f90f2316f2d7">座位机号（门店内唯一，对应线下的座位号），座位机号与设备id一致时，seatId和seatNumber传一样的值</p>
    */
    @NotBlank(message = "seatNumber不能为空")
    @SerializedName("seatNumber")
    private String seatNumber;
    /**
    * <p data-diff-id="ct-diff-id-2a0e748c-5f00-49ae-8865-86f31920130c">座位相对坐标y轴</p>
    */
    @NotBlank(message = "seatTop不能为空")
    @SerializedName("seatTop")
    private String seatTop;
    /**
    * <p data-diff-id="ct-diff-id-5f817f3b-82b4-41bd-9fa8-3414b84d53fe">座位相对坐标x轴</p>
    */
    @NotBlank(message = "seatLefts不能为空")
    @SerializedName("seatLefts")
    private String seatLefts;
    /**
    * <p data-diff-id="ct-diff-id-ff4e3cde-90b9-4447-a93f-e7f61997d1dc">座位朝向，1-上，2-右，3-下，4-左</p>
    */
    @SerializedName("seatDirection")
    private Integer seatDirection;
    /**
    * <p data-diff-id="ct-diff-id-b5cd6b09-1f3c-48bb-871a-8de2606f1abc">座位角度（代表了朝向的偏转）</p>
    */
    @SerializedName("seatAngle")
    private String seatAngle;
    /**
    * <p data-diff-id="ct-diff-id-904d2946-058f-4235-a785-a152f4db670e">座位宽度，厘米</p>
    */
    @SerializedName("seatWidth")
    private String seatWidth;
    /**
    * <p data-diff-id="ct-diff-id-49048b20-ccb8-42f0-9e5f-f701bc93355d">座位高度，厘米</p>
    */
    @SerializedName("seatHeight")
    private String seatHeight;

    public String getSeatId() {
        return seatId;
    }
    public void setSeatId(String seatId) {
        this.seatId = seatId;
    }
    public String getThirdPartyDeviceItemId() {
        return thirdPartyDeviceItemId;
    }
    public void setThirdPartyDeviceItemId(String thirdPartyDeviceItemId) {
        this.thirdPartyDeviceItemId = thirdPartyDeviceItemId;
    }
    public String getSeatNumber() {
        return seatNumber;
    }
    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }
    public String getSeatTop() {
        return seatTop;
    }
    public void setSeatTop(String seatTop) {
        this.seatTop = seatTop;
    }
    public String getSeatLefts() {
        return seatLefts;
    }
    public void setSeatLefts(String seatLefts) {
        this.seatLefts = seatLefts;
    }
    public Integer getSeatDirection() {
        return seatDirection;
    }
    public void setSeatDirection(Integer seatDirection) {
        this.seatDirection = seatDirection;
    }
    public String getSeatAngle() {
        return seatAngle;
    }
    public void setSeatAngle(String seatAngle) {
        this.seatAngle = seatAngle;
    }
    public String getSeatWidth() {
        return seatWidth;
    }
    public void setSeatWidth(String seatWidth) {
        this.seatWidth = seatWidth;
    }
    public String getSeatHeight() {
        return seatHeight;
    }
    public void setSeatHeight(String seatHeight) {
        this.seatHeight = seatHeight;
    }




    @Override
    public String toString() {
        return "ZoneSeats{" + "seatId=" + seatId + "," + "thirdPartyDeviceItemId=" + thirdPartyDeviceItemId + "," + "seatNumber=" + seatNumber + "," + "seatTop=" + seatTop + "," + "seatLefts=" + seatLefts + "," + "seatDirection=" + seatDirection + "," + "seatAngle=" + seatAngle + "," + "seatWidth=" + seatWidth + "," + "seatHeight=" + seatHeight + "}";
    }
}
