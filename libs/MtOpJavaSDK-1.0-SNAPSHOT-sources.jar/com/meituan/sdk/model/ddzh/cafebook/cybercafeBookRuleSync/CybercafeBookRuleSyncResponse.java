package com.meituan.sdk.model.ddzh.cafebook.cybercafeBookRuleSync;

import com.google.gson.annotations.SerializedName;

/**
* 网吧订座规则同步
* This file was automatically generated.
*/
public class CybercafeBookRuleSyncResponse {
    /**
    * 同步结果，true-成功，false-失败
    */
    @SerializedName("result")
    private Boolean result;

    public Boolean getResult() {
        return result;
    }
    public void setResult(Boolean result) {
        this.result = result;
    }




    @Override
    public String toString() {
        return "CybercafeBookRuleSyncResponse{" + "result=" + result + "}";
    }
}
