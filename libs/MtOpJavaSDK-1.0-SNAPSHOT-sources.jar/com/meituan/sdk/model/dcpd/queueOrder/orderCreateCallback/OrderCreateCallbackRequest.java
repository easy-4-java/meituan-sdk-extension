package com.meituan.sdk.model.dcpd.queueOrder.orderCreateCallback;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 取号结果回调
* This file was automatically generated.
*/
@ApiMeta(
    path = "/dcpd/queue/order/create/callback",
    businessId = 49,
    apiVersion = "10014",
    apiName = "order_create_callback",
    needAuth = true
)
public class OrderCreateCallbackRequest implements MeituanRequest<Boolean> {
    /**
    * <p data-diff-id="ct-diff-id-ba6127ca-3bff-4dfa-a756-d7837fbbda56">美团侧桌型id，取号成功时必传</p>
    */
    @SerializedName("tableTypeId")
    private Integer tableTypeId;
    /**
    * <p data-diff-id="ct-diff-id-261d5f03-ab55-49d4-90e1-9c1e255dcc5c">美团侧订单id</p>
    */
    @NotBlank(message = "orderViewId不能为空")
    @SerializedName("orderViewId")
    private String orderViewId;
    /**
    * <p data-diff-id="ct-diff-id-964fb75d-ecb4-4efc-a0af-b455e2f61507">三方订单id，取号成功时必传</p>
    */
    @SerializedName("orderId")
    private String orderId;
    /**
    * <p data-diff-id="ct-diff-id-daad14a6-b6c6-4209-b7eb-63b9bb9e1d26">订单序号，即当前订单在队列中所处的位置，从1开始。index=9代表前面还有8桌。取号成功时必传</p>
    */
    @SerializedName("index")
    private Integer index;
    /**
    * <p data-diff-id="ct-diff-id-ea296c68-062b-4256-ae6b-6c89e94ba259">排队号码数字部分，如A24为24，取号成功时必传</p>
    */
    @SerializedName("num")
    private Integer num;
    /**
    * <p data-diff-id="ct-diff-id-9c7147c5-5ee2-4eac-ad9b-20eab7459aff">取号时间，毫秒级时间戳，取号成功时必传</p>
    */
    @SerializedName("takeNumTime")
    private Long takeNumTime;
    /**
    * <p data-diff-id="ct-diff-id-716cdd95-82c9-477b-bd17-1aefcd24fe18">取号订单状态，2为取号失败，3或null为取号成功，其他值无效</p>
    */
    @SerializedName("status")
    private Integer status;
    /**
    * <p data-diff-id="ct-diff-id-039b75b7-3871-4453-981b-5135ea544f50">取号失败时的信息提示，用于向用户展示</p>
    */
    @SerializedName("msg")
    private String msg;

    public Integer getTableTypeId() {
        return tableTypeId;
    }
    public void setTableTypeId(Integer tableTypeId) {
        this.tableTypeId = tableTypeId;
    }
    public String getOrderViewId() {
        return orderViewId;
    }
    public void setOrderViewId(String orderViewId) {
        this.orderViewId = orderViewId;
    }
    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public Integer getIndex() {
        return index;
    }
    public void setIndex(Integer index) {
        this.index = index;
    }
    public Integer getNum() {
        return num;
    }
    public void setNum(Integer num) {
        this.num = num;
    }
    public Long getTakeNumTime() {
        return takeNumTime;
    }
    public void setTakeNumTime(Long takeNumTime) {
        this.takeNumTime = takeNumTime;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }


    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "OrderCreateCallbackRequest{" + "tableTypeId=" + tableTypeId + "," + "orderViewId=" + orderViewId + "," + "orderId=" + orderId + "," + "index=" + index + "," + "num=" + num + "," + "takeNumTime=" + takeNumTime + "," + "status=" + status + "," + "msg=" + msg + "}";
    }
}
