package com.meituan.sdk.model.ddzhkh.miniprogram.tradeOrderDataChange;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-ae70b424-eb19-4764-a625-403071b252fd">租车行业必传</p>
* This file was automatically generated.
*/
public class CarRentalOrderInfoReq {
    /**
    * <p data-diff-id="ct-diff-id-cac59feb-76bd-4cee-9ab3-865a75f0e840">下单人姓名，预约成功必传</p>
    */
    @SerializedName("personName")
    private String personName;
    /**
    * <p data-diff-id="ct-diff-id-1fbac257-977a-46ee-913f-9605637a4169">下单人手机号，预约成功必传</p>
    */
    @SerializedName("personMobileNo")
    private String personMobileNo;
    /**
    * <p data-diff-id="ct-diff-id-1be7ed8a-aed1-4485-9a49-7a5d96d01c6e">车牌号，预约成功必传</p>
    */
    @SerializedName("licensePlateNumber")
    private String licensePlateNumber;
    /**
    * <p data-diff-id="ct-diff-id-5d07dfcb-87cb-47b5-9c44-37e19aa140df">车型，预约成功必传</p>
    */
    @SerializedName("carType")
    private String carType;
    /**
    * <p data-diff-id="ct-diff-id-165adbb0-dea9-42b1-b767-752e8b83c7f6">车辆配置，预约成功必传</p>
    */
    @SerializedName("carDisposition")
    private String carDisposition;
    /**
    * <p data-diff-id="ct-diff-id-cf3a7052-72f4-4111-be93-2461ec13d52d">租用时长（小时），预约成功必传</p>
    */
    @SerializedName("rentalPeriod")
    private Integer rentalPeriod;
    /**
    * <p data-diff-id="ct-diff-id-034852dd-8a89-4e12-a340-4c5598b0ade7">租车开始时间，毫秒时间戳，预约成功必传</p>
    */
    @SerializedName("rentalBeginTime")
    private Long rentalBeginTime;
    /**
    * <p data-diff-id="ct-diff-id-0f5b2640-ac9a-4482-b2d6-41e046ad6ebb">租车结束时间，毫秒时间戳，预约成功必传</p>
    */
    @SerializedName("rentalEndTime")
    private Long rentalEndTime;
    /**
    * <p data-diff-id="ct-diff-id-088623a0-c6f8-4ace-a100-2159dfa93581">验单时间，毫秒时间戳，已验证必传</p>
    */
    @SerializedName("verifyTime")
    private Long verifyTime;
    /**
    * <p data-diff-id="ct-diff-id-fbbe384d-5a1a-401b-91b3-fda5f89ecbe7">完成时间，毫秒时间戳，已验证必传</p>
    */
    @SerializedName("completeTime")
    private Long completeTime;
    /**
    * <p data-diff-id="ct-diff-id-c560cbf6-06cb-418f-ac7a-36b915363713">取消时间，毫秒时间戳，已取消必传</p>
    */
    @SerializedName("cancelTime")
    private Long cancelTime;
    /**
    * <p data-diff-id="ct-diff-id-312360f9-7954-4730-a4c3-97dda1a29a05">商户配置的押金金额（分），预约成功必传</p>
    */
    @SerializedName("depositAmount")
    private Long depositAmount;
    /**
    * <p data-diff-id="ct-diff-id-3edd2e64-ea39-4248-bc4c-91cfb4fc089b">日均保险（分），预约成功必传</p>
    */
    @SerializedName("dailyInsuranceAmount")
    private Long dailyInsuranceAmount;
    /**
    * <p data-diff-id="ct-diff-id-2fd77b97-8462-487c-9334-f7f2cdf97637">日均租金（分），下单必传</p>
    */
    @SerializedName("dailyRentalAmount")
    private Long dailyRentalAmount;
    /**
    * <p data-diff-id="ct-diff-id-36777392-7636-40d9-bcca-9be59ae91c47">商户订单总价，预约成功必传</p>
    */
    @SerializedName("vendorTotalAmount")
    private Long vendorTotalAmount;
    /**
    * <p data-diff-id="ct-diff-id-6b016b20-e768-4fc4-ab7c-17b3c0f8ced2">用车人信息，预约成功必传</p>
    */
    @SerializedName("useCarPersonReq")
    private UseCarPersonReq useCarPersonReq;
    /**
    * <p data-diff-id="ct-diff-id-8e3ef55d-b181-4781-aada-c18f3b518436">取车信息，预约成功必传</p>
    */
    @SerializedName("pickUpCarInfoReq")
    private PackCarInfoReq pickUpCarInfoReq;
    /**
    * <p data-diff-id="ct-diff-id-f417649c-d3c4-4868-bf1d-d5007e6b1a8b">还车信息，预约成功必传</p>
    */
    @SerializedName("returnCarInfoReq")
    private PackCarInfoReq returnCarInfoReq;
    /**
    * <p data-diff-id="ct-diff-id-596e5442-1c20-4af4-a9f5-2a26bc08d76a">费项组成，预约成功、已验证、撤销验证必传</p>
    */
    @SerializedName("feeDetailList")
    private List<FeeDetail> feeDetailList;

    public String getPersonName() {
        return personName;
    }
    public void setPersonName(String personName) {
        this.personName = personName;
    }
    public String getPersonMobileNo() {
        return personMobileNo;
    }
    public void setPersonMobileNo(String personMobileNo) {
        this.personMobileNo = personMobileNo;
    }
    public String getLicensePlateNumber() {
        return licensePlateNumber;
    }
    public void setLicensePlateNumber(String licensePlateNumber) {
        this.licensePlateNumber = licensePlateNumber;
    }
    public String getCarType() {
        return carType;
    }
    public void setCarType(String carType) {
        this.carType = carType;
    }
    public String getCarDisposition() {
        return carDisposition;
    }
    public void setCarDisposition(String carDisposition) {
        this.carDisposition = carDisposition;
    }
    public Integer getRentalPeriod() {
        return rentalPeriod;
    }
    public void setRentalPeriod(Integer rentalPeriod) {
        this.rentalPeriod = rentalPeriod;
    }
    public Long getRentalBeginTime() {
        return rentalBeginTime;
    }
    public void setRentalBeginTime(Long rentalBeginTime) {
        this.rentalBeginTime = rentalBeginTime;
    }
    public Long getRentalEndTime() {
        return rentalEndTime;
    }
    public void setRentalEndTime(Long rentalEndTime) {
        this.rentalEndTime = rentalEndTime;
    }
    public Long getVerifyTime() {
        return verifyTime;
    }
    public void setVerifyTime(Long verifyTime) {
        this.verifyTime = verifyTime;
    }
    public Long getCompleteTime() {
        return completeTime;
    }
    public void setCompleteTime(Long completeTime) {
        this.completeTime = completeTime;
    }
    public Long getCancelTime() {
        return cancelTime;
    }
    public void setCancelTime(Long cancelTime) {
        this.cancelTime = cancelTime;
    }
    public Long getDepositAmount() {
        return depositAmount;
    }
    public void setDepositAmount(Long depositAmount) {
        this.depositAmount = depositAmount;
    }
    public Long getDailyInsuranceAmount() {
        return dailyInsuranceAmount;
    }
    public void setDailyInsuranceAmount(Long dailyInsuranceAmount) {
        this.dailyInsuranceAmount = dailyInsuranceAmount;
    }
    public Long getDailyRentalAmount() {
        return dailyRentalAmount;
    }
    public void setDailyRentalAmount(Long dailyRentalAmount) {
        this.dailyRentalAmount = dailyRentalAmount;
    }
    public Long getVendorTotalAmount() {
        return vendorTotalAmount;
    }
    public void setVendorTotalAmount(Long vendorTotalAmount) {
        this.vendorTotalAmount = vendorTotalAmount;
    }
    public UseCarPersonReq getUseCarPersonReq() {
        return useCarPersonReq;
    }
    public void setUseCarPersonReq(UseCarPersonReq useCarPersonReq) {
        this.useCarPersonReq = useCarPersonReq;
    }
    public PackCarInfoReq getPickUpCarInfoReq() {
        return pickUpCarInfoReq;
    }
    public void setPickUpCarInfoReq(PackCarInfoReq pickUpCarInfoReq) {
        this.pickUpCarInfoReq = pickUpCarInfoReq;
    }
    public PackCarInfoReq getReturnCarInfoReq() {
        return returnCarInfoReq;
    }
    public void setReturnCarInfoReq(PackCarInfoReq returnCarInfoReq) {
        this.returnCarInfoReq = returnCarInfoReq;
    }
    public List<FeeDetail> getFeeDetailList() {
        return feeDetailList;
    }
    public void setFeeDetailList(List<FeeDetail> feeDetailList) {
        this.feeDetailList = feeDetailList;
    }




    @Override
    public String toString() {
        return "CarRentalOrderInfoReq{" + "personName=" + personName + "," + "personMobileNo=" + personMobileNo + "," + "licensePlateNumber=" + licensePlateNumber + "," + "carType=" + carType + "," + "carDisposition=" + carDisposition + "," + "rentalPeriod=" + rentalPeriod + "," + "rentalBeginTime=" + rentalBeginTime + "," + "rentalEndTime=" + rentalEndTime + "," + "verifyTime=" + verifyTime + "," + "completeTime=" + completeTime + "," + "cancelTime=" + cancelTime + "," + "depositAmount=" + depositAmount + "," + "dailyInsuranceAmount=" + dailyInsuranceAmount + "," + "dailyRentalAmount=" + dailyRentalAmount + "," + "vendorTotalAmount=" + vendorTotalAmount + "," + "useCarPersonReq=" + useCarPersonReq + "," + "pickUpCarInfoReq=" + pickUpCarInfoReq + "," + "returnCarInfoReq=" + returnCarInfoReq + "," + "feeDetailList=" + feeDetailList + "}";
    }
}
