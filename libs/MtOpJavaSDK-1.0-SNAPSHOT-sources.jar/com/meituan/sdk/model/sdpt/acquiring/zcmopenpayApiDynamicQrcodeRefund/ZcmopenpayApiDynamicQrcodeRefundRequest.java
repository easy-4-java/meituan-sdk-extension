package com.meituan.sdk.model.sdpt.acquiring.zcmopenpayApiDynamicQrcodeRefund;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 【美团收单】动态二维码订单退款
* This file was automatically generated.
*/
@ApiMeta(
    path = "/sdpt/acquiring/sdpt/acquiring/api/dynamic-code/payment/refund",
    businessId = 52,
    apiVersion = "10136",
    apiName = "zcmopenpay_api_dynamic_qrcode_refund",
    needAuth = false
)
public class ZcmopenpayApiDynamicQrcodeRefundRequest implements MeituanRequest<ZcmopenpayApiDynamicQrcodeRefundResponse> {
    /**
    * <p data-diff-id="ct-diff-id-61789cf7-3899-4a19-b8ea-c0dc2a7f87be">门店ID</p>
    */
    @NotNull(message = "merchantId不能为空")
    @SerializedName("merchantId")
    private Long merchantId;
    /**
    * <p data-diff-id="ct-diff-id-364dfaba-8710-407c-8abf-5a2423f98e04">平台单号，outOrderNo 二选一</p>
    */
    @SerializedName("dynamicCodePaymentOrderId")
    private String dynamicCodePaymentOrderId;
    /**
    * <p data-diff-id="ct-diff-id-16f7bb2b-b461-4915-8a95-4739112264a0">业务方单号</p>
    */
    @SerializedName("outOrderNo")
    private String outOrderNo;
    /**
    * <p data-diff-id="ct-diff-id-c8221516-8391-4291-9132-2c2bea46d48a">业务方退款单号</p>
    */
    @NotBlank(message = "refundRequestNo不能为空")
    @SerializedName("refundRequestNo")
    private String refundRequestNo;
    /**
    * <p data-diff-id="ct-diff-id-fb118063-aa05-4547-861b-9cadb42629ec">退款金额</p>
    */
    @NotNull(message = "refundAmount不能为空")
    @SerializedName("refundAmount")
    private Long refundAmount;
    /**
    * <p data-diff-id="ct-diff-id-0edcd936-b110-4c6f-a2b1-1aa928901814">退款原因</p>
    */
    @NotBlank(message = "refundReason不能为空")
    @SerializedName("refundReason")
    private String refundReason;

    public Long getMerchantId() {
        return merchantId;
    }
    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }
    public String getDynamicCodePaymentOrderId() {
        return dynamicCodePaymentOrderId;
    }
    public void setDynamicCodePaymentOrderId(String dynamicCodePaymentOrderId) {
        this.dynamicCodePaymentOrderId = dynamicCodePaymentOrderId;
    }
    public String getOutOrderNo() {
        return outOrderNo;
    }
    public void setOutOrderNo(String outOrderNo) {
        this.outOrderNo = outOrderNo;
    }
    public String getRefundRequestNo() {
        return refundRequestNo;
    }
    public void setRefundRequestNo(String refundRequestNo) {
        this.refundRequestNo = refundRequestNo;
    }
    public Long getRefundAmount() {
        return refundAmount;
    }
    public void setRefundAmount(Long refundAmount) {
        this.refundAmount = refundAmount;
    }
    public String getRefundReason() {
        return refundReason;
    }
    public void setRefundReason(String refundReason) {
        this.refundReason = refundReason;
    }


    @Override
    public MeituanResponse<ZcmopenpayApiDynamicQrcodeRefundResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ZcmopenpayApiDynamicQrcodeRefundResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ZcmopenpayApiDynamicQrcodeRefundRequest{" + "merchantId=" + merchantId + "," + "dynamicCodePaymentOrderId=" + dynamicCodePaymentOrderId + "," + "outOrderNo=" + outOrderNo + "," + "refundRequestNo=" + refundRequestNo + "," + "refundAmount=" + refundAmount + "," + "refundReason=" + refundReason + "}";
    }
}
