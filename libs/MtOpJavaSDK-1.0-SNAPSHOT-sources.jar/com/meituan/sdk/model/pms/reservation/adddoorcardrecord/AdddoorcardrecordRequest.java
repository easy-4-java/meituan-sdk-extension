package com.meituan.sdk.model.pms.reservation.adddoorcardrecord;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 添加制卡记录
* This file was automatically generated.
*/
@ApiMeta(
    path = "/pms/reservation/adddoorcardrecord",
    businessId = 57,
    apiVersion = "10031",
    apiName = "adddoorcardrecord",
    needAuth = true
)
public class AdddoorcardrecordRequest implements MeituanRequest<AdddoorcardrecordResponse> {
    /**
    * <p data-diff-id="ct-diff-id-0403754b-d300-45b8-a689-5ac396afa5e8">酒店ID</p>
    */
    @NotNull(message = "hotelId不能为空")
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * <p data-diff-id="ct-diff-id-bb0c48ab-bc32-40af-bb7b-9aabf0e5ed38">房间号</p>
    */
    @NotBlank(message = "roomNumber不能为空")
    @SerializedName("roomNumber")
    private String roomNumber;
    /**
    * <p data-diff-id="ct-diff-id-fab018be-0c0d-4593-bf31-260fca2ae972">锁号</p>
    */
    @NotBlank(message = "doorlockNo不能为空")
    @SerializedName("doorlockNo")
    private String doorlockNo;
    /**
    * <p data-diff-id="ct-diff-id-1d946ea2-09cb-49b7-ae65-87bf6567c957">制卡时间，格式yyyy-MM-dd HH:mm:ss</p>
    */
    @NotBlank(message = "createTime不能为空")
    @SerializedName("createTime")
    private String createTime;
    /**
    * <p data-diff-id="ct-diff-id-573cdb8b-f7f1-4596-bd1c-7fc976ee451a">过期时间<span style="color: rgba(0, 0, 0, 0.65)">，格式yyyy-MM-dd HH:mm:ss</span></p>
    */
    @NotBlank(message = "expireTime不能为空")
    @SerializedName("expireTime")
    private String expireTime;
    /**
    * <p data-diff-id="ct-diff-id-dae4c31b-155d-45b0-8a98-39e4e1314d48">占房ID</p>
    */
    @NotNull(message = "occupationId不能为空")
    @SerializedName("occupationId")
    private Long occupationId;
    /**
    * <p data-diff-id="ct-diff-id-3899623b-dcbb-434d-82f9-d869472bcbef">接待单ID</p>
    */
    @SerializedName("checkinId")
    private Long checkinId;
    /**
    * <p data-diff-id="ct-diff-id-c58765f3-e838-4c59-968c-f3435131e7ed">客历ID</p>
    */
    @SerializedName("customerId")
    private Long customerId;
    /**
    * <p data-diff-id="ct-diff-id-671000ac-36b8-48ab-bb53-ad01c9a64897">门锁序列号SN</p>
    */
    @SerializedName("sn")
    private String sn;
    /**
    * <p data-diff-id="ct-diff-id-fbfceacb-4207-4945-b93a-1351296e18ed">门卡卡号</p>
    */
    @SerializedName("extendNo")
    private String extendNo;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getRoomNumber() {
        return roomNumber;
    }
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }
    public String getDoorlockNo() {
        return doorlockNo;
    }
    public void setDoorlockNo(String doorlockNo) {
        this.doorlockNo = doorlockNo;
    }
    public String getCreateTime() {
        return createTime;
    }
    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }
    public String getExpireTime() {
        return expireTime;
    }
    public void setExpireTime(String expireTime) {
        this.expireTime = expireTime;
    }
    public Long getOccupationId() {
        return occupationId;
    }
    public void setOccupationId(Long occupationId) {
        this.occupationId = occupationId;
    }
    public Long getCheckinId() {
        return checkinId;
    }
    public void setCheckinId(Long checkinId) {
        this.checkinId = checkinId;
    }
    public Long getCustomerId() {
        return customerId;
    }
    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
    public String getSn() {
        return sn;
    }
    public void setSn(String sn) {
        this.sn = sn;
    }
    public String getExtendNo() {
        return extendNo;
    }
    public void setExtendNo(String extendNo) {
        this.extendNo = extendNo;
    }


    @Override
    public MeituanResponse<AdddoorcardrecordResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<AdddoorcardrecordResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "AdddoorcardrecordRequest{" + "hotelId=" + hotelId + "," + "roomNumber=" + roomNumber + "," + "doorlockNo=" + doorlockNo + "," + "createTime=" + createTime + "," + "expireTime=" + expireTime + "," + "occupationId=" + occupationId + "," + "checkinId=" + checkinId + "," + "customerId=" + customerId + "," + "sn=" + sn + "," + "extendNo=" + extendNo + "}";
    }
}
