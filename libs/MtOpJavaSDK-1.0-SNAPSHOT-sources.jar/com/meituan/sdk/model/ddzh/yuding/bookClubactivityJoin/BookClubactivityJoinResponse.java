package com.meituan.sdk.model.ddzh.yuding.bookClubactivityJoin;

import com.google.gson.annotations.SerializedName;

/**
* 俱乐部拼场活动美团侧参与接口
* This file was automatically generated.
*/
public class BookClubactivityJoinResponse {
    /**
    * 操作是否成功
    */
    @SerializedName("success")
    private Boolean success;

    public Boolean getSuccess() {
        return success;
    }
    public void setSuccess(Boolean success) {
        this.success = success;
    }




    @Override
    public String toString() {
        return "BookClubactivityJoinResponse{" + "success=" + success + "}";
    }
}
