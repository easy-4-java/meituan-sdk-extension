package com.meituan.sdk.model.pms.reservation.queryBreakfast;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 查询在住房间早餐信息
* This file was automatically generated.
*/
public class QueryBreakfastResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    @SerializedName("data")
    private List<BreakfastDTO> data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public List<BreakfastDTO> getData() {
        return data;
    }
    public void setData(List<BreakfastDTO> data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "QueryBreakfastResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
