package com.meituan.sdk.model.resv2.rule.supplyRuleQuery;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 桌型可预订餐段的特殊配置
* This file was automatically generated.
*/
public class VendorSpecialRuleDTO {
    /**
    * 特殊可订规则
    */
    @SerializedName("vendorSpecialBookableRuleDTOS")
    private List<VendorSpecialBookableRuleDTO> vendorSpecialBookableRuleDTOS;
    /**
    * 特殊不可订规则
    */
    @SerializedName("vendorSpecialUnbookableRuleDTOS")
    private List<VendorSpecialUnbookableRuleDTO> vendorSpecialUnbookableRuleDTOS;

    public List<VendorSpecialBookableRuleDTO> getVendorSpecialBookableRuleDTOS() {
        return vendorSpecialBookableRuleDTOS;
    }
    public void setVendorSpecialBookableRuleDTOS(List<VendorSpecialBookableRuleDTO> vendorSpecialBookableRuleDTOS) {
        this.vendorSpecialBookableRuleDTOS = vendorSpecialBookableRuleDTOS;
    }
    public List<VendorSpecialUnbookableRuleDTO> getVendorSpecialUnbookableRuleDTOS() {
        return vendorSpecialUnbookableRuleDTOS;
    }
    public void setVendorSpecialUnbookableRuleDTOS(List<VendorSpecialUnbookableRuleDTO> vendorSpecialUnbookableRuleDTOS) {
        this.vendorSpecialUnbookableRuleDTOS = vendorSpecialUnbookableRuleDTOS;
    }




    @Override
    public String toString() {
        return "VendorSpecialRuleDTO{" + "vendorSpecialBookableRuleDTOS=" + vendorSpecialBookableRuleDTOS + "," + "vendorSpecialUnbookableRuleDTOS=" + vendorSpecialUnbookableRuleDTOS + "}";
    }
}
