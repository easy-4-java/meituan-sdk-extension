package com.meituan.sdk.model.ddzhkh.merchantreceipt.merchantreceiptRefundRefundcallback;

import com.google.gson.annotations.SerializedName;

/**
* 商家券退券回调
* This file was automatically generated.
*/
public class MerchantreceiptRefundRefundcallbackResponse {
    /**
    * 退款订单ID
    */
    @SerializedName("orderRefundId")
    private Long orderRefundId;
    /**
    * 订单ID
    */
    @SerializedName("orderId")
    private Long orderId;

    public Long getOrderRefundId() {
        return orderRefundId;
    }
    public void setOrderRefundId(Long orderRefundId) {
        this.orderRefundId = orderRefundId;
    }
    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }




    @Override
    public String toString() {
        return "MerchantreceiptRefundRefundcallbackResponse{" + "orderRefundId=" + orderRefundId + "," + "orderId=" + orderId + "}";
    }
}
