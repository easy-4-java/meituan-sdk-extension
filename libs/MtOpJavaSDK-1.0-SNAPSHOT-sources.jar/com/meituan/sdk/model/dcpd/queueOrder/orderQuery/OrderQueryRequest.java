package com.meituan.sdk.model.dcpd.queueOrder.orderQuery;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import javax.validation.constraints.NotBlank;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 查询订单
* This file was automatically generated.
*/
@ApiMeta(
    path = "/dcpd/queue/order/query",
    businessId = 49,
    apiVersion = "10017",
    apiName = "order_query",
    needAuth = true
)
public class OrderQueryRequest implements MeituanRequest<OrderQueryResponse> {
    /**
    * <p data-diff-id="ct-diff-id-f095d72d-939d-4b78-9ed3-c1b3c44ac0a4"><em><span style="color: rgba(0, 0, 0, 0.65)">美团侧订单id</span></em></p>
    */
    @NotBlank(message = "orderViewId不能为空")
    @SerializedName("orderViewId")
    private String orderViewId;
    /**
    * <p data-diff-id="ct-diff-id-118cbdb6-b959-4344-a353-b75d64c47a5f"><em><span style="color: rgba(0, 0, 0, 0.65)">三方订单id</span></em></p>
    */
    @NotBlank(message = "orderId不能为空")
    @SerializedName("orderId")
    private String orderId;

    public String getOrderViewId() {
        return orderViewId;
    }
    public void setOrderViewId(String orderViewId) {
        this.orderViewId = orderViewId;
    }
    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }


    @Override
    public MeituanResponse<OrderQueryResponse> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<OrderQueryResponse>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "OrderQueryRequest{" + "orderViewId=" + orderViewId + "," + "orderId=" + orderId + "}";
    }
}
