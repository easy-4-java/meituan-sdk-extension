package com.meituan.sdk.model.ddzhkh.dingdan.orderQueryInfo;

import com.google.gson.annotations.SerializedName;

/**
* 金额分摊信息 注：类型为对象类型，详见扩展参数
* This file was automatically generated.
*/
public class AmountShare {
    /**
    * 资金类型，2-抵用券，5-积分 6-立减，8-商户抵用券，10-C端美团支付，12-优惠代码，15-美团立减，17-商家立减，18-美团商家立减，21-次卡，22-打折卡，23-B端美团支付，24-全渠道会员券，25-pos支付，26-线下认款平台，28-商家折上折，29-美团分销支付
    */
    @SerializedName("amountType")
    private Long amountType;
    /**
    * 优惠名称
    */
    @SerializedName("title")
    private String title;
    /**
    * 优惠金额(单位分)
    */
    @SerializedName("value")
    private Long value;

    public Long getAmountType() {
        return amountType;
    }
    public void setAmountType(Long amountType) {
        this.amountType = amountType;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public Long getValue() {
        return value;
    }
    public void setValue(Long value) {
        this.value = value;
    }




    @Override
    public String toString() {
        return "AmountShare{" + "amountType=" + amountType + "," + "title=" + title + "," + "value=" + value + "}";
    }
}
