package com.meituan.sdk.model.resv2.table.supplyTableDelete;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 删除桌型/桌位
* This file was automatically generated.
*/
@ApiMeta(
    path = "/resv2/table/supply/deleteTable",
    businessId = 7,
    apiVersion = "10007",
    apiName = "supply_table_delete",
    needAuth = true
)
public class SupplyTableDeleteRequest implements MeituanRequest<Boolean> {
    @NotNull(message = "vendorTableDeleteDTO不能为空")
    @SerializedName("vendorTableDeleteDTO")
    private VendorTableDeleteDTO vendorTableDeleteDTO;
    /**
    * <p data-diff-id="ct-diff-id-99eb3312-d0e9-4835-95e6-e197bf8f70b7"><span style="color: #333">请求唯一标识符</span></p>
    */
    @SerializedName("uuid")
    private String uuid;

    public VendorTableDeleteDTO getVendorTableDeleteDTO() {
        return vendorTableDeleteDTO;
    }
    public void setVendorTableDeleteDTO(VendorTableDeleteDTO vendorTableDeleteDTO) {
        this.vendorTableDeleteDTO = vendorTableDeleteDTO;
    }
    public String getUuid() {
        return uuid;
    }
    public void setUuid(String uuid) {
        this.uuid = uuid;
    }


    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "SupplyTableDeleteRequest{" + "vendorTableDeleteDTO=" + vendorTableDeleteDTO + "," + "uuid=" + uuid + "}";
    }
}
