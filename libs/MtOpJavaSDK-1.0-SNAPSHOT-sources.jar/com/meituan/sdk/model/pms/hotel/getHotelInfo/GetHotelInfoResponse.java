package com.meituan.sdk.model.pms.hotel.getHotelInfo;

import com.google.gson.annotations.SerializedName;

/**
* 获取指定酒店的基本信息
* This file was automatically generated.
*/
public class GetHotelInfoResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    /**
    * 酒店基本信息
    */
    @SerializedName("data")
    private HotelDTO data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public HotelDTO getData() {
        return data;
    }
    public void setData(HotelDTO data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "GetHotelInfoResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
