package com.meituan.sdk.model.dcpd.queueShop.onlineQueueConfigUpdate;

import com.meituan.sdk.annotations.ApiMeta;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 修改线上取号配置接口
* This file was automatically generated.
*/
@ApiMeta(
    path = "/dcpd/queue/shop/config/onlineQueue/update",
    businessId = 49,
    apiVersion = "10008",
    apiName = "online_queue_config_update",
    needAuth = true
)
public class OnlineQueueConfigUpdateRequest implements MeituanRequest<Boolean> {
    /**
    * <p data-diff-id="ct-diff-id-7d5c9802-2255-4498-800f-5109b0a89d4f">是否开启点评美团排队入口，1-开启，0-关闭</p>
    */
    @NotNull(message = "openStatus不能为空")
    @SerializedName("openStatus")
    private Integer openStatus;
    /**
    * <p data-diff-id="ct-diff-id-302a8e90-7fe7-4f86-a130-9b72c00661b8">不排队时，是否支持线上取号，1-支持，0-不支持</p>
    */
    @NotNull(message = "supportOnlineWithoutOrder不能为空")
    @SerializedName("supportOnlineWithoutOrder")
    private Integer supportOnlineWithoutOrder;
    /**
    * <p data-diff-id="ct-diff-id-ccfdbf3a-d5de-45b8-b0a2-be940d06770d">在线排队设置</p>
    */
    @NotNull(message = "onlineOrderConfig不能为空")
    @SerializedName("onlineOrderConfig")
    private OnlineOrderConfig onlineOrderConfig;

    public Integer getOpenStatus() {
        return openStatus;
    }
    public void setOpenStatus(Integer openStatus) {
        this.openStatus = openStatus;
    }
    public Integer getSupportOnlineWithoutOrder() {
        return supportOnlineWithoutOrder;
    }
    public void setSupportOnlineWithoutOrder(Integer supportOnlineWithoutOrder) {
        this.supportOnlineWithoutOrder = supportOnlineWithoutOrder;
    }
    public OnlineOrderConfig getOnlineOrderConfig() {
        return onlineOrderConfig;
    }
    public void setOnlineOrderConfig(OnlineOrderConfig onlineOrderConfig) {
        this.onlineOrderConfig = onlineOrderConfig;
    }


    @Override
    public MeituanResponse<Boolean> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<Boolean>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "OnlineQueueConfigUpdateRequest{" + "openStatus=" + openStatus + "," + "supportOnlineWithoutOrder=" + supportOnlineWithoutOrder + "," + "onlineOrderConfig=" + onlineOrderConfig + "}";
    }
}
