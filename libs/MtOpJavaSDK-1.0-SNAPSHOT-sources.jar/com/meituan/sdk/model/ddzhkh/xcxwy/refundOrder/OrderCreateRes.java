package com.meituan.sdk.model.ddzhkh.xcxwy.refundOrder;

import com.google.gson.annotations.SerializedName;

/**
* 退款结果
* This file was automatically generated.
*/
public class OrderCreateRes {
    /**
    * 美团退款号
    */
    @SerializedName("refundId")
    private Long refundId;
    /**
    * 三方退款号
    */
    @SerializedName("vendorRefundId")
    private String vendorRefundId;
    /**
    * 三点订单号
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * 退款申请时间，时间戳，精度毫秒
    */
    @SerializedName("createTime")
    private Long createTime;
    /**
    * 退给用户实付金额，单位：分
    */
    @SerializedName("totalRefundAmount")
    private Long totalRefundAmount;

    public Long getRefundId() {
        return refundId;
    }
    public void setRefundId(Long refundId) {
        this.refundId = refundId;
    }
    public String getVendorRefundId() {
        return vendorRefundId;
    }
    public void setVendorRefundId(String vendorRefundId) {
        this.vendorRefundId = vendorRefundId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public Long getCreateTime() {
        return createTime;
    }
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
    public Long getTotalRefundAmount() {
        return totalRefundAmount;
    }
    public void setTotalRefundAmount(Long totalRefundAmount) {
        this.totalRefundAmount = totalRefundAmount;
    }




    @Override
    public String toString() {
        return "OrderCreateRes{" + "refundId=" + refundId + "," + "vendorRefundId=" + vendorRefundId + "," + "vendorOrderId=" + vendorOrderId + "," + "createTime=" + createTime + "," + "totalRefundAmount=" + totalRefundAmount + "}";
    }
}
