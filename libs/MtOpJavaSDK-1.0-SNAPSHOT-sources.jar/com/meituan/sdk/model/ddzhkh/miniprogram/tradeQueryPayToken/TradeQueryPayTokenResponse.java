package com.meituan.sdk.model.ddzhkh.miniprogram.tradeQueryPayToken;

import com.google.gson.annotations.SerializedName;

/**
* 查询支付token
* This file was automatically generated.
*/
public class TradeQueryPayTokenResponse {
    /**
    * 系统交互结果
    */
    @SerializedName("extra")
    private ExtraData extra;
    /**
    * 业务交互结果
    */
    @SerializedName("res")
    private TradeInwardRes res;

    public ExtraData getExtra() {
        return extra;
    }
    public void setExtra(ExtraData extra) {
        this.extra = extra;
    }
    public TradeInwardRes getRes() {
        return res;
    }
    public void setRes(TradeInwardRes res) {
        this.res = res;
    }




    @Override
    public String toString() {
        return "TradeQueryPayTokenResponse{" + "extra=" + extra + "," + "res=" + res + "}";
    }
}
