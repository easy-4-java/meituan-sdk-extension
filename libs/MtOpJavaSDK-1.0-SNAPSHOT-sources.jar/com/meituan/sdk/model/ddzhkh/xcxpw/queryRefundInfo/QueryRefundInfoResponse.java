package com.meituan.sdk.model.ddzhkh.xcxpw.queryRefundInfo;

import com.google.gson.annotations.SerializedName;

/**
* 查询退款结果
* This file was automatically generated.
*/
public class QueryRefundInfoResponse {
    /**
    * 业务交互结果
    */
    @SerializedName("extra")
    private BaseResponseHeader extra;
    /**
    * 支付结果查询
    */
    @SerializedName("res")
    private ResObj res;

    public BaseResponseHeader getExtra() {
        return extra;
    }
    public void setExtra(BaseResponseHeader extra) {
        this.extra = extra;
    }
    public ResObj getRes() {
        return res;
    }
    public void setRes(ResObj res) {
        this.res = res;
    }




    @Override
    public String toString() {
        return "QueryRefundInfoResponse{" + "extra=" + extra + "," + "res=" + res + "}";
    }
}
