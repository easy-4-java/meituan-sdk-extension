package com.meituan.sdk.model.ddzh.yuding.orderMaxRefundAmountQuery;

import com.google.gson.annotations.SerializedName;

/**
* 订单最大可退金额查询
* This file was automatically generated.
*/
public class OrderMaxRefundAmountQueryResponse {
    /**
    * 最大可退金额, 以分为单位
    */
    @SerializedName("maxRefundAmount")
    private Long maxRefundAmount;

    public Long getMaxRefundAmount() {
        return maxRefundAmount;
    }
    public void setMaxRefundAmount(Long maxRefundAmount) {
        this.maxRefundAmount = maxRefundAmount;
    }




    @Override
    public String toString() {
        return "OrderMaxRefundAmountQueryResponse{" + "maxRefundAmount=" + maxRefundAmount + "}";
    }
}
