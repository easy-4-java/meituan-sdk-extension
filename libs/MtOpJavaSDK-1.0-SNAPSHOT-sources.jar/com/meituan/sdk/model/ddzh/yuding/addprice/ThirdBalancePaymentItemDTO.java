package com.meituan.sdk.model.ddzh.yuding.addprice;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-be537ad3-6787-4510-bbcf-fe661f37abba"><span style="color: ">尾款项目明细列表</span></p>
* This file was automatically generated.
*/
public class ThirdBalancePaymentItemDTO {
    /**
    * <p data-diff-id="ct-diff-id-21150660-81ca-4b7a-9e17-26ad5c97fefa"><span style="color: ">三方尾款明细项ID</span></p>
    */
    @NotNull(message = "id不能为空")
    @SerializedName("id")
    private Long id;
    /**
    * <p data-diff-id="ct-diff-id-aa75bd80-48d0-46ff-988b-21730cfd2cf4"><span style="color: ">尾款明细项金额，单位：分</span></p>
    */
    @NotNull(message = "unitPrice不能为空")
    @SerializedName("unitPrice")
    private Long unitPrice;
    /**
    * <p data-diff-id="ct-diff-id-b860f361-7b0c-4720-95e2-73f62ece48bc"><span style="color: ">是否上门费项，1：是，2：否，不校验上门费金额</span></p>
    */
    @NotNull(message = "type不能为空")
    @SerializedName("type")
    private Long type;
    /**
    * <p data-diff-id="ct-diff-id-e8731777-5703-4f07-a27b-be18e4370e2e"><span style="color: ">购买量</span></p>
    */
    @NotNull(message = "size不能为空")
    @SerializedName("size")
    private Long size;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getUnitPrice() {
        return unitPrice;
    }
    public void setUnitPrice(Long unitPrice) {
        this.unitPrice = unitPrice;
    }
    public Long getType() {
        return type;
    }
    public void setType(Long type) {
        this.type = type;
    }
    public Long getSize() {
        return size;
    }
    public void setSize(Long size) {
        this.size = size;
    }




    @Override
    public String toString() {
        return "ThirdBalancePaymentItemDTO{" + "id=" + id + "," + "unitPrice=" + unitPrice + "," + "type=" + type + "," + "size=" + size + "}";
    }
}
