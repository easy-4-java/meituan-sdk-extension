package com.meituan.sdk.model.ddzh.thirdresource.addDeviceModel;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* <p data-diff-id="ct-diff-id-ab4744b3-cfc5-48bc-b2a8-b9375ff294d8">相关规则列表</p>
* This file was automatically generated.
*/
public class DeviceModelRules {
    /**
    * <p data-diff-id="ct-diff-id-4dfd7ead-4fbf-4df3-833b-4544de69c81a"><span style="color: #333">使用年龄限制</span></p>
    */
    @SerializedName("ageRestriction")
    private Integer ageRestriction;
    /**
    * <p data-diff-id="ct-diff-id-d1b2a373-d02c-4bc3-a401-b7c5d68bb890"><span style="color: ">使用流程列表</span></p>
    */
    @SerializedName("operationSteps")
    private List<OperationStepInfo> operationSteps;

    public Integer getAgeRestriction() {
        return ageRestriction;
    }
    public void setAgeRestriction(Integer ageRestriction) {
        this.ageRestriction = ageRestriction;
    }
    public List<OperationStepInfo> getOperationSteps() {
        return operationSteps;
    }
    public void setOperationSteps(List<OperationStepInfo> operationSteps) {
        this.operationSteps = operationSteps;
    }




    @Override
    public String toString() {
        return "DeviceModelRules{" + "ageRestriction=" + ageRestriction + "," + "operationSteps=" + operationSteps + "}";
    }
}
