package com.meituan.sdk.model.mlive.comment.queryLiveRoomCommentV2;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 评论查询接口，集采场景
* This file was automatically generated.
*/
@ApiMeta(
    path = "/mlive/comment/query/v2",
    businessId = 50,
    apiVersion = "10012",
    apiName = "query_live_room_comment_v2",
    needAuth = false
)
public class QueryLiveRoomCommentV2Request implements MeituanRequest<List<LiveRoomCommentDTO>> {
    /**
    * <p data-diff-id="ct-diff-id-bc8bc920-4126-4190-beca-32788c4564ac">消息条数限制，最大200</p>
    */
    @SerializedName("limit")
    private Long limit;
    /**
    * <p data-diff-id="ct-diff-id-923ece43-8eb3-49d6-96dd-b7a73abdc4ef">请求开始时间，yyyy-MM-dd HH:mm:ss 格式</p>
    */
    @SerializedName("startTime")
    private String startTime;
    /**
    * <p data-diff-id="ct-diff-id-e7760f80-d42c-4869-b114-55c275e5dc5d">请求结束时间，yyyy-MM-dd HH:mm:ss 格式</p>
    */
    @SerializedName("endTime")
    private String endTime;
    /**
    * <p data-diff-id="ct-diff-id-36f5d92f-484e-4a52-93f3-81ee909d4c2e">直播场次id</p>
    */
    @SerializedName("liveId")
    private Long liveId;
    /**
    * <p data-diff-id="ct-diff-id-83c7b9c0-64e0-4dd4-81a9-54bd38456283">页码<span style="color: #333">，时间区间内的页数，从1开始，</span><span style="color: rgba(0, 0, 0, 0.87)">最大限制30页</span></p>
    */
    @SerializedName("pageNum")
    private Integer pageNum;
    /**
    * <p data-diff-id="ct-diff-id-ad57a199-8202-4c40-9204-50dd22b27482">主播id</p>
    */
    @SerializedName("anchorId")
    private Long anchorId;

    public Long getLimit() {
        return limit;
    }
    public void setLimit(Long limit) {
        this.limit = limit;
    }
    public String getStartTime() {
        return startTime;
    }
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    public String getEndTime() {
        return endTime;
    }
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    public Long getLiveId() {
        return liveId;
    }
    public void setLiveId(Long liveId) {
        this.liveId = liveId;
    }
    public Integer getPageNum() {
        return pageNum;
    }
    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }
    public Long getAnchorId() {
        return anchorId;
    }
    public void setAnchorId(Long anchorId) {
        this.anchorId = anchorId;
    }


    @Override
    public MeituanResponse<List<LiveRoomCommentDTO>> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<List<LiveRoomCommentDTO>>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "QueryLiveRoomCommentV2Request{" + "limit=" + limit + "," + "startTime=" + startTime + "," + "endTime=" + endTime + "," + "liveId=" + liveId + "," + "pageNum=" + pageNum + "," + "anchorId=" + anchorId + "}";
    }
}
