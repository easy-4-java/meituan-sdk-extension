package com.meituan.sdk.model.ddzh.thirdresource.chargeDeviceStatusSync;

import javax.validation.constraints.NotBlank;
import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* <p data-diff-id="ct-diff-id-9e276280-d90d-4d85-a161-fc4b2d90415e">充电站设备状态信息列表</p>
* This file was automatically generated.
*/
public class ConnectorStatusInfo {
    /**
    * <p data-diff-id="ct-diff-id-2a7c9da4-3fcb-43f1-90ab-a84337b84de7">充电设备接口ID</p>
    */
    @NotBlank(message = "connectorId不能为空")
    @SerializedName("connectorId")
    private String connectorId;
    /**
    * <p data-diff-id="ct-diff-id-6d5f3293-cf69-469f-b8e7-18c29f34e293">充电枪所属的桩设备ID</p>
    */
    @NotBlank(message = "equipmentId不能为空")
    @SerializedName("equipmentId")
    private String equipmentId;
    /**
    * <p data-diff-id="ct-diff-id-89b22cde-8030-4d7f-b259-577ac94d9099">设备接口状态，0-离网；1-空闲；2-占用（未充电）；6-占用（充电中）；7-占用（预约锁定）；255：故障</p>
    */
    @NotNull(message = "status不能为空")
    @SerializedName("status")
    private Integer status;
    /**
    * <p data-diff-id="ct-diff-id-ed934e7d-0665-4b0d-9ac7-4baec9c5016a">车位状态，0-未知；10-空闲；50-占用，若有车位状态识别，此字段建议返回真实值</p>
    */
    @SerializedName("parkStatus")
    private Integer parkStatus;
    /**
    * <p data-diff-id="ct-diff-id-9cf884cf-0e8a-4f4d-ba09-ef2d38082252">地锁状态，0-未知；10-已解锁；50-已上锁。若有地锁状态识别，此字段建议返回真实值</p>
    */
    @SerializedName("lockStatus")
    private Integer lockStatus;

    public String getConnectorId() {
        return connectorId;
    }
    public void setConnectorId(String connectorId) {
        this.connectorId = connectorId;
    }
    public String getEquipmentId() {
        return equipmentId;
    }
    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getParkStatus() {
        return parkStatus;
    }
    public void setParkStatus(Integer parkStatus) {
        this.parkStatus = parkStatus;
    }
    public Integer getLockStatus() {
        return lockStatus;
    }
    public void setLockStatus(Integer lockStatus) {
        this.lockStatus = lockStatus;
    }




    @Override
    public String toString() {
        return "ConnectorStatusInfo{" + "connectorId=" + connectorId + "," + "equipmentId=" + equipmentId + "," + "status=" + status + "," + "parkStatus=" + parkStatus + "," + "lockStatus=" + lockStatus + "}";
    }
}
