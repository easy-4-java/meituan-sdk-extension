package com.meituan.sdk.model.rhone.mtp.productLevelPriceNoticeV2;

import com.meituan.sdk.annotations.ApiMeta;
import java.util.List;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.meituan.sdk.internal.utils.JsonUtil;
import com.google.gson.annotations.SerializedName;
import com.meituan.sdk.MeituanResponse;
import com.meituan.sdk.MeituanRequest;

/**
* 多层价格日历变化通知V2
* This file was automatically generated.
*/
@ApiMeta(
    path = "/rhone/mtp/api/level/price/notice/v2",
    businessId = 66,
    apiVersion = "10023",
    apiName = "product_level_price_notice_v2",
    needAuth = false
)
public class ProductLevelPriceNoticeV2Request implements MeituanRequest<ProductLevelPriceNoticeV2Response> {
    /**
    * <p data-diff-id="ct-diff-id-21e97f32-1dc7-4529-bbea-2e9393dc9cc1"><span style="color: ">合作方产品ID</span></p>
    */
    @SerializedName("partnerDealId")
    private String partnerDealId;
    /**
    * <p data-diff-id="ct-diff-id-36418bf1-8524-4790-9a7b-e898fc051d5b"><span style="color: ">价格日历的开始时间，格式：yyyy-MM-dd</span></p>
    */
    @SerializedName("startTime")
    private String startTime;
    /**
    * <p data-diff-id="ct-diff-id-6dedae62-6563-4e1f-9a26-24f44a664c9b"><span style="color: ">合作方ID</span></p>
    */
    @SerializedName("partnerId")
    private Integer partnerId;
    /**
    * <p data-diff-id="ct-diff-id-fc2315f5-9dc4-4022-bb47-55e5f3c00208"><span style="color: ">价格日历的结束时间，格式：yyyy-MM-dd</span></p>
    */
    @SerializedName("endTime")
    private String endTime;
    /**
    * <p data-diff-id="ct-diff-id-73d42f58-c604-411a-a497-161e796e85eb"><span style="color: ">层级及价格库存信息数据</span></p>
    */
    @SerializedName("body")
    private List<BodySub> body;

    public String getPartnerDealId() {
        return partnerDealId;
    }
    public void setPartnerDealId(String partnerDealId) {
        this.partnerDealId = partnerDealId;
    }
    public String getStartTime() {
        return startTime;
    }
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    public Integer getPartnerId() {
        return partnerId;
    }
    public void setPartnerId(Integer partnerId) {
        this.partnerId = partnerId;
    }
    public String getEndTime() {
        return endTime;
    }
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    public List<BodySub> getBody() {
        return body;
    }
    public void setBody(List<BodySub> body) {
        this.body = body;
    }


    @Override
    public MeituanResponse<ProductLevelPriceNoticeV2Response> deserializeResponse(String response) {
        Type type = new TypeToken<MeituanResponse<ProductLevelPriceNoticeV2Response>>(){}.getType();
        return JsonUtil.fromJson(response, type);
    }
    @Override
    public String serializeToJson() {
        return JsonUtil.toJson(this);
    }


    @Override
    public String toString() {
        return "ProductLevelPriceNoticeV2Request{" + "partnerDealId=" + partnerDealId + "," + "startTime=" + startTime + "," + "partnerId=" + partnerId + "," + "endTime=" + endTime + "," + "body=" + body + "}";
    }
}
