package com.meituan.sdk.model.pms.tmc.bookingCheck;


/**
* 价格计划代码
* This file was automatically generated.
*/
public class Data {





}
