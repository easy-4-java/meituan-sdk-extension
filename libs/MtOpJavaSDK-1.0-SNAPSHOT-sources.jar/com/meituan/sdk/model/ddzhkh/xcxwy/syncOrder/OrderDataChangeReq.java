package com.meituan.sdk.model.ddzhkh.xcxwy.syncOrder;

import com.google.gson.annotations.SerializedName;
import javax.validation.constraints.NotNull;

/**
* 
* This file was automatically generated.
*/
public class OrderDataChangeReq {
    /**
    * <p data-diff-id="ct-diff-id-3b8827a8-402e-4f4c-8862-be11a07fcc5d">美团订单号，与三方订单号二选一必传</p>
    */
    @SerializedName("orderId")
    private Long orderId;
    /**
    * <p data-diff-id="ct-diff-id-8484d149-3bfd-4f5d-8370-94e7e3cfcb14">三方订单号，与美团订单号二选一必传</p>
    */
    @SerializedName("vendorOrderId")
    private String vendorOrderId;
    /**
    * <p data-diff-id="ct-diff-id-7c3fbf0f-e621-4c0b-baa8-e1a48690e210"><span style="color: rgba(0, 0, 0, 0.65)">版本号，保障接口幂等，低于或等于上一个版本不处理</span></p>
    */
    @NotNull(message = "version不能为空")
    @SerializedName("version")
    private Long version;
    /**
    * <p data-diff-id="ct-diff-id-5290da7c-da4e-4fff-9707-87068e626e8a">商户订单原状态。hasStatusChange为true时必传，为false时不可传递。</p><p data-diff-id="ct-diff-id-145d9258-414e-495a-81e6-60657535f933">行业枚举:</p>
    */
    @SerializedName("fromStatus")
    private String fromStatus;
    /**
    * <p data-diff-id="ct-diff-id-43c7fee7-b22d-4125-997e-ba5a4aef9180">商户订单新状态。hasStatusChange为true时必传，为false时不可传递。</p><p data-diff-id="ct-diff-id-8f127e88-5a55-4e8f-b5c6-8155f776836b">行业枚举:</p>
    */
    @SerializedName("toStatus")
    private String toStatus;
    /**
    * <p data-diff-id="ct-diff-id-2525993f-d789-4bb2-b21d-158afbaf0a62">是否存在状态变更</p>
    */
    @NotNull(message = "hasStatusChange不能为空")
    @SerializedName("hasStatusChange")
    private Boolean hasStatusChange;
    @SerializedName("extReq")
    private PrintingExtReq extReq;

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
    public String getVendorOrderId() {
        return vendorOrderId;
    }
    public void setVendorOrderId(String vendorOrderId) {
        this.vendorOrderId = vendorOrderId;
    }
    public Long getVersion() {
        return version;
    }
    public void setVersion(Long version) {
        this.version = version;
    }
    public String getFromStatus() {
        return fromStatus;
    }
    public void setFromStatus(String fromStatus) {
        this.fromStatus = fromStatus;
    }
    public String getToStatus() {
        return toStatus;
    }
    public void setToStatus(String toStatus) {
        this.toStatus = toStatus;
    }
    public Boolean getHasStatusChange() {
        return hasStatusChange;
    }
    public void setHasStatusChange(Boolean hasStatusChange) {
        this.hasStatusChange = hasStatusChange;
    }
    public PrintingExtReq getExtReq() {
        return extReq;
    }
    public void setExtReq(PrintingExtReq extReq) {
        this.extReq = extReq;
    }




    @Override
    public String toString() {
        return "OrderDataChangeReq{" + "orderId=" + orderId + "," + "vendorOrderId=" + vendorOrderId + "," + "version=" + version + "," + "fromStatus=" + fromStatus + "," + "toStatus=" + toStatus + "," + "hasStatusChange=" + hasStatusChange + "," + "extReq=" + extReq + "}";
    }
}
