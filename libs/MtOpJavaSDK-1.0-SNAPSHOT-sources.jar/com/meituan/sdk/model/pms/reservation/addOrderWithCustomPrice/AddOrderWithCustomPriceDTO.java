package com.meituan.sdk.model.pms.reservation.addOrderWithCustomPrice;

import com.google.gson.annotations.SerializedName;

/**
* 订单信息
* This file was automatically generated.
*/
public class AddOrderWithCustomPriceDTO {
    /**
    * 酒店ID
    */
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * 订单ID
    */
    @SerializedName("orderId")
    private String orderId;
    /**
    * 账套ID
    */
    @SerializedName("billId")
    private Long billId;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public Long getBillId() {
        return billId;
    }
    public void setBillId(Long billId) {
        this.billId = billId;
    }




    @Override
    public String toString() {
        return "AddOrderWithCustomPriceDTO{" + "hotelId=" + hotelId + "," + "orderId=" + orderId + "," + "billId=" + billId + "}";
    }
}
