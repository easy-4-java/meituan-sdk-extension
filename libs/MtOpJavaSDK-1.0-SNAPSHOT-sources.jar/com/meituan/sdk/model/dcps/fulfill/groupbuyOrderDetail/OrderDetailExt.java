package com.meituan.sdk.model.dcps.fulfill.groupbuyOrderDetail;

import com.google.gson.annotations.SerializedName;

/**
* 扩展信息
* This file was automatically generated.
*/
public class OrderDetailExt {
    /**
    * 骑手取餐号
    */
    @SerializedName("serialNumber")
    private String serialNumber;
    /**
    * 餐具备注
    */
    @SerializedName("wareCount")
    private String wareCount;
    /**
    * 打包费
    */
    @SerializedName("packFee")
    private Long packFee;
    /**
    * 骑手隐私号
    */
    @SerializedName("riderPhoneForBusiness")
    private String riderPhoneForBusiness;
    /**
    * 骑手姓名
    */
    @SerializedName("riderName")
    private String riderName;

    public String getSerialNumber() {
        return serialNumber;
    }
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }
    public String getWareCount() {
        return wareCount;
    }
    public void setWareCount(String wareCount) {
        this.wareCount = wareCount;
    }
    public Long getPackFee() {
        return packFee;
    }
    public void setPackFee(Long packFee) {
        this.packFee = packFee;
    }
    public String getRiderPhoneForBusiness() {
        return riderPhoneForBusiness;
    }
    public void setRiderPhoneForBusiness(String riderPhoneForBusiness) {
        this.riderPhoneForBusiness = riderPhoneForBusiness;
    }
    public String getRiderName() {
        return riderName;
    }
    public void setRiderName(String riderName) {
        this.riderName = riderName;
    }




    @Override
    public String toString() {
        return "OrderDetailExt{" + "serialNumber=" + serialNumber + "," + "wareCount=" + wareCount + "," + "packFee=" + packFee + "," + "riderPhoneForBusiness=" + riderPhoneForBusiness + "," + "riderName=" + riderName + "}";
    }
}
