package com.meituan.sdk.model.pms.tmc.getHotelInfo;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 酒店信息查询
* This file was automatically generated.
*/
public class GetHotelInfoResponse {
    /**
    * 酒店ID
    */
    @SerializedName("hotelId")
    private Long hotelId;
    /**
    * 酒店名称
    */
    @SerializedName("hotelName")
    private String hotelName;
    /**
    * 酒店品牌
    */
    @SerializedName("brand")
    private String brand;
    /**
    * 酒店地址
    */
    @SerializedName("address")
    private String address;
    /**
    * 酒店电话
    */
    @SerializedName("phone")
    private String phone;
    /**
    * 酒店介绍
    */
    @SerializedName("description")
    private String description;
    /**
    * 城市ID
    */
    @SerializedName("cityId")
    private String cityId;
    /**
    * 行政区域ID
    */
    @SerializedName("districtId")
    private String districtId;
    /**
    * 经度
    */
    @SerializedName("longitude")
    private String longitude;
    /**
    * 纬度
    */
    @SerializedName("latitude")
    private String latitude;
    /**
    * 开业日期
    */
    @SerializedName("openingDate")
    private String openingDate;
    /**
    * 装修日期
    */
    @SerializedName("decorationDate")
    private String decorationDate;
    /**
    * 酒店图片
    */
    @SerializedName("imageUrls")
    private List<String> imageUrls;
    /**
    * 服务设施
    */
    @SerializedName("serviceFacilities")
    private List<EnumDTO> serviceFacilities;

    public Long getHotelId() {
        return hotelId;
    }
    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }
    public String getHotelName() {
        return hotelName;
    }
    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }
    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getCityId() {
        return cityId;
    }
    public void setCityId(String cityId) {
        this.cityId = cityId;
    }
    public String getDistrictId() {
        return districtId;
    }
    public void setDistrictId(String districtId) {
        this.districtId = districtId;
    }
    public String getLongitude() {
        return longitude;
    }
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
    public String getLatitude() {
        return latitude;
    }
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
    public String getOpeningDate() {
        return openingDate;
    }
    public void setOpeningDate(String openingDate) {
        this.openingDate = openingDate;
    }
    public String getDecorationDate() {
        return decorationDate;
    }
    public void setDecorationDate(String decorationDate) {
        this.decorationDate = decorationDate;
    }
    public List<String> getImageUrls() {
        return imageUrls;
    }
    public void setImageUrls(List<String> imageUrls) {
        this.imageUrls = imageUrls;
    }
    public List<EnumDTO> getServiceFacilities() {
        return serviceFacilities;
    }
    public void setServiceFacilities(List<EnumDTO> serviceFacilities) {
        this.serviceFacilities = serviceFacilities;
    }




    @Override
    public String toString() {
        return "GetHotelInfoResponse{" + "hotelId=" + hotelId + "," + "hotelName=" + hotelName + "," + "brand=" + brand + "," + "address=" + address + "," + "phone=" + phone + "," + "description=" + description + "," + "cityId=" + cityId + "," + "districtId=" + districtId + "," + "longitude=" + longitude + "," + "latitude=" + latitude + "," + "openingDate=" + openingDate + "," + "decorationDate=" + decorationDate + "," + "imageUrls=" + imageUrls + "," + "serviceFacilities=" + serviceFacilities + "}";
    }
}
