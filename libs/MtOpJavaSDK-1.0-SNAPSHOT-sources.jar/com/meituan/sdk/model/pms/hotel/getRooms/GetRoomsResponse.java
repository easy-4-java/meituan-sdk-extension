package com.meituan.sdk.model.pms.hotel.getRooms;

import java.util.List;
import com.google.gson.annotations.SerializedName;

/**
* 查询酒店房间信息
* This file was automatically generated.
*/
public class GetRoomsResponse {
    /**
    * 错误信息
    */
    @SerializedName("msg")
    private String msg;
    /**
    * 业务状态码
    */
    @SerializedName("code")
    private Long code;
    /**
    * 房间列表
    */
    @SerializedName("data")
    private List<RoomDTO> data;

    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Long getCode() {
        return code;
    }
    public void setCode(Long code) {
        this.code = code;
    }
    public List<RoomDTO> getData() {
        return data;
    }
    public void setData(List<RoomDTO> data) {
        this.data = data;
    }




    @Override
    public String toString() {
        return "GetRoomsResponse{" + "msg=" + msg + "," + "code=" + code + "," + "data=" + data + "}";
    }
}
